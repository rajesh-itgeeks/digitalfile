import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import en from "./locales/en.json";
import de from "./locales/de.json";
import es from "./locales/es.json";
import it from "./locales/it.json";
import fr from "./locales/fr.json";
import nl from "./locales/nl.json";
import sv from "./locales/sv.json";

const resources = {
  en: { translation: en },
  de: { translation: de },
  es: { translation: es },
  fr: { translation: fr },
  it: { translation: it },
  nl: { translation: nl },
  sv: { translation: sv },
};

i18n
  .use(initReactI18next)
  .init({
    resources,
    lng: 'en', // default language
    fallbackLng: 'fr',
    // debug: true,
    supportedLngs: ['en', 'de', 'es', 'fr', 'it', 'nl', 'sv'],
    // keySeparator: false,
    interpolation: {
      escapeValue: false
    }
  });

export default i18n;
