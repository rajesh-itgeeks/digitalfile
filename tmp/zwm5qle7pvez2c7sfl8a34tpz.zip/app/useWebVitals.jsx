import { useEffect } from 'react';
import { onLCP, onINP } from 'web-vitals';

export function useWebVitals() {
  useEffect(() => {
    if (typeof window === 'undefined') return;

    onLCP((lcp) => {
      console.log('Web Vitals - LCP (s):', lcp.value / 1000);
      console.log('LCP details:', lcp.entries);
    }, { reportAllChanges: true });

    onINP((inp) => {
      console.log('Web Vitals - INP (s):', inp.value / 1000);
      console.log('INP details:', inp.entries);
    }, { reportAllChanges: true });

  }, []);
}
