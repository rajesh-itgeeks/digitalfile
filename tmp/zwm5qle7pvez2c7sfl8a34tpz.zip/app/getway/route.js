import { authenticateUser } from "../api/server/middlewares/auth.middleware.server.js";
import { sendResponse } from "../api/server/utils/sendResponse.js";
import { statusCode } from "../api/server/constants/statusCodes.js";

// Define microservices endpoints
const services = {
    analytics: "http://localhost:3000",
};

// Loader function to handle GET requests
export const loader = async ({ request }) => {
    return handleProxy(request);
};

// Action function to handle POST, PUT, DELETE requests
export const action = async ({ request }) => {
    console.log('-----------------------------action running');
    const data = {
        test: "this is test data"
    }
    // addJobToQueue(data);
};

// Function to handle API proxying
const handleProxy = async (request) => {
    const isAuthenticated = await authenticateUser(request);

    if (!isAuthenticated.status) {
        return sendResponse(statusCode.BAD_REQUEST, false, isAuthenticated.message);
    }

    const accessToken = request.session?.accessToken;

    request.headers.set("sat_data", accessToken);
    request.headers.set("shop", request.session?.shop);

    const url = new URL(request.url);
    const path = url.pathname.replace("/api/getway/", ""); // Extract service path
    const [serviceName, ...servicePath] = path.split("/");

    if (!services[serviceName]) {
        return sendResponse(statusCode.NOT_FOUND, false, 'Service not found');
    }

    // Forward request to the target microservice
    const targetUrl = `${services[serviceName]}/${servicePath.join("/")}${url.search}`;
    console.log(':::---target url :', targetUrl);

    const response = await fetch(targetUrl, {
        method: request.method,
        headers: request.headers,
        body: ["GET", "POST", "HEAD"].includes(request.method) ? null : await request.text(),

    });

    // Return response from the microservice
    return new Response(response.body, {
        status: response.status,
        headers: response.headers,
    });
};
