// Function to generate an email for contacting support
export const contactSupportEmail = (details, merchantEmail) => {
  const data = {
    from: process.env.SMTP_USER_EMAIL,
    to: merchantEmail,
    subject: `You have a form submission for ${details.orderNumber}`,
    replyTo: details.customerEmail,
    html: `
<div style="margin: 0; padding: 0; font-family: Arial, sans-serif; color: #333;">
      <table width="800" align="center" cellpadding="0" cellspacing="0" border="0" style="border-collapse: collapse;">
      
        <!-- Support Email Content -->
        <tr>
          <td style="padding: 40px; box-sizing: border-box;color:black;">
            <p style="font-weight: 700; margin: 0; padding:5px;">Support Request Details</p>
            <p style="margin: 0; padding:5px;"><strong>Order Number:</strong> <a href="#">${details.orderNumber}</a></p>
            <p style="margin: 0; padding:5px;"><strong>Phone:</strong> ${details.phone}</p>
            <p style="margin: 0; padding:5px;"><strong>Message:</strong> ${details.message}</p>
            <p style="margin: 0; padding:5px;">Our support team will review your request and reach out shortly. Thank you for your patience.</p>
            <p style="margin: 0; padding:5px;">Best regards,<br><strong>Account Editor Support Team</strong></p>
          </td>
        </tr>
      
        <!-- Footer -->
      </table>
    </div>
    `
  };

  return data;
};

// Function to generate an email for a custom plan support request
export const customPlanSupportEmail = (details) => {
  const data = {
    from: process.env.SMTP_USER_EMAIL,
    to: process.env.SUPPORT_EMAIL, 
    subject: `New Custom Plan Request from ${details.firstName} ${details.lastName}`,
    replyTo: details.email,
    html: `
<div style="margin: 0; padding: 0; font-family: Arial, sans-serif; color: #333;">
  <table width="800" align="center" cellpadding="0" cellspacing="0" border="0" style="border-collapse: collapse;">
    
    <!-- Custom Plan Request Email Content -->
    <tr>
      <td style="padding: 40px; box-sizing: border-box; color:black;">
        <p style="font-weight: 700; margin: 0; padding:5px;">Custom Plan Request Details</p>
        <p style="margin: 0; padding:5px;"><strong>First Name:</strong> ${details.firstName}</p>
        <p style="margin: 0; padding:5px;"><strong>Last Name:</strong> ${details.lastName}</p>
        <p style="margin: 0; padding:5px;"><strong>Phone:</strong> ${details.phone}</p>
        <p style="margin: 0; padding:5px;"><strong>Email:</strong> ${details.email}</p>
        <p style="margin: 0; padding:5px;"><strong>Store URL:</strong> <a href="${details.storeUrl}" target="_blank">${details.storeUrl}</a></p>
        <p style="margin: 0; padding:5px;"><strong>Message:</strong> ${details.message}</p>
        <p style="margin: 20px 0 0 5px;">Please review the request and reach out to the merchant to discuss their custom plan needs.</p>
        <p style="margin: 0; padding:5px;">Best regards,<br><strong>Account Editor Support Team</strong></p>
      </td>
    </tr>
    
    <!-- Footer -->
  </table>
</div>
    `
  };

  return data;
};
