import React, { lazy, Suspense, useMemo } from "react";
import { Page, Layout, BlockStack, Box, Divider, Text } from "@shopify/polaris";
import { useTranslation } from "react-i18next";
import "./assets/index.css";
import { useDispatch, useSelector } from "react-redux";
import { setPageId } from "./components/store/PageSlice";
import Statistic from "./components/index/Statistic";
import Support from "./components/index/HepSupports";
import Footer from "./components/common/Footer";
import APIServicess from "./services/ApiServices";

export default function Index() {
  const { t } = useTranslation();
  const dispatch = useDispatch();

  const storeValue = useSelector((state) => state.store);
  const planStatus = useSelector((state) => state.planStatus);
  const pageId = useSelector((state) => state.pageId);

  const shopName = useMemo(() => {
    return storeValue?.domain?.replace(".myshopify.com", "") || "";
  }, [storeValue?.domain]);

  const APIServ = useMemo(() => new APIServicess(), []);

  const redirectEditor = async (type) => {
    try {
      let checkoutId = pageId;

      if (!checkoutId) {
        const pagesdata = await APIServ.getShopPagePreviewing();
        const idString = pagesdata?.data?.[0]?.id;
        checkoutId = idString?.match(/\d+$/)?.[0];

        if (checkoutId) dispatch(setPageId(checkoutId));
      }

      if (!checkoutId || !shopName) return;

      const pageType = type === "orderStatus" ? "order-status" : "thank-you";
      const url = `https://admin.shopify.com/store/${shopName}/settings/checkout/editor/profiles/${checkoutId}?page=${pageType}&context=apps`;

      window.open(url, "_blank");
    } catch (error) {
      console.error("Redirect error:", error);
    }
  };

  return (
    <Page
      title={t("Index.pageTitle")}
      fullWidth
      actionGroups={[
        {
          title: t("Settings.page.actionGroup.title"),
          actions: [
            {
              content: t("Settings.page.actionGroup.orderStatus"),
              accessibilityLabel: t("Settings.page.actionGroup.orderStatusLabel"),
              onAction: () => redirectEditor("orderStatus"),
            },
            {
              content: t("Settings.page.actionGroup.thankYou"),
              accessibilityLabel: t("Settings.page.actionGroup.thankYouLabel"),
              onAction: () => redirectEditor("thankyou"),
            },
          ],
        },
      ]}
    >
      <Divider borderWidth="050" />
      <Layout>
        <Layout.Section>
          <Box as="div" className="main-container">
            <BlockStack gap="400">
              <Statistic storeValue={storeValue} planStatus={planStatus} />
              <Support />
                <Footer />
            </BlockStack>
          </Box>
        </Layout.Section>
      </Layout>
    </Page>
  );
}