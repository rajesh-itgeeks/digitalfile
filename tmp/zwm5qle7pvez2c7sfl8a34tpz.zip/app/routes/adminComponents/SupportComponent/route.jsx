import React, { useState, useEffect } from "react";
import Pagination from "../utils/Pagination/route";
import Loader from "../utils/Loaderr/CommonLoader/Loader";
import Slist from "./SupportList/Slist.jsx";
import "../StoreComponent/store.css";
const route = () => {
  const [currentPage, setCurrentPage] = useState(1);
  const [partners, setPartners] = useState([]);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const itemsPerPage = 7;

  const fetchPartners = async () => {
    setLoading(true);
    setError(null);

    try {
      const response = await fetch(`/api/admin/support`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          page: currentPage,
          limit: itemsPerPage,
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to fetch data");
      }
      const data = await response?.json();
      // console.log("data",data)
      setPartners(data.result.data || []);
      setTotalPages(data.result.totalPages || 1);
    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    fetchPartners();
  }, [currentPage]);

  return (
    <div className="main-partner-container">
      <div className="top-heading">
        <h2>Supports</h2>
        <p>List of supports</p>
      </div>
      <div className="table-wrapper">
        {loading ? (
          <Loader />
        ) : error ? (
          <p style={{ color: "red" }}>{error}</p>
        ) : partners.length === 0 ? (
          <p>No stores found.</p>
        ) : (
          <>
            <table className="partner-table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Phone </th>
                  <th>Started</th>

                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <Slist stores={partners} fetchStores={fetchPartners} />
              </tbody>
            </table>

            <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              onPageChange={setCurrentPage}
            />
          </>
        )}
      </div>
    </div>
  );
};

export default route;
