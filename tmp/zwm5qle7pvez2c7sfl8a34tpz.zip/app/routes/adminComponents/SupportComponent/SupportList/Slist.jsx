import React, { useState,useCallback } from "react";
import { useNavigate} from "@remix-run/react";
import "./Slist.css";
import OverlayLoader from "../../utils/Loaderr/overlayLoader/route";
import { v4 as uuidv4 } from "uuid";
import { MdDelete } from "react-icons/md";
import Toaster from "../../utils/toster/toster";
import { TbMessageCircleUp } from "react-icons/tb";

const Slist = ({ stores,fetchStores }) => {
  const navigate = useNavigate();
  
  const [showDeletePopup, setShowDeletePopup] = useState(false);
  const [showReplyPopup, setShowReplyPopup] = useState(false);
  const [selectedStoreId, setSelectedStoreId] = useState(null);
  const [selectedStore, setSelectedStore] = useState(null);
  const [replyMessage, setReplyMessage] = useState("");
  const[toast,setToast]=useState(null)

  const handleDeleteClick = (id) => {
    setSelectedStoreId(id);
    setShowDeletePopup(true);
  };

    const showError = useCallback((error) => {
      setToast({ message: error, type: "error" });
    }, []);
    const showSuccess = useCallback((success) => {
      setToast({ message: success, type: "success" });
    }, []);
  const confirmDelete = async () => {
    if (!selectedStoreId) return;
    try {
      const response = await fetch(`/api/admin/support`, {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ id: selectedStoreId }), 
      });

      if (response.status) {
        showSuccess("Delete Successfully");
        fetchStores();

      } else {
        showError("Failed to delete message.");
      }
    } catch (error) {
      showError(error);
    }

    setShowDeletePopup(false);
  };

  const handleReplyClick = (store) => {
    setSelectedStore(store);
    setShowReplyPopup(true);
  };

  const sendReply = async () => {
    if (!selectedStore) return;

    try {
      const response = await fetch(`/api/admin/support`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          id: selectedStore._id, 
          message: replyMessage,
        }),
      });

      if (response.status) {
        showSuccess("Send Successfully");
      } else {
        showError("Failed to send message.");
      }
    } catch (error) {
      showError("Server Error.");
    }

    setShowReplyPopup(false);
    setReplyMessage(""); 
  };

  return (
    <>
      {stores.length > 0 ? (
        stores.map((store) => (
          <tr key={uuidv4()}>
            <td>{store?.firstName}{store?.lastName}</td>
            <td>{store.email}</td>
            <td>{store.phone}</td>
            <td>{store.createdAt}</td>
            <td className="support-buttons">
              <button className="delete-btn" onClick={() => handleDeleteClick(store._id)}>
                <MdDelete />
              </button>
              <button className="reply-btn" onClick={() => handleReplyClick(store)}>
                <TbMessageCircleUp />
              </button>
            </td>
          </tr>
        ))
      ) : (
        <tr>
          <td colSpan="6">No stores found.</td>
        </tr>
      )}
 {toast && <Toaster message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
      {/* Delete Confirmation Popup */}
      {showDeletePopup && (
        <div className="popup-overlay">
          <div className="popup-box">
            <p>Are you sure you want to delete this store?</p>
            <div className="popup-buttons">
              <button className="confirm-btn" onClick={confirmDelete}>Yes</button>
              <button className="cancel-btn" onClick={() => setShowDeletePopup(false)}>No</button>
            </div>
          </div>
        </div>
      )}

      {/* Reply Popup */}
      {showReplyPopup && (
        <div className="popup-overlay">
          <div className="popup-box">
            <p>Send a reply to {selectedStore?.shopJson?.name}</p>
            <textarea
              className="reply-input"
              placeholder="Type your message..."
              value={replyMessage}
              onChange={(e) => setReplyMessage(e.target.value)}
            />
            <div className="popup-buttons">
              <button className="send-btn" onClick={sendReply}>Send</button>
              <button className="cancel-btn" onClick={() => setShowReplyPopup(false)}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default Slist;