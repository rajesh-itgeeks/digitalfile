import React, { useState, useEffect, useRef } from "react";
import { FiX } from "react-icons/fi";
import OrderList from "./orderList/orderlist";
import { useParams } from "@remix-run/react";
import { IoFilterSharp } from "react-icons/io5";
import "./style.css";
import Pagination from "../utils/Pagination/route";

const OrderEditss = () => {
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 6;
  const [orders, setOrders] = useState([]);
  const [totalPages, setTotalPages] = useState(1);
  const [totalOrders, setTotalOrders] = useState();
  const { id } = useParams();
  const [orderaction,setorderaction] = useState()
  const [filterOpen, setFilterOpen] = useState(false);
  const [selectedActions, setSelectedActions] = useState([]);

  const filterRef = useRef(null);

  const actionOptions = [
    "add_item",
    "store_credit",
    "up_sell_revenue",
    "remove_item",
    "order_refund",
    "update_status",
    "cancel_order",
    "swap_item",
    "update_item",
    "update_contact_info",
    "update_shipping_address",
  ];

  const toggleFilter = () => setFilterOpen(!filterOpen);

  const handleFilterChange = async (actions, page = 1) => {
    try {
      const response = await fetch(`/api/admin/order/${id}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          orderAction: actions,
          page,
          limit: itemsPerPage,
        }),
      });

      const data = await response.json();

      setOrders(data.result.data);
      setTotalPages(data.result.totalPages);
      setTotalOrders(data.result.totalOrder);
      setorderaction(data.result.totalRecords);

    } catch (error) {
      console.error("Error filtering data:", error);
    }
  };

  const handleActionChange = async (action) => {
    let updatedActions = selectedActions.includes(action)
      ? selectedActions.filter((a) => a !== action)
      : [...selectedActions, action];

    setSelectedActions(updatedActions);
    await handleFilterChange(updatedActions, 1);
  };

  const clearFilters = async () => {
    setFilterOpen(false);
    setSelectedActions([]);
    await handleFilterChange([], 1);
  };

  const removeSelectedFilter = async (type, value) => {
    if (type === "action") {
      const updatedActions = selectedActions.filter((a) => a !== value);
      setSelectedActions(updatedActions);
      await handleFilterChange(updatedActions, 1);
    }
  };

  useEffect(() => {
    handleFilterChange([], 1);
  }, []);

  const paginate = (pageNumber) => {
    setCurrentPage(pageNumber);
    handleFilterChange(selectedActions, pageNumber);
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (filterRef.current && !filterRef.current.contains(event.target)) {
        setFilterOpen(false);
      }
    };

    if (filterOpen) {
      document.addEventListener("mousedown", handleClickOutside);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [filterOpen]);

  return (
    <div className="main-order-container">
      <div className="filterr">
        <button className="apply-filter-btn" onClick={toggleFilter}>
          <IoFilterSharp />
        </button>

        {filterOpen && (
          <div className="filter-box" ref={filterRef}>
            <button className="close-icon-btn" onClick={toggleFilter}>
              <FiX />
            </button>
            <div className="filter-options">
              <div className="filter-item">Filter by Action</div>
              <div className="action-list">
                {actionOptions.map((action) => (
                  <label key={action} className="checkbox-label">
                    <input
                      type="checkbox"
                      value={action}
                      checked={selectedActions.includes(action)}
                      onChange={() => handleActionChange(action)}
                    />
                    {action}
                  </label>
                ))}
              </div>
            </div>
          </div>
        )}

        {selectedActions.length > 0 && (
          <div className="selected-filters">
            <div className="selct-itemss">
              {selectedActions.map((action) => (
                <p key={action}>
                  {action}{" "}
                  <FiX onClick={() => removeSelectedFilter("action", action)} />
                </p>
              ))}
              <button className="clear-filter-btn" onClick={clearFilters}>
                Clear All
              </button>
            </div>
          </div>
        )}
      </div>

      <div className="table-wrapper">
        <table className="partner-table">
          <thead>
            <tr>
              <th>OrderId</th>
              <th>OrderAction</th>
              <th>CustomerId</th>
              <th>CreatedAt</th>
            </tr>
          </thead>
          <tbody>
            <OrderList orders={orders} />
          </tbody>
        </table>
        <div className="total-count-container">
        <h4 className="total-order">Total Order Actions:{orderaction}</h4>
        <h4 className="total-order">TotalsOrders:{totalOrders}</h4>
        </div>
        <Pagination
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={paginate}
        />
      </div>
    </div>
  );
};

export default OrderEditss;
