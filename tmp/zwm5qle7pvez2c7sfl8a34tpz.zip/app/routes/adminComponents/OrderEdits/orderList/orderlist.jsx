import React from "react";

const orderlist = ({ orders }) => {
  return (
    <>
      {orders?.length > 0 ? (
        orders.map((order, index) => (
          <tr key={index}>
            <td>{order?.orderId}</td>
            <td>{order?.orderAction}</td>
            <td>{order?.customerId?.split("/").pop()}</td>

            <td>{order?.createdAt}</td>
            <td></td>
          </tr>
        ))
      ) : (
        <tr>
          <td colSpan="6">No orders found.</td>
        </tr>
      )}
    </>
  );
};

export default orderlist;
