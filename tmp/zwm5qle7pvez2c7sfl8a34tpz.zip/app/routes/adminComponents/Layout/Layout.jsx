import React from 'react';
import './Layout.css';
import Sidebar from '../Sidebar/route'

const Layout = ({ children }) => {
  return (
    <div className="main-dashboard-container">
      <div className="sidebar-container">
        <Sidebar/>
      </div>
      <div className="outlet-container">
        {children}
      </div>
    </div>
  );
};

export default Layout;