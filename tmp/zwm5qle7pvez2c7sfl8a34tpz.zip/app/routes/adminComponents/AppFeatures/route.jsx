import React, { useState, useEffect } from "react";
import "./appfeature.css";
import { useParams } from "@remix-run/react";
import Loader from "../utils/Loaderr/CommonLoader/Loader";
const Route = () => {
  const [selectedFeatures, setSelectedFeatures] = useState([]);
  const [loading, setloading] = useState(true);
  const [allFeatures, setAllFeatures] = useState([
    "upSell",
    "orderCancellationReason",
    "restocking",
  ]);
  const { id } = useParams();

  const handleSubmit = async () => {
    setloading(true);
    try {
      const response = await fetch(`/api/admin/store/partners`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ id, hiddenFeatures: selectedFeatures }),
      });

      const data = await response.json();
      if (!data.result.hiddenFeatures) {
        setSelectedFeatures([]);
        setloading(false);
      }
      if (data.result.hiddenFeatures) {
        setSelectedFeatures(data.result.hiddenFeatures);
        setloading(false);
      }
    } catch (error) {
      console.error("Error sending data:", error);
    }
  };

  useEffect(() => {
    handleSubmit();
  }, []);

  const handleCheckboxChange = (event) => {
    const { value, checked } = event.target;
    setSelectedFeatures((prev) =>
      checked ? [...prev, value] : prev.filter((item) => item !== value),
    );
  };

  return (
    <div className="main-feature-container">
      <div className="top-headingp">
        <h2>App Features</h2>
        {allFeatures.length === 0 ? (
          <p style={{ color: "red" }}>Not Found</p>
        ) : (
          <p>Select app features you want to hide</p>
        )}
      </div>
      {loading ? (
        <Loader />
      ) : (
        allFeatures.length > 0 && (
          <>
            <div className="feature-input-container">
              {allFeatures.map((feature, index) => (
                <label key={index}>
                  <input
                    type="checkbox"
                    value={feature}
                    checked={selectedFeatures.includes(feature)}
                    onChange={handleCheckboxChange}
                  />
                  {feature}
                </label>
              ))}
            </div>
            <button onClick={handleSubmit}>Submit</button>
          </>
        )
      )}
    </div>
  );
};

export default Route;
