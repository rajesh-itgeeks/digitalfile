import React, { useState, useEffect } from "react";
import LangList from '../LangList/LangList';
import '../Message/MessageLayout/style.css'
// import Pagination from "../adminComponents/utils/Pagination/route";
import Pagintion from "../../utils/Pagination/route"
import Loader from "../../utils/Loaderr/CommonLoader/Loader";
import "../../StoreComponent/store.css";
import './style.css'

const Route = () => {
   const [showReplyPopup, setShowReplyPopup] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [languages, setLanguages] = useState([]);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const itemsPerPage = 7;

  const fetchLanguages = async () => {
    setLoading(true);
    setError(null);

    try {
      const res = await fetch(`/api/admin/language/details?page=${currentPage}&limit=${itemsPerPage}`);
      if (!res.ok) throw new Error("Failed to fetch language data");
    
      const data = await res.json();
      console.log("--data",data)
      setLanguages(data?.result?.data || []);
      setTotalPages(data?.result?.pages || 1);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };
const HandleAddLanguage=async()=>{
  setShowReplyPopup(true);
}
  useEffect(() => {
    fetchLanguages();
  }, [currentPage]);

  return (
    <div className="main-partner-container lang-container">

      <div className="top-heading m-head">
        <div className="headd">
        <h2>Languages</h2>
        <p>List of languages</p>
        </div>
        <button className='add-msg' onClick={HandleAddLanguage}>Add Language</button>
      </div>
      <div className="table-wrapper">
        {
          loading ?(
            <Loader/>

          ):(
            <table className="partner-table">
            <thead>
              <tr>
                <th>Language</th>
               
              </tr>
            </thead>
            <tbody>
              <LangList languages={languages} />
            </tbody>
          </table>
          )
        }
      

        {/* Uncomment when pagination is ready */}
        <Pagintion
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={setCurrentPage}
        />
      </div>
      {showReplyPopup && (
  <div className="popup-overlay">
    <div className="popup-box">
      <p>Send a reply as JSON</p>
      <div className="msg-box">
        <textarea
          className="msg-input"
          placeholder="Enter JSON..."
          // value={replyMessage}
          // onChange={(e) => setReplyMessage(e.target.value)}
        />
      </div>
      
      <div className="popup-buttons">
        <button className="send-btn" >Save</button>
        <button className="cancel-btn" onClick={() => setShowReplyPopup(false)}>Cancel</button>
      </div>
    </div>
  </div>
)}
    </div>
  );
};

export default Route;
