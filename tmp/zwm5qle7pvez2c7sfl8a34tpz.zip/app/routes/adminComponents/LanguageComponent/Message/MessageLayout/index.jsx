import React, { useState } from 'react'
import './style.css'
import MessageList from '../MessageList/MessageList'
import Pagination from '../../../utils/Pagination/route'

import { useParams } from '@remix-run/react'
const index = () => {
  const [showReplyPopup, setShowReplyPopup] = useState(false);
  const [replyMessage, setReplyMessage] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const { id } = useParams();
  console.log("id",id)
   
    const itemsPerPage = 8;
  const handleReplyClick = () => {
      setShowReplyPopup(true);
    };
  
    const sendReply = async () => {
  
      // try {
      //   const response = await fetch(`/api/admin/support`, {
      //     method: "POST",
      //     headers: {
      //       "Content-Type": "application/json",
      //     },
      //     body: JSON.stringify({
      //       id: selectedStore._id, 
      //       message: replyMessage,
      //       page: currentPage,
      //       limit: itemsPerPage,
      //     }),
      //   });
      // setTotalPages(data.result.totalPages || 1);
  
      //   if (response.status) {
      //     showSuccess("Send Successfully");
      //   } else {
      //     showError("Failed to send message.");
      //   }
      // } catch (error) {
      //   showError("Server Error.");
      // }
  
      setShowReplyPopup(false);
      setReplyMessage(""); 
    };
  return (
    <>
    <div className="main-partner-container">
      <div className="top-heading m-head">
      <h2>Messages</h2>
     <button className='add-msg' onClick={handleReplyClick}>Add New</button>
      </div>
      <div className="table-wrapper">
      
        
      <table className="partner-table">
        <thead>
          <tr>
            <th>Key</th>
            <th>Value</th>
            <th>Actions</th>

            
          </tr>
        </thead>
        <tbody>
          <MessageList />
        </tbody>
      </table>

      {/* <Pagination
        currentPage={currentPage}
        totalPages={totalPages}
        onPageChange={setCurrentPage}
      /> */}
    
    {showReplyPopup && (
  <div className="popup-overlay">
    <div className="popup-box">
      <p>Send a reply as JSON</p>
      <div className="msg-box">
        <textarea
          className="msg-input"
          placeholder="Enter JSON..."
          value={replyMessage}
          onChange={(e) => setReplyMessage(e.target.value)}
        />
      </div>
      
      <div className="popup-buttons">
        <button className="send-btn" onClick={sendReply}>Save</button>
        <button className="cancel-btn" onClick={() => setShowReplyPopup(false)}>Cancel</button>
      </div>
    </div>
  </div>
)}

</div>
    </div>
    {/* <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              onPageChange={setCurrentPage}
            /> */}

    </>
  )
}

export default index