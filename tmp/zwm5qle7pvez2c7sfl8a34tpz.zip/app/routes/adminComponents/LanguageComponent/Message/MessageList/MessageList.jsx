import React, { useState } from "react";
// import "./LangList.css";
import { useNavigate } from "@remix-run/react";
import '../../../StoreComponent/store.css'
import '../../../SupportComponent/SupportList/Slist.css'
import { MdDelete } from "react-icons/md";
import { FiEdit } from "react-icons/fi";
import { CiSaveUp2 } from "react-icons/ci";
import '../MessageLayout/style.css'
import { v4 as uuidv4 } from "uuid";
// import OverlayLoader from "../../utils/Loaderr/overlayLoader/route.jsx";s
const List = ({messages}) => {
  console.log("--messsages",messages)
  const navigate = useNavigate();
  const [showDeletePopup, setShowDeletePopup] = useState(false);
  const [loader, setLoader] = useState(false);
  const [edit, setEdit] = useState(false);
  const [value, setValue] = useState("English");




  // const handleNavigate = (id) => {
  //   setLoader(true);
  //   navigate(`/app/storedetail/${id}`);
  // };
  const handleDeleteClick = (id) => {
    setShowDeletePopup(true);
  };
  const confirmDelete = async () => {
    // try {
    //   const response = await fetch(`/api/admin/support`, {
    //     method: "DELETE",
    //     headers: {
    //       "Content-Type": "application/json",
    //     },
    //     body: JSON.stringify({ id: selectedStoreId }), 
    //   });

    //   if (response.status) {
    //     showSuccess("Delete Successfully");
    //     fetchStores();

    //   } else {
    //     showError("Failed to delete message.");
    //   }
    // } catch (error) {
    //   showError(error);
    // }

    setShowDeletePopup(false);
  };
  const handleEdit = () => {
    setEdit(true);
  };

  const handleSave = async () => {
    console.log("--value", value)
    setEdit(false);
    // try {
    //   // API call here
    //   const response = await fetch('/api/update-text', {
    //     method: 'POST',
    //     headers: { 'Content-Type': 'application/json' },
    //     body: JSON.stringify({ updatedValue: value }),
    //   });

    //   if (response.ok) {
    //     console.log('Update successful');
    //     setEdit(false);
    //   } else {
    //     console.error('Update failed');
    //   }
    // } catch (err) {
    //   console.error('Error:', err);
    // }
  };



  return (
    <>
      <tr>
        <td style={{ width: "45%" }}>Englishh</td>


        <td style={{ width: "45%" }}>
          {edit ? (
            <input
              className="edit-input"
              type="text"
              placeholder="New value"
              value={value}
              onChange={(e) => setValue(e.target.value)}
            />
          ) : (
            value
          )}
        </td>

        <td className="support-buttons" style={{ width: "20%" }}>
          <button className="delete-btn" onClick={() => handleDeleteClick()}>
            <MdDelete />
          </button>
          {edit ? (
            <button className="save-btn" onClick={handleSave}>
              <CiSaveUp2 />
            </button>
          ) : (
            <button className="edit-btn" onClick={handleEdit}>
              <FiEdit />
            </button>
          )}
        </td>
      </tr>
      

      {showDeletePopup && (
        <div className="popup-overlay">
          <div className="popup-box">
            <p>Are you sure you want to delete this </p>
            <div className="popup-buttons">
              <button className="confirm-btn" onClick={confirmDelete}>Yes</button>
              <button className="cancel-btn" onClick={() => setShowDeletePopup(false)}>No</button>
            </div>
          </div>
        </div>
        
      )}


      {/* {partners.length > 0 ? (
        partners.map((partner) => (
          <tr key={uuidv4()}>
            <td>{partner?.shopJson?.name}</td>
            <td>{partner?.shopJson?.customer_email}</td>
            <td>{partner.planName}</td>
            <td>{partner.myshopify_domain}</td>
            <td>{partner.orderCount}</td>
            <td>
              <button
                className="view-btn"
                onClick={() => handleNavigate(partner._id)}
              >
                View
              </button>
            </td>
          </tr>
        ))
      ) : (
        <tr>
          <td colSpan="6">No partners found.</td>
        </tr>
      )}
      {loader && <OverlayLoader />} */}
    </>
  );
};

export default List;
