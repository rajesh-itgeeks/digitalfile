import React, { useState } from "react";
import "./LangList.css";
import { useNavigate } from "@remix-run/react";
import { v4 as uuidv4 } from "uuid";
import OverlayLoader from "../../utils/Loaderr/overlayLoader/route.jsx";
const List = ({ languages }) => {
  console.log("languages", languages)
  const navigate = useNavigate();
  const [loader, setLoader] = useState(false);

  const handleClick = (id) => {
    console.log("-------id", id)
    setLoader(true);
    navigate(`/app/messageLayout/${id}`);
  };
  return (
    <>
      {/* <div> */}
        {languages && languages.length > 0 ? (
          languages.map((lang) => (
            <tr key={uuidv4()}>
              <td onClick={() => handleClick(lang._id)} className="Lang-row" >
                {lang.lang || "—"}
              </td>

            </tr>
          ))
        ) : (
          <tr>
            <td colSpan="3">No languages found.</td>
          </tr>
        )
        }
        {/* {loader && <OverlayLoader />} */}
      {/* </div> */}


    </>
  );
};
//   return (
//     <>
// <tr>
//   <td onClick={handleClick} className="Lang-row">Englishh</td>
//   </tr>  
//   <tr>
//   <td>Englishh</td>
//   </tr>  
//   <tr>
//   <td>Englishh</td>
//   </tr>  



//       {/* {partners.length > 0 ? (
//         partners.map((partner) => (
//           <tr key={uuidv4()}>
//             <td>{partner?.shopJson?.name}</td>
//             <td>{partner?.shopJson?.customer_email}</td>
//             <td>{partner.planName}</td>
//             <td>{partner.myshopify_domain}</td>
//             <td>{partner.orderCount}</td>
//             <td>
//               <button
//                 className="view-btn"
//                 onClick={() => handleNavigate(partner._id)}
//               >
//                 View
//               </button>
//             </td>
//           </tr>
//         ))
//       ) : (
//         <tr>
//           <td colSpan="6">No partners found.</td>
//         </tr>
//       )}
//       {loader && <OverlayLoader />} */}
//     </>
//   );


export default List;
