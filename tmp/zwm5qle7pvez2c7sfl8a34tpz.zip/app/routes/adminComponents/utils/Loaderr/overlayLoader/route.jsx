import React from "react";
import "./overlay.css";

const route = () => {
  return (
    <div className="loading-overlay">
      <div className="spinner"></div>
    </div>
  );
};

export default route;
