import React from "react";
import "./pagination.css";

const Pagination = ({ currentPage, totalPages, onPageChange }) => {
  const goToPreviousPage = () => onPageChange(currentPage - 1);
  const goToNextPage = () => onPageChange(currentPage + 1);

  return (
    <div className="pagination">
      <button
        onClick={goToPreviousPage}
        disabled={currentPage === 1}
        className="pg-button"
      >
        Pre
      </button>

      {Array.from({ length: totalPages }, (_, i) => i + 1)
        .filter(
          (page) =>
            page === 1 ||
            page === totalPages ||
            (page >= currentPage - 1 && page <= currentPage + 1),
        )
        .map((page, index, arr) => (
          <React.Fragment key={page}>
            {index > 0 && page !== arr[index - 1] + 1 && <span>...</span>}
            <button
              className={currentPage === page ? "active" : ""}
              onClick={() => onPageChange(page)}
            >
              {page}
            </button>
          </React.Fragment>
        ))}

      <button
        onClick={goToNextPage}
        disabled={currentPage === totalPages}
        className="pg-button"
      >
        Next
      </button>
    </div>
  );
};

export default Pagination;
