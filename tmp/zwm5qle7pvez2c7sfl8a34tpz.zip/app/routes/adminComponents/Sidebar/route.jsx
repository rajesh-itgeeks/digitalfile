import React, { memo } from "react";
import { Link, useLocation } from "@remix-run/react";
import { CiHome } from "react-icons/ci";
import { IoMdPerson } from "react-icons/io";
import { FaPhoneAlt } from "react-icons/fa";
import { IoLogOutOutline } from "react-icons/io5";
import { MdOutlineMail , MdLanguage } from "react-icons/md";


import "./side.css";

const Sidebar = memo(() => {
  const location = useLocation();

  const navLinks = [
    { to: "/app/admin", icon: <CiHome />, label: "Home" },
    { to: "/app/supportlist", icon: <FaPhoneAlt />, label: "Support" },
    { to: "/app/emailtemplate", icon: <MdOutlineMail />, label: "Emails" },
    { to: "/app/languageTab", icon: <MdLanguage />, label: "Language " },
    { to: "/app/logout", icon: <IoLogOutOutline />, label: "Logout" },
  ];

  return (
    <div className="sidebar-containerr">
      <nav className="nav-links">
        {navLinks.map(({ to, icon, label }) => (
          <Link key={to} to={to} prefetch="intent" className={`link ${location.pathname === to ? "active" : ""}`}>
            {icon}
            <span>{label}</span>
          </Link>
        ))}
      </nav>
    </div>
  );
});

export default Sidebar;
