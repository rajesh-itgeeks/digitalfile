import React, { useEffect, useState } from "react";
import "./style.css";
import Loader from "../utils/Loaderr/CommonLoader/Loader";



const PartnerDetail = () => {
  const [activeTab, setActiveTab] = useState("orderEdit");
  const [loading, setloading] = useState(true);
  const [editTrue, seteditTrue] = useState(false);
  const [editedEmail , setEditedEmail] = useState({
    id:"",
    subject:"",
    htmlbody:""
  })
  const [emailTemplate, setemailTemplate] = useState();


  const fetchData = async () => {
    try {
      const response = await fetch(`/api/admin/email`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          type: activeTab,
        }),
      });
      const data = await response.json();
      setEditedEmail({
        id: data.result._id,
        subject: data.result.subject,
        htmlbody: data.result.emailTemplate,
      })
      let orderDetail = await fetch(`/api/admin/random-order`,{
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          template: data.result.emailTemplate,
        }),
      })
      orderDetail = await orderDetail.json();
      console.log(orderDetail)
      setemailTemplate(orderDetail.result);
      setloading(false);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  useEffect(() => {
    setloading(true);
    fetchData();
  }, [activeTab]);

  const tabs = [
    { id: "orderEdit", label: "Order Edit" },
    { id: "addUpSellItem", label: "Add UpSell Item" },
    { id: "paymentPending", label: "Payment Pending" },
    { id: "orderCancellation", label: "Order Cancel" },
  ];

  const handleSave = async () => {
    setloading(true)
    const response = await fetch(`/api/admin/email`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
            id:editedEmail.id,
          subject: editedEmail.subject,
          emailTemplate: editedEmail.htmlbody
        }),
      });
      const data = await response.json();
      if (data.status) {
        seteditTrue(false)
        fetchData();
      }
  }
  


  if (editTrue) {
    return loading ? (
      <Loader />
    ) : (
      <div className="edit-email-container">
        <h2>Edit Email Template</h2>
        <div className="edit-buttons">
          <button className="cancel-btn" onClick={()=>seteditTrue(false)}>
            Cancel
          </button>
          <button className="save-btn" onClick={handleSave}>
            Save
          </button>
        </div>
        <div className="preview-email-container">
          <div className="input-div">
            <label>Email Subject</label>
            <input type="text" value={editedEmail.subject} onChange={(e)=> setEditedEmail({...editedEmail, subject:e.target.value})}/>
          </div>
          <div className="email-body input-div">
            <label>Email Body</label>
            <textarea value={editedEmail.htmlbody} onChange={(e)=> setEditedEmail({...editedEmail, htmlbody:e.target.value})}></textarea>
          </div>
        </div>
      </div>
    );
  } else {
    return (
      <div className="main-email-container">
        <div className="email-tabs">
          {tabs.map((tab) => (
            <div
              key={tab.id}
              className={`email-tab ${activeTab === tab.id ? "active" : ""}`}
              onClick={() => setActiveTab(tab.id)}
            >
              <div className="tab-content">
                <h4>{tab.label}</h4>
              </div>
            </div>
          ))}
        </div>
        {loading ? (
          <Loader />
        ) : (
          <div className="email-template-container">
            <div className="eidt-button-container">
              <button className="edit-button" onClick={()=>seteditTrue(true)}>
                edit
              </button>
            </div>
            <div
              className="email-template-wrap"
              dangerouslySetInnerHTML={{ __html: emailTemplate }}
            ></div>
          </div>
        )}
      </div>
    );
  }
};

export default PartnerDetail;







