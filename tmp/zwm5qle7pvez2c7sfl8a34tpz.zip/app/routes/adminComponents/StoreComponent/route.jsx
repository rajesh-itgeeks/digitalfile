import React, { useState, useEffect } from "react";
import "./store.css";
import List from "./StoreList/List";
import Pagination from "../utils/Pagination/route";
import Loader from "../utils/Loaderr/CommonLoader/Loader";
const route = () => {
  const [currentPage, setCurrentPage] = useState(1);
  const [partners, setPartners] = useState([]);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const itemsPerPage = 8;

  useEffect(() => {
    const fetchPartners = async () => {
      setLoading(true);
      setError(null);

      try {
        const response = await fetch(`/api/admin/store/partnerlist`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            page: currentPage,
            limit: itemsPerPage,
            type: "all",
          }),
        });

        if (!response.ok) {
          throw new Error("Failed to fetch data");
        }
        const data = await response?.json();
        console.log(data, "=================");


        setPartners(data.result.data || []);
        setTotalPages(data.result.totalPages || 1);
      } catch (error) {
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };

    fetchPartners();
  }, [currentPage]);

  return (
    <div className="main-partner-container">
      <div className="top-heading">
        <h2>Stores</h2>
        <p>List of stores connected to services</p>
      </div>
      <div className="table-wrapper">
        {loading ? (
          <Loader />
        ) : error ? (
          <p style={{ color: "red" }}>{error}</p>
        ) : partners.length === 0 ? (
          <p>No stores found.</p>
        ) : (
          <>
            <table className="partner-table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Plan</th>
                  <th>Shop</th>
                  <th>Orders</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <List partners={partners} />
              </tbody>
            </table>

            <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              onPageChange={setCurrentPage}
            />
          </>
        )}
      </div>
    </div>
  );
};

export default route;
