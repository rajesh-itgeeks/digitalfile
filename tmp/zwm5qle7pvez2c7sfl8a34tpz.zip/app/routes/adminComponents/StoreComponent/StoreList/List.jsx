import React, { useState } from "react";
import "./List.css";
import { useNavigate } from "@remix-run/react";
import { v4 as uuidv4 } from "uuid";
import OverlayLoader from "../../utils/Loaderr/overlayLoader/route.jsx";
const List = ({ partners }) => {
  const navigate = useNavigate();
  const [loader, setLoader] = useState(false);
  console.log(partners, "=============")

  const handleNavigate = (id) => {
    setLoader(true);
    navigate(`/app/storedetail/${id}`);
  };

  return (
    <>
      {partners.length > 0 ? (
        partners.map((partner) => (
          <tr key={uuidv4()}>
            <td>{partner?.shopJson?.name}</td>
            <td>{partner?.shopJson?.customer_email}</td>
            <td>{partner.planName}</td>
            <td>{partner.myshopify_domain}</td>
            <td>{partner.orderCount}</td>
            <td>
              <button
                className="view-btn"
                onClick={() => handleNavigate(partner._id)}
              >
                View
              </button>
            </td>
          </tr>
        ))
      ) : (
        <tr>
          <td colSpan="6">No partners found.</td>
        </tr>
      )}
      {loader && <OverlayLoader />}
    </>
  );
};

export default List;
