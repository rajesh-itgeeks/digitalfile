import React, { useEffect, useState } from "react";
import "./style.css";
import { FiUser } from "react-icons/fi";

import StoreProfile from "../StoreProfile/StoreProfile.jsx";
import OrderEditss from "../../OrderEdits/route.jsx";
import { useParams } from "@remix-run/react";
import AppFeatures from "../../AppFeatures/route.jsx";

const PartnerDetail = () => {
  const [activeTab, setActiveTab] = useState("profile");
  const [storeDetail, setstoreDetail] = useState();
  const [loading, setloading] = useState(true);
  const { id } = useParams();
  const fetchData = async () => {
    try {
      const response = await fetch(`/api/admin/store/partners`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(id),
      });
      const data = await response.json();
      setstoreDetail(data.result);
      setloading(false);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  if (id) {
    useEffect(() => {
      fetchData();
    }, [id]);
  }
  const tabs = [
    { id: "profile", label: "Store Profile", icon: <FiUser /> },
    { id: "orderEdits", label: "Order Edits", icon: <FiUser /> },
    { id: "features", label: "App Features", icon: <FiUser /> },
  ];
  const renderComponent = () => {
    switch (activeTab) {
      case "profile":
        return (
          <StoreProfile
            loadDetail={loading}
            storeinfo={storeDetail}
            fetchData={fetchData}
          />
        );
      case "orderEdits":
        return <OrderEditss />;
      case "features":
        return <AppFeatures />;
    }
  };

  return (
    <div className="main-partnerDetail-container">
      <div className="top-tabs-partnerDetail">
        {tabs.map((tab) => (
          <div
            key={tab.id}
            className={`tabs-partnerdetail-box ${activeTab === tab.id ? "active" : ""}`}
            onClick={() => setActiveTab(tab.id)}
          >
            <div className="tab-icon">{tab.icon}</div>
            <div className="tab-content">
              <h4>{tab.label}</h4>
            </div>
          </div>
        ))}
      </div>

      {renderComponent()}
    </div>
  );
};

export default PartnerDetail;
