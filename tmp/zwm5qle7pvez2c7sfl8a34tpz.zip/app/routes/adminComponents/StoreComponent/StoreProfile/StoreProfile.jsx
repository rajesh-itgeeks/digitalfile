import React, { useState, useEffect, useCallback } from "react";
import "./StoreProfile.css";
import { useLocation, useParams } from "react-router-dom";
import Toaster from "../../utils/toster/toster";
import Loader from "../../utils/Loaderr/CommonLoader/Loader";
const StoreProfile = ({ loadDetail, storeinfo, fetchData }) => {
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const chargeId = queryParams.get("charge_id");
  const { id } = useParams();
  const [showModal, setShowModal] = useState(false);
  const [amount, setAmount] = useState("");
  const [trialDays, setTrialDays] = useState("");
  const [planType, setPlanType] = useState("EVERY_30_DAYS");
  const [loading, setLoading] = useState(false);
  const [subscribeId, setSubscribeId] = useState("");
  const [toast, setToast] = useState(null);
  const [errors, setErrors] = useState({});
  const showError = useCallback((error) => {
    setToast({ message: error, type: "error" });
  }, []);
  const validateAmount = (value) => {
    setAmount(value);
    if (value === "") {
      setErrors((prev) => ({ ...prev, amount: "" }));
    } else if (isNaN(value) || Number(value) <= 0) {
      setErrors((prev) => ({ ...prev, amount: "Amount must be integer" }));
    } else {
      setErrors((prev) => ({ ...prev, amount: "" }));
    }
  };

  const validateTrialDays = (value) => {
    setTrialDays(value);
    if (value === "") {
      setErrors((prev) => ({ ...prev, trialDays: "" }));
    } else if (
      isNaN(value) ||
      Number(value) < 0 ||
      !Number.isInteger(Number(value))
    ) {
      setErrors((prev) => ({
        ...prev,
        trialDays: "Trial days must be a  integer",
      }));
    } else {
      setErrors((prev) => ({ ...prev, trialDays: "" }));
    }
  };

  const sendPlanDetail = useCallback(async () => {
    if (!subscribeId && !chargeId) return;

    try {
      const response = await fetch(`/api/admin/plan/${id}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ chargeId }),
      });

      await response.json();
      if (chargeId) {
        const url = new URL(window.location.href);
        url.searchParams.delete("charge_id");
        window.history.replaceState({}, "", url);
      }
      fetchData();
    } catch (error) {
      console.error("Error sending plan details:", error);
      showError("Failed to update plan details.");
    }
  }, [chargeId, id, fetchData, showError, subscribeId]);

  const handlelink = async () => {
    if (
      !amount ||
      !planType ||
      !trialDays ||
      errors.amount ||
      errors.trialDays
    ) {
      setShowModal(false);
      return showError("amount and trial days is number and requird");
    }

    setLoading(true);
    let shops = localStorage.getItem("shop");
    let storeName = shops?.replace(".myshopify.com", "");
    try {
      const response = await fetch(`/api/admin/subscribe/${id}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ price: amount, interval: planType, trialDays,  returnUrl : `https://admin.shopify.com/store/${storeName}/apps/account-editor/app/storedetail/${id}` }),
      });

      const res = await response.json();
      const subscribe = res?.result?.appSubscription?.id;

      if (res.error) showError(res.error);

      if (subscribe) {
        setSubscribeId(subscribe);
        await fetch(`/api/admin/plan/${id}`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ interval: planType, subscribeId: subscribe}),
        });
        // console.log(res.result.confirmationUrl, "=================");


        res?.result?.confirmationUrl && window.open(res.result.confirmationUrl);
      }
    } catch (error) {
      console.error("Error:", error);
      showError("Subscription process failed.");
    } finally {
      setLoading(false);
      setShowModal(false);
      setAmount("");
      setTrialDays("");
    }
  };

  useEffect(() => {
    if (chargeId) sendPlanDetail();
  }, [chargeId]);

  if (loadDetail) {
    return <Loader />;
  }
  return (
    <>
      <div className="profile-main-container">
        <div className="top-heading">
          <h2>Store Details</h2>
          <p>Store Details and Amenities</p>
        </div>
        <div className="profile-sections">
          <div className="section">
            <div className="sec-div">
              <h4>Active Plan:</h4>
              <button>{storeinfo?.planName || "N/A"}</button>
            </div>
            <div className="sec-div">
              <h4>Trial Days:</h4>
              <p>{storeinfo?.trialDays || "N/A"} Days</p>
            </div>

            <div className="sec-div">
              <h4>Domain:</h4>
              <p>{storeinfo?.myshopify_domain || "N/A"}</p>
            </div>
            <div className="sec-div">
              <h4>Shopify Plan:</h4>
              <p>{storeinfo?.shopJson?.plan_name || "N/A"}</p>
            </div>
            <div className="sec-div">
              <button
                className="customize-btn"
                onClick={() => setShowModal(true)}
              >
                Customize Plan
              </button>
            </div>
            
            
          </div>
          <div className="section">
            <div className="sec-div">
              <h4>Plan Type:</h4>
              <button>{storeinfo?.interval || "N/A"}</button>
            </div>
            <div className="sec-div">
              <h4>Shop Name:</h4>
              <p>{storeinfo?.shopJson?.name || "N/A"}</p>
            </div>
            <div className="sec-div">
              <h4>Amount:</h4>
              <p>{storeinfo?.amount || "N/A"}</p>
            </div>
          </div>
          <div className="section">
            <div className="sec-div">
              <h4>Plan Start Date:</h4>
              <button>{storeinfo?.createdAt || "N/A"}</button>
            </div>
            <div className="sec-div">
              <h4>Shop Owner:</h4>
              <p>{storeinfo?.shopJson?.shop_owner || "N/A"}</p>
            </div>
            <div className="sec-div">
              <h4>Email:</h4>
              <p>{storeinfo?.shopJson?.customer_email || "N/A"}</p>
            </div>
          </div>
        </div>
      </div>

      {showModal && (
        <div
          className="modal-overlay"
          onClick={() => !loading && setShowModal(false)}
        >
          <div className="modal-container" onClick={(e) => e.stopPropagation()}>
            <button
              className="close-btn"
              onClick={() => !loading && setShowModal(false)}
            >
              ✖
            </button>
            <h3>Customize Plan</h3>
            <div className="modal-content">
              <div className="input-group">
                <div className="row">
                  <label>Amount</label>
                  <input
                    type="text"
                    placeholder="Enter amount"
                    value={amount}
                    onChange={(e) => validateAmount(e.target.value)}
                    disabled={loading}
                  />
                </div>
                {errors.amount && (
                  <span className="error-message">{errors.amount}</span>
                )}
              </div>

              <div className="input-group">
                <div className="row">
                  <label>Type</label>
                  <select
                    value={planType}
                    onChange={(e) => setPlanType(e.target.value)}
                    disabled={loading}
                  >
                    <option value="EVERY_30_DAYS">Monthly</option>
                    <option value="ANNUAL">Yearly</option>
                  </select>
                </div>
              </div>

              <div className="input-group">
                <div className="row">
                  <label>Trial Days</label>
                  <input
                    type="text"
                    placeholder="Enter Trial Days"
                    value={trialDays}
                    onChange={(e) => validateTrialDays(e.target.value)}
                    disabled={loading}
                  />
                </div>
                {errors.trialDays && (
                  <span className="error-message">{errors.trialDays}</span>
                )}
              </div>

              <button
                className="submit-btn"
                onClick={handlelink}
                disabled={loading || errors.amount || errors.trialDays}
              >
                {loading ? "Processing..." : "Submit"}
              </button>
            </div>

            {loading && (
              <div className="loading-overlay">
                <div className="spinner"></div>
              </div>
            )}
          </div>
        </div>
      )}

      {toast && (
        <Toaster
          message={toast.message}
          type={toast.type}
          onClose={() => setToast(null)}
        />
      )}
    </>
  );
};

export default StoreProfile;
