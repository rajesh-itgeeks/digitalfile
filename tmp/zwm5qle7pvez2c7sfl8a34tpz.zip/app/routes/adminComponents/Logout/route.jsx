import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { logout } from "../../components/store/AuthSlice";
import { useNavigate } from "@remix-run/react";
import "./logout.css";
const LogoutRoute = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [showModal, setShowModal] = useState(true);
  const [loading, setloading] = useState(false)
  const handleClose = () => {
    setShowModal(false);
    navigate(-1);
  };

  const handleLogout = () => {
    setloading(true)
    dispatch(logout());
    navigate("/app");
  };

  return (
    showModal && (
      <div className="modal-overlay">
        <div className="modal">
          <h2>Confirm Logout</h2>
          <p>Are you sure you want to logout?</p>
          <div className="modal-buttons">
            <button className="cancel-btn" onClick={handleClose}>
              Cancel
            </button>
            <button className="logout-btn" onClick={handleLogout}>
              {loading ? "Processing" : "Logout"} 
            </button>
          </div>
        </div>
      </div>
    )
  );
};

export default LogoutRoute;
