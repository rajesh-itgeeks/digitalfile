import React, { useEffect, useState, useRef } from "react";
import { FiUsers, FiX } from "react-icons/fi";
import { IoFilterSharp } from "react-icons/io5";
import { FaFileDownload } from "react-icons/fa";
import Homelist from "../Listhome/Homelist";
import "./syle.css";
import Pagination from "../../utils/Pagination/route";
import Loader from "../../utils/Loaderr/CommonLoader/Loader";
import { IoIosSearch } from "react-icons/io";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
const actionOptions = ["shopify", "advanced", "professional", "plus_sandbox", "trial", "paused", "frozen", "cancelled", "custom", "enterprise", "development", "essential", "staff", "partner_test", "affiliate", "basic", "npo_lite", "unlimited", "shopify_plus", "starter",];


const Home = () => {
  const [currentPage, setCurrentPage] = useState(1);
  const [stores, setStores] = useState([]);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [filterOpen, setFilterOpen] = useState(false);
  const [selectedActions, setSelectedActions] = useState([]);
  const [searchPlanType, setSearchPlanType] = useState('');
  const filterRef = useRef();

  const [storeCounts, setStoreCounts] = useState({
    total: 0,
    customize: 0,
    professional: 0,
    essential: 0,
    active: 0,
  });

  const itemsPerPage = 7;

  const tabs = [
    { key: "all", label: "Total Stores" },
    { key: "customize", label: "Customize Stores" },
    { key: "professional", label: "Professional Stores" },
    { key: "essential", label: "Essential Stores" },
    { key: "active", label: "Active Stores" },
  ];
  // download csv file
  const downloadCSV = async () => {
    try {
      const response = await fetch(`/api/admin/store/partnerlist`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: activeTab,
          query: searchTerm.trim(),
          shopType: selectedActions,
          download: true
        }),
      });

      const data = await response.json();
      const storesData = data.result?.data || [];

      if (storesData.length === 0) {
        // alert("No data to export!");
        toast.error("No data to export!");
        return;
      }

      const headers = Object.keys(storesData[0]).join(",");
      const rows = storesData.map((store) =>
        Object.values(store)
          .map((value) => `"${String(value).replace(/"/g, '""')}"`)
          .join(",")
      );

      const csvContent = [headers, ...rows].join("\n");
      const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);

      const link = document.createElement("a");
      link.setAttribute("href", url);
      link.setAttribute("download", "filtered_stores.csv");
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      console.error("Error downloading CSV:", error);
    }
  };


  const toggleFilter = () => setFilterOpen(!filterOpen);
  // api call to get total storeCounts
  useEffect(() => {
    const fetchStoreCounts = async () => {
      try {
        const response = await fetch("/api/admin/store/partners");
        const data = await response.json();
        setStoreCounts({
          total: data.result.total || 0,
          customize: data.result.customize || 0,
          professional: data.result.professional || 0,
          essential: data.result.essential || 0,
          active: data.result.activeStores || 0,
        });
      } catch (error) {
        console.error("Error fetching store counts:", error);
      }
    };

    fetchStoreCounts();
  }, []);
  // function to close filter box when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (filterRef.current && !filterRef.current.contains(event.target)) {
        setFilterOpen(false);
      }
    };

    if (filterOpen) {
      document.addEventListener("mousedown", handleClickOutside);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [filterOpen]);

  // fetch partnerlist data
  useEffect(() => {
    const fetchStores = async () => {
      setLoading(true);
      setError(null);

      try {
        const response = await fetch(`/api/admin/store/partnerlist`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            page: currentPage,
            limit: itemsPerPage,
            type: activeTab,
            query: searchTerm.trim(),
            shopType: selectedActions,
          }),
        });

        const data = await response.json();

        if (!response.ok) {
          setError(data.message);
        } else {
          setStores(data.result || []);
          setTotalPages(data.result.totalPages || 1);
          setCurrentPage(data.result.currentPage || 1);
        }
      } catch (error) {
        console.log(error);
      } finally {
        setLoading(false);
      }
    };

    fetchStores();
  }, [activeTab, currentPage, searchTerm, selectedActions]);
  // function to handle tab chng
  const handleTabChange = (tab) => {
    setActiveTab(tab);
    setCurrentPage(1);
  };
  // filter functions
  const handleActionChange = (action) => {
    const updatedActions = selectedActions.includes(action)
      ? selectedActions.filter((a) => a !== action)
      : [...selectedActions, action];

    setSelectedActions(updatedActions);
    setCurrentPage(1);
  };

  const removeSelectedFilter = (action) => {
    const updatedActions = selectedActions.filter((a) => a !== action);
    setSelectedActions(updatedActions);
  };

  const clearFilters = () => {
    setSelectedActions([]);
  };

  return (
    <>
      <div className="main-home-container">
        <div className="top-home-boxes">
          {tabs.map((tab) => (
            <div
              key={tab.key}
              className={`boxx ${activeTab === tab.key ? "active-tab" : ""}`}
              onClick={() => handleTabChange(tab.key)}
            >
              <div className="boxx-content">
                <p>{tab.label}</p>
                <h4>{storeCounts[tab.key === "all" ? "total" : tab.key]}</h4>
              </div>
              <div className="box-icon">
                <FiUsers />
              </div>
            </div>
          ))}
        </div>
        

        <div className="boxxxx">
          <div className="filterr">
            <button className="apply-filter-btn" onClick={toggleFilter}>
              <IoFilterSharp />
            </button>
            <div className="csv-icon" onClick={downloadCSV}><FaFileDownload /><div className="tool-tip" ><p>Download CSV</p></div></div>
            {filterOpen && (
              <div className="filter-box" ref={filterRef}>
                <button className="close-icon-btn" onClick={toggleFilter}>
                  <FiX />
                </button>
                <div className="filter-options">
                  <div className="filter-item">Filter by PlanType</div>
                  <input className="search-plan-input" type="text" placeholder="Search planType" value={searchPlanType} onChange={(e) => setSearchPlanType(e.target.value)} />
                  <div className="action-list">
                    {(() => {
                      const filteredActions = actionOptions.filter((action) =>
                        action.toLowerCase().includes(searchPlanType.toLowerCase())
                      );

                      return filteredActions.length > 0 ? (
                        filteredActions.map((action) => (
                          <label key={action} style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "10px" }}>
                            <input
                              type="checkbox"
                              checked={selectedActions.includes(action)}
                              onChange={() => handleActionChange(action)}
                            />
                            {action}
                          </label>
                        ))
                      ) : searchPlanType ? (
                        <p style={{ color: "gray", fontStyle: "italic" }}>No match found</p>
                      ) : null;
                    })()}
                  </div>


                </div>
              </div>
            )}


          </div>
          <div className="input-filter-box">
            <div className="search-icon">
              <IoIosSearch />

            </div>
            <div className="search-input-container">
              <input
                className="search-input"

                type="text"
                placeholder="Enter ShopName"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>

          </div>


        </div>
        <div className="display-types">
          {selectedActions.length > 0 && (
            <div className="selected-filters">
              <div className="selct-itemss">
                {selectedActions.map((action) => (
                  <p key={action}>
                    {action}{" "}
                    <FiX onClick={() => removeSelectedFilter(action)} />
                  </p>
                ))}
                <button className="clear-filter-btn" onClick={clearFilters}>
                  Clear All
                </button>
              </div>
            </div>
          )}
        </div>
        <div className="table-wrapper">
          {loading ? (
            <Loader />
          ) : error ? (
            <p style={{ color: "red" }}>{error}</p>
          ) : stores.length === 0 ? (
            <p>No stores found for this category.</p>
          ) : (
            <>
              <table className="Home-table">
                <thead>
                  <tr>
                    <th>Stores</th>
                    <th>Store Name</th>
                    <th>Email</th>
                    <th>Current Status</th>
                    <th>Action</th>
                    {activeTab === "active" && <th>Total Orders</th>}
                  </tr>
                </thead>
                <tbody>
                  <Homelist stores={stores} storeStatus={activeTab} />
                </tbody>
              </table>
              <Pagination
                currentPage={currentPage}
                totalPages={totalPages}
                onPageChange={setCurrentPage}
              />
            </>
          )}
        </div>
        <ToastContainer position="top-center" autoClose={3000} hideProgressBar />
      </div>
    </>
  );
};

export default Home;
// import React, { useEffect, useRef } from 'react';

// function Route() {
//   const contentRef = useRef(null);

//   useEffect(() => {
//     // Ensure code only runs on the client
//     if (typeof window !== 'undefined') {
//       // Dynamically import html2pdf only in the browser
//       import('html2pdf.js').then((html2pdf) => {
//         document.getElementById('download-btn').onclick = () => {
//           const element = contentRef.current;
//           const opt = {
//             margin: 0.2,
//             filename: 'downloaded-from-api.pdf',
//             image: { type: 'jpeg', quality: 0.98 },
//             html2canvas: { scale: 2 },
//             jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' },
//           };
//           html2pdf.default().set(opt).from(element).save();
//         };
//       });
//     }
//   }, []);

//   const htmlContent = `
// <body style="margin: 0; padding: 0; font-family: 'Inter', sans-serif;">
//   <div style="width: 100%; max-width: 600px; margin: 0 auto;">
//     <table class="email" width="100%" border="0" cellspacing="0" cellpadding="0" style="border-radius: 8px;">
//       <tr>
//         <td>
//           <table border="0" style="width: 100%; padding: 16px;" cellspacing="0" cellpadding="0">
//             <tbody>
//               <tr>
//                 <td>
//                   <table border="0" cellspacing="0" cellpadding="0" style="width: 100%;">
//                     <tbody>
//                       <tr>
//                         <td>
//                           <div><img src="" alt="img" width="133" /></div>
//                         </td>
//                         <td>
//                           <p style="text-align: right; margin: 0; font-size: 14px; line-height: 20px; color: #777777;">Receipt / Tax Invoice ODID#1156</p>
//                           <p style="text-align: right; margin: 0; font-size: 14px; line-height: 20px; color: #777777;">Created 2025-04-08T01:28:32-04:00</p>
//                           <p style="text-align: right; margin: 0; font-size: 14px; line-height: 20px; color: #777777;">Last Updated 2025-04-08T01:29:16-04:00</p>
//                         </td>
//                       </tr>
//                     </tbody>
//                   </table>
//                 </td>
//               </tr>

//               <tr>
//                 <td>
//                   <table border="0" cellspacing="0" cellpadding="0" style="width: 100%; text-align: left; margin-top: 24px;">
//                     <tbody>
//                       <tr>
//                         <th style="width: 500px; color: #303030; font-size: 13px;">Shipping address</th>
//                         <th style="width: 500px; color: #303030; font-size: 13px;">Customer</th>
//                         <th align="right" style="width: 500px; color: #303030; font-size: 13px;">Order</th>
//                       </tr>
//                       <tr style="width: 100%;">
//                         <td>
//                           <div style="color: #777777; font-size: 13px; line-height: 22px; font-weight: 500; margin-top: 13px;">
//                             <p style="margin: 0;">1250 Hospital Shivaji Nagar</p>
//                             <p style="margin: 0;">Bhopal</p>
//                             <p style="margin: 0;">462016</p>
//                             <p style="margin: 0;">India</p>
//                           </div>
//                         </td>
//                         <td>
//                           <div style="color: #777777; font-size: 13px; line-height: 22px; font-weight: 500; margin-top: 13px;">
//                             <!-- Customer details can be filled here -->
//                           </div>
//                         </td>
//                         <td align="right" style="vertical-align: top;">
//                           <div style="color: #777777; font-size: 13px; line-height: 22px; font-weight: 500; margin-top: 13px;">
//                             <p style="margin: 0;">paid</p>
//                             <p style="margin: 0;">mayurirajput@itgeeks.com</p>
//                           </div>
//                         </td>
//                       </tr>
//                     </tbody>
//                   </table>
//                 </td>
//               </tr>

//               <tr>
//                 <td>
//                   <table border="0" cellspacing="0" cellpadding="0" style="width: 100%; margin-top: 24px; border: 1px solid #EBEBEB;">
//                     <tbody>
//                       <tr>
//                         <th align="left" style="width: 25%; padding: 12px; background-color: #F9FAFB; font-size: 13px; color: #303030;">Items</th>
//                         <th align="left" style="width: 25%; background-color: #F9FAFB; font-size: 13px; color: #303030;">Price</th>
//                         <th align="left" style="width: 25%; background-color: #F9FAFB; font-size: 13px; color: #303030;">Qty</th>
//                         <th align="left" style="width: 25%; background-color: #F9FAFB; font-size: 13px; color: #303030;">Total</th>
//                       </tr>
//                       <tr>
//                         <td style="width: 25%; padding: 16px; color: #777777; font-size: 13px; line-height: 22px;">
//                           <strong>The Multi-location Snowboard</strong><br>/ 32SKU:
//                         </td>
//                         <td style="width: 25%; color: #777777; font-size: 13px;">729.95 INR</td>
//                         <td style="width: 25%; color: #777777; font-size: 13px;">1</td>
//                         <td style="width: 25%; padding-right: 16px; color: #777777; font-size: 13px;">729.95 INR</td>
//                       </tr>
//                     </tbody>
//                   </table>
//                 </td>
//               </tr>

//               <tr>
//                 <td>
//                   <table align="right" border="0" cellspacing="0" cellpadding="0" style="width: 46%; margin-top: 20px;">
//                     <tbody>
//                       <tr>
//                         <td style="font-size: 13px; color: #777777; line-height: 16px; padding-top: 16px;">Order discount</td>
//                         <td style="text-align: right; color: #777777; font-size: 13px; padding-top: 16px;">-500.00 INR</td>
//                       </tr>
//                       <tr>
//                         <td style="font-size: 13px; color: #777777; line-height: 16px; padding-top: 16px;">Subtotal</td>
//                         <td style="text-align: right; color: #777777; font-size: 13px; padding-top: 16px;">229.95 INR</td>
//                       </tr>
//                       <tr>
//                         <td style="font-size: 13px; color: #777777; line-height: 16px; padding-top: 16px;">Shipping</td>
//                         <td style="text-align: right; color: #777777; font-size: 13px; padding-top: 16px;">0.00 INR</td>
//                       </tr>
//                       <tr>
//                         <td style="font-size: 13px; color: #777777; line-height: 16px; padding-top: 16px;">VAT</td>
//                         <td style="text-align: right; color: #777777; font-size: 13px; padding-top: 16px;">41.39 INR</td>
//                       </tr>
//                       <tr>
//                         <td colspan="2" style="padding-top: 16px; font-size: 13px; color: #777777; line-height: 22px;">Los Angeles <br>County Tax 0.25%</td>
//                       </tr>
//                       <tr>
//                         <td colspan="2" style="padding-top: 16px; font-size: 13px; color: #777777; line-height: 22px;">Los Angeles <br>County District Tax <br>Sp 2.25%</td>
//                       </tr>
//                       <tr>
//                         <td colspan="2" style="padding-top: 16px; font-size: 13px; color: #777777; line-height: 22px;">Los Angeles Co <br>Local Tax Sl 1%</td>
//                       </tr>
//                       <tr>
//                         <td colspan="2" style="padding-top: 16px; font-size: 13px; color: #777777; line-height: 22px;">California State <br>Tax 6%</td>
//                       </tr>
//                       <tr>
//                         <td style="border-bottom: 1px solid #303030; color: #303030; font-size: 13px; padding-top: 16px; padding-bottom: 20px;">Total</td>
//                         <td style="border-bottom: 1px solid #303030; color: #303030; font-size: 13px; padding-top: 16px; padding-bottom: 20px;">271.34 INR</td>
//                       </tr>
//                     </tbody>
//                   </table>
//                 </td>
//               </tr>

//               <tr>
//                 <td>
//                   <table border="0" cellspacing="0" cellpadding="0" style="width: 100%; margin-top: 24px; text-align: center;">
//                     <tbody>
//                       <tr>
//                         <td>
//                           <p style="color:#8A8A8A; font-size: 13px; line-height: 22px; margin: 0;">Thank you for shopping with us!</p>
//                           <p style="margin-top: 24px; margin-bottom: 0;">
//                             <a href="mailto:mayurirajput@itgeeks.com" style="color: #1990C6; font-size: 13px; text-decoration: none;">mayurirajput@itgeeks.com</a>
//                           </p>
//                         </td>
//                       </tr>
//                     </tbody>
//                   </table>
//                 </td>
//               </tr>

//             </tbody>
//           </table>
//         </td>
//       </tr>
//     </table>
//   </div>
// </body>
// `;

//   return (
//     <div>
//       <div
//         ref={contentRef}
//         dangerouslySetInnerHTML={{ __html: htmlContent }}
//         style={{ padding: 20, background: '#fff' }}
//       />
//       <button id="download-btn">Download PDF</button>
//     </div>
//   );
// }

// export default Route;
