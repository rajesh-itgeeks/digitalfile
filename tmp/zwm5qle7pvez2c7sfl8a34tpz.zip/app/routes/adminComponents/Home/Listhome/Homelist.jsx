import React, { useState } from "react";
import { v4 as uuidv4 } from "uuid";
import { useNavigate } from "@remix-run/react";
import OverlayLoader from "../../utils/Loaderr/overlayLoader/route.jsx";
import "../HomeLayout/syle.css";

const Homelist = ({ stores, storeStatus }) => {
  const [loader, setLoader] = useState(false);

  const navigate = useNavigate();

  const handleNavigate = (id) => {
    setLoader(true);
    navigate(`/app/storedetail/${id}`);
  };

  
  const getInstallationStatus = (storeDomain) => {
    const matchedSession = stores?.sessionData?.find(
      (session) => session?.shop === storeDomain,
    );
    return matchedSession ? "Installed" : "Uninstalled";
  };

  return (
    <>
      {stores?.data.length > 0 ? (
        stores?.data.map((store) => {
          return (
            <tr key={uuidv4()}>
              <td>{store?.myshopify_domain}</td>
              <td>{store?.shopJson?.name}</td>
              <td>{store?.shopJson?.email}</td>
              <td>{getInstallationStatus(store?.myshopify_domain)}</td>
              <td>
                <button
                  className="view-btn"
                  onClick={() => handleNavigate(store._id)}
                >
                  View
                </button>
              </td>

              {storeStatus == "active" ? <td>{store.orderCount}</td> : null}
            </tr>
          );
        })
      ) : (
        <tr>
          <td colSpan="6">No stores found.</td>
        </tr>
      )}
      {loader && <OverlayLoader />}
    </>
  );
};

export default Homelist;
