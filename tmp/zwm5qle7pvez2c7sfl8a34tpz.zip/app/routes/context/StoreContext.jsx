import { useEffect, useMemo, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import { setStoreValue } from "../components/store/StoreSlice";
import APIServicess from "../services/ApiServices";

export default function StoreContext() {
  const dispatch = useDispatch();
  const storeValue = useSelector((state) => state.store);
  const apiCalledRef = useRef(false);

  const api = useMemo(() => new APIServicess(), []);

  useEffect(() => {
    if (!storeValue && !apiCalledRef.current) {
      apiCalledRef.current = true;

      if ("requestIdleCallback" in window) {
        window.requestIdleCallback(() => {
          api.getStoreData()
            .then((res) => {
              if (res?.status) {
                dispatch(setStoreValue(res?.result?.data || res?.result));
              }
            })
            .catch((err) => {
              console.error("Custom DB fetch failed", err);
            });
        });
      } else {
        // Fallback: 500ms delay before API call
        setTimeout(() => {
          api.getStoreData()
            .then((res) => {
              if (res?.status) {
                dispatch(setStoreValue(res?.result?.data || res?.result));
              }
            })
            .catch((err) => {
              console.error("Custom DB fetch failed", err);
            });
        }, 500);
      }
    }
  }, [storeValue, dispatch, api]);

  return null;
}