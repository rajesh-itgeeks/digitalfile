import { json } from "@remix-run/node";
import shopify from "../shopify.server";

//Loder for GraphQL
export const loader = async ({ params, request }) => {
  let slug = params["*"];
  const { admin, session } = await shopify.authenticate.admin(request);

  if (!admin || !session) {
    console.error("Authentication failed: admin or session is undefined");
    return json({ error: "Authentication failed" }, { status: 401 });
  }

  let data = { "status": false, "error": "routerNotFound" };

  //Cottection
 if (slug === "collections") {
  try {
    let result = [];
    let hasNextPage = true;
    let endCursor = null;

    while (hasNextPage) {
      const query = `
        {
          collections(first: 250${endCursor ? `, after: "${endCursor}"` : ""}) {
            pageInfo {
              hasNextPage
              endCursor
            }
            edges {
              node {
                id
                handle
                title
                updatedAt
                description
                ruleSet {
                  appliedDisjunctively
                  rules {
                    column
                    condition
                    relation
                  }
                }
              }
            }
          }
        }
      `;

      const response = await admin.graphql(query);
      const parsed = await response.json();

      const collections = parsed?.data?.collections?.edges || [];
      result.push(...collections.map(edge => edge.node));

      hasNextPage = parsed?.data?.collections?.pageInfo?.hasNextPage;
      endCursor = parsed?.data?.collections?.pageInfo?.endCursor;
    }

    return json({ status: true, data: result });

  } catch (error) {
    console.error("Error fetching collections:", error);
    return json({ error: "Failed to fetch collections: " + error.message }, { status: 500 });
  }
}

  if (slug === "segment") {
  try {
    let allSegments = [];
    let hasNextPage = true;
    let cursor = null;

    while (hasNextPage) {
      const query = `
        {
          segments(first: 250${cursor ? `, after: "${cursor}"` : ""}) {
            pageInfo {
              hasNextPage
              endCursor
            }
            nodes {
              creationDate
              id
              lastEditDate
              name
            }
          }
        }
      `;

      const response = await admin.graphql(query);
      const parsedResponse = await response.json();

      const segments = parsedResponse?.data?.segments?.nodes || [];
      allSegments.push(...segments);

      hasNextPage = parsedResponse?.data?.segments?.pageInfo?.hasNextPage;
      cursor = parsedResponse?.data?.segments?.pageInfo?.endCursor;
    }

    return json({ status: true, data: allSegments });

  } catch (error) {
    console.error("Error fetching customer segments:", error);
    return json({ error: "Failed to fetch customer segments" }, { status: 500 });
  }
}


  //Pagepre view
  if (slug === "pagepreview") {
    try {
      const query = `
        query {
          checkoutProfiles(query: "", first: 10) {
            nodes {
              id
              isPublished
            }
          }
        }
      `;

      const response = await admin.graphql(query);
      let parsedResponse = await response.json();
      // Ensure correct response structure
      let responseData = {
        status: true,
        data: parsedResponse?.data?.checkoutProfiles?.nodes || []
      };

      return json(responseData);
    } catch (error) {
      console.error("Error fetching checkout profiles:", error);
      return json({ error: "Failed to fetch checkout profiles" }, { status: 500 });
    }
  }

  //Online store id
  if (slug === "publication") {
    try {
      const query = `
        query {
          publications(first: 10) {
            edges {
              node {
                id
                name
              }
            }
          }
        }
      `;

      const response = await admin.graphql(query);
      let parsedResponse = await response.json();

      //Ensure correct response structure
      let responseData = {
        status: true,
        data: parsedResponse?.data?.publications?.edges || []
      };

      return json(responseData);
    } catch (error) {
      console.error("Error fetching checkout profiles:", error);
      return json({ error: "Failed to fetch online store id" }, { status: 500 });
    }
  }

  //Online store id
  if (slug === "store") {
    try {
      const query = `
        query {
          shop {
            name
            currencyCode
            currencyFormats {
              moneyFormat
              moneyWithCurrencyFormat
            }
          }
        }
      `;
  
      const response = await admin.graphql(query);
      let parsedResponse = await response.json();
  
      // Ensure correct response structure
      let responseData = {
        status: true,
        data: parsedResponse?.data?.shop || {},
      };
  
      return json(responseData);
    } catch (error) {
      console.error("Error fetching store details:", error);
      return json({ error: "Failed to fetch store details" }, { status: 500 });
    }
  }
  return json(data);
};
