import { createSlice } from '@reduxjs/toolkit';

//Upsell list slice for redux's
const upsellListSlice = createSlice({
  name: 'upsellList',
  initialState: null,
  reducers: {
    setUpsellList: (state, action) => {
      return action.payload;
    },
  },
});

export const { setUpsellList } = upsellListSlice.actions;
export default upsellListSlice.reducer;