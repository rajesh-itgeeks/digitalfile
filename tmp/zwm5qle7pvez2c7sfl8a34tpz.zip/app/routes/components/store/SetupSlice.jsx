import { createSlice } from '@reduxjs/toolkit';

//Setup slice for redux's
const setupSlice = createSlice({
  name: 'setup',
  initialState: null,
  reducers: {
    setSetup: (state, action) => {
      return action.payload;
    },
  },
});

export const { setSetup } = setupSlice.actions;
export default setupSlice.reducer;
