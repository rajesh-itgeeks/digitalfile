import { createSlice } from '@reduxjs/toolkit';

//Collections slice for redux's
const collectionsSlice = createSlice({
  name: 'collections',
  initialState: null,
  reducers: {
    setCollections: (state, action) => {
      return action.payload;
    },
  },
});

export const { setCollections } = collectionsSlice.actions;
export default collectionsSlice.reducer;
