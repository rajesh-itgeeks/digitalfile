import { createSlice } from '@reduxjs/toolkit';

//Page slice for redux's
const pageSlice = createSlice({
  name: 'pageId',
  initialState: null,
  reducers: {
    setPageId: (state, action) => {
      return action.payload;
    },
  },
});

export const { setPageId } = pageSlice.actions;
export default pageSlice.reducer;
