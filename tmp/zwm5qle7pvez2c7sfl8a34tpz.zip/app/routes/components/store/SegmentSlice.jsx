import { createSlice } from '@reduxjs/toolkit';

//Segment slice for redux's
const segmentSlice = createSlice({
  name: 'segment',
  initialState: null,
  reducers: {
    setSegment: (state, action) => {
      return action.payload;
    },
  },
});

export const { setSegment } = segmentSlice.actions;
export default segmentSlice.reducer;
