import { createSlice } from '@reduxjs/toolkit';

//Store slice for redux's
const storeSlice = createSlice({
  name: 'store',
  initialState: null,
  reducers: {
    setStoreValue: (state, action) => {
      return action.payload;
    },
  },
});

export const { setStoreValue } = storeSlice.actions;
export default storeSlice.reducer;
