import { createSlice } from '@reduxjs/toolkit';

//Page slice for redux's
const planStatusSlice = createSlice({
  name: 'planStatus',
  initialState: true,
  reducers: {
    setPlanStatus: (state, action) => {
      return action.payload;
    },
  },
});

export const { setPlanStatus } = planStatusSlice.actions;
export default planStatusSlice.reducer;