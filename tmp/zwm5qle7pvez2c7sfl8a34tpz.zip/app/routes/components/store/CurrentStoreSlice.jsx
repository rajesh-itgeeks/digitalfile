import { createSlice } from '@reduxjs/toolkit';

//Collections slice for redux's
const currentStoreSlice = createSlice({
  name: 'currentStore',
  initialState: null,
  reducers: {
    setCurrentStore: (state, action) => {
      return action.payload;
    },
  },
});

export const { setCurrentStore } = currentStoreSlice.actions;
export default currentStoreSlice.reducer;