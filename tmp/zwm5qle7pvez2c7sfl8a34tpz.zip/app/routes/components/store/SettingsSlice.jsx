import { createSlice } from '@reduxjs/toolkit';

//Settings slice for redux's
const settingsSlice = createSlice({
  name: 'settings',
  initialState: null,
  reducers: {
    setSettings: (state, action) => {
      return action.payload;
    },
  },
});

export const { setSettings } = settingsSlice.actions;
export default settingsSlice.reducer;