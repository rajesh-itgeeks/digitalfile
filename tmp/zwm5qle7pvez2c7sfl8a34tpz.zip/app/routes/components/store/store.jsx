import { configureStore } from "@reduxjs/toolkit";
import storeSlice from "./StoreSlice";
import settingsSlice from "./SettingsSlice";
import setCollections from "./CollectionsSlice";
import segmentSlice from "./SegmentSlice";
import setupSlice from "./SetupSlice";
import upsellListSlice from "./UpsellListSlice";
import pageSlice from "./PageSlice";
import publicationSlice from "./PublicationSlice";
import currentStoreSlice from "./CurrentStoreSlice";
import planStatusSlice from "./PlanStatusSlice";
import notificationSlice from "./NotificationSlice";
import invoicesSlice from "./InvoicesSlice";
import { combineReducers } from "redux";
import authSlice from './AuthSlice';

//Root reducer for redux's
const rootReducer = combineReducers({
  store: storeSlice,
  settings: settingsSlice,
  collections: setCollections,
  segment: segmentSlice,
  setup: setupSlice,
  upsellList: upsellListSlice,
  pageId: pageSlice,
  publication: publicationSlice,
  currentStore : currentStoreSlice,
  planStatus : planStatusSlice,
  notification : notificationSlice,
  invoices : invoicesSlice,
  auth: authSlice
});

//Store for redux's
const store = configureStore({
  reducer: rootReducer,
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: false,
    }),
});

export { store };
export default store;