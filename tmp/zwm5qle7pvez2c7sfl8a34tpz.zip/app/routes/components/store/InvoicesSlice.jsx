import { createSlice } from '@reduxjs/toolkit';

//Collections slice for redux's
const invoicesSlice = createSlice({
  name: 'invoices',
  initialState: null,
  reducers: {
    setInvoices: (state, action) => {
      return action.payload;
    },
  },
});

export const { setInvoices } = invoicesSlice.actions;
export default invoicesSlice.reducer;