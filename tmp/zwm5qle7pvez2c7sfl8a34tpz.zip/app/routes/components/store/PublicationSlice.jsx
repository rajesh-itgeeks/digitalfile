import { createSlice } from '@reduxjs/toolkit';

//Publication slice for redux's
const publicationSlice = createSlice({
  name: 'publication',
  initialState: null,
  reducers: {
    setPublication: (state, action) => {
      return action.payload;
    },
  },
});

export const { setPublication } = publicationSlice.actions;
export default publicationSlice.reducer;