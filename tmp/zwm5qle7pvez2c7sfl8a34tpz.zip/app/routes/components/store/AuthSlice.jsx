import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  isLoggedIn:
    typeof window !== "undefined" && localStorage.getItem("login") === "true",
  shop:
    typeof window !== "undefined" && localStorage.getItem("shop"),
};

const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    login: (state) => {
      state.isLoggedIn = true;
      if (typeof window !== "undefined") {
        localStorage.setItem("login", "true");
      }
    },
    logout: (state) => {
      state.isLoggedIn = false;
      if (typeof window !== "undefined") {
        localStorage.removeItem("login");
      }
    },
  },
});

export const { login, logout } = authSlice.actions;
export default authSlice.reducer;
