import { Card, Box, BlockStack, InlineGrid, Image, Text, InlineStack, Link } from '@shopify/polaris';
import { useTranslation } from 'react-i18next';
import { call, visit, faq, suggest } from "../common/Images";

//Support
export default function Support() {
    const { t } = useTranslation();
    const Supports = t("Support.list", { returnObjects: true });
    const iconMap = [call, visit, faq, suggest];

    return (
        <>
            <Box as={'div'}>
                <InlineGrid gap="400" columns={{ "xs": 1, "sm":2, "md":2, "lg": 2 }}>                    
                    {
                        Supports.map((support, index) => (
                            <Card key={index}>
                                <InlineStack wrap={false} gap="400">
                                    <Box as={'div'}>
                                        <Image source={iconMap[index]} alt={support.title} />
                                    </Box>
                                    <BlockStack gap="200">
                                        <Text variant="headingSm" as="h6" fontWeight="medium">
                                            <Link url={
                                                index== 0 ? 'https://calendar.app.google/RPg4bzNQaj2AzXP57'
                                                : index== 1 ? 'https://www.accounteditor.com/help-guide'
                                                : index== 2 ? 'https://www.accounteditor.com/faqs'
                                                : 'https://www.accounteditor.com/contact-us'
                                            }
                                            target='_blank'
                                            >{support.title}</Link>
                                        </Text>                                        
                                        <Text variant="headingXs" as="span" fontWeight="regular">{support.description}</Text>
                                    </BlockStack>
                                </InlineStack>
                            </Card>
                        ))
                    }
                </InlineGrid>
            </Box>
        </>
    );
}