import { useState, useEffect } from 'react';
import { Card, Box, BlockStack, InlineGrid, Text, Button } from '@shopify/polaris';
import { useTranslation } from 'react-i18next';

//Settings
export default function Settings({ storeValue }) {
    const { t } = useTranslation();
    const Settings = t("Index.settings", { returnObjects: true });
    const [columans, setColumans] = useState(2);

    useEffect(() => {
        let hidingFeatures = storeValue?.hidingFeatures;
        const hasUpsellRules = hidingFeatures?.includes('upsellRules');
        setColumans(hasUpsellRules ? 2 : 3)
    }, [storeValue]);

    return (
        <>
            <Box as={'div'}>
                <InlineGrid gap="400" columns={{ "xs": 1, "lg": columans }}>
                    {
                        Settings.slice(0, columans).map((setting, index) => (
                            <Card key={index}>
                                <BlockStack gap="200">
                                    <Text variant="headingSm" as="h6">{setting.title}</Text>
                                    <Box as={'p'} paddingInlineEnd="1200">
                                        <Text variant="headingXs" as="span" fontWeight="regular">{setting.description}</Text>
                                    </Box>
                                    <Box as={'div'}>
                                        <Button url={`/app/settings?type=${(index === 0) ? "editing" : (index === 1) ? "cancel" : "upsell"}`}>
                                            {setting.btn}
                                        </Button>
                                    </Box>
                                </BlockStack>
                            </Card>
                        ))
                    }
                </InlineGrid>
            </Box>
        </>
    );
}