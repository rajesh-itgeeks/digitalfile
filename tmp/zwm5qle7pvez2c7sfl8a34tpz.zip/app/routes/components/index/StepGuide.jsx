import { useState, useEffect, useCallback } from 'react';
import { Card, Box, BlockStack, ProgressBar, Text, Button, InlineStack, Divider, useBreakpoints } from '@shopify/polaris';
import { ChevronDownIcon, ChevronUpIcon } from '@shopify/polaris-icons';
import { useTranslation } from 'react-i18next';
import CancelOrder from "../common/svgs/CancelOrder";
import ChoosePlan from "../common/svgs/ChoosePlan";
import OrderConfirmed from "../common/svgs/OrderConfirmed";
import Thankyou from "../common/svgs/Thankyou";

//Step guide
export default function StepGuide({ setup, pageId }) {
    const [steps, setSteps] = useState(0);
    const [totalProgress, setTotalProgress] = useState(0);
    const [stepGuideActive, setStepGuideActive] = useState(true);
    const [stepOne, setStepOne] = useState(false);
    const [stepTwo, setStepTwo] = useState(false);
    const [stepThree, setStepThree] = useState(false);
    const [stepFour, setStepFour] = useState(false);
    const [shopName, setShopName] = useState('');
    const [page, setPage] = useState('');
    const { t } = useTranslation();
    const { lgUp, smDown } = useBreakpoints();

    //Check if setup is completed
    useEffect(() => {
        // if (setup) {
        //     const booleanValues = [
        //         setup?.orderEditingFeature,
        //         setup?.editingWindow,
        //         setup?.smartCollections
        //         // setup?.plan,
        //     ];
        //     const trueCount = booleanValues.filter(value => value === true).length;
        //     const average = (trueCount / booleanValues.length) * 100;
        //     setTotalProgress(average.toFixed(2));
        //     setStepOne(setup?.orderEditingFeature);
        //     setStepTwo(setup?.editingWindow);
        //     setStepThree(setup?.smartCollections);
        //     setStepFour(setup?.plan);
        // }

        const shopifyConfig = window?.shopify?.config;
        let shop = shopifyConfig.shop;
        const shopName = shop.replace(".myshopify.com", "");
        setShopName(shopName);
        setPage(pageId);
    }, [setup, pageId]);

    //Load data from json file
    const guides = t("Index.setup.guides", { returnObjects: true });

    //Setup guide handler
    const setupGuideHandler = useCallback((step) => {
        setSteps(step);
    }, []);    

    return (
        <>
            <Card>
                <Box as={'div'}>
                    <BlockStack gap={300}>
                        <Box as={'div'}>
                            <InlineStack wrap={false} align="space-between">
                                <Text variant="headingLg" as="h4">{t("Index.setup.title")}</Text>
                                <Button icon={stepGuideActive ? ChevronUpIcon : ChevronDownIcon} variant="plain" onClick={() => setStepGuideActive(!stepGuideActive)} />
                            </InlineStack>
                        </Box>
                        <Box>
                            <BlockStack gap="200">
                                <Text variant="headingSm" as="p" fontWeight="regular">{t("Index.setup.description")}</Text>
                                <Box as={'div'}>
                                    <InlineStack wrap={false} blockAlign="center" gap="200">
                                        <Text variant="headingSm" as="p" fontWeight="regular">{(totalProgress == 0) ? 0 : ((totalProgress == 33.33) ? 1 : ((totalProgress == 66.67) ? 2 : ((totalProgress == 100) ? 3 : 4)))} {t("Index.setup.of")} 3 {t("Index.setup.task")}</Text>
                                        <Box as={'div'} width="125px">
                                            <ProgressBar progress={totalProgress} size="small" tone="primary" />
                                        </Box>
                                    </InlineStack>
                                </Box>
                            </BlockStack>
                        </Box>
                        {
                            stepGuideActive && <>
                                <Box className="motion-appear-above-animation">
                                    <BlockStack gap="300">
                                        <Divider />
                                        <Box as={'div'}>
                                            <BlockStack gap="200">
                                                {
                                                    guides.slice(0, 3).map((guide, index) => (
                                                        <Box as={'div'} key={index} padding="200" background={steps == index ? "bg" : ""} borderRadius="200">
                                                            <BlockStack gap="200">
                                                                <InlineStack align="space-between">
                                                                    <Box as={'div'} className="setup-guide-full">
                                                                        <Button variant="plain" fullWidth textAlign="start" tone="success" onClick={() => setupGuideHandler(index)}>
                                                                            <InlineStack as="span" blockAlign={smDown ? "start" : "center"} wrap={false} gap="300" align="start">
                                                                                {
                                                                                    (index == 0 && stepOne || index == 1 && stepTwo || stepThree && index == 2 || index == 3 && stepFour) ? <svg width={(index == 0 && smDown) ? "40" : "20"} height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                                        <path d="M13.28 9.03003C13.4125 8.88785 13.4846 8.69981 13.4812 8.50551C13.4778 8.31121 13.3991 8.12582 13.2617 7.98841C13.1242 7.85099 12.9389 7.77228 12.7446 7.76885C12.5503 7.76543 12.3622 7.83755 12.22 7.97003L9.25003 10.94L8.03003 9.72003C7.88785 9.58755 7.69981 9.51543 7.50551 9.51885C7.31121 9.52228 7.12582 9.601 6.98841 9.73841C6.85099 9.87582 6.77228 10.0612 6.76885 10.2555C6.76543 10.4498 6.83755 10.6379 6.97003 10.78L8.72003 12.53C8.86066 12.6705 9.05128 12.7494 9.25003 12.7494C9.44878 12.7494 9.6394 12.6705 9.78003 12.53L13.28 9.03003Z" fill="#108060" />
                                                                                        <path fillRule="evenodd" clipRule="evenodd" d="M17 10C17 10.9193 16.8189 11.8295 16.4672 12.6788C16.1154 13.5281 15.5998 14.2997 14.9497 14.9497C14.2997 15.5998 13.5281 16.1154 12.6788 16.4672C11.8295 16.8189 10.9193 17 10 17C9.08075 17 8.1705 16.8189 7.32122 16.4672C6.47194 16.1154 5.70026 15.5998 5.05025 14.9497C4.40024 14.2997 3.88463 13.5281 3.53284 12.6788C3.18106 11.8295 3 10.9193 3 10C3 8.14348 3.7375 6.36301 5.05025 5.05025C6.36301 3.7375 8.14348 3 10 3C11.8565 3 13.637 3.7375 14.9497 5.05025C16.2625 6.36301 17 8.14348 17 10ZM15.5 10C15.5 11.4587 14.9205 12.8576 13.8891 13.8891C12.8576 14.9205 11.4587 15.5 10 15.5C8.54131 15.5 7.14236 14.9205 6.11091 13.8891C5.07946 12.8576 4.5 11.4587 4.5 10C4.5 8.54131 5.07946 7.14236 6.11091 6.11091C7.14236 5.07946 8.54131 4.5 10 4.5C11.4587 4.5 12.8576 5.07946 13.8891 6.11091C14.9205 7.14236 15.5 8.54131 15.5 10Z" fill="#108060" />
                                                                                    </svg> : <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                                        <path fillRule="evenodd" clipRule="evenodd" d="M8.63461 3.13322C9.07675 3.04575 9.53337 3 10 3C10.4666 3 10.9232 3.04575 11.3654 3.13322C11.7324 3.20583 11.9711 3.56221 11.8985 3.92923C11.8259 4.29624 11.4695 4.53491 11.1025 4.4623C10.7464 4.39187 10.3779 4.35484 10 4.35484C9.62212 4.35484 9.25356 4.39187 8.89754 4.4623C8.53052 4.53491 8.17414 4.29625 8.10153 3.92923C8.02893 3.56221 8.26759 3.20583 8.63461 3.13322ZM12.95 4.3655C13.1581 4.05461 13.5789 3.97131 13.8898 4.17945C14.6529 4.69031 15.3097 5.34715 15.8206 6.11021C16.0287 6.4211 15.9454 6.84185 15.6345 7.04999C15.3236 7.25812 14.9029 7.17483 14.6947 6.86394C14.2824 6.24803 13.752 5.71761 13.1361 5.30527C12.8252 5.09714 12.7419 4.67639 12.95 4.3655ZM7.04999 4.3655C7.25812 4.67639 7.17483 5.09714 6.86394 5.30527C6.24803 5.71761 5.71761 6.24803 5.30527 6.86394C5.09714 7.17483 4.67639 7.25812 4.3655 7.04999C4.05461 6.84185 3.97131 6.4211 4.17945 6.11021C4.69031 5.34715 5.34715 4.69031 6.11021 4.17945C6.4211 3.97131 6.84185 4.05461 7.04999 4.3655ZM16.0708 8.10153C16.4378 8.02893 16.7942 8.26759 16.8668 8.63461C16.9542 9.07675 17 9.53337 17 10C17 10.4666 16.9542 10.9232 16.8668 11.3654C16.7942 11.7324 16.4378 11.9711 16.0708 11.8985C15.7038 11.8259 15.4651 11.4695 15.5377 11.1025C15.6081 10.7464 15.6452 10.3779 15.6452 10C15.6452 9.62212 15.6081 9.25356 15.5377 8.89754C15.4651 8.53052 15.7038 8.17414 16.0708 8.10153ZM3.92923 8.10153C4.29624 8.17414 4.53491 8.53052 4.4623 8.89754C4.39187 9.25356 4.35484 9.62212 4.35484 10C4.35484 10.3779 4.39187 10.7464 4.4623 11.1025C4.53491 11.4695 4.29625 11.8259 3.92923 11.8985C3.56221 11.9711 3.20583 11.7324 3.13322 11.3654C3.04575 10.9232 3 10.4666 3 10C3 9.53337 3.04575 9.07675 3.13322 8.63461C3.20583 8.26759 3.56221 8.02893 3.92923 8.10153ZM15.6345 12.95C15.9454 13.1581 16.0287 13.5789 15.8206 13.8898C15.3097 14.6529 14.6529 15.3097 13.8898 15.8206C13.5789 16.0287 13.1581 15.9454 12.95 15.6345C12.7419 15.3236 12.8252 14.9029 13.1361 14.6947C13.752 14.2824 14.2824 13.752 14.6947 13.1361C14.9029 12.8252 15.3236 12.7419 15.6345 12.95ZM4.3655 12.95C4.67639 12.7419 5.09714 12.8252 5.30527 13.1361C5.71761 13.752 6.24803 14.2824 6.86394 14.6947C7.17483 14.9029 7.25812 15.3236 7.04999 15.6345C6.84185 15.9454 6.4211 16.0287 6.11021 15.8206C5.34715 15.3097 4.69031 14.6529 4.17945 13.8898C3.97131 13.5789 4.05461 13.1581 4.3655 12.95ZM8.10153 16.0708C8.17414 15.7038 8.53052 15.4651 8.89754 15.5377C9.25356 15.6081 9.62212 15.6452 10 15.6452C10.3779 15.6452 10.7464 15.6081 11.1025 15.5377C11.4695 15.4651 11.8259 15.7038 11.8985 16.0708C11.9711 16.4378 11.7324 16.7942 11.3654 16.8668C10.9232 16.9542 10.4666 17 10 17C9.53337 17 9.07675 16.9542 8.63461 16.8668C8.26759 16.7942 8.02893 16.4378 8.10153 16.0708Z" fill="#4A4A4A" />
                                                                                    </svg>
                                                                                }
                                                                                <Text variant="headingSm" as="p" fontWeight="medium" tone="base">{guide.title}</Text>
                                                                            </InlineStack>
                                                                        </Button>
                                                                        {
                                                                            steps == index && <Box as={'div'} className="motion-appear-above-animation">
                                                                                <Box as={'div'} paddingInlineStart="800">
                                                                                    <InlineStack wrap={false} blockAlign="start" align="start">
                                                                                        <BlockStack gap="200">
                                                                                            <Text variant="headingSm" as="p" tone="subdued" fontWeight="regular">{guide.description}</Text>
                                                                                            <Box as={'div'}>
                                                                                                <Button textAlign="start" variant="primary"
                                                                                                    url={
                                                                                                        index == 0
                                                                                                            ? `https://admin.shopify.com/store/${shopName}/settings/checkout/editor/profiles/${page}?page=thank-you&context=apps`
                                                                                                            : index == 1
                                                                                                                ? `/app/settings?type=editing`
                                                                                                                : index == 2
                                                                                                                    ? `/app/settings?type=cancel`
                                                                                                                    : `/app/pricing`
                                                                                                    }
                                                                                                    target={
                                                                                                        index == 0 ? "_blank" : "_self"
                                                                                                    }
                                                                                                >{guide.btn}</Button>
                                                                                            </Box>
                                                                                        </BlockStack>
                                                                                    </InlineStack>
                                                                                </Box>
                                                                            </Box>
                                                                        }
                                                                    </Box>
                                                                    {
                                                                        (steps === index && lgUp) &&
                                                                        (
                                                                            index === 0 ? <Thankyou /> :
                                                                            index === 1 ? <OrderConfirmed /> :
                                                                            index === 2 ? <CancelOrder /> :
                                                                            index === 3 ? <ChoosePlan /> :
                                                                            null
                                                                        )
                                                                    }
                                                                </InlineStack>
                                                            </BlockStack>
                                                        </Box>
                                                    ))
                                                }
                                            </BlockStack>
                                        </Box>
                                    </BlockStack>
                                </Box>
                            </>
                        }
                    </BlockStack>
                </Box>
            </Card>
        </>
    )
}