import { BlockStack, Box, InlineGrid, SkeletonBodyText, Card } from "@shopify/polaris";

//Skeleton
export default function Skeleton() {
    return (
        <div style={{ width: "100%", margin: "auto", maxWidth: "950px" }}>
            <Box>
                <BlockStack gap="400">
                    <Card>
                        <BlockStack gap="400">
                            <SkeletonBodyText />
                            <SkeletonBodyText />
                            <SkeletonBodyText />
                        </BlockStack>
                    </Card>
                    <InlineGrid columns={3} gap="400">
                        <Card>
                            <SkeletonBodyText />
                        </Card>
                        <Card>
                            <SkeletonBodyText />
                        </Card>
                        <Card>
                            <SkeletonBodyText />
                        </Card>
                    </InlineGrid>
                    <InlineGrid columns={2} gap="400">
                        <Card>
                            <SkeletonBodyText />
                        </Card>
                        <Card>
                            <SkeletonBodyText />
                        </Card>
                    </InlineGrid>
                </BlockStack>
            </Box>
        </div>
    );
}
