import { BlockStack, Box, Button, InlineGrid, DatePicker, InlineStack, OptionList, Popover, TextField, useBreakpoints, Scrollable, Icon, Select, Card, Text } from '@shopify/polaris';
import { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { CalendarIcon, ArrowRightIcon } from '@shopify/polaris-icons';
import { useTranslation } from "react-i18next";
import { useSelector } from "react-redux";
import currencyJson from "../common/currencysymbols.json";
import APIServicess from "../../services/ApiServices";

export default function Statistic({ storeValue, planStatus }) {
    const { t } = useTranslation();
    const { mdDown, lgUp } = useBreakpoints();
    const shouldShowMultiMonth = lgUp;
    const today = new Date(new Date().setHours(0, 0, 0, 0));
    const yesterday = new Date(new Date(today).setDate(today.getDate() - 1));
    const currentStore = useSelector((state) => state.currentStore);
    
    // Memoize API service instance
    const APIServ = useMemo(() => new APIServicess(), []);
    
    // State management
    const [loading, setLoading] = useState(true);
    const [columans, setColumans] = useState(3);
    const [stats, setStats] = useState({});
    const [symbol, setSymbol] = useState('');
    const [upsellState, setUpsellState] = useState(false);
    const [popoverActive, setPopoverActive] = useState(false);
    const [inputValues, setInputValues] = useState({});
    const datePickerRef = useRef(null);
    const apiCallInProgress = useRef(false);

    // Date ranges - memoized to prevent recreation on every render
    const ranges = useMemo(() => [
        {
            title: t("Index.Statistic.today"),
            alias: "today",
            period: { since: today, until: today },
        },
        {
            title: t("Index.Statistic.yesterday"),
            alias: "yesterday",
            period: { since: yesterday, until: yesterday },
        },
        {
            title: t("Index.Statistic.last7days"),
            alias: "last7days",
            period: {
                since: new Date(new Date(today).setDate(today.getDate() - 7)),
                until: yesterday,
            },
        },
        {
            title: t("Index.Statistic.last30Days"),
            alias: "last30days",
            period: {
                since: new Date(new Date(today).setDate(today.getDate() - 30)),
                until: yesterday,
            },
        },
        {
            title: t("Index.Statistic.thisMonth"),
            alias: "thisMonth",
            period: {
                since: new Date(today.getFullYear(), today.getMonth(), 1),
                until: new Date(today.getFullYear(), today.getMonth() + 1, 0)
            },
        },
        {
            title: t("Index.Statistic.lastMonth"),
            alias: "lastMonth",
            period: {
                since: new Date(today.getFullYear(), today.getMonth() - 1, 1),
                until: new Date(today.getFullYear(), today.getMonth(), 0)
            },
        }
    ], [t, today, yesterday]);

    // Active date range state
    const [activeDateRange, setActiveDateRange] = useState(ranges[0]);
    const [{ month, year }, setDate] = useState({
        month: activeDateRange.period.since.getMonth(),
        year: activeDateRange.period.since.getFullYear(),
    });

    // Initialize component
    useEffect(() => {
        if (storeValue?.currency) {
            setSymbol(currencyJson[storeValue.currency] || '$');
        }
        
        if (currentStore) {
            setLoading(false);
        }

        const hidingFeatures = storeValue?.hidingFeatures;
        const hasUpsellRules = hidingFeatures?.includes('upsellRules');
        setColumans((!hasUpsellRules && planStatus) ? 4 : 3);
        setUpsellState(hasUpsellRules);

        // Initial data fetch
        getStatistics({
            startDate: formatDate(activeDateRange.period.since),
            endDate: formatDate(activeDateRange.period.until)
        });
    }, [storeValue, currentStore]);

    // Date formatting utilities
    const formatDate = useCallback((date) => {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }, []);

    // Statistics fetching with debounce and duplicate call prevention
    const getStatistics = useCallback(async (data) => {
        if (apiCallInProgress.current) return;
        
        try {
            apiCallInProgress.current = true;
            const datas = await APIServ.getStatistics(data);
            if (datas.status) {
                setStats(datas.result);
            }
        } catch (error) {
            console.error("Error fetching data:", error);
        } finally {
            apiCallInProgress.current = false;
        }
    }, [APIServ]);

    // Handle date range changes
    useEffect(() => {
        if (!activeDateRange) return;

        setInputValues({
            since: formatDate(activeDateRange.period.since),
            until: formatDate(activeDateRange.period.until),
        });

        // Update calendar view if needed
        const monthDifference = (activeDateRange.period.until.getFullYear() - year) * 12 + 
                               (activeDateRange.period.until.getMonth() - month);
        if (monthDifference > 1 || monthDifference < 0) {
            setDate({
                month: activeDateRange.period.until.getMonth(),
                year: activeDateRange.period.until.getFullYear(),
            });
        }

        // Auto-fetch for non-custom ranges
        if (activeDateRange.alias !== 'custom') {
            getStatistics({
                startDate: formatDate(activeDateRange.period.since),
                endDate: formatDate(activeDateRange.period.until)
            });
        }
    }, [activeDateRange, formatDate, getStatistics, month, year]);

    // Date picker handlers
    const handleStartInputValueChange = (value) => {
        setInputValues(prev => ({ ...prev, since: value }));
        if (isValidDate(value)) {
            const newSince = parseYearMonthDayDateString(value);
            setActiveDateRange(prev => ({
                ...prev,
                period: {
                    since: newSince,
                    until: newSince <= prev.period.until ? prev.period.until : newSince
                }
            }));
        }
    };

    const handleEndInputValueChange = (value) => {
        setInputValues(prev => ({ ...prev, until: value }));
        if (isValidDate(value)) {
            const newUntil = parseYearMonthDayDateString(value);
            setActiveDateRange(prev => ({
                ...prev,
                period: {
                    since: newUntil >= prev.period.since ? prev.period.since : newUntil,
                    until: newUntil
                }
            }));
        }
    };

    // Date validation utilities
    const VALID_YYYY_MM_DD_DATE_REGEX = /^\d{4}-\d{1,2}-\d{1,2}/;
    const isValidDate = (date) => {
        return date.length === 10 && 
               VALID_YYYY_MM_DD_DATE_REGEX.test(date) && 
               !isNaN(new Date(date).getDate());
    };

    const parseYearMonthDayDateString = (input) => {
        const [year, month, day] = input.split("-");
        return new Date(Number(year), Number(month) - 1, Number(day));
    };

    // UI rendering
    const buttonValue = activeDateRange.title === "Custom"
        ? `${activeDateRange.period.since.toDateString()} - ${activeDateRange.period.until.toDateString()}`
        : activeDateRange.title;

    return (
        <Box>
            <BlockStack gap="400">
                {/* Date Picker Popover */}
                <Popover
                    active={popoverActive}
                    autofocusTarget="none"
                    preferredAlignment="left"
                    preferredPosition="below"
                    fluidContent
                    sectioned={false}
                    fullHeight
                    activator={
                        <Button
                            size="slim"
                            icon={CalendarIcon}
                            onClick={() => setPopoverActive(!popoverActive)}
                        >
                            {buttonValue}
                        </Button>
                    }
                    onClose={() => setPopoverActive(false)}
                >
                    <Popover.Pane fixed>
                        <InlineGrid columns={{ xs: "1fr", md: "max-content max-content" }} gap={0}>
                            <Box maxWidth={mdDown ? "516px" : "212px"} width="100%" padding={{ xs: 500, md: 0 }} paddingBlockEnd={{ xs: 100, md: 0 }}>
                                {mdDown ? (
                                    <Select
                                        label="dateRangeLabel"
                                        labelHidden
                                        onChange={(value) => {
                                            const result = ranges.find(({ title, alias }) => 
                                                title === value || alias === value
                                            );
                                            setActiveDateRange(result);
                                        }}
                                        value={activeDateRange?.title || activeDateRange?.alias || ""}
                                        options={ranges.map(({ alias, title }) => title || alias)}
                                    />
                                ) : (
                                    <Scrollable style={{ height: "260px" }}>
                                        <OptionList
                                            options={ranges.map((range) => ({
                                                value: range.alias,
                                                label: range.title,
                                            }))}
                                            selected={activeDateRange.alias}
                                            onChange={(value) => {
                                                setActiveDateRange(ranges.find(range => range.alias === value[0]));
                                            }}
                                        />
                                    </Scrollable>
                                )}
                            </Box>
                            <Box padding={{ xs: 200 }} paddingBlockEnd={{ xs: 100 }} maxWidth={mdDown ? "320px" : "516px"}>
                                <BlockStack gap="200">
                                    <InlineStack gap="200">
                                        <TextField
                                            role="combobox"
                                            label="Since"
                                            labelHidden
                                            prefix={<Icon source={CalendarIcon} />}
                                            value={inputValues.since}
                                            onChange={handleStartInputValueChange}
                                            onBlur={({ relatedTarget }) => {
                                                if (relatedTarget && !nodeContainsDescendant(datePickerRef.current, relatedTarget)) {
                                                    setPopoverActive(false);
                                                }
                                            }}
                                            autoComplete="off"
                                            disabled
                                        />
                                        <Icon source={ArrowRightIcon} />
                                        <TextField
                                            role="combobox"
                                            label="Until"
                                            labelHidden
                                            prefix={<Icon source={CalendarIcon} />}
                                            value={inputValues.until}
                                            onChange={handleEndInputValueChange}
                                            onBlur={({ relatedTarget }) => {
                                                if (relatedTarget && !nodeContainsDescendant(datePickerRef.current, relatedTarget)) {
                                                    setPopoverActive(false);
                                                }
                                            }}
                                            autoComplete="off"
                                            disabled
                                        />
                                    </InlineStack>
                                    <DatePicker
                                        month={month}
                                        year={year}
                                        selected={{
                                            start: activeDateRange.period.since,
                                            end: activeDateRange.period.until,
                                        }}
                                        onMonthChange={(month, year) => setDate({ month, year })}
                                        onChange={({ start, end }) => {
                                            const newRange = ranges.find(range => 
                                                range.period.since.valueOf() === start.valueOf() &&
                                                range.period.until.valueOf() === end.valueOf()
                                            ) || {
                                                alias: "custom",
                                                title: "Custom",
                                                period: { since: start, until: end },
                                            };
                                            setActiveDateRange(newRange);
                                        }}
                                        multiMonth={shouldShowMultiMonth}
                                        allowRange
                                        disableDatesAfter={new Date()}
                                    />
                                </BlockStack>
                            </Box>
                        </InlineGrid>
                    </Popover.Pane>
                    <Popover.Pane fixed>
                        <Popover.Section>
                            <InlineStack align="end" gap="100">
                                <Button onClick={() => setPopoverActive(false)}>
                                    {t("Index.Statistic.cancel")}
                                </Button>
                                <Button variant="primary" onClick={() => {
                                    setPopoverActive(false);
                                    getStatistics({
                                        startDate: formatDate(activeDateRange.period.since),
                                        endDate: formatDate(activeDateRange.period.until)
                                    });
                                }}>
                                    {t("Index.Statistic.apply")}
                                </Button>
                            </InlineStack>
                        </Popover.Section>
                    </Popover.Pane>
                </Popover>

                {/* Statistics Cards */}
                <InlineGrid gap="400" columns={{ xs: 1, sm: 2, md:columans, lg: columans }}>
                    <StatCard 
                        title={t("Index.Statistic.ordersEdit")} 
                        value={stats?.orderEdits || 0} 
                    />
                    <StatCard 
                        title={t("Index.Statistic.appAttributedRevenue")} 
                        value={`${symbol}${stats?.revenue !== undefined 
                            ? new Intl.NumberFormat('en-US', { 
                                minimumFractionDigits: 1, 
                                maximumFractionDigits: 1 
                              }).format(stats.revenue)
                            : 0.00}`} 
                    />
                    <StatCard 
                        title={t("Index.Statistic.ordersCancelled")} 
                        value={stats?.cancelledOrders || 0} 
                    />
                    {columans === 4 && (
                        <StatCard 
                            title={t("Index.Statistic.upsellRevenue")} 
                            value={`${symbol}${stats?.discountAmount !== undefined
                                ? new Intl.NumberFormat('en-US', { 
                                    minimumFractionDigits: 1, 
                                    maximumFractionDigits: 1 
                                  }).format(stats.discountAmount)
                                : 0.00}`} 
                        />
                    )}
                </InlineGrid>
            </BlockStack>
        </Box>
    );
}

// Helper component for statistic cards
function StatCard({ title, value }) {
    return (
        <Card>
            <BlockStack gap="200">
                <Box borderColor="bg-surface-emphasis-active" borderStyle="dashed" borderBlockEndWidth="025">
                    <Text variant="headingMd" as="h6">{title}</Text>
                </Box>
                <Text variant="headingLg" as="h6">{value}</Text>
            </BlockStack>
        </Card>
    );
}

// Helper function for DOM containment check
function nodeContainsDescendant(rootNode, descendant) {
    if (!rootNode || !descendant) return false;
    if (rootNode === descendant) return true;
    
    let parent = descendant.parentNode;
    while (parent) {
        if (parent === rootNode) return true;
        parent = parent.parentNode;
    }
    return false;
}