import { Image } from "@shopify/polaris";
export default function Banner() {
    return (
        <Image src="https://dov09fhkljn5r.cloudfront.net/test-image/dashboardImage.png" loading="lazy" alt="banner"/>
    )
}