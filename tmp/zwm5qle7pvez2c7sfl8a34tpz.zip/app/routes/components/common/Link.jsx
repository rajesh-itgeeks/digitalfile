import { Link as RemixLink, useNavigate } from "@remix-run/react";
import React from "react";

export function Link({ children, to, ...rest }) {
  const navigate = useNavigate();

  const handleNavigation = React.useCallback(
    (to) => {
      history.pushState({}, "", to);
      navigate(to);
    },
    [navigate]
  );

  return (
    <RemixLink
      to={to}
      {...rest}
      onClick={(e) => {
        e.preventDefault();
        handleNavigation(to);
      }}
    >
      {children}
    </RemixLink>
  );
}
