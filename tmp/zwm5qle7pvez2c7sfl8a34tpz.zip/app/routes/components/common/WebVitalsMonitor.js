import { useEffect } from "react";
import { getLCP, getFID, getCLS, getFCP, getTTFB } from "web-vitals";

const WebVitalsMonitor = ({ shop }) => {
  useEffect(() => {
    // 1️⃣ Shopify shop check karein
    const storedShop = localStorage.getItem("shopify_shop");

    if (!shop && !storedShop) return;

    // 2️⃣ Local storage me shop save karein
    if (shop) {
      localStorage.setItem("shopify_shop", shop);
    }

    const apiHandle = window.location.origin;
    const monitorUrl = `${apiHandle}/api/external/webhooks/web-vitals-matrics`;
    let metrics = [];
    console.log(apiHandle, "=============");
    function sendToAnalytics(metric) {
      metrics.push({
        name: metric.name,
        value: metric.value,
        id: metric.id,
        delta: metric.delta,
      });
      
      if (metrics.length >= 5) {
        let sendData = { shop: shop || storedShop, metrics };
        console.log("📡 Sending Web Vitals Data:", sendData);

        fetch(monitorUrl, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(sendData),
        })
          .then((res) => res.json())
          .then((data) => console.log("✅ DB Entry Success:", data))
          .catch((err) => console.error("❌ DB Entry Error:", err));

        metrics = [];
      }
    }

    // 3️⃣ Web Vitals Start (Delay of 3s to ensure app setup is complete)
      getLCP(sendToAnalytics);
      getFID(sendToAnalytics);
      getCLS(sendToAnalytics);
      getFCP(sendToAnalytics);
      getTTFB(sendToAnalytics);

    return () => {
      metrics = [];
    };
  }, [shop]);

  return null; // No UI needed
};

export default WebVitalsMonitor;
