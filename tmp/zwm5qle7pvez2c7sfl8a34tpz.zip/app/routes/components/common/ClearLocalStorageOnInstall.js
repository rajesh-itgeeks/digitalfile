import { useEffect } from "react";
import { useSearchParams } from "@remix-run/react";
import { persistor } from "../store/store"; // Import Redux Persistor

export default function ClearLocalStorageOnInstall() {
  const [searchParams] = useSearchParams();
  const shop = searchParams.get("shop"); // Shopify sends this on install

  useEffect(() => {
    if (!shop) return; // Ensure shop parameter exists

    const isFirstInstall = sessionStorage.getItem("app_first_install") === "true"; // ✅ Fix: Convert to Boolean

    if (!isFirstInstall) {
      console.log("🔹 Clearing LocalStorage & Redux Persist on First Install...");

      localStorage.clear(); // ✅ Clears all stored data
      persistor.purge().then(() => {
        console.log("✅ Redux Persist Purged");
        persistor.flush().then(() => {
          console.log("✅ Redux Persist Flushed");

          localStorage.setItem("app_installed", "true");
          sessionStorage.setItem("app_first_install", "true"); // ✅ Prevent clearing on refresh
        });
      });
    }
  }, [shop]);

  return null;
}
