import { Banner } from '@shopify/polaris';
import React, { useState } from "react";
import { useTranslation } from "react-i18next";

//Footer 
export default function PaymentFailed() {
    const { t } = useTranslation();
    const [active, setActive] = useState(true);
    return (
        <>
            { active &&  <Banner
                title={t("Index.PaymentFailed.title")}
                tone="warning"
                action={{content: t("Index.PaymentFailed.btn1"), url: ''}}
                secondaryAction={{content: t("Index.PaymentFailed.btn2"), url: ''}}
                onDismiss={() => setActive(!active)}
                >
                    <p>{t("Index.PaymentFailed.description")}</p>
                </Banner>            
            }
        </>        
    )
}