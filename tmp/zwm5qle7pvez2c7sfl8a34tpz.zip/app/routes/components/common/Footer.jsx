import { useEffect } from 'react';
import { Box, Link, Text } from '@shopify/polaris';
import Intercom from '@intercom/messenger-js-sdk';
import { useSelector } from 'react-redux';

export default function Footer() {
  const storeValue = useSelector((state) => state.store);

  useEffect(() => {
    // Static Intercom settings
    Intercom({
      app_id: 'wm481ncb',
      user_id: storeValue?.domain,
      name: storeValue?.shopJson?.shop_owner,
      email: storeValue?.shopJson?.email,
      created_at: Math.floor(new Date().getTime() / 1000),
    });
  }, [storeValue]);

  return (
    <Box as="div" padding="600">
      <Text variant="bodySm" as="p" tone="subdued" alignment="center">
        © All rights reserved{' '}
        <Link
          url="https://www.accounteditor.com/features"
          removeUnderline
          target="_blank"
        >
          AE - Account Editor
        </Link>
      </Text>
    </Box>
  );
}