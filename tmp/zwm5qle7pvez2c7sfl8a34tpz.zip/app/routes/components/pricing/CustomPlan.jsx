import { useState, useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import { BlockStack, Card, Box, InlineGrid, Text, Button, TextField } from "@shopify/polaris";
import APIServicess from '../../services/ApiServices';

//Custom plan
export default function CustomPlan() {
    const { t } = useTranslation();
    const [fcontactName, setFcntactName] = useState('');
    const [lcontactName, setLcontactName] = useState('');
    const [contactPhone, setContactPhone] = useState('');
    const [contactEmail, setContactEmail] = useState('');
    const [contactMessage, setContactMessage] = useState('');
    const [fnameError, setFnameError] = useState(false);
    const [lnameError, setLnameError] = useState(false);
    const [phoneError, setPhoneError] = useState(false);
    const [emailError, setEmailError] = useState(false);
    const [messageError, setMessageError] = useState(false);
    const [isSaving, setIsSaving] = useState(false);
    const APIServ = new APIServicess(); 

    // Submit Form
    const contactFormSubmit = async () => {
        setIsSaving(true);
        try {
            const errors = {
                firstName: !fcontactName?.trim(),
                lastName: !lcontactName?.trim(),
                email: !/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(contactEmail),
                phone: !/^[0-9]{10,15}$/.test(contactPhone),
                message: !contactMessage?.trim(),
            };

            setFnameError(errors.firstName);
            setLnameError(errors.lastName);
            setEmailError(errors.email);
            setPhoneError(errors.phone);
            setMessageError(errors.message);

            if (Object.values(errors).some(Boolean)) {                
                return;
            }

            const shopifyConfig = window?.shopify?.config;
            let shop = shopifyConfig.shop;
            const data = {
                firstName: fcontactName,
                lastName: lcontactName,
                phone: contactPhone,
                email: contactEmail,
                message: contactMessage,
                storeUrl : `https://${shop}`
            };
            const response = await APIServ.appyForCustomPlan(data);
            if(response.status) {
                shopify.toast.show(t("Pricing.mailSent"), {
                    duration: 1500,
                });
                setFcntactName('');
                setLcontactName('');
                setContactPhone('');
                setContactEmail('');
                setContactMessage('');
            }
        } catch (error) {
            console.error('Error handling form submission:', error);
        } finally {
            setIsSaving(false);
        }
    };

    //Handle text fields actions
    const handleTextFieldChange = useCallback((value, type) => {
        const fieldMap = {
            firstName: { setValue: setFcntactName, setError: setFnameError },
            lastName: { setValue: setLcontactName, setError: setLnameError },
            phone: { setValue: setContactPhone, setError: setPhoneError },
            email: { setValue: setContactEmail, setError: setEmailError},
            note: { setValue: setContactMessage, setError: setMessageError },
        };
    
        if (fieldMap[type]) {
            let newValue = value;
    
            // 🛑 Ensure only numbers are entered in the phone field
            if (type === "phone") {
                newValue = value.replace(/\D/g, ""); // Remove non-numeric characters
            }
    
            fieldMap[type].setValue(newValue);
            fieldMap[type].setError(false);  // Remove error for the current field
    
            // Validate the field based on regex or emptiness
            if (fieldMap[type].regex) {
                fieldMap[type].setError(!fieldMap[type].regex.test(newValue));
            } else {
                fieldMap[type].setError(newValue === "");
            }
        }
    }, [
        setFcntactName, setFnameError, 
        setLcontactName, setLnameError, 
        setContactPhone, setPhoneError, 
        setContactEmail, setEmailError, 
        setContactMessage, setMessageError
    ]);
    
    
    return (
        <>
            <Box className="motion-appear-above-animation">
                <Card>
                    <BlockStack gap="200">
                        <Text variant="headingLg" as="h5" fontWeight="regular">{t("Pricing.customPlanTitle")}</Text>                    
                        <BlockStack as={'div'} gap="300">
                            <Text variant="headingSm" as="p" fontWeight="regular">{t("Pricing.customPlanDesc")}</Text>
                            <InlineGrid gap="200" columns={{ "xs": 1, "lg": 2 }}>
                                <TextField
                                    label={t("Pricing.firstNameLable")}
                                    value={fcontactName}
                                    onChange={(event) => handleTextFieldChange(event, 'firstName')}
                                    autoComplete="off"
                                    placeholder={t("Pricing.firstNamePlaceholder")}
                                    error={fnameError ? t("Pricing.invalidFname") : ""}
                                    onFocus={() => setFnameError(false)}
                                    onBlur={() => setFnameError(false)}
                                />
                                <TextField
                                    label={t("Pricing.lastNameLable")}
                                    value={lcontactName}
                                    onChange={(event) => handleTextFieldChange(event, 'lastName')}
                                    autoComplete="off"
                                    placeholder={t("Pricing.lastNamePlaceholder")}
                                    error={lnameError ? t("Pricing.invalidlName") : ""}
                                    onFocus={() => setLnameError(false)}
                                    onBlur={() => setLnameError(false)}
                                />
                            </InlineGrid>
                            <InlineGrid gap="200" columns={{ "xs": 1, "lg": 2 }}>
                                <TextField
                                    label={t("Pricing.emailLable")}
                                    value={contactEmail}
                                    onChange={(event) => handleTextFieldChange(event, 'email')}
                                    autoComplete="off"
                                    placeholder={t("Pricing.emailPlaceholder")}
                                    onFocus={() => setEmailError(false)}
                                    onBlur={() => setEmailError(false)}
                                    error={emailError && !contactEmail ? t("Pricing.requiredEmail") : emailError ? t("Pricing.invalidEmail") : ""}
                                />
                                <TextField
                                    label={t("Pricing.phoneLable")}
                                    value={contactPhone}
                                    onChange={(event) => handleTextFieldChange(event, 'phone')}
                                    autoComplete="off"
                                    placeholder={t("Pricing.phonePlaceholder")}
                                    onFocus={() => setPhoneError(false)}
                                    onBlur={() => setPhoneError(false)}
                                    error={phoneError && !contactPhone ? t("Pricing.requiredPhone") : phoneError ? t("Pricing.invalidPhone") : ""}
                                />
                            </InlineGrid>
                            <InlineGrid gap="400" columns={1}>
                                <TextField
                                    label={t("Pricing.NoteLable")}
                                    value={contactMessage}
                                    onChange={(event) => handleTextFieldChange(event, 'note')}
                                    autoComplete="off"
                                    placeholder={t("Pricing.NotePlaceholder")}
                                    multiline={5}
                                    onFocus={() => setMessageError(false)}
                                    onBlur={() => setMessageError(false)}
                                    error={messageError ? t("Pricing.invalidMessage") : ""}
                                />
                                <Box as={'div'}>
                                    <Button variant="primary" onClick={contactFormSubmit} loading={isSaving}>{t("Pricing.submitBtn")}</Button>
                                </Box>
                            </InlineGrid>
                        </BlockStack>
                    </BlockStack>
                </Card>
            </Box>
        </>
    )
}