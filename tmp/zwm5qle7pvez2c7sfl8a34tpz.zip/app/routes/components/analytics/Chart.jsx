import React, { useState, useEffect} from 'react';
import {
    LineChart,
    Line,
    XAxis,
    YAxis,
    Tooltip,
    ResponsiveContainer,
    CartesianGrid,
    Legend,
} from 'recharts';

import { Box, Text, BlockStack, InlineStack, Spinner, InlineGrid, Card } from '@shopify/polaris';
import currencyJson from "../common/currencysymbols.json";
import { useSelector } from "react-redux";
import { useTranslation } from "react-i18next";

const renderCustomTooltip = ({ active, payload, label }) => {
    const [symbol, setSymbol] = useState('');
    const storeValue = useSelector((state) => state.store);
    useEffect(() => {
        if (storeValue?.currency) {
            setSymbol(currencyJson[storeValue.currency] || '$');
        }

    }, [payload, storeValue]);

    if (active && payload && payload.length) {
        const data = payload[0].payload;  
        let currentCount = data.count;
        let previousCount = data.pvcount; 
        let zeroValue = 0;
        let hundrendValue = 100;

        let percentageChange = (currentCount == 0 && previousCount == 0) ? `${zeroValue.toFixed(2)}%` : (previousCount == 0 || previousCount == 0.00 ? `${hundrendValue.toFixed(2)}%` : `${Math.min(100,Math.abs(((currentCount - previousCount) / previousCount) * 100)).toFixed(2)}%`);
        const isDecrease = currentCount < previousCount;

        let isStringArray = typeof data.count === 'string';

      return (
        <div className="tooltip-wrap">
            <p className="tooltip-ct-data">
                <span className="tooltip-ct-name">{data.name}</span>
                <span className="tooltip-ct-value">{isStringArray ? symbol : ""}{data.count}</span>
                <span className="tooltip-ct-change">{percentageChange} {currentCount == previousCount ? "" : isDecrease ? '↓' : '↑'}</span>
            </p>
            <p className="tooltip-pv-data">
                <span className="tooltip-ct-name">{data.previous.name}</span>
                <span className="tooltip-ct-value">{isStringArray ? symbol : ""}{data.pvcount}</span>
            </p>
        </div>
      );
    }
  
    return null;
  };

const renderCustomLegend = (dataAarry, dataType) => {
    let lastIndex = dataAarry.length - 1;
    return (
        <>
            {
                dataType == 'DAILY' ? (
                    <div style={{ display: 'flex', gap: '20px', marginTop: '20px', marginLeft: '20px', justifyContent: 'center' }}>
                        <Box>
                            <InlineStack gap="800">
                                <p className="ac-first-date">{DateDisplay(dataAarry[lastIndex]?.date )} - {DateDisplay(dataAarry[0]?.date)}</p>
                                <p className="ac-last-date"> {DateDisplay(dataAarry[lastIndex]?.previous.date)} - {DateDisplay(dataAarry[0]?.previous.date)}</p>
                            </InlineStack>
                        </Box>
                    </div>
                ) : (
                    <div style={{ display: 'flex', gap: '20px', marginTop: '20px', marginLeft: '20px', justifyContent: 'center' }}>
                        <Box>
                            <InlineStack gap="800">
                                <p className="ac-first-date">{DateDisplay(dataAarry[0]?.date)}</p>
                                <p className="ac-last-date">{DateDisplay(dataAarry[lastIndex]?.previous.date)}</p>
                            </InlineStack>
                        </Box>
                    </div>
                )
            }
        </>
    );
};

function DateDisplay(date) {  
    const d = new Date(date);
    const day = String(d.getUTCDate()).padStart(2, '0');
    const month = d.toLocaleString('en-GB', { month: 'short', timeZone: 'UTC' });
    const year = d.getUTCFullYear();
  
    const formattedDate = `${day} ${month} ${year}`;  
    return formattedDate;
  }

export default function ComparisonChart({ graphLoading, dataType, data }) {
    const { t } = useTranslation();

    const allZeroCounts = data.every(item => (item.count == "0.00" || item.count === 0) && (item.pvcount == "0.00" || item.pvcount === 0));
    const rawMax = Math.max(...data.map(d => Math.max(Number(d.count), Number(d.pvcount))));

    const [symbol, setSymbol] = useState('');
    const storeValue = useSelector((state) => state.store);
    useEffect(() => {
        if (storeValue?.currency) {
            setSymbol(currencyJson[storeValue.currency] || '$');
        }

    }, [data, storeValue]);

    const calculateDynamicYMax = (rawMax) => {
        if (rawMax === 0) return 10;
    
        const digits = Math.pow(10, Math.floor(Math.log10(rawMax)));
        let yMax = Math.ceil(rawMax / digits) * digits;
    
        if ((yMax - rawMax) / rawMax < 0.15) {
            const bump = 0.15 * rawMax;
            yMax = Math.ceil((rawMax + bump) / digits) * digits;
        }
    
        return yMax;
    };
    const yMax = calculateDynamicYMax(rawMax);

    const generateYTicks = (yMax) => {
        if (yMax <= 10) {
            return Array.from({ length: yMax + 1 }, (_, i) => i);
        }
        const quarter = Math.ceil(yMax / 4); // ceil se 0 avoid hoga
        return [0, quarter, 2 * quarter, 3 * quarter, 4 * quarter];
    };

    const yTicks = generateYTicks(yMax);

    const formatTick = (value) => {
        const isString = typeof data[0]?.count === "string";
        const formattedValue = 
          value >= 1_000_000_000 ? (value / 1_000_000_000).toFixed(1) + "B" :
          value >= 1_000_000 ? (value / 1_000_000).toFixed(1) + "M" :
          value >= 1_000 ? (value / 1_000).toFixed(1) + "K" :
          value;
        
        return isString ? `${symbol}${formattedValue}` : formattedValue;
    };

    const getYAxisWidth = (yMax) => {
        if (yMax >= 1_000_000_000) return 75;
        if (yMax >= 100_000_000) return 75;
        if (yMax >= 10_000_000) return 70;
        if (yMax >= 1_000_000) return 75;
        if (yMax >= 100_000) return 70;
        if (yMax >= 10_000) return 65;
        if (yMax >= 1_000) return 55;
        return 55;
    };

    const chartData = dataType === 'DAILY' ? [...data].reverse() : data;
    const getDynamicInterval = (length) => {
  if (length <= 7) return "preserveEnd";
  if (length <= 30) return 2;
  if (length <= 50) return 4;
  return Math.floor(length / 10); // dynamically adjust for large datasets
};

    return (
        <div style={{ width: '100%', height: 200 }}>
            {
                graphLoading ? <div style={{ display: 'flex', width: '100%', height: "100%", justifyContent: "center", alignItems: "center" }}>
                    <Spinner accessibilityLabel="Small spinner example" size="small" />
                </div> : (
                    !allZeroCounts ? <ResponsiveContainer>
                        <LineChart
                            data={chartData}
                            margin={{ top: 20, right: 30, left: 0, bottom: 5 }}
                        >
                            <CartesianGrid stroke="rgba(235, 235, 235, 1)" vertical={false} />
                            <XAxis
                                dataKey="name"
                                tickLine={false}
                                stroke='rgba(235, 235, 235, 1)'
                                tick={{ fill: 'rgba(138, 138, 138, 1)', fontWeight: '500' }}
                                interval={getDynamicInterval(data.length)}
                                tickMargin={15}
                            />
                            <YAxis
                                domain={[0, yMax]}
                                ticks={yTicks}
                                allowDecimals={false}
                                tickFormatter={formatTick}
                                axisLine={false}
                                tickLine={false}
                                tickMargin={15}
                                width={getYAxisWidth(yMax)}
                                tick={{ fontWeight: '500', fill: 'rgba(138, 138, 138, 1)' }}
                            />
                            <Tooltip content={renderCustomTooltip}/>
                            <Legend content={renderCustomLegend(chartData, dataType)} />
                            <Line
                                type="monotone"
                                dataKey="count"
                                stroke="rgba(51, 177, 233, 1)"
                                strokeWidth={2}
                                dot={false}
                            />
                            <Line
                                type="monotone"
                                dataKey="pvcount"
                                stroke="rgba(51, 177, 233, 1)"
                                strokeWidth={1}
                                strokeDasharray="4 4"
                                dot={false}
                            />
                        </LineChart>
                    </ResponsiveContainer> : <div style={{ display: 'flex', width: '100%', height: "100%", justifyContent: "center" }}>
                        <BlockStack align="center">
                            <Text variant="semibold" fontWeight="medium" as="span" alignment="center">{t("Analytics.noFound.text1")}</Text>
                            <Text variant="headingSm" fontWeight="medium" as="span" alignment="center">{t("Analytics.noFound.text2")}</Text>
                        </BlockStack>
                    </div>
                )
            }
        </div>
    );
}
