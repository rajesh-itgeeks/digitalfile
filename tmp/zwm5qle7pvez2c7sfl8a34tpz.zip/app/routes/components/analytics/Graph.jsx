import { useState, useMemo, useCallback, useEffect } from 'react';
import { Layout, Card, BlockStack, InlineStack, Icon, Checkbox, FormLayout, Select, Text, TextField, Divider, Box, Button, ButtonGroup, RadioButton, InlineGrid } from '@shopify/polaris';
import {
    CaretDownIcon, CaretUpIcon
} from '@shopify/polaris-icons';

import Chart from './Chart';
import { useTranslation } from "react-i18next";
import currencyJson from "../common/currencysymbols.json";

export default function Graph({graphData, graphLoading, dataType, stats, storeValue,  orderEditData, attributedData, upsellData, cancelledData, orderValueData, supportData}) {
    const { t } = useTranslation();
    const [symbol, setSymbol] = useState('');    
    const Analytics = t("Analytics.graph", { returnObjects: true });

    // Initialize component
    useEffect(() => {
        if (storeValue?.currency) {
            setSymbol(currencyJson[storeValue.currency] || '$');
        }
    }, [storeValue]);

    return (
        <Box>
            <InlineGrid columns={{ xs: 1, sm: 1, md:2, lg: 2 }} gap="400">
                {
                    Analytics.map((items, index)=>(
                        <Card key={index}>
                            <BlockStack gap="300">
                                <Box>
                                    <StatCard 
                                        title={items.title} 
                                        stats={stats}
                                        symbol={symbol}
                                        keys={items.key}
                                    />
                                    <Chart graphLoading={graphLoading} graphData={graphData} dataType={dataType} data={
                                        items.key == "ordersEdited" 
                                        ? orderEditData
                                        : items.key == "appAttributedRevenue"
                                        ? attributedData
                                        : items.key == "upsellRevenue"
                                        ? upsellData
                                        : items.key == "ordersCancelled"
                                        ? cancelledData
                                        : items.key == "averageOrderValue"
                                        ? orderValueData 
                                        : supportData
                                    }/>                  
                                </Box> 
                            </BlockStack>
                        </Card>
                    ))
                }
            </InlineGrid>            
        </Box>
    )
}

// Helper component for statistic cards
function StatCard({ title, stats, symbol, keys }) {
    let value;
    console.log(keys, "==========");
    switch (keys) {
        case "ordersEdited":
            value = stats?.orderEdits || 0;
            console.log(stats?.orderEdits, "================");
        break;
    case "appAttributedRevenue":
      value = stats?.revenue !== undefined 
        ? `${symbol}${new Intl.NumberFormat('en-US', { minimumFractionDigits: 1, maximumFractionDigits: 1 }).format(stats.revenue)}`
        : `${symbol}0.0`;
      break;
    case "upsellRevenue":
      value = stats?.upsellRevenue !== undefined 
        ? `${symbol}${new Intl.NumberFormat('en-US', { minimumFractionDigits: 1, maximumFractionDigits: 1 }).format(stats.upsellRevenue)}`
        : `${symbol}0.0`;
      break;
    case "ordersCancelled":
      value = stats?.cancelledOrders || 0;
      break;
    case "averageOrderValue":
      value = stats?.averageOrderValue !== undefined 
        ? `${symbol}${new Intl.NumberFormat('en-US', { minimumFractionDigits: 1, maximumFractionDigits: 1 }).format(stats.averageOrderValue)}`
        : `${symbol}0.0`;
      break;
    default:
      value = stats?.supportRequestRecieved || 0;
    }

    

    const titles = title.replace(/{number}|{numebr}/gi, value);
    return (
        <Box id="graph-Analytics" width="100%" padding="300" borderRadius="200">
            <BlockStack>
                <Box borderColor="bg-surface-brand" paddingBlockEnd="100">
                    <Box id="graph-Analytics-title">
                        <Text variant="headingLg" as="h6">{titles}</Text>
                    </Box>
                </Box>                                 
            </BlockStack>
        </Box>         
    );
}