import { Page, Button, Card, Box, Badge, Layout, BlockStack, FormLayout, Select, Text, TextField, Divider, RadioButton, InlineStack, Checkbox, Thumbnail, Banner, List, Icon, InlineGrid, Autocomplete } from '@shopify/polaris';
import { useTranslation } from 'react-i18next';
import { useState, useCallback, useEffect, useMemo } from 'react';
import { DeleteIcon } from '@shopify/polaris-icons';
import { SaveBar, Modal, TitleBar } from "@shopify/app-bridge-react";
import { thumbnail } from "../../common/Images";
import APIServicess from "../../../services/ApiServices";
import { useDispatch, useSelector } from "react-redux";
import { setUpsellList } from "../../store/UpsellListSlice";
import { setCollections } from "../../store/CollectionsSlice";
import { setSegment } from "../../store/SegmentSlice";
import { setPublication } from "../../store/PublicationSlice";

export default function UpsellUpdate({ setScreenShow, setSaveBarActive, upsellId }) {
  const { t } = useTranslation();
  const [settingsStatus, setSettingsStatus] = useState(false);
  const [upsellLable, setUpsellLable] = useState('');
  const [conditions, setConditions] = useState('all');
  const [rules, setRules] = useState([{ type: "segment", sign: "=", id: "" }]);
  const [segmentsList, setSegmentsList] = useState([]);
  const [collectionList, setCollectionList] = useState([]);
  const [productLimitView, setProductLimitView] = useState('5');
  const [productView, setProductView] = useState("list");
  const [selectedPrduct, setSelectedPrduct] = useState([]);
  const [discountValue, setDiscountValue] = useState('');
  const [upsellTitleError, setUpsellTitleError] = useState(false);
  const [titleErrorMassage, setTitleErrorMassage] = useState(t('Settings.UpsellCreate.titleSection.section.errorEmpty'));
  const [hasChanges, setHasChanges] = useState(false);
  const collections = useSelector((state) => state.collections);
  const segment = useSelector((state) => state.segment);
  const publication = useSelector((state) => state.publication);
  const [selectedItems, setSelectedItems] = useState([]);
  const [sameValueError, setSameValueError] = useState(false);
  const [productError, setProductError] = useState(false);
  const APIServ = useMemo(() => new APIServicess(), []);
  const dispatch = useDispatch();
  const [errors, setErrors] = useState({});
  const [saveBarLoading, setSaveBarLoading] = useState(false);
  const [banner, setBanner] = useState(false);
  const [upsellData, setUpsellData] = useState({});
  const [activeId, setActiveId] = useState('');
  const [currentActive, setCurrentActive] = useState(false);
  const getUpsellList = useSelector((state) => state.upsellList);
  const [isLoadingButton, setIsLoadingButton] = useState(false);
  const [initialState, setInitialState] = useState({});
  const [onlineStoreId, setOnlineStoreId] = useState('');
  const [inputValues, setInputValues] = useState({});
  const [listVisibleIndex, setListVisibleIndex] = useState(null);
  const data = useMemo(() => ({
    name: upsellLable,
    productMustMatch: conditions,
    condition: rules,
    productLimit: productLimitView,
    selectView: productView,
    products: selectedPrduct,
    discount: discountValue,
    isActive: settingsStatus
  }), [upsellLable, conditions, rules, productLimitView, productView, selectedPrduct, discountValue, settingsStatus]);

  useEffect(() => {
    const fetchSegment = async () => {
      if (segment && segment.length) {
        const formattedSegments = segment.map(segment => ({
          label: segment.name,
          value: segment.id
        }));
        setSegmentsList(formattedSegments);
      } else {
        // Fetch settings after store data is fetched
        const segments = await APIServ.getSegment();
        if (segments.status) {
          dispatch(setSegment(segments.data));
        }
      }
    }

    const fetchCollection = async () => {
      if (collections && collections.length) {
        const formattedCollections = collections.map(collection => ({
          label: collection.title,
          value: collection.id
        }));
        setCollectionList(formattedCollections);
      } else {
        // Fetch settings after store data is fetched
        const collection = await APIServ.getCollections();
        if (collection.status) {
          dispatch(setCollections(collection.data));
        }
      }
    }
    const fetchPublication = async () => {
      if (publication && publication.length) {
        const onlineStoreId = publication.find(pub => pub.node.name === "Online Store")?.node?.id;
        if (onlineStoreId) {
          setOnlineStoreId(onlineStoreId.replace("gid://shopify/Publication/", ""));
        }
      } else {
        // Fetch publications data
        const publication = await APIServ.getPublication();
        if (publication.status) {
          dispatch(setPublication(publication.data));
        }
      }
    }

    fetchSegment();
    fetchCollection();
    fetchPublication();

    fetchUpsell();
    setActiveId(getUpsellList?.result?.activeId ?? '');
  }, [upsellId, getUpsellList, collections, segment, publication]);

  const fetchUpsell = async () => {
    if (upsellId) {
      try {
        let response = await APIServ.getUpsellByid(upsellId);
        if (response.status) {
          let condition = response?.result?.condition;
          if(collections.length > 0 && segment.length > 0){
            const result = condition?.reduce((acc, item, index) => {
              if (item.type === 'segment') {
                const label = segment?.find(opt => opt.id === item.id)?.name;
                if (label) {
                  acc[index] = label;
                }
              } else {
                const label = collections?.find(opt => opt.id === item.id)?.title;
                if (label) {
                  acc[index] = label;
                }
              }

              return acc;
            }, {});
            setInputValues(result);
          }          

          setUpsellData(response?.result);
          setUpsellLable(response?.result?.name);
          setConditions(response?.result?.productMustMatch);
          setRules(response?.result?.condition);
          setProductView(response?.result?.selectView);
          setSelectedPrduct(response?.result?.products);
          setDiscountValue(response?.result?.discount != 0 ? response?.result?.discount : '');
          setSettingsStatus(response?.result?.isActive);
          setInitialState({
            name: response?.result?.name,
            productMustMatch: response?.result?.productMustMatch,
            condition: response?.result?.condition,
            productLimit: response?.result?.productLimit,
            selectView: response?.result?.selectView,
            products: response?.result?.products,
            discount: response?.result?.discount != 0 ? response?.result?.discount : '',
            isActive: response?.result?.isActive
          });
        }
      } catch (error) {
        console.error("Error fetching upsell:", error);
      }
    }
  };

  const handleStateChange = useCallback((key, value, index) => {
    let updatedRules;
    switch (key) {
      case 'upsellTitle':
        setUpsellLable(value);
        if (typeof value === 'string' && value.length > 0) {
          setUpsellTitleError(false);
        }
        break;
      case 'conditions':
        setConditions(value);
        break;
      case 'rule':
        updatedRules = [...rules];
        updatedRules[index].type = value;
        updatedRules[index].id = '';
        setRules(updatedRules);
        break;
      case 'operator':
        updatedRules = [...rules];
        const currentid = updatedRules[index]?.id;
        const type = updatedRules[index]?.type;
        const isDuplicate = (type === 'segment' || type === 'collection') &&
          updatedRules.some((rule, i) => rule.id === currentid && rule.sign === value && i !== index);
        if (isDuplicate) {
          setSameValueError(true);
          return;
        } else {
          updatedRules[index].sign = value;
          setRules(updatedRules);
          setSameValueError(false);
        }
        break;
      case 'productView':
        setProductView(value);
        break;
      case 'discounts':
        if (value === "") {
          setDiscountValue("");
        } else {
          let numberValue = value.replace(/[-+e.]/g, '').replace(/[^0-9]/g, '');
          if (!isNaN(numberValue) && numberValue >= 1 && numberValue <= 100) {
            setDiscountValue(numberValue);
          }
        }
        break;
      default:
        break;
    }
    const isDataChanged = !areObjectsEqual(data, initialState);
    setSaveBarActive(isDataChanged);
    setHasChanges(isDataChanged);
  }, [rules, data, initialState]);

  const handleChangeCartId = useCallback((value, index) => {
    if (/^\d*$/.test(value)) {
      const updatedRules = [...rules];
      updatedRules[index].id = value;
      setRules(updatedRules);
      const isDataChanged = !areObjectsEqual(data, initialState);
      setHasChanges(isDataChanged);
      setSaveBarActive(isDataChanged);
      setErrors({});
    }
  }, [rules, data, initialState]);

  const handleChangeId = useCallback((value, index, type) => {
    const updatedRules = [...rules];
    const currentSign = updatedRules[index]?.sign;
    const isDuplicate = (type === 'segment' || type === 'collection') &&
      updatedRules.some((rule, i) => rule.id === value && rule.sign === currentSign && i !== index);
    if (isDuplicate) {
      setSameValueError(true);
      return;
    } else {
      setSameValueError(false);
    }
    updatedRules[index].id = value;
    setRules(updatedRules);
    const isDataChanged = !areObjectsEqual(data, initialState);
    setSaveBarActive(isDataChanged);
    setHasChanges(isDataChanged);
  }, [rules, data, initialState]);

  const removeCurrentRule = useCallback((index) => {
    const updatedRules = rules.filter((_, i) => i !== index);
    setRules(updatedRules);
    data.condition = updatedRules;
    const isDataChanged = !areObjectsEqual(data, initialState);
    setSaveBarActive(isDataChanged);
    setHasChanges(isDataChanged);
    setSameValueError(false);
  }, [rules, data, initialState]);

  const addNewRule = useCallback(() => {
    const newRule = { type: "segment", sign: "=", id: "" };
    const updatedRules = [...rules, newRule];
    setRules(updatedRules);
    const isDataChanged = !areObjectsEqual(data, initialState);
    setSaveBarActive(isDataChanged);
    setHasChanges(isDataChanged);
    setSameValueError(false);
  }, [rules, data, initialState]);

  const toggleUpsellStatus = useCallback(() => {
    if (activeId !== upsellId && settingsStatus == false && activeId !== '') {
      shopify.modal.show('switch-upsell__popup');
    } else {
      let newvalue = !settingsStatus;
      setSettingsStatus(newvalue);
      const isDataChanged = !areObjectsEqual(data, initialState);
      setHasChanges(isDataChanged);
      setSaveBarActive(isDataChanged);
    }
  }, [settingsStatus, activeId, data, initialState]);

  const upsellStatusUpdate = useCallback(() => {
    let newvalue = !settingsStatus;
    setSettingsStatus(newvalue);
    const isDataChanged = !areObjectsEqual(data, initialState);
    setHasChanges(isDataChanged);
    setSaveBarActive(isDataChanged);
    setCurrentActive(true);
    shopify.modal.hide('switch-upsell__popup');
  }, [settingsStatus, currentActive, data, initialState]);

  useEffect(() => {
    if (hasChanges) {
      shopify.saveBar.show('timeframe-save-bar');
    } else {
      shopify.saveBar.hide('timeframe-save-bar');
    }
  }, [hasChanges]);

  const areObjectsEqual = useCallback((object1, object2) => {
    if (object1 === object2) return true;
    if (typeof object1 !== "object" || typeof object2 !== "object" || object1 === null || object2 === null) {
      return false;
    }
    const keys1 = Object.keys(object1);
    const keys2 = Object.keys(object2);
    if (keys1.length !== keys2.length) return false;
    return keys1.every(key => keys2.includes(key) && areObjectsEqual(object1[key], object2[key]));
  }, []);

  const saveUpsellSettings = useCallback(async () => {
    try {
      let continuous = true;
      if (!data.name) {
        setUpsellTitleError(true);
        setTitleErrorMassage(t('Settings.UpsellCreate.titleSection.section.errorEmpty'))
        continuous = false;
      }

      const newErrors = {};
      rules.forEach((rule, index) => {
        if (!rule.id) {
          newErrors[index] = (rule.type == 'segment') || (rule.type == 'collection') ? t('Settings.UpsellCreate.conditionsSection.section.errorEmpty') : t('Settings.UpsellCreate.conditionsSection.section.errorCart')
          continuous = false;
        }
      });

      setErrors(newErrors);

      if (selectedPrduct.length > 0) {
        const formattedData = selectedPrduct.map(product => {
          return {
            id: product?.id,
            title: product?.title,
            images: Array.isArray(product?.images) && product.images.length > 0 ? [product.images[0]] : [],
            variants: Array.isArray(product?.variants) ? product.variants.map(variant => ({
              variant_id: variant?.id,
              price: parseFloat(variant?.price) || 0,
              title: variant?.title,
              option_id: variant?.options || null,
            })) : [],
          };
        });

        data.products = formattedData;
      } else {
        setProductError(true);
        continuous = false;
      }

      if (!data.discount) {
        data.discount = 0;
      }

      if (continuous && Object.keys(newErrors).length === 0) {
        setSaveBarLoading(true);
        setBanner(false);
        if (currentActive) {
          await APIServ.upsellListUpdate({ id: activeId, type: 'deactive' });
        }
        const response = await APIServ.upsellUpdateById(upsellId, data);
        if (response.status) {
          const upsellList = await APIServ.getUpsellList({ limit: 10, offset: 0, shortBy: 'DES' });
          if (upsellList.status) {
            dispatch(setUpsellList(upsellList));
            shopify.saveBar.hide('timeframe-save-bar');
            setSaveBarLoading(true);
          }
          setScreenShow('lists');
          setSaveBarActive(false);
        } else {
          setUpsellTitleError(true);
          setTitleErrorMassage(response.message);
        }
      } else {
        setBanner(true);
        window.scrollTo({ top: 0, behavior: "smooth" });
      }
    } catch (e) {
      console.error('Error saving upsell settings:', e);
      shopify.saveBar.hide('timeframe-save-bar');
      return;
    } finally {
      setSaveBarLoading(false);
    }
  }, [upsellLable, selectedPrduct, rules, discountValue, currentActive, settingsStatus, data, APIServ, activeId, upsellId, dispatch, setScreenShow, setSaveBarActive, t]);

  const discardChanges = useCallback(() => {
    fetchUpsell();
    setHasChanges(false);
    setSaveBarActive(false);
  }, [fetchUpsell]);

  const openResourcePicker = useCallback(async () => {
    if (typeof window !== "undefined" && window.shopify) {
      try {
        let product = selectedPrduct;
        const filteredIds = selectedPrduct.map(product => ({ id: product.id }));
        const selected = await window.shopify.resourcePicker({
          type: "product",
          selectionIds: filteredIds,
          multiple: productLimitView,
          filter: {
            hidden: true,
            variants: false,
            draft: false,
            archived: false,
            query: `publication_ids:${onlineStoreId} AND inventory_total:>0 OR inventory_total:<0`
          }
        });
        const updatedProducts = selected !== undefined ? selected : product.length > 0 ? product : [];
        setSelectedPrduct(updatedProducts);
        if (selected && product.length !== selected.length) {
          setHasChanges(true);
        }
        setProductError(false);
      } catch (error) {
        console.error("Error opening Resource Picker:", error);
      }
    } else {
      console.error("Shopify App Bridge not available.");
    }
  }, [productLimitView, selectedPrduct, productError]);

  const getPriceRange = useCallback((variants = []) => {
    const prices = variants.map(variant => parseFloat(variant.price));
    if (prices.length === 1 || prices.every(price => price === prices[0])) {
      return `$${prices[0]}`;
    }
    return `$${Math.min(...prices)}-$${Math.max(...prices)}`;
  }, []);

  const removeProductFormList = useCallback((index) => {
    setSelectedPrduct(prevProducts => {
      const updatedProducts = prevProducts.filter((_, i) => i !== index);
      if (updatedProducts.length !== data.products) {
        const isDataChanged = !areObjectsEqual(data, initialState);
        setHasChanges(isDataChanged);
      }
      return updatedProducts;
    });
    setProductError(false);
  }, [hasChanges, data, initialState]);

  const handleSelectAll = useCallback(() => {
    if (selectedItems.length === selectedPrduct.length) {
      setSelectedItems([]);
    } else {
      setSelectedItems(selectedPrduct.map((_, index) => index));
    }
  }, [selectedItems, selectedPrduct]);

  const handleSelect = useCallback((index) => {
    setSelectedItems((prev) =>
      prev.includes(index) ? prev.filter((i) => i !== index) : [...prev, index]
    );
  }, []);

  const handleSelectProductRemove = useCallback(() => {
    const updatedProducts = selectedPrduct.filter((_, index) => !selectedItems.includes(index));
    setSelectedPrduct(updatedProducts);
    setSelectedItems([]);
    setProductError(false);
    if (updatedProducts.length !== data.products) {
      const isDataChanged = !areObjectsEqual(data, initialState);
      setHasChanges(isDataChanged);
    }
  }, [selectedItems, selectedPrduct, data, initialState]);

  const handleBlur = useCallback((index) => {
    if (!rules[index].id) {
      setErrors((prevErrors) => ({ ...prevErrors, [index]: "Field is required" }));
    }
  }, [rules]);

  const handleFocus = useCallback((index) => {
    setErrors((prevErrors) => {
      const updatedErrors = { ...prevErrors };
      delete updatedErrors[index];
      return updatedErrors;
    });
  }, []);

  const iconContent = useCallback(() => {
    return (
      <svg viewBox="0 0 20 20" className="Polaris-Icon__Svg" focusable="false" aria-hidden="true" fill="#8e1f0b"><path d="M10 6a.75.75 0 0 1 .75.75v3.5a.75.75 0 0 1-1.5 0v-3.5a.75.75 0 0 1 .75-.75Z"></path><path d="M11 13a1 1 0 1 1-2 0 1 1 0 0 1 2 0Z"></path><path fillRule="evenodd" d="M17 10a7 7 0 1 1-14 0 7 7 0 0 1 14 0Zm-1.5 0a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0Z"></path></svg>
    );
  }, []);

  const replaceNumber = useCallback((text, number) => {
    if (number == 'error') {
      const conditions = [upsellTitleError, Object.keys(errors).length !== 0, productError];
      const trueCount = conditions.filter(Boolean).length;
      return text.replace("{number}", trueCount);
    } else {
      return text.replace("{number}", number);
    }
  }, [upsellTitleError, errors, productError]);

  const backToList = useCallback(() => {
    if (!hasChanges) {
      setHasChanges(true);
      setScreenShow('lists');
    } else {
      shopify.saveBar.leaveConfirmation();
    }
  }, [hasChanges, setScreenShow]);
  // Return upsell html 
  return (
    <>
      {/* Save bar */}
      <SaveBar id="timeframe-save-bar">
        <button variant="primary" onClick={saveUpsellSettings}{...(saveBarLoading ? { loading: "" } : {})}>{t('Settings.timeframe.buttons.save')}</button>
        <button onClick={discardChanges}>{t('Settings.timeframe.buttons.')}</button>
      </SaveBar>

      {/* Current active upsell offer dectived */}
      <Modal id="switch-upsell__popup" onHide={() => setIsLoadingButton(false)}>
        <Box>
          <Box padding={500}>
            <Text>{t("Settings.upsellList.switchUpsellMessage")}</Text>
            <br />
            <Text><strong>{t("Settings.upsellList.note")}</strong>{t("Settings.upsellList.switchUpsellNote")}</Text>
          </Box>
          <Box padding={{ xs: '400', sm: '400' }} borderBlockStartWidth="0165" borderColor="border-brand">
            <InlineStack align="end" gap={100}>
              <Button onClick={() => shopify.modal.hide('switch-upsell__popup')}>{t("Settings.upsellList.cancel")}</Button>
              <Button variant="primary" onClick={() => upsellStatusUpdate()} loading={isLoadingButton}>
                {t("Settings.upsellList.switch")}
              </Button>
            </InlineStack>
          </Box>
        </Box>
        <TitleBar title={t("Settings.upsellList.switchUpsell")}></TitleBar>
      </Modal>

      {/* Upsell settings */}
      <Box className="upsell-create motion-appear-above-animation upsell-create__container">

        {/* Upsell error banner */}
        <Box as={'div'}>
          {
            ((upsellTitleError && banner) || (Object.keys(errors).length !== 0 && banner) || (productError && banner)) && <>
              <Banner
                title={t('Settings.UpsellCreate.errorBanner.title')}
                tone="critical"
                onDismiss={() => setBanner(false)}
              >
                <BlockStack gap="200">
                  <Text fontWeight="semibold" as="h4">{replaceNumber(t('Settings.UpsellCreate.errorBanner.description'), 'error')}{ }</Text>
                  <List type="bullet">
                    {
                      upsellTitleError && <List.Item>{t('Settings.UpsellCreate.errorBanner.errorOne')}</List.Item>
                    }
                    {
                      Object.keys(errors).length !== 0 && <List.Item>{t('Settings.UpsellCreate.errorBanner.errorTwo')}</List.Item>
                    }
                    {
                      productError && <List.Item>{t('Settings.UpsellCreate.errorBanner.errorThree')}</List.Item>
                    }
                  </List>
                </BlockStack>
              </Banner>
              <Box padding="300"></Box>
            </>
          }
        </Box>

        {/* Upsell page heading and on off button */}
        <Page
          backAction={{ onAction: () => backToList() }}
          title={t('Settings.UpsellCreate.title')}
          primaryAction={<Button variant="plain" onClick={() => toggleUpsellStatus(settingsStatus)}>
            <span className={`switch__button  ${settingsStatus == true ? 'selected' : ''}`}>
              <span className="active-dot"></span>
            </span>
          </Button>}
          titleMetadata={<Badge tone={!settingsStatus ? "" : "success"}>{!settingsStatus ? t('Settings.UpsellCreate.off') : t('Settings.UpsellCreate.on')}</Badge>}
          fullWidth
        >

          <Layout>

            {/* Upsell title settings */}
            <Layout.AnnotatedSection
              id="edit-timeframe-settings"
              title={t('Settings.UpsellCreate.titleSection.title')}
              description={t('Settings.UpsellCreate.titleSection.description')}
            >
              <BlockStack gap={400}>
                <Card>
                  <FormLayout>
                    <BlockStack gap={200}>
                      <Text fontWeight="semibold" as="h4">{t('Settings.UpsellCreate.titleSection.section.title')}</Text>
                      <BlockStack gap={100}>
                        <TextField
                          value={upsellLable}
                          onChange={(event) => handleStateChange('upsellTitle', event, "")}
                          autoComplete="off"
                          placeholder={t('Settings.UpsellCreate.titleSection.section.placeholder')}
                          error={upsellTitleError && titleErrorMassage}
                          maxLength={20}
                          showCharacterCount
                        />
                        <Text as='p' tone="subdued">{t('Settings.UpsellCreate.titleSection.section.description')}</Text>
                      </BlockStack>
                    </BlockStack>
                  </FormLayout>
                </Card>
              </BlockStack>
            </Layout.AnnotatedSection>
            <Box as="div" className="annotated-section">
              <Divider borderWidth="050" />
            </Box>

            {/* Upsell rule conditions */}
            <Layout.AnnotatedSection
              id="edit-timeframe-settings"
              title={t('Settings.UpsellCreate.conditionsSection.title')}
              description={t('Settings.UpsellCreate.conditionsSection.description')}
            >
              <BlockStack gap={400}>
                <Card>
                  <FormLayout>
                    <BlockStack gap={200}>
                      <Text fontWeight="semibold" as="h4">{t('Settings.UpsellCreate.conditionsSection.section.title')}</Text>
                      <BlockStack gap={100}>
                        <Text as='p'>{t('Settings.UpsellCreate.conditionsSection.section.description')}</Text>
                        <BlockStack>
                          <RadioButton
                            label={t('Settings.UpsellCreate.conditionsSection.section.optionOne')}
                            checked={conditions === 'all'}
                            name="conditions"
                            onChange={(event) => handleStateChange('conditions', 'all', "")}
                          />
                          <RadioButton
                            label={t('Settings.UpsellCreate.conditionsSection.section.optionTwo')}
                            name="conditions"
                            checked={conditions === 'any'}
                            onChange={(event) => handleStateChange('conditions', 'any', "")}
                          />
                          <Box as={'div'}>
                            <BlockStack gap={200}>
                              {
                                rules.map((rule, index) => (
                                  <InlineGrid wrap={false} gap="200" key={index} columns={['twoThirds', 'oneThird']}>
                                    <Box as={'div'}>
                                      <InlineGrid columns={2} gap="200">
                                        <Box as={'div'}>
                                          <Select
                                            options={t('Settings.UpsellCreate.conditionsSection.section.rule', { returnObjects: true })}
                                            onChange={(event) => handleStateChange('rule', event, index)}
                                            value={rule.type}
                                          />
                                        </Box>
                                        <Box as={'div'}>
                                          <Select
                                            options={
                                              ((rule.type == 'segment') || (rule.type == 'collection'))
                                                ? t('Settings.UpsellCreate.conditionsSection.section.opratorOne', { returnObjects: true })
                                                : t('Settings.UpsellCreate.conditionsSection.section.opratorTwo', { returnObjects: true })
                                            }
                                            onChange={(event) => handleStateChange('operator', event, index)}
                                            value={rule.sign}
                                          />
                                        </Box>
                                      </InlineGrid>
                                    </Box>
                                    <Box as={'div'}>
                                      <InlineStack wrap={false} gap="200">
                                        {
                                          ((rule.type == 'segment') || (rule.type == 'collection'))
                                            ? <Box as={'div'} width={(index > 0) ? "80%" : "100%"}>
                                              {/* <Select
                                                options={(rule.type === 'segment')
                                                  ? segmentsList.filter((option, i) =>
                                                    !(rules.some((r, idx) => r.id === option.value && idx !== index)) // Ignore current index
                                                  )
                                                  : collectionList.filter((option, i) =>
                                                    !(rules.some((r, idx) => r.id === option.value && idx !== index)) // Ignore current index
                                                  )
                                                }
                                                value={rule.id}
                                                onChange={(event) => handleChangeId(event, index, rule.type)}
                                                placeholder={t("Settings.UpsellCreate.conditionsSection.section.select")}
                                                error={errors[index]}
                                                onFocus={() => handleFocus(index)}
                                                onBlur={() => handleBlur(index)}
                                              /> */}
                                              <Autocomplete
                                                options={
                                                  (rule.type === 'segment' ? segmentsList : collectionList)
                                                    .filter(option =>
                                                      !rules.some((r, idx) =>
                                                        r.id === option.value &&
                                                        r.sign === rule.sign &&
                                                        idx !== index
                                                      )
                                                    )
                                                    .filter(option =>
                                                      (inputValues?.[index] || '').trim() === '' ||
                                                      option.label.toLowerCase().includes(inputValues[index].toLowerCase())
                                                    )
                                                }

                                                selected={rule.id ? [rule.id] : []}                                                
                                                onSelect={(selected) => {
                                                  const selectedValue = selected[0];
                                                  const selectedOption = (rule.type === 'segment' ? segmentsList : collectionList).find(
                                                    (opt) => opt.value === selectedValue
                                                  );

                                                  handleChangeId(selectedValue, index, rule.type);
                                                  setInputValues(prev => ({
                                                    ...prev,
                                                    [index]: selectedOption?.label || ''
                                                  }));
                                                  setListVisibleIndex(null);
                                                }}
                                                textField={
                                                  <Autocomplete.TextField
                                                    onChange={(value) => {
                                                      setInputValues(prev => ({ ...prev, [index]: value }));
                                                      setListVisibleIndex(index);
                                                    }}
                                                    value={inputValues?.[index] || ''}
                                                    placeholder={t("Settings.UpsellCreate.conditionsSection.section.select")}
                                                    error={errors[index]}
                                                    autoComplete="off"
                                                    onFocus={() => {
                                                      setInputValues(prev => ({ ...prev, [index]: '' }));
                                                      setListVisibleIndex(index);
                                                      handleFocus(index);
                                                    }}
                                                    onBlur={() => {
                                                      const currentValue = rule.id ? [rule.id] : [];
                                                      const selectedOption = (rule.type === 'segment' ? segmentsList : collectionList).find(
                                                        (opt) => opt.value === currentValue[0] 
                                                      );

                                                      if (selectedOption) {
                                                        setInputValues(prev => ({ ...prev, [index]: selectedOption.label }));
                                                      } else {
                                                        setInputValues(prev => ({ ...prev, [index]: '' }));
                                                      }
                                                      setTimeout(() => {
                                                        setListVisibleIndex(null);
                                                      }, 200);

                                                      handleBlur(index);
                                                    }}
                                                  />
                                                }
                                                visible={listVisibleIndex === index}
                                              />
                                            </Box>
                                            : <TextField
                                              value={rule.id}
                                              onChange={(event) => handleChangeCartId(event, index)}
                                              prefix="$"
                                              autoComplete="off"
                                              onFocus={() => handleFocus(index)}
                                              onBlur={() => handleBlur(index)}
                                              error={errors[index]}
                                            />
                                        }
                                        {
                                          (index > 0) && <Button id="remove-rule" icon={DeleteIcon} tone="critical" onClick={() => removeCurrentRule(index)} />
                                        }
                                      </InlineStack>
                                    </Box>
                                  </InlineGrid>
                                ))
                              }
                            </BlockStack>
                          </Box>
                        </BlockStack>
                      </BlockStack>
                      <Box as={'div'}>
                        <Button onClick={addNewRule}>{t('Settings.UpsellCreate.conditionsSection.section.btn')}</Button>
                      </Box>
                      {
                        sameValueError &&
                        <Box>
                          <InlineStack gap="200">
                            <Box>
                              <Icon source={iconContent} />
                            </Box><Text as='p' tone="critical" >{t('Settings.UpsellCreate.conditionsSection.section.sameCondition')}</Text>
                          </InlineStack>
                        </Box>
                      }
                    </BlockStack>
                  </FormLayout>
                </Card>
              </BlockStack>
            </Layout.AnnotatedSection>
            <Box as="div" className="annotated-section">
              <Divider borderWidth="050" />
            </Box>

            {/* Upsell product view */}
            <Layout.AnnotatedSection
              id="edit-timeframe-settings"
              title={t('Settings.UpsellCreate.productViewSection.title')}
              description={t('Settings.UpsellCreate.productViewSection.description')}
            >
              <BlockStack gap={400}>
                <Card>
                  <FormLayout>
                    <BlockStack gap={200}>
                      <Text fontWeight="semibold" as="h4">{t('Settings.UpsellCreate.productViewSection.section.sectionTwo.title')}</Text>
                      <BlockStack gap={100}>
                        <Text as='p' tone="subdued">{t('Settings.UpsellCreate.productViewSection.section.sectionTwo.description')}</Text>
                        <BlockStack>
                          <RadioButton
                            label={t('Settings.UpsellCreate.productViewSection.section.sectionTwo.list')}
                            checked={productView === 'list'}
                            name="productView"
                            onChange={(event) => handleStateChange('productView', 'list', "")}
                          />
                          <RadioButton
                            label={t('Settings.UpsellCreate.productViewSection.section.sectionTwo.carousel')}
                            name="productView"
                            checked={productView === 'slide'}
                            onChange={(event) => handleStateChange('productView', 'slide', "")}
                          />
                        </BlockStack>
                      </BlockStack>
                    </BlockStack>
                  </FormLayout>
                </Card>
              </BlockStack>
            </Layout.AnnotatedSection>
            <Box as="div" className="annotated-section">
              <Divider borderWidth="050" />
            </Box>

            {/* Upsell product selection */}
            <Layout.AnnotatedSection
              id="edit-timeframe-settings"
              title={t('Settings.UpsellCreate.productSelectSection.title')}
              description={t('Settings.UpsellCreate.productSelectSection.description')}
            >
              <BlockStack gap={400}>
                <Card>
                  <FormLayout>
                    <BlockStack gap={200}>
                      <Text fontWeight="semibold" as="h4">{t('Settings.UpsellCreate.productSelectSection.section.title')}</Text>
                      {
                        selectedPrduct.length > 0
                          ? <Box>
                            <BlockStack gap="200">
                              <InlineStack align='space-between'>
                                <Checkbox
                                  label={replaceNumber(t('Settings.UpsellCreate.productSelectSection.section.itemsShow'), selectedPrduct.length)}
                                  checked={selectedItems.length === selectedPrduct.length && selectedPrduct.length > 0}
                                  onChange={handleSelectAll}
                                />
                                <Button onClick={handleSelectProductRemove} disabled={selectedItems.length == 0}>
                                  {t('Settings.UpsellCreate.productSelectSection.section.allDelete')}
                                </Button>
                              </InlineStack>
                              <Divider />
                              <Box>
                                <BlockStack gap="200">
                                  {
                                    selectedPrduct.map((product, index) => (
                                      <Box key={index}>
                                        <InlineStack key={index} align="space-between">
                                          <InlineStack blockAlign="center" gap="200">
                                            <Checkbox
                                              checked={selectedItems.includes(index)}
                                              onChange={() => handleSelect(index)}
                                            />
                                            <InlineStack blockAlign="center" gap="200">
                                              <Thumbnail source={product?.images?.[0]?.originalSrc ?? thumbnail} size="small" alt="Black choker necklace" />
                                              <BlockStack>
                                                <Text fontWeight="semibold" as="h4">{product?.title}</Text>
                                                <Text as="p">{getPriceRange(product?.variants)}</Text>
                                              </BlockStack>
                                            </InlineStack>
                                          </InlineStack>
                                          <Button variant="plain" tone="critical" onClick={() => removeProductFormList(index)}>{t('Settings.UpsellCreate.productSelectSection.section.remove')}</Button>
                                        </InlineStack>
                                        <Box paddingBlockEnd="200"></Box>
                                        <Divider />
                                      </Box>
                                    ))
                                  }
                                  {
                                    selectedPrduct.length < 5 && <Box><Button onClick={openResourcePicker}>{t('Settings.UpsellCreate.productSelectSection.section.selectProduct')}</Button></Box>
                                  }
                                </BlockStack>
                              </Box>
                            </BlockStack>
                          </Box>
                          : <><Box padding={800} borderRadius="100" borderStyle="dashed" borderColor={productError ? "text-critical" : "icon-secondary"} borderWidth="0165">
                            <BlockStack gap="200" inlineAlign="center">
                              <Box>
                                <Button onClick={openResourcePicker}>{t('Settings.UpsellCreate.productSelectSection.section.selectProduct')}</Button>
                              </Box>
                              <BlockStack inlineAlign="center">
                                <Text as='p' tone="subdued">{t('Settings.UpsellCreate.productSelectSection.section.description')}</Text>
                              </BlockStack>
                            </BlockStack>
                          </Box>
                            {
                              productError &&
                              <Box>
                                <InlineStack gap="200">
                                  <Box className="error-icon">
                                    <Icon source={iconContent} />
                                  </Box><Text as='p' tone="critical" >{t('Settings.UpsellCreate.productSelectSection.section.errors')}</Text>
                                </InlineStack>
                              </Box>
                            }
                          </>
                      }
                    </BlockStack>
                  </FormLayout>
                </Card>
              </BlockStack>
            </Layout.AnnotatedSection>
            <Box as="div" className="annotated-section">
              <Divider borderWidth="050" />
            </Box>

            {/* Upsell discount */}
            <Layout.AnnotatedSection
              id="edit-timeframe-settings"
              title={t('Settings.UpsellCreate.discountsSection.title')}
              description={t('Settings.UpsellCreate.discountsSection.description')}
            >
              <BlockStack gap={400}>
                <Card>
                  <FormLayout>
                    <BlockStack gap={200}>
                      <Text fontWeight="semibold" as="h4">{t('Settings.UpsellCreate.discountsSection.section.title')}</Text>
                      <BlockStack gap={100}>
                        <Text as='p' tone="subdued">{t('Settings.UpsellCreate.discountsSection.section.description')}</Text>
                        <TextField
                          value={discountValue}
                          onChange={(event) => handleStateChange('discounts', event, "")}
                          autoComplete="off"
                          placeholder={t('Settings.UpsellCreate.discountsSection.section.placeholder')}
                        />
                      </BlockStack>
                    </BlockStack>
                  </FormLayout>
                </Card>
              </BlockStack>
            </Layout.AnnotatedSection>
            {/* Upsell end all settings */}
          </Layout>
        </Page>
      </Box>
    </>
  )
}