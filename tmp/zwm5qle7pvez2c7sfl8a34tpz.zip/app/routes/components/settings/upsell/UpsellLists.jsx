import { useState, useCallback, useEffect } from 'react';
import { Tooltip, CalloutCard, Box, Badge, Popover, ChoiceList, BlockStack, EmptySearchResult, IndexTable, Card, useIndexResourceState, InlineStack, Text, Button, Icon, TextField, ButtonGroup, Banner } from '@shopify/polaris';
import { useAppBridge, Modal, TitleBar } from "@shopify/app-bridge-react";
import { useTranslation } from 'react-i18next';
import { DeleteIcon, EditIcon, SearchIcon, SortIcon } from '@shopify/polaris-icons';
import APIServicess from '../../../services/ApiServices';
import { useDispatch, useSelector } from "react-redux";
import { setUpsellList } from "../../store/UpsellListSlice";
import { upsellPlan } from "../../common/Images";
import Skeleton from '../Skeleton';


export default function Lists({ setScreenShow, setUpsellId }) {
  // Import necessary hooks and utilities
  const { t } = useTranslation();
  const dispatch = useDispatch();
  const APIServ = new APIServicess();
  const shopify = useAppBridge();
  const storeValue = useSelector((state) => state.store);
  const planName = storeValue?.planName;
  const getUpsellList = useSelector((state) => state.upsellList);

  // State variables for component behavior
  const [upsellListData, setUpsellListData] = useState([]);
  const [selectedStatus, setSelectedStatus] = useState(null);
  const [changeStatus, setChangeStatus] = useState(null);
  const [isLoadingButton, setIsLoadingButton] = useState(false);
  const [searchValue, setSearchValue] = useState("");
  const [sortBy, setSortBy] = useState('DES');
  const [sortByActive, setSortByActive] = useState(false);
  const [currentPage, setCurrentPage] = useState(null);
  const [totalPage, setTotalPage] = useState(0);
  const [bannerShow, setBannerShow] = useState(true);
  const [totalCountItems, setTotalCountItems] = useState(0);
  const listLimit = 10;
  const [firstLoad, setFirstLoad] = useState(false);
  const [upsellRulesState, setUpsellRulesState] = useState(false);
  const [requestBody, setRequestBody] = useState({
    limit: listLimit,
    offset: 0,
    query: '',
    shortBy: sortBy
  });

  // Effect to initialize upsell list from Redux store
  useEffect(() => {
    const fetchNotification = async () => {
      if (getUpsellList) {
        setTotalCountItems(getUpsellList?.result?.totalCountItems)
        if (getUpsellList.result?.data && getUpsellList.result.data?.length > 0) {
          setUpsellListData(getUpsellList.result.data);
          setSelectedStatus(getUpsellList.result.activeId);
          setCurrentPage(getUpsellList.result.currentPage);
          setTotalPage(getUpsellList.result.numberOfPages);
        } else if (getUpsellList.result.totalCount > 0) {
          setRequestBody({ ...requestBody, offset: getUpsellList.currentPage - 1 });
        } else {
          setUpsellListData([]);
        }
        setFirstLoad(true)
      } else {
        const upsellList = await APIServ.getUpsellList({ limit: 10, offset: 0, shortBy: 'DES' });
        if (upsellList.status) {
          dispatch(setUpsellList(upsellList));
        }
      }
    }
    fetchNotification();    
    let hidingFeatures = storeValue?.hidingFeatures;
    const upsellRules = hidingFeatures?.includes('upsellRules');
    setUpsellRulesState(upsellRules);
  }, [getUpsellList])


  // Effect to fetch upsell list data based on request parameters
  useEffect(() => {
    if (firstLoad) {
      const fetchUpsellList = async () => {
        let getUpsellList = await APIServ.getUpsellList(requestBody);
        if (getUpsellList.status) {
          dispatch(setUpsellList(getUpsellList));
        }
      };
      fetchUpsellList();
      setIsLoadingButton(false);
      setSortByActive(false);
    }
  }, [requestBody]);

  // Function to handle status change of an upsell item
  const handleChange = (id, selectedStatus) => {
    setChangeStatus(id);
    let actionType = 'active';
    if (selectedStatus === id) {
      actionType = 'deactive';
      upsellStatusUpdate(id, actionType);
    } else if (selectedStatus && selectedStatus !== id) {
      shopify.modal.show('switch-upsell__popup');
    } else {
      upsellStatusUpdate(id, actionType);
    }
  };

  // Function to update the status of an upsell item
  const upsellStatusUpdate = (id, type) => {
    setIsLoadingButton(true);
    type == 'active' ? setSelectedStatus(id) : null;
    (async () => {
      try {
        const response = await APIServ.upsellListUpdate({ id: id, type: type });
        if (response.result) {
          setRequestBody({ ...requestBody, offset: 0 });
          shopify.modal.hide('switch-upsell__popup');
        }
      } catch (error) {
        console.error('Error update upsell lists:', error.response);
      }
    })();
  }

  // Function to delete an upsell item
  const deleteListItem = (id) => {
    setChangeStatus(id);
    shopify.modal.show('upsell-delete-item__popup');
  }

  const upsellListDelete = (id) => {
    (async () => {
      try {
        setIsLoadingButton(true);
        const response = await APIServ.upsellItemDelete(id);
        if (response.result) {
          setRequestBody({ ...requestBody });
          shopify.modal.hide('upsell-delete-item__popup');
        }
      } catch (error) {
        console.error('Error delete upsell lists:', error.response);
      }
    })();
  }

  // Render Empty State component based on total items count
  const emptyStateMarkup = totalCountItems > 0 ? (
    <EmptySearchResult
      title={t("Settings.upsellList.searchEmpty.title")}
      description={t("Settings.upsellList.searchEmpty.description")}
      withIllustration
    />
  ) : (
    <EmptySearchResult
      title={t("Settings.upsellList.notfound")}
      description={
        <Box as="span">
          <Button variant="primary" onClick={() => setScreenShow('create')}>
            {t("Settings.upsellList.btn")}
          </Button>
        </Box>
      }
      withIllustration
    />
  );

  // Handle to edit the upsell item
  const handleUrlOpen = (id) => {
    setScreenShow('update');
    setUpsellId(id);
  }

  // Handle search input change and fetch updated upsell lists
  const handleSearchChange = (value) => {
    setSearchValue(value);
    setTimeout(() => {
      const updatedRequestBody = {
        ...requestBody,
        query: value
      };
      setRequestBody(updatedRequestBody);
    }, 500);
  };

  // Toggle sorting and selection change visibility
  const toggleSortBy = useCallback(() => setSortByActive((prevSortByActive) => !prevSortByActive), []);
  const handleSortByChange = useCallback((value) => {
    setSortBy(value[0]);
    setRequestBody((prevRequestBody) => ({ ...prevRequestBody, shortBy: value[0] }));
  }, []);

  // Sort by popup button
  const sortByPopupButton = (
    <Button onClick={toggleSortBy} disclosure size="large">
      <Icon
        source={SortIcon}
        tone="base"
      />
    </Button>
  );

  // Manage resource selection state for upsell items
  const { selectedResources, allResourcesSelected, handleSelectionChange } = useIndexResourceState(upsellListData);
  const resourceName = {
    singular: t('Settings.upsellList.singular'),
    plural: t('Settings.upsellList.plural'),
  };

  // Generate table rows for upsell list items
  const rowMarkup = upsellListData.map(({ _id: id, name, createdAt, updatedAt, isActive }, index) => {
    const createdAtFormat = new Intl.DateTimeFormat('en-GB', {
      day: '2-digit',
      month: 'short',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
      timeZone: 'Asia/Kolkata'
    }).format(new Date(createdAt));
    const updatedAtFormat = new Intl.DateTimeFormat('en-GB', {
      day: '2-digit',
      month: 'short',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
      timeZone: 'Asia/Kolkata'
    }).format(new Date(updatedAt));
    return (
      <IndexTable.Row
        id={id}
        key={id}
        selected={selectedResources.includes(id)}
        position={index}
      >
        {/* Display Upsell Item Name */}
        <IndexTable.Cell>
          <Text variant="bodyMd" fontWeight="bold" as="span">
            {name}
          </Text>
        </IndexTable.Cell>

        {/* Display Active/Inactive Badge with Toggle Button */}
        <IndexTable.Cell>
          <Box style={{margin: 'auto', width: '60px'}}>
            <BlockStack inlineAlign="center">
              <Button variant="plain" onClick={() => handleChange(id, selectedStatus)}>
                {isActive ? (
                  <Badge tone="success">{t("Settings.upsellList.active")}</Badge>
                ) : (
                  <Badge tone="">{t("Settings.upsellList.inactive")}</Badge>
                )}
              </Button>
            </BlockStack>
          </Box>
        </IndexTable.Cell>

        {/* Toggle Upsell Item Status (Active/Inactive) */}
        <IndexTable.Cell>
          <BlockStack inlineAlign="center">
            <Button variant="plain" onClick={() => handleChange(id, selectedStatus)}>
                <span className={`switch__button  ${isActive == true ? 'selected' : ''}`}>
                    <span className="active-dot"></span>
                </span>
            </Button>
          </BlockStack>
        </IndexTable.Cell>

        {/* Display Created At Date */}
        <IndexTable.Cell>
          <BlockStack inlineAlign="center">
            {createdAtFormat}
          </BlockStack>
        </IndexTable.Cell>

        {/* Display Updated At Date */}
        <IndexTable.Cell>
          <BlockStack inlineAlign="center">
            {updatedAtFormat}
          </BlockStack>
        </IndexTable.Cell>
        {/* Action Buttons (Edit & Delete) */}
        <IndexTable.Cell>
          <BlockStack inlineAlign="end">
            <ButtonGroup>
              <Tooltip content={t("Settings.upsellList.editTooltip")}>
                <Button
                  onClick={() => handleUrlOpen(id)}
                  icon={EditIcon}
                  variant="tertiary"
                  size="micro"
                ></Button>
              </Tooltip>
              <Tooltip content={t("Settings.upsellList.deleteTooltip")}>
                <Button
                  onClick={() => deleteListItem(id, selectedStatus)}
                  icon={DeleteIcon}
                  variant="tertiary"
                  size="micro"
                  tone="critical"
                >
                </Button>
              </Tooltip>
            </ButtonGroup>
          </BlockStack>
        </IndexTable.Cell>
      </IndexTable.Row>
    )
  });


  return (
    <>
      {/* Check if the current plan is not 'professional', then show a CalloutCard to upgrade */}
      {upsellRulesState ? (
        <CalloutCard
          title={t("Settings.upsellList.calloutCardPlan.title")}
          illustration={upsellPlan}
          primaryAction={{
            variant: 'primary',
            content: t("Settings.upsellList.calloutCardPlan.btn"),
            url: "/app/pricing"
          }}
        >
          <p>{t("Settings.upsellList.calloutCardPlan.description")}</p>
        </CalloutCard>
      ) : (
        <>
          {/* Modal for switching upsell status */}
          <Modal id="switch-upsell__popup" onHide={() => setIsLoadingButton(false)}>
            <Box>
              <Box padding={500}>
                <Text>{t("Settings.upsellList.switchUpsellMessage")}</Text>
                <br />
                <Text><strong>{t("Settings.upsellList.note")}</strong>{t("Settings.upsellList.switchUpsellNote")}</Text>
              </Box>
              <Box padding={{ xs: '400', sm: '400' }} borderBlockStartWidth="0165" borderColor="border-brand">
                <InlineStack align="end" gap={100}>
                  <Button onClick={() => shopify.modal.hide('switch-upsell__popup')}>{t("Settings.upsellList.cancel")}</Button>
                  <Button variant="primary" onClick={() => upsellStatusUpdate(changeStatus, 'active')} loading={isLoadingButton}>
                    {t("Settings.upsellList.switch")}
                  </Button>
                </InlineStack>
              </Box>
            </Box>
            <TitleBar title={t("Settings.upsellList.switchUpsell")}></TitleBar>
          </Modal>
          
          {/* Modal for deleting an upsell item */}
          <Modal id="upsell-delete-item__popup" onHide={() => setIsLoadingButton(false)}>
            <Box>
              <Box padding={500}>{t("Settings.upsellList.deleteUpsellMessage")}</Box>
              <Box padding={{ xs: '400', sm: '400' }} borderBlockStartWidth="0165" borderColor="border-brand">
                <InlineStack align="end" gap={100}>
                  <Button onClick={() => shopify.modal.hide('upsell-delete-item__popup')}>{t("Settings.upsellList.cancel")}</Button>
                  <Button variant="primary" tone="critical" onClick={() => upsellListDelete(changeStatus, 'active')} loading={isLoadingButton}>
                    {t("Settings.upsellList.delete")}
                  </Button>
                </InlineStack>
              </Box>
            </Box>
            <TitleBar title={t("Settings.upsellList.deleteUpsell")}></TitleBar>
          </Modal>

          {/* Main Upsell List UI */}
          {
            !getUpsellList ? <Skeleton /> : <Box>
            <BlockStack gap="400">

              {/* Header with title and create button */}
              <InlineStack blockAlign="center" align="space-between" gap="200">
              <Box className="upsell-list__title">
                <Text variant="headingLg" as="h6">{t('Settings.upsellList.title')}</Text>
              </Box>
                
                {totalCountItems > 0 && (
                  <Button variant="primary" onClick={() => setScreenShow('create')}>{t('Settings.upsellList.btn')}</Button>
                )}
              </InlineStack>

              {/* Display banner if there are upsell items */}
              {totalCountItems > 0 && bannerShow && (
                <Banner onDismiss={() => (setBannerShow(false))}>{<span dangerouslySetInnerHTML={{ __html: t("Settings.upsellList.bannerText") }}></span>}</Banner>
              )}

              {/* Card containing search bar and table */}
              <Card padding={{ xs: '0', sm: '0' }}>
                {totalCountItems > 0 && (
                  <Box className="searchbar-with__filters">
                    <TextField
                      prefix={<Icon source={SearchIcon} />}
                      value={searchValue}
                      onChange={handleSearchChange}
                      placeholder="Search"
                      clearButton
                      onClearButtonClick={() => handleSearchChange("")}
                    />
                    <Popover
                      active={sortByActive}
                      activator={sortByPopupButton}
                      autofocusTarget="first-node"
                      onClose={toggleSortBy}
                    >
                      <Box padding={{ xs: '400', sm: '400' }}>
                        <ChoiceList
                          choices={[
                            { label: 'Newest first', value: 'DES' },
                            { label: 'Oldest first', value: 'ASE' }
                          ]}
                          selected={sortBy}
                          onChange={handleSortByChange}
                        />
                      </Box>
                    </Popover>
                  </Box>
                )}

                {/* Table to display upsell list */}
                <IndexTable
                  resourceName={resourceName}
                  itemCount={upsellListData.length}
                  selectedItemsCount={
                    allResourcesSelected ? 'All' : selectedResources.length
                  }
                  selectable={false}
                  emptyState={ emptyStateMarkup}
                  onSelectionChange={handleSelectionChange}
                  headings={[
                    { title: t("Settings.upsellList.name") },
                    { title: t("Settings.upsellList.status"), alignment: "center" },
                    { title: t("Settings.upsellList.toggleRule"), alignment: "center" },
                    { title: t("Settings.upsellList.created"), alignment: "center" },
                    { title: t("Settings.upsellList.updated"), alignment: "center" },
                    { title: t("Settings.upsellList.actions"), alignment: "end" },
                  ]}
                  pagination={
                    upsellListData.length > 0
                      ? {
                        hasPrevious: currentPage > 0,
                        hasNext: totalPage > currentPage,
                        onNext: () => setRequestBody({ ...requestBody, offset: currentPage + 1 }),
                        onPrevious: () => setRequestBody({ ...requestBody, offset: currentPage - 1 }),
                      }
                      : undefined
                  }
                >
                  {rowMarkup}
                </IndexTable>
              </Card>
            </BlockStack>
          </Box>
          }
        </>
      )}
    </>
  )
}