import { useState, useMemo, useCallback, useEffect } from 'react';
import { Layout, Card, BlockStack, InlineStack, Icon, Checkbox, FormLayout, Banner, Link, Select, Text, TextField, Divider, Box, Button, ButtonGroup, RadioButton } from '@shopify/polaris';
import { useAppBridge, SaveBar } from "@shopify/app-bridge-react";
import { useTranslation } from 'react-i18next';
import { DiscountIcon, DeleteIcon, EditIcon, CashDollarIcon, CheckIcon } from '@shopify/polaris-icons';
import APIServicess from '../../services/ApiServices';
import { useDispatch, useSelector } from "react-redux";
import { setSettings } from "../store/SettingsSlice";
import { setSetup } from "../store/SetupSlice";
import { useNavigate } from "@remix-run/react";

export default function Cancellations({ setSaveBarActive }) {
    // Import necessary hooks and utilities
    const dispatch = useDispatch();
    const storeValue = useSelector((state) => state.store);
    const settings = useSelector((state) => state.settings);
    const shopify = useAppBridge();
    const { t } = useTranslation();
    const navigate = useNavigate();
    const APIServ = new APIServicess();

    // State variables for component behavior
    const [editingIndex, setEditingIndex] = useState(null);
    const [editingValue, setEditingValue] = useState('');
    const [newReasons, setNewReasons] = useState([]);
    const [restockingFeeError, setRestockingFeeError] = useState('');
    const [saveBarLoading, setSaveBarLoading] = useState(false);
    const [saveBarOpen, setSaveBarOpen] = useState(false);
    const [restockingFeeState, setRestockingFeeState] = useState(false);
    const [cancellationReasonsState, setCancellationReasonsState] = useState(false);
    const planName = storeValue?.planName;    

    // State management for cancellation setting fields
    const [state, setState] = useState({
        smartCancellation: false,
        restockingFee: false,
        restockingFeeValue: '',
        restockingFeeMessage: '',
        restockingFeeType: 'percentage',
        cancellationReasons: [],
        credit : "originalPayment"
    });
    const [initialState, setInitialState] = useState(state);

    // Effect to initialize settings from Redux store
    useEffect(() => {
        const fetchNotification = async () => {
            if (settings?.cancelOrder) {
                const cancelOrder = settings.cancelOrder.isOn;
                const credit = settings.cancelOrder.credit || "originalPayment";
                let restockingFee = settings.cancelOrder.restockingFees?.isOn;
                // Restocking fee only applies to 'professional' plan
                
                let hidingFeatures = storeValue?.hidingFeatures;
                const hasrestockingFee = hidingFeatures?.includes('restockingFee');
                setRestockingFeeState(hasrestockingFee);
                const hasReasons = hidingFeatures?.includes('cancellationReasons');
                setCancellationReasonsState(hasReasons);
                if (hasrestockingFee) {
                    restockingFee = false;
                }
                const {
                    type: restockingFeeType,
                    value: restockingFeeValue,
                    message: restockingFeeMessage
                } = settings.cancelOrder.restockingFees || {};

                const cancellationReasons = Array.isArray(settings.cancelOrder.reason) && settings.cancelOrder.reason.length > 0
                    ? settings.cancelOrder.reason.map(item => item.desc)
                    : initialState.cancellationReasons;

                    console.log(cancellationReasons, "===============");

                const newState = {
                    smartCancellation: cancelOrder,
                    restockingFee,
                    restockingFeeType,
                    restockingFeeValue,
                    restockingFeeMessage,
                    cancellationReasons,
                    credit : credit
                };

                setInitialState(newState);
                setState(newState);
            } else {
                // Fetch settings after store data is fetched
                const setting = await APIServ.getShopSettings();
                if (setting.status) {
                    dispatch(setSettings(setting.result));
                }
            }
        }
        fetchNotification();
    }, [settings]);

    // Tracks changes in state and updates the Shopify save bar accordingly
    useEffect(() => {
        const hasChanges = JSON.stringify(state) !== JSON.stringify(initialState)
        shopify.saveBar[hasChanges ? 'show' : 'hide']('cancellations-save-bar');
        hasChanges ? setSaveBarActive(true) : setSaveBarActive(false);
        hasChanges ? setSaveBarOpen(true) : setSaveBarOpen(false);
    }, [state, initialState]);


    // Memoized condition to disable UI elements when smart cancellation is off
    const isDisabled = useMemo(() =>
        !state.smartCancellation, [state.smartCancellation]
    );

    // Unified state update handler for various input fields
    const handleStateChange = useCallback((key) => (value) => {
        setState(prev => {
            const newState = { ...prev, [key]: value };
            if (key === 'restockingFeeType') {
                newState.restockingFeeValue = '';
            } else if (key === 'smartCancellation' && !value) {
                newState.restockingFee = false;
                setRestockingFeeError('');
            }
            return newState;
        });
    }, []);

    const handleRestockingFeeChange = useCallback((value) => {
        let numericValue = value.replace(/[^0-9]/g, '');
        numericValue = numericValue.replace(/^0+/, '');    
        // Treat undefined, null, or empty string as 'percentage'
        const restockingType = state?.restockingFeeType?.trim() || 'percentage';

        if (restockingType === 'percentage' && numericValue > 100) return;

        setState(prev => ({
            ...prev,
            restockingFeeValue: numericValue
        }));
    }, [state?.restockingFeeType]);


    // Adds a new empty reason field (max limit of 5)
    const handleAddReasonField = useCallback(() => {
        if (state.cancellationReasons.length + newReasons.length <= 5) {
            setNewReasons(prev => [...prev, '']);
        }
    }, []);

    // Enables editing mode for a specific cancellation reason
    const handleEditReason = useCallback((index) => {
        setEditingIndex(index);
        setEditingValue(state.cancellationReasons[index]);
    }, [state.cancellationReasons]);

    // Saves a newly added or edited cancellation reason
    const handleSaveReason = useCallback((index, reason, isNew = false) => {
        const trimmedReason = reason.trim();
        if (trimmedReason === '') {
            if (isNew) {
                setNewReasons(prev => prev.filter((_, i) => i !== index));
            } else {
                setEditingValue(state.cancellationReasons[index]);
            }
            setEditingIndex(null);
            return;
        }
        setState(prev => {
            const updatedReasons = isNew
                ? [...prev.cancellationReasons, trimmedReason]
                : prev.cancellationReasons.map((r, i) => (i === index ? trimmedReason : r));

            return { ...prev, cancellationReasons: updatedReasons };
        });
        if (isNew) {
            setNewReasons(prev => prev.filter((_, i) => i !== index));
        }
        setEditingIndex(null);
    }, [setState, setNewReasons, setEditingValue, setEditingIndex, state.cancellationReasons]);


    // Handles saving settings with API integration
    const handleSave = useCallback(async () => {
        setRestockingFeeError('');
        if(state.credit == 'originalPayment'){
            if (state.restockingFee && state.restockingFeeType !== 'shippingtaxes') {
                if (!state.restockingFeeValue) {
                    setRestockingFeeError(t('Settings.cancellations.restockingFees.errors.required'));
                    return;
                }
            }
        }
        setSaveBarLoading(true);
        let updateData = {
            cancelOrder: {
                isOn: state.smartCancellation,                
                restockingFees: {
                    isOn: (state.credit === 'originalPayment') ? state.restockingFee : false,
                    message: (state.credit === 'originalPayment') ? state.restockingFeeMessage : "",
                    type: (state.credit === 'originalPayment') ? (state.restockingFeeType == undefined ? 'percentage' : state.restockingFeeType) : "percentage",
                    value: (state.credit === 'originalPayment') ? parseInt(state.restockingFeeValue || 0) : 0 
                },
                credit : state.credit
            },
        }

        const isDataChanged = !areObjectsEqual(state.cancellationReasons, initialState.cancellationReasons);
        if(isDataChanged){  
            updateData.cancelOrder.reason = state.cancellationReasons.map((desc, index) => ({
                desc,
                key: `cr${index + 1}`
            }));
        }
        try {
            let response = await APIServ.UpdateShopSettings(updateData);
            if (response.status) {
                shopify.toast.show(t("Settings.success_message"), {
                    duration: 2000,
                });
                setSaveBarLoading(false);
                setSaveBarActive(false);
                shopify.saveBar.hide('cancellations-save-bar');
                let getSettings = await APIServ.getShopSettings();
                if (getSettings.status) {
                    dispatch(setSettings(getSettings.result));
                    let data = { smartCollections: true };
                    let response = await APIServ.setupGuideFetch(data);
                    dispatch(setSetup(response.result));
                }
            }
        } catch {
            console.error('Error saving settings:', e);
            shopify.saveBar.hide('cancellations-save-bar');
            setSaveBarActive(false);
            return;
        }
    }, [state]);

    // Resets all changes and restores the initial state
    const handleDiscard = useCallback(() => {
        setState(initialState);
        setEditingIndex(null);
        setNewReasons([]);
        setSaveBarActive(false);
        shopify.saveBar.hide('cancellations-save-bar');
    }, [initialState, shopify.saveBar]);


    // Redirects to the plan page
    const redirectPlanPage = (url) => {
        if (saveBarOpen) {
            shopify.saveBar.leaveConfirmation();
            return;
        }
        navigate(url);
    }

    const handleChange = (value) => {
        setState((prevState) => ({
            ...prevState,
            credit: value,
        }));
    };    

    // Compares two objects recursively to check for equality.
    const areObjectsEqual = (object1, object2) => {
        if (object1 === object2) return true;
        if (typeof object1 !== "object" || typeof object2 !== "object" || object1 === null || object2 === null) {
            return false;
        }
        const keys1 = Object.keys(object1);
        const keys2 = Object.keys(object2);

        if (keys1.length !== keys2.length) return false;
        return keys1.every(key => keys2.includes(key) && areObjectsEqual(object1[key], object2[key]));
    };

    return (
        <>
            {/* Save Bar for Discard and Save Actions */}
            <SaveBar id="cancellations-save-bar">
                <button onClick={handleDiscard}>{t('Settings.cancellations.buttons.discard')}</button>
                <button variant="primary" onClick={handleSave}{...(saveBarLoading ? { loading: "" } : {})}>{t('Settings.cancellations.buttons.save')}</button>
            </SaveBar>
            <Layout>
                {/* Smart Cancellation Settings Section */}
                <Layout.AnnotatedSection
                    id="edit-cancellations-settings"
                    title={t('Settings.cancellations.smartCancellationSettings.title')}
                    description={t('Settings.cancellations.smartCancellationSettings.description')}
                >
                    <BlockStack gap={400}>
                        <Card>
                            <FormLayout>
                                <BlockStack gap={200}>
                                    <Text fontWeight="semibold" as="h4">{t('Settings.cancellations.enableSmartCancellation.title')}</Text>
                                    <Checkbox
                                        label={t('Settings.cancellations.enableSmartCancellation.label')}
                                        checked={state.smartCancellation}
                                        value="smart_cancellation"
                                        onChange={handleStateChange('smartCancellation')}
                                    />
                                </BlockStack>
                            </FormLayout>
                        </Card>
                    </BlockStack>
                </Layout.AnnotatedSection>

                {/* Divider */}
                <Box as="div" className="annotated-section">
                    <Divider borderWidth="050" />
                </Box>

                {/* ===================================== */}
                <Layout.AnnotatedSection
                    id="order-editing-settings"
                    title={t('Settings.cancellations.cancelRefundOptions.title')}
                    description={t('Settings.cancellations.cancelRefundOptions.description')}
                >
                    <BlockStack gap={400}>
                        <Card>
                            <FormLayout>
                                <BlockStack gap={200}>
                                    <Text fontWeight="semibold" as="h4">{t('Settings.cancellations.cancelRefundOptions.sectionTitle')}</Text>
                                    <BlockStack>
                                        <RadioButton
                                            label={t('Settings.cancellations.cancelRefundOptions.radioBtn1.lable')}
                                            helpText={t('Settings.cancellations.cancelRefundOptions.radioBtn1.helpText')}
                                            checked={state.credit === 'originalPayment'}
                                            name="credit"
                                            onChange={()=>handleChange("originalPayment")}
                                            disabled={isDisabled}
                                        />
                                        <RadioButton
                                            label={t('Settings.cancellations.cancelRefundOptions.radioBtn2.lable')}
                                            helpText={t('Settings.cancellations.cancelRefundOptions.radioBtn2.helpText')}
                                            checked={state.credit === 'flowAction'}
                                            name="credit"
                                            onChange={()=>handleChange("flowAction")}
                                            disabled={isDisabled}
                                        />
                                    </BlockStack>                              
                                </BlockStack>
                            </FormLayout>
                        </Card>
                    </BlockStack>
                </Layout.AnnotatedSection>

                {/* Divider */}
                <Box as="div" className="annotated-section">
                    <Divider borderWidth="050" />
                </Box>
                {/* ===================================== */}

                {/* Restocking Fee Settings Section */}                
                <Layout.AnnotatedSection
                    id="order-editing-settings"
                    title={t('Settings.cancellations.restockingFees.title')}
                    description={t('Settings.cancellations.restockingFees.description')}
                >

                    <BlockStack gap={400}>
                        <Card>
                            <FormLayout>
                                <BlockStack gap={200}>
                                    <Text fontWeight="semibold" as="h4">{t('Settings.cancellations.restockingFees.enableRestockingFees.title')}</Text>
                                    <Checkbox
                                        label={t('Settings.cancellations.restockingFees.enableRestockingFees.enable')}
                                        // checked={isDisabled ? false : state.restockingFee}
                                        checked={(state.credit !== 'originalPayment' && !isDisabled) ? false : state.restockingFee}
                                        disabled={(state.credit !== 'originalPayment' && !isDisabled) ? true : isDisabled }
                                        // disabled={restockingFeeState  ? true : (state.credit === 'originalPayment' || isDisabled)}
                                        value="restockingFee"
                                        onChange={handleStateChange('restockingFee')}
                                    />

                                    {/* Show Upgrade Plan Message if Required */}
                                    {/* {planName != 'professional' && (
                                        <Text>{t('Settings.cancellations.restockingFees.requiredPlan')} <Button variant="plain" onClick={() => redirectPlanPage('/app/pricing')}>{t('Settings.cancellations.restockingFees.planUpgrade')}</Button></Text>
                                    )} */}

                                    {/* Restocking Fee Input Fields */}
                                    {state?.restockingFee && !restockingFeeState && state.credit == 'originalPayment' &&  (
                                        <Box className="motion-appear-above-animation">
                                            <Box as="div" className="restocking-fee-columns">
                                                {/* Restocking Fee Type Selection */}
                                                <Select
                                                    label={t('Settings.cancellations.restockingFees.enableRestockingFees.feeTypeLabel')}
                                                    options={t('Settings.cancellations.restockingFees.enableRestockingFees.feeType', { returnObjects: true })}
                                                    onChange={handleStateChange('restockingFeeType')}
                                                    value={state.restockingFeeType}
                                                    disabled={isDisabled}
                                                />
                                                {/* Restocking Fee Value Input */}
                                                <TextField
                                                    type="text"
                                                    prefix={
                                                        <Icon
                                                          source={
                                                            state?.restockingFeeType === 'percentage'
                                                              ? DiscountIcon
                                                              : state?.restockingFeeType
                                                              ? CashDollarIcon
                                                              : DiscountIcon
                                                          }
                                                          tone="base"
                                                        />
                                                      }
                                                    label={state?.restockingFeeType === "shippingtaxes"
                                                        ? t("Settings.cancellations.restockingFees.notApplicable")
                                                        : `${state?.restockingFeeType
                                                            ? state.restockingFeeType.charAt(0).toUpperCase() + state.restockingFeeType.slice(1)
                                                            : "Percentage"
                                                          } ${t('Settings.cancellations.restockingFees.enableRestockingFees.restockingFee')}`}
                                                    value={state?.restockingFeeValue > 0 ? state?.restockingFeeValue : ''}
                                                    onChange={handleRestockingFeeChange}
                                                    autoComplete="off"
                                                    error={restockingFeeError}
                                                    onFocus={() => setRestockingFeeError(false)}
                                                    disabled={!isDisabled && (state?.restockingFeeType !== 'percentage' && state?.restockingFeeType !== 'fixed')}
                                                />
                                            </Box>
                                            {/* Restocking Fee Note Input */}
                                            <TextField
                                                maxLength={80}
                                                showCharacterCount
                                                disabled={isDisabled}
                                                placeholder={t('Settings.cancellations.restockingFees.note.placeholder')}
                                                label={t('Settings.cancellations.restockingFees.note.label')}
                                                value={state?.restockingFeeMessage}
                                                onChange={handleStateChange('restockingFeeMessage')}
                                                autoComplete="off"
                                            />
                                        </Box>
                                    )}
                                </BlockStack>
                            </FormLayout>
                        </Card>
                    </BlockStack>
                </Layout.AnnotatedSection>

                {/* Divider */}
                <Box as="div" className="annotated-section">
                    <Divider borderWidth="050" />
                </Box>                  

                {/* Cancellation Reasons Section */}
                <Layout.AnnotatedSection
                    id="order-editing-settings"
                    title={t("Settings.cancellations.reasons.title")}
                    description={t("Settings.cancellations.reasons.description")}
                >
                    <BlockStack gap={400}>                        
                        <Card>
                            <Text fontWeight="semibold" as="h4">{t("Settings.cancellations.reasons.heading")}</Text>
                            {/* List of Cancellation Reasons */}
                            <Box className="reasons-lists">
                                {state.cancellationReasons.map((reason, index) => (
                                    <Box key={index} className="reason-list-item">
                                        {editingIndex === index ? (
                                            <Box className="reason-add-field">
                                                <TextField
                                                    disabled={isDisabled}
                                                    maxLength={80}
                                                    showCharacterCount
                                                    type="text"
                                                    placeholder={t("Settings.cancellations.reasons.heading")}
                                                    value={editingValue}
                                                    onChange={(value) => setEditingValue(value)}
                                                    autoComplete="off"
                                                />
                                                <Button disabled={isDisabled} size="large" variant="secondary" tone="success" icon={CheckIcon} onClick={() => handleSaveReason(index, editingValue)} />
                                            </Box>
                                        ) : (
                                            <InlineStack align="space-between" blockAlign="center">
                                                <Text>{reason}</Text>
                                                <ButtonGroup>
                                                    <Button disabled={isDisabled} size="large" icon={EditIcon} onClick={() => handleEditReason(index)} />
                                                    {state?.cancellationReasons?.length > 1 && (
                                                        <Button disabled={isDisabled}
                                                            size="large" tone="critical"
                                                            icon={DeleteIcon}
                                                            onClick={() => setState(prev => ({
                                                                ...prev,
                                                                cancellationReasons: prev.cancellationReasons.filter((_, i) => i !== index)
                                                            }))}
                                                        />
                                                    )}
                                                </ButtonGroup>
                                            </InlineStack>
                                        )}
                                    </Box>
                                ))}
                            </Box>

                            {/* New Cancellation Reasons */}
                            {newReasons.map((reason, index) => (
                                <Box key={index} className="reason-add-field new-reason">
                                    <TextField
                                        disabled={isDisabled}
                                        maxLength={80}
                                        showCharacterCount
                                        type="text"
                                        placeholder={t('Settings.cancellations.reasons.placeholder')}
                                        value={reason}
                                        onChange={(value) => setNewReasons(prev => {
                                            const updated = [...prev];
                                            updated[index] = value;
                                            return updated;
                                        })}
                                        autoComplete="off"

                                    />
                                    <Button
                                        disabled={isDisabled}
                                        size="large" variant="secondary"
                                        icon={CheckIcon}
                                        onClick={() => handleSaveReason(index, newReasons[index], true)}
                                    />
                                </Box>
                            ))}
                            {/* {state.cancellationReasons.length + newReasons.length == 5 && restockingFeeState && (
                                <Box className="new-reason">
                                    <Text>
                                        {t('Settings.cancellations.reasons.requiredPlan')}
                                        <Button variant="plain" onClick={() => redirectPlanPage('/app/pricing')}>
                                            {t('Settings.cancellations.reasons.planUpgrade')}
                                        </Button>
                                    </Text>
                                </Box>
                            )} */}

                            {/* Add Reason Button */}
                            <Button
                                disabled={state.cancellationReasons.length + newReasons.length == 5 && cancellationReasonsState ? true : isDisabled}
                                variant="secondary"
                                onClick={handleAddReasonField}>{t("Settings.cancellations.reasons.add")}</Button>
                                <Box padding="200"></Box>
                                <Banner>{<span dangerouslySetInnerHTML={{ __html: t("Settings.cancellations.reasons.bannerText") }} style={{paddingRight: '5px'}}></span>}<Button variant='plain' url={`/app/localization`}>{t('Settings.timeframe.shippingDetails.link')}</Button></Banner>
                        </Card>
                    </BlockStack>
                </Layout.AnnotatedSection>
            </Layout>
        </>
    );
}   