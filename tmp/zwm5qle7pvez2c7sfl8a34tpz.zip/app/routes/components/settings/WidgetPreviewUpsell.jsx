import { BlockStack, Box, Card, InlineStack, Text, Thumbnail, Icon, Button, Image, useBreakpoints, InlineGrid, Scrollable } from "@shopify/polaris";
import {
    ProductIcon
} from '@shopify/polaris-icons';
import { useSelector } from "react-redux";
import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';

export default function WidgetPreviewUpsell({ setShowUpsellList }) {
    const getUpsellList = useSelector((state) => state.upsellList);
    const [view, setView] = useState('list');
    const storeValue = useSelector((state) => state.store);
    const { lgUp } = useBreakpoints();
    const { t } = useTranslation();
    useEffect(() => {
        if (getUpsellList) {
            let idToFind = getUpsellList?.result?.activeId;
            let data = getUpsellList?.result?.data;
            const filteredItem = data.find(item => item._id === idToFind);
            const selectView = filteredItem ? filteredItem.selectView : "list";
            setView(selectView);
            setShowUpsellList(storeValue?.planName == 'professional' ? true : false);
        }
    }, [getUpsellList])

    return (
        <>
            {
                // storeValue?.planName == 'professional' && <Box>
                <Box>
                    <Card>
                        <Box>
                            <BlockStack gap="800">
                                <Text variant="headingXl" as="h3">{t('Settings.previewWidget.upsellTitle')}</Text>
                                {
                                    view == 'list' ? <BlockStack gap="200">
                                        <InlineStack>
                                            <InlineStack blockAlign="center" gap="200">
                                                <Thumbnail
                                                    source="https://cdn.shopify.com/s/files/1/0906/1076/2016/files/Main_0a40b01b-5021-48c1-80d1-aa8ab4876d3d.jpg"
                                                    alt="Black choker necklace"
                                                />
                                                <BlockStack gap="50">
                                                    <Text as="p" variant="headingMd" fontWeight="medium">Black Leather Choker Necklace</Text>
                                                    <InlineStack align="start" gap="100">
                                                        <Box>
                                                            <Icon
                                                                source={ProductIcon}
                                                                tone="info"
                                                            />
                                                        </Box>
                                                        <Text as="p" fontWeight="regular" tone="magic-subdued">$850.00 (10% off)</Text>
                                                    </InlineStack>
                                                </BlockStack>
                                            </InlineStack>
                                            <InlineStack blockAlign="center" gap="200">
                                                <Text as="p" variant="headingMd">$765.00</Text>
                                                <Button>Select</Button>
                                            </InlineStack>
                                        </InlineStack>

                                        <Box position="relative" className="upsell-or-condition">
                                            <Text as="p" fontWeight="regular">Or</Text>
                                        </Box>

                                        <InlineStack>
                                            <InlineStack blockAlign="center" gap="200">
                                                <Thumbnail
                                                    source="https://cdn.shopify.com/s/files/1/0906/1076/2016/files/Main_0a40b01b-5021-48c1-80d1-aa8ab4876d3d.jpg"
                                                    alt="Black choker necklace"
                                                />
                                                <BlockStack gap="50">
                                                    <Text as="p" variant="headingMd" fontWeight="medium">The 3p Fulfilled Snowboard</Text>
                                                    <InlineStack align="start" gap="100">
                                                        <Box>
                                                            <Icon
                                                                source={ProductIcon}
                                                                tone="info"
                                                            />
                                                        </Box>
                                                        <Text as="p" fontWeight="regular" tone="magic-subdued">$1000.00 (10% off)</Text>
                                                    </InlineStack>
                                                </BlockStack>
                                            </InlineStack>
                                            <InlineStack blockAlign="center" gap="200">
                                                <Text as="p" variant="headingMd">$900.00</Text>
                                                <Button>Select</Button>
                                            </InlineStack>
                                        </InlineStack>

                                        <Box position="relative" className="upsell-or-condition">
                                            <Text as="p" fontWeight="regular">Or</Text>
                                        </Box>

                                        <InlineStack>
                                            <InlineStack blockAlign="center" gap="200">
                                                <Thumbnail
                                                    source="https://cdn.shopify.com/s/files/1/0906/1076/2016/files/Main_0a40b01b-5021-48c1-80d1-aa8ab4876d3d.jpg"
                                                    alt="Black choker necklace"
                                                />
                                                <BlockStack gap="50">
                                                    <Text as="p" variant="headingMd" fontWeight="medium">The Videographer Snowboard</Text>
                                                    <InlineStack align="start" gap="100">
                                                        <Box>
                                                            <Icon
                                                                source={ProductIcon}
                                                                tone="info"
                                                            />
                                                        </Box>
                                                        <Text as="p" fontWeight="regular" tone="magic-subdued">$500.00 (10% off)</Text>
                                                    </InlineStack>
                                                </BlockStack>
                                            </InlineStack>
                                            <InlineStack blockAlign="center" gap="200">
                                                <Text as="p" variant="headingMd">$450.00</Text>
                                                <Button>Select</Button>
                                            </InlineStack>
                                        </InlineStack>
                                    </BlockStack> :
                                    <Scrollable horizontal>
                                        <Box width="1200px" paddingBlockEnd="400">                                        
                                        <InlineStack gap="800" wrap={false}>
                                            <Box className="upsell-or-condition-line" position="relative">
                                                <BlockStack gap="200">
                                                    <Box borderColor="bg" borderStyle="solid" borderWidth="0165">
                                                        <Image src="https://cdn.shopify.com/s/files/1/0906/1076/2016/files/Main_0a40b01b-5021-48c1-80d1-aa8ab4876d3d.jpg" alt="Upsell product" width="100%" />
                                                    </Box>
                                                    <Text as="p" variant="headingMd" fontWeight="medium">The Multi-location Snowboard</Text>
                                                    <InlineStack align="start" gap="100">
                                                        <Box>
                                                            <Icon
                                                                source={ProductIcon}
                                                                tone="info"
                                                            />
                                                        </Box>
                                                        <Text as="p" fontWeight="regular" tone="magic-subdued">$600.00 (10% off)</Text>
                                                    </InlineStack>
                                                    <Text as="p" variant="headingMd">$540.00</Text>
                                                    <Button>Select</Button>
                                                </BlockStack>
                                                {
                                                    lgUp && <Box className="upsell-or-condition-or">
                                                        <Text as="p" fontWeight="regular">Or</Text>
                                                    </Box>
                                                }
                                            </Box>
                                            <Box className="upsell-or-condition-line" position="relative">
                                                <BlockStack gap="200">
                                                    <Box borderColor="bg" borderStyle="solid" borderWidth="0165">
                                                        <Image src="https://cdn.shopify.com/s/files/1/0906/1076/2016/files/Main_0a40b01b-5021-48c1-80d1-aa8ab4876d3d.jpg" alt="Upsell product" width="100%" />
                                                    </Box>
                                                    <Text as="p" variant="headingMd" fontWeight="medium">Black Leather Choker Necklace</Text>
                                                    <InlineStack align="start" gap="100">
                                                        <Box>
                                                            <Icon
                                                                source={ProductIcon}
                                                                tone="info"
                                                            />
                                                        </Box>
                                                        <Text as="p" fontWeight="regular" tone="magic-subdued">$850.00 (10% off)</Text>
                                                    </InlineStack>
                                                    <Text as="p" variant="headingMd">$765.00</Text>
                                                    <Button>Select</Button>
                                                </BlockStack>
                                                {
                                                    lgUp && <Box className="upsell-or-condition-or">
                                                        <Text as="p" fontWeight="regular">Or</Text>
                                                    </Box>
                                                }
                                            </Box>
                                            <Box className="upsell-or-condition-line" position="relative">
                                                <BlockStack gap="200">
                                                    <Box borderColor="bg" borderStyle="solid" borderWidth="0165">
                                                        <Image src="https://cdn.shopify.com/s/files/1/0906/1076/2016/files/Main_0a40b01b-5021-48c1-80d1-aa8ab4876d3d.jpg" alt="Upsell product" width="100%" />
                                                    </Box>
                                                    <Text as="p" variant="headingMd" fontWeight="medium">The 3p Fulfilled Snowboard</Text>
                                                    <InlineStack align="start" gap="100">
                                                        <Box>
                                                            <Icon
                                                                source={ProductIcon}
                                                                tone="info"
                                                            />
                                                        </Box>
                                                        <Text as="p" fontWeight="regular" tone="magic-subdued">$1000.00 (10% off)</Text>
                                                    </InlineStack>
                                                    <Text as="p" variant="headingMd">$100.00</Text>
                                                    <Button>Select</Button>
                                                </BlockStack>
                                                {
                                                    lgUp && <Box className="upsell-or-condition-or">
                                                        <Text as="p" fontWeight="regular">Or</Text>
                                                    </Box>
                                                }
                                            </Box>
                                            <Box className="upsell-or-condition-line" position="relative">
                                                <BlockStack gap="200">
                                                    <Box borderColor="bg" borderStyle="solid" borderWidth="0165">
                                                        <Image src="https://cdn.shopify.com/s/files/1/0906/1076/2016/files/Main_0a40b01b-5021-48c1-80d1-aa8ab4876d3d.jpg" alt="Upsell product" width="100%" />
                                                    </Box>
                                                    <Text as="p" variant="headingMd" fontWeight="medium">The Videographer Snowboard</Text>
                                                    <InlineStack align="start" gap="100">
                                                        <Box>
                                                            <Icon
                                                                source={ProductIcon}
                                                                tone="info"
                                                            />
                                                        </Box>
                                                        <Text as="p" fontWeight="regular" tone="magic-subdued">$500.00 (10% off)</Text>
                                                    </InlineStack>
                                                    <Text as="p" variant="headingMd">$450.00</Text>
                                                    <Button>Select</Button>
                                                </BlockStack>
                                                {
                                                    lgUp && <Box className="upsell-or-condition-or">
                                                        <Text as="p" fontWeight="regular">Or</Text>
                                                    </Box>
                                                }
                                            </Box>
                                            <Box className="upsell-or-condition-line" position="relative">
                                                <BlockStack gap="200">
                                                    <Box borderColor="bg" borderStyle="solid" borderWidth="0165">
                                                        <Image src="https://cdn.shopify.com/s/files/1/0906/1076/2016/files/Main_0a40b01b-5021-48c1-80d1-aa8ab4876d3d.jpg" alt="Upsell product" width="100%" />
                                                    </Box>
                                                    <Text as="p" variant="headingMd" fontWeight="medium">Black Leather Choker Necklace</Text>
                                                    <InlineStack align="start" gap="100">
                                                        <Box>
                                                            <Icon
                                                                source={ProductIcon}
                                                                tone="info"
                                                            />
                                                        </Box>
                                                        <Text as="p" fontWeight="regular" tone="magic-subdued">$200.00 (10% off)</Text>
                                                    </InlineStack>
                                                    <Text as="p" variant="headingMd">$180.00</Text>
                                                    <Button>Select</Button>
                                                </BlockStack>
                                            </Box>
                                        </InlineStack>
                                        </Box>
                                    </Scrollable>
                                }
                            </BlockStack>
                        </Box>
                    </Card>
                </Box>
                // </Box>
            }
        </>
    )
}