import { Layout, BlockStack, Card, FormLayout, Checkbox, Text, Box, Divider, TextField, InlineStack, Button, Icon, Link, Banner, Select } from '@shopify/polaris';
import { useState, useCallback, useEffect, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import APIServicess from '../../services/ApiServices';
import { useDispatch, useSelector } from "react-redux";
import { useAppBridge, SaveBar } from "@shopify/app-bridge-react";
import { setSettings } from "../store/SettingsSlice";
import Skeleton from './Skeleton';
export default function Shipping({ setSaveBarActive, setSearchParams, setSelectedTab }) {
    // Import necessary hooks and utilities
    const dispatch = useDispatch();
    const storeValue = useSelector((state) => state.store);
    const settings = useSelector((state) => state.settings);
    const shopify = useAppBridge();
    const { t } = useTranslation();
    const APIServ = new APIServicess();

    const [saveBarLoading, setSaveBarLoading] = useState(false);
    const [shippingEnable, setShippingEnable] = useState(true);
    const [object, setObject] = useState({});
    const [initialState, setInitialState] = useState({});
    const [shippingSection, setShippingSection] = useState(false);

    // Set initial state set
    useEffect(() => {
        const fetchSettings = async () => {
            if (!settings || Object.keys(settings).length === 0) {
                // Fetch settings after store data is fetched
                const setting = await APIServ.getShopSettings();
                if (setting.status) {
                    dispatch(setSettings(setting.result));
                    setShippingEnable(setting?.result?.shippingDetails?.isOn);
                    setShippingSection(true);
                    let shipping = setting?.result?.shipping;
                    let update = {
                        city: shipping?.shippingAddress?.city || false,
                        state: shipping?.shippingAddress?.state || false,
                        country: shipping?.shippingAddress?.country || false,
                        smarterAddress: shipping?.addressLookup?.isOn || false,
                        customerAddresses: shipping?.addressValidation?.isOn || false,
                        recalculateShipping: shipping?.enableShippingFee?.isOn || false,
                        recalculateShippingItem: shipping?.enableShippingFeeItem?.isOn || false,
                        splitShippingToggle: shipping?.splitShippingToggle?.isOn || false,
                    };
                    setObject(update);
                    setInitialState(update);
                }
            } else {
                setShippingEnable(settings?.shippingDetails?.isOn);
                setShippingSection(true);
                let shipping = settings?.shipping;
                let update = {
                    city: shipping?.shippingAddress?.city || false,
                    state: shipping?.shippingAddress?.state || false,
                    country: shipping?.shippingAddress?.country || false,
                    smarterAddress: shipping?.addressLookup?.isOn || false,
                    customerAddresses: shipping?.addressValidation?.isOn || false,
                    recalculateShipping: shipping?.enableShippingFee?.isOn || false,
                    splitShippingToggle: shipping?.splitShippingToggle?.isOn || false,
                    recalculateShippingItem: shipping?.enableShippingFeeItem?.isOn || false,
                };
                setObject(update);
                setInitialState(update);
            }
        }
        fetchSettings();
    }, [settings]);

    //Handle discard all changes 
    const handleDiscard = () => {
        setObject(initialState);
    }

    //save all changes
    const handleSave = async () => {
        setSaveBarLoading(true);
        try {
            let updateData = {
                shipping: {
                    shippingAddress: {
                        city: object.city,
                        state: object.city ? object.state : false,
                        country: !object.city ? false : !object.state ? false : object.country,
                    },
                    addressLookup: {
                        isOn: object.smarterAddress,
                    },
                    addressValidation: {
                        isOn: object.customerAddresses,
                    },
                    enableShippingFee: {
                        isOn: object.recalculateShipping,
                    },
                    enableShippingFeeItem: {
                        isOn: !object.recalculateShipping ? false : object.recalculateShippingItem,
                    },                    
                    splitShippingToggle : {
                        isOn : object.splitShippingToggle
                    }
                }
            }
            let response = await APIServ.UpdateShopSettings(updateData);
            if (response.status) {
                shopify.toast.show(t("Settings.success_message"), {
                    duration: 2000,
                });
                setSaveBarActive(false);
                shopify.saveBar.hide('timeframe-save-bar');
                let getSettings = await APIServ.getShopSettings();
                if (getSettings.status) {
                    dispatch(setSettings(getSettings.result));
                }
            }
        } catch (error) {
            console.log(error);
        } finally {
            setSaveBarLoading(false);
        }
    }

    //save all changes
    const handleChangeChecked = (type, value) => {
        setObject((prev) => {
            const updated = {
                ...prev,
                [type]: value,
            };

            if (type === 'recalculateShipping' && !value) {
                updated.recalculateShippingItem = false;
            }

            return updated;
        });
    };

    //save all changes
    const backToTimeframe = () => {
        setSearchParams({ type: "editing" });
        setSelectedTab(0);
    }

    //Check changes
    useEffect(() => {
        const isDataChanged = !areObjectsEqual(object, initialState);
        setSaveBarActive(isDataChanged);
        if (isDataChanged) {
            shopify.saveBar.show('timeframe-save-bar');
        } else {
            shopify.saveBar.hide('timeframe-save-bar');
        }
    }, [object, initialState]);

    // Compares two objects recursively to check for equality.
    const areObjectsEqual = (object1, object2) => {
        if (object1 === object2) return true;
        if (typeof object1 !== "object" || typeof object2 !== "object" || object1 === null || object2 === null) {
            return false;
        }
        const keys1 = Object.keys(object1);
        const keys2 = Object.keys(object2);

        if (keys1.length !== keys2.length) return false;
        return keys1.every(key => keys2.includes(key) && areObjectsEqual(object1[key], object2[key]));
    };

    return (
        <>
            <SaveBar id="timeframe-save-bar">
                <button onClick={handleDiscard}>{t('Settings.timeframe.buttons.discard')}</button>
                <button variant="primary" onClick={handleSave}{...(saveBarLoading ? { loading: "" } : {})}>{t('Settings.timeframe.buttons.save')}</button>
            </SaveBar>
            {
                !settings ? <Skeleton /> : <>
                    {
                        !shippingEnable && <Box className="timeframe-info-banner">
                            <Banner tone="warning">{<><span dangerouslySetInnerHTML={{ __html: t('Settings.Shipping.banner.text') }}></span> <Button variant='plain' onClick={() => backToTimeframe()}>{t('Settings.Shipping.banner.link')}</Button></>}</Banner>
                        </Box>
                    }
                    {
                        shippingSection && <Box className="upsell-create motion-appear-above-animation">
                            <Layout>
                                
                                {/* <Layout.AnnotatedSection
                            id="edit-timeframe-settings"
                            title={t('Settings.Shipping.smarterAddress.title')}
                            description={t('Settings.Shipping.smarterAddress.description')}
                        >
                            <BlockStack gap={400}>
                                <Card>
                                    <FormLayout>
                                        <BlockStack gap={200}>
                                            <Text fontWeight="semibold" as="h4">
                                                {t('Settings.Shipping.smarterAddress.settingSection.title')}
                                            </Text>
                                            <BlockStack gap={100}>
                                                <Checkbox
                                                    label={t('Settings.Shipping.smarterAddress.settingSection.lable')}
                                                    checked={(!shippingEnable) ? false : object.smarterAddress}
                                                    onChange={()=>handleChangeChecked('smarterAddress', !object.smarterAddress)}
                                                    disabled={!shippingEnable}
                                                />
                                            </BlockStack>
                                        </BlockStack>
                                    </FormLayout>
                                </Card>
                            </BlockStack>
                        </Layout.AnnotatedSection>  */}
                                {/* Divider */}
                                {/* <Box as="div" className="annotated-section">
                            <Divider borderWidth="050" />
                        </Box>  */}

                                

                                <Layout.AnnotatedSection
                                    id="edit-timeframe-settings"
                                    title={t('Settings.Shipping.recalculateShipping.title')}
                                    description={t('Settings.Shipping.recalculateShipping.description')}
                                >
                                    <BlockStack gap={400}>
                                        <Card>
                                            <FormLayout>
                                                <BlockStack gap={200}>
                                                    <Text fontWeight="semibold" as="h4">
                                                        {t('Settings.Shipping.recalculateShipping.settingSection.title')}
                                                    </Text>
                                                    <BlockStack gap={100}>
                                                        <Checkbox
                                                            label={t('Settings.Shipping.recalculateShipping.settingSection.lable')}
                                                            checked={(!shippingEnable) ? false : object.recalculateShipping}
                                                            onChange={() => handleChangeChecked('recalculateShipping', !object.recalculateShipping)}
                                                            disabled={!shippingEnable}
                                                        />
                                                    </BlockStack>
                                                </BlockStack>
                                            </FormLayout>
                                        </Card>
                                        <Card>
                                            <FormLayout>
                                                <BlockStack gap={200}>
                                                    <Text fontWeight="semibold" as="h4">
                                                        {t('Settings.Shipping.recalculateShipping.settingSection.title1')}
                                                    </Text>
                                                    <BlockStack gap={100}>
                                                        <Checkbox
                                                            label={t('Settings.Shipping.recalculateShipping.settingSection.lable1')}
                                                            checked={(!shippingEnable) ? false : (object.recalculateShippingItem && object.recalculateShipping)}
                                                            onChange={() => handleChangeChecked('recalculateShippingItem', !object.recalculateShippingItem)}
                                                            disabled={!shippingEnable ? !shippingEnable : !object.recalculateShipping}
                                                        />
                                                    </BlockStack>
                                                </BlockStack>
                                            </FormLayout>
                                        </Card>
                                    </BlockStack>
                                </Layout.AnnotatedSection>

                                {/* Divider */}
                                <Box as="div" className="annotated-section">
                                            <Divider borderWidth="050" /> 
                                        </Box>
                                        <Layout.AnnotatedSection
                                            id="edit-timeframe-settings"
                                            title={t('Settings.Shipping.splitShipping.title')}
                                            description={t('Settings.Shipping.splitShipping.description')}
                                        >
                                            <BlockStack gap={400}>
                                                <Card>
                                                    <FormLayout>
                                                        <BlockStack gap={200}>
                                                            <Text fontWeight="semibold" as="h4">
                                                                {t('Settings.Shipping.splitShipping.settingSection.title')}
                                                            </Text>
                                                            <BlockStack gap={100}>
                                                                <Checkbox
                                                                    label={t('Settings.Shipping.splitShipping.settingSection.lable')}
                                                                    checked={(!shippingEnable) ? false : object.splitShippingToggle}
                                                                    onChange={() => handleChangeChecked('splitShippingToggle', !object.splitShippingToggle)}
                                                                    // disabled={!shippingEnable }
                                                                    disabled={!shippingEnable}   
                                                                />
                                                            </BlockStack>
                                                        </BlockStack>
                                                    </FormLayout>
                                                </Card>
                                            </BlockStack>
                                        </Layout.AnnotatedSection>

                                <Layout.AnnotatedSection
                                    id="edit-timeframe-settings"
                                    title={t('Settings.Shipping.editableAddress.title')}
                                    description={t('Settings.Shipping.editableAddress.description')}
                                >
                                    <BlockStack gap={400}>
                                        <Card>
                                            <FormLayout>
                                                <BlockStack gap={200}>
                                                    <Text fontWeight="semibold" as="h4">
                                                        {t('Settings.Shipping.editableAddress.settingSection.title')}
                                                    </Text>
                                                    <Text variant="bodySm" as="p">{t('Settings.Shipping.editableAddress.settingSection.description')}</Text>
                                                    <BlockStack gap={100}>
                                                        <Checkbox
                                                            label={t('Settings.Shipping.editableAddress.settingSection.city')}
                                                            checked={(!shippingEnable) ? false : object.city}
                                                            onChange={() => handleChangeChecked('city', !object.city)}
                                                            disabled={!shippingEnable}
                                                        />
                                                        <Checkbox
                                                            label={t('Settings.Shipping.editableAddress.settingSection.state')}
                                                            checked={(!shippingEnable) ? false : (!object.city) ? false : object.state}
                                                            onChange={() => handleChangeChecked('state', !object.state)}
                                                            disabled={(!shippingEnable) ? true : !object.city}
                                                        />
                                                        <Checkbox
                                                            label={t('Settings.Shipping.editableAddress.settingSection.country')}
                                                            checked={(!shippingEnable) ? false : (!object.city) ? false : (!object.state) ? false : object.country}
                                                            onChange={() => handleChangeChecked('country', !object.country)}
                                                            disabled={(!shippingEnable) ? true : (!object.city) ? true : !object.state}
                                                        />
                                                    </BlockStack>
                                                    {
                                                        !object.city && <Banner>{<span dangerouslySetInnerHTML={{ __html: t("Settings.Shipping.editableAddress.settingSection.noteText") }}></span>}</Banner>
                                                    }
                                                </BlockStack>
                                            </FormLayout>
                                        </Card>
                                    </BlockStack>
                                </Layout.AnnotatedSection>

                                {/* Divider */}
                                <Box as="div" className="annotated-section">
                                    <Divider borderWidth="050" />
                                </Box>

                                <Layout.AnnotatedSection
                                    id="edit-timeframe-settings"
                                    title={t('Settings.Shipping.customerAddresses.title')}
                                    description={t('Settings.Shipping.customerAddresses.description')}
                                >
                                    <BlockStack gap={400}>
                                        <Card>
                                            <FormLayout>
                                                <BlockStack gap={200}>
                                                    <Text fontWeight="semibold" as="h4">
                                                        {t('Settings.Shipping.customerAddresses.settingSection.title')}
                                                    </Text>
                                                    <BlockStack gap={100}>
                                                        <Checkbox
                                                            label={t('Settings.Shipping.customerAddresses.settingSection.lable')}
                                                            checked={(!shippingEnable) ? false : object.customerAddresses}
                                                            onChange={() => handleChangeChecked('customerAddresses', !object.customerAddresses)}
                                                            disabled={!shippingEnable}
                                                        />
                                                    </BlockStack>
                                                </BlockStack>
                                            </FormLayout>
                                        </Card>
                                    </BlockStack>
                                </Layout.AnnotatedSection>

                                {/* Divider */}
                                <Box as="div" className="annotated-section">
                                    <Divider borderWidth="050" />
                                </Box>

                            </Layout>
                        </Box>
                    }
                </>
            }
        </>
    )
}