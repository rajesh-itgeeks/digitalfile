import { useState } from 'react';
import Lists from "./upsell/UpsellLists";
import UpsellCreate from "./upsell/UpsellCreate";
import UpsellUpdate from "./upsell/UpsellUpdate";

export default function Upsell({setSaveBarActive}) {  
    const [screenShow, setScreenShow] = useState('lists');
    const [upsellId, setUpsellId] = useState('');
    return (
        <>
            { screenShow === 'lists' && <Lists setScreenShow={setScreenShow} setUpsellId={setUpsellId}/> }
            { screenShow === 'create' && <UpsellCreate setScreenShow={setScreenShow} setSaveBarActive={setSaveBarActive}/> }
            { screenShow === 'update' && <UpsellUpdate setScreenShow={setScreenShow} setSaveBarActive={setSaveBarActive} upsellId={upsellId} /> }
        </>
    )
}