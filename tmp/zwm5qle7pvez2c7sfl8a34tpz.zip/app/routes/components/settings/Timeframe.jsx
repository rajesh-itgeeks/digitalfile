import { useState, useCallback, useEffect, useMemo } from 'react';
import { Layout, Card, Banner, ChoiceList, Checkbox, BlockStack, FormLayout, Select, Text, InlineGrid, TextField, Divider, Box, InlineStack, Button } from '@shopify/polaris';
import { useAppBridge, SaveBar } from "@shopify/app-bridge-react";
import { useTranslation } from 'react-i18next';
import APIServicess from '../../services/ApiServices';
import { useDispatch, useSelector } from "react-redux";
import { setSettings } from "../store/SettingsSlice";
import { setSetup } from "../store/SetupSlice";
import CreatableSelect from "react-select/creatable";

export default function Timeframe({ setSaveBarActive, setSearchParams, setSelectedTab }) {
    // Import necessary hooks and utilities
    const dispatch = useDispatch();
    const storeValue = useSelector((state) => state.store);
    const planStatus = useSelector((state) => state.planStatus);
    const settings = useSelector((state) => state.settings);
    const shopify = useAppBridge();
    const { t } = useTranslation();
    const APIServ = new APIServicess();

    // State variables for component behavior
    const [saveBarLoading, setSaveBarLoading] = useState(false);
    const [showBanner, setShowBanner] = useState(false);
    const [timeFrameError, setTimeFrameError] = useState(false);
    const [customTimeframeState, setCustomTimeframeState] = useState(false);
    const planName = storeValue?.planName;
    let hidingFeatures = storeValue?.hidingFeatures;
    const hascustomTimeframe = hidingFeatures?.includes('customTimeframe'); 
    const [orderTags, setOrderTags] = useState('');
    const [orderTagsOptions, setOrderTagsOptions] = useState([]);

    const [productTags, setProductTags] = useState('');
    const [productTagsOptions, setProductTagsOptions] = useState([]);

    // Filter time options based on plan name
    let timeOptions = t('Settings.timeframe.timeOptions', { returnObjects: true });
    if (hascustomTimeframe && planStatus) {
        timeOptions = timeOptions.filter(option => option.value !== "custom");
    }

    // State management for timeframe setting fields
    const [state, setState] = useState({
        selectedTimeframe: '',
        customDuration: 'minutes',
        customValue: 1,
        contactInfo: ["", ""],
        shippingDetails: true,
        supportOptions: true,
        orderItemOptions: ["", "", "", ""],
        orderTags : [],
        productTags : [],
        orderHolds : false,
        orderChangesRevert: false
    });
    const [initialState, setinitialState] = useState(state);
    const [isDisabled, setIsDisabled] = useState(true);

    // Effect to initialize settings from Redux store
    useEffect(() => {
        const fetchNotification = async () => {
            if (settings && Object.keys(settings).length > 0) {
                let selectedTime = settings.presetTimeFrame.type == 'custom' ? 'custom' : settings.presetTimeFrame.time;
                let customObject = [1, "minute"];
                if (selectedTime === 'custom' && settings?.presetTimeFrame?.time) {
                    const match = settings.presetTimeFrame.time.match(/^(\d+)([a-zA-Z]+)$/);
                    if (match) {
                        customObject = [parseInt(match[1], 10), match[2]];
                    }
                }
                // Construct updated state from settings
                const updatedState = {
                    selectedTimeframe: selectedTime,
                    customDuration: customObject[1],
                    customValue: customObject[0],
                    contactInfo: [settings.contactInformation.email.isOn && 'email', settings.contactInformation.phone.isOn && 'phone'].filter(Boolean),
                    shippingDetails: settings.shippingDetails.isOn,
                    supportOptions: settings.support.isOn,
                    orderItemOptions: [settings.orderItems?.increaseQuantity?.isOn && 'increaseQuantity', settings.orderItems?.decreaseQuantity?.isOn && 'decreaseQuantity', settings.orderItems?.swap?.isOn && 'swap', settings.orderItems?.removeItem?.isOn && 'remove', settings.orderItems?.addItems?.isOn && 'add'].filter(Boolean),
                    orderTags : settings?.orderTags,
                    productTags : settings?.productTags,
                    orderHolds : settings?.orderHolds?.isOn,
                    orderChangesRevert: settings?.orderChangesRevert?.isOn
                };

                let orderTags = settings?.orderTags;
                const formattedorderTag = orderTags?.map(orderTag => ({
                    label: orderTag,
                    value: orderTag
                }));
                setOrderTagsOptions(formattedorderTag);

                let productTags = settings?.productTags;
                const formattedproductTag = productTags?.map(productTag => ({
                    label: productTag,
                    value: productTag
                }));
                setProductTagsOptions(formattedproductTag);
    
                // Update component state with settings data
                setinitialState(updatedState);
                setState(updatedState);
                setIsDisabled(!updatedState.selectedTimeframe);
                setShowBanner(!updatedState.selectedTimeframe);
            } else {
                // Fetch settings after store data is fetched
                const setting = await APIServ.getShopSettings();
                if (setting.status) {
                    dispatch(setSettings(setting.result));
                }
            }
            setCustomTimeframeState(hascustomTimeframe);
        }
        fetchNotification();
    }, [settings])

    // Effect to track changes in state
    useEffect(() => {
        const hasChanges = JSON.stringify(state) !== JSON.stringify(initialState);
        shopify.saveBar[hasChanges ? 'show' : 'hide']('timeframe-save-bar');
        hasChanges ? setSaveBarActive(true) : setSaveBarActive(false);
    }, [state, initialState]);

    // Handler to update state based on user input
    const handleStateChange = (key) => (value) => {
        if (Array.isArray(value)) {
            const orderMap = {
                orderItemOptions: ['quantity', 'swap', 'remove', 'add'],
                contactInfo: ['email', 'phone']
            };
            const order = orderMap[key] || orderMap.default;
            value = value.sort((a, b) => order.indexOf(a) - order.indexOf(b));
        }
        setState(prev => ({ ...prev, [key]: value }));
        if (key === 'selectedTimeframe') {
            setIsDisabled(false);
            setShowBanner(false)
        }
    };

    // Handler to validate custom duration and change value accordingly
    const handleCustomValueChange = useCallback(value => {
        setState(prev => ({ ...prev, customValue: value.replace(/[^0-9]/g, '').replace(/^0+/, '') }));
    }, []);

    // Handler to validate and save settings in database
    const handleSave = async () => {
        setTimeFrameError(false);
        if (state.selectedTimeframe === 'custom' && !state.customValue) {
            setTimeFrameError(t('Settings.timeframe.customOptions.errors.required'));
            return;
        }
        setSaveBarLoading(true);
        let duration = state.customDuration == 'minute' ? 'minutes' : state.customDuration;
        let updateData = {
            presetTimeFrame: {
                time: state.selectedTimeframe == 'custom' ? state.customValue + duration : state.selectedTimeframe,
                type: state.selectedTimeframe == 'custom' ? 'custom' : ''
            },
            contactInformation: {
                email: { isOn: state.contactInfo.includes('email') },
                phone: { isOn: state.contactInfo.includes('phone') }
            },
            shippingDetails: { isOn: state.shippingDetails },
            support: { isOn: state.supportOptions },
            orderItems: {
                increaseQuantity: { isOn: state.orderItemOptions.includes('increaseQuantity') },
                decreaseQuantity: { isOn: state.orderItemOptions.includes('decreaseQuantity') },
                swap: { isOn: state.orderItemOptions.includes('swap') },
                removeItem: { isOn: state.orderItemOptions.includes('remove') },
                addItems: { isOn: state.orderItemOptions.includes('add') }
            },
            orderTags :  state.orderTags,
            productTags : state.productTags,
            orderHolds : { isOn: state.orderHolds },
            orderChangesRevert: {isOn: state.orderChangesRevert}
        }
        try {
            let response = await APIServ.UpdateShopSettings(updateData);
            if (response.status) {
                shopify.toast.show(t("Settings.success_message"), {
                    duration: 2000,
                });
                setSaveBarLoading(false);
                setSaveBarActive(false);
                shopify.saveBar.hide('timeframe-save-bar');
                let getSettings = await APIServ.getShopSettings();
                if (getSettings.status) {
                    dispatch(setSettings(getSettings.result));
                    let data = { editingWindow: true };
                    let response = await APIServ.setupGuideFetch(data);
                    dispatch(setSetup(response.result));
                }
            }
        } catch {
            console.error('Error saving settings:', e);
            setSaveBarActive(false);
            shopify.saveBar.hide('timeframe-save-bar');
            return;
        }
    };

    // Discard Handler to Reset State
    const handleDiscard = () => {
        setState(initialState);
        setIsDisabled(!initialState.selectedTimeframe);
        setShowBanner(!initialState.selectedTimeframe);        
        shopify.saveBar.hide('timeframe-save-bar');
        setSaveBarActive(false);

        let orderTags = initialState.orderTags;
        const formattedorderTags = orderTags.map(orderTag => ({
            label: orderTag,
            value: orderTag
        }));
        setOrderTagsOptions(formattedorderTags);

        let productTags = initialState.productTags;
        const formattedproductTags = productTags.map(productTag => ({
            label: productTag,
            value: productTag
        }));
        setProductTagsOptions(formattedproductTags);
    };

    // Generate Custom Duration Options Based on Value
    const getCustomOptions = () => {
        const value = parseInt(state.customValue);
        return [
            { label: value > 1 ? t('Settings.timeframe.customOptions.minutesPlural') : t('Settings.timeframe.customOptions.minutes'), value: 'minutes' },
            { label: value > 1 ? t('Settings.timeframe.customOptions.hoursPlural') : t('Settings.timeframe.customOptions.hours'), value: 'hours' },
            { label: value > 1 ? t('Settings.timeframe.customOptions.daysPlural') : t('Settings.timeframe.customOptions.days'), value: 'days' }
        ];
    };

    const isStateEmpty = useMemo(() => {
        return state.contactInfo.length === 0 &&
            state.orderItemOptions.length === 0 &&
            state.shippingDetails === false &&
            state.supportOptions === false;
    }, [state]);

    
    // Handle removal or clearing of selected emails
    const handleChangeOrderTags = (newValue) => {
        const cleanedOptions = [];
        const seen = new Set();    
        (newValue || []).forEach((option) => {
            const trimmed = option.value.trim();
            const lower = trimmed.toLowerCase();
    
            if (trimmed !== "" && !seen.has(lower)) {
                seen.add(lower);
                cleanedOptions.push({ ...option, value: trimmed });
            }
        });    
        setOrderTagsOptions(cleanedOptions);    
        setState((prevState) => ({
            ...prevState,
            orderTags: cleanedOptions.map((option) => option.value),
        }));
    };
    

    const handleKeyDownOrderTags = (event) => {
        const trimmedValue = orderTags?.trim();
        if (!trimmedValue) return;    
        if (event.key === 'Enter' || event.key === 'Tab') {
            event.preventDefault();    
            const lowerValue = trimmedValue.toLowerCase();
            const existingTags = (state.orderTags || []).map(tag => tag.toLowerCase());    
            if (existingTags.includes(lowerValue)) {
                setOrderTags('');
                return;
            }    
            const newOption = createOption(trimmedValue);    
            setOrderTagsOptions((prev = []) => [...prev, newOption]);    
            setState((prevState) => ({
                ...prevState,
                orderTags: [...(prevState.orderTags || []), trimmedValue],
            }));    
            setOrderTags('');
        }
    };

    // Remove dropdown arrow
    const customComponents = {
        DropdownIndicator: null,
        IndicatorSeparator: null,
    };

    //Handle feild Blur
    const handleBlurOrderTags = (event) => {
        const trimmedValue = orderTags?.trim();
        if (!trimmedValue) return;    
        const lowerValue = trimmedValue.toLowerCase();
        const existingTags = (state.orderTags || []).map(tag => tag.toLowerCase());    
        if (existingTags.includes(lowerValue)) {
            setOrderTags('');
            return; // Don't add duplicate (case-insensitive)
        }    
        const newOption = createOption(trimmedValue);    
        setOrderTagsOptions((prev = []) => [...prev, newOption]);    
        setState((prevState) => ({
            ...prevState,
            orderTags: [...(prevState.orderTags || []), trimmedValue],
        }));    
        setOrderTags('');
    };
    

    // Handle removal or clearing of selected emails
    const handleChangeProductTags = (newValue) => {
        const cleanedOptions = [];
        const seen = new Set();    
        (newValue || []).forEach((option) => {
            const trimmed = option.value.trim();
            const lower = trimmed.toLowerCase();    
            if (trimmed !== "" && !seen.has(lower)) {
                seen.add(lower);
                cleanedOptions.push({ ...option, value: trimmed });
            }
        });    
        setProductTagsOptions(cleanedOptions);    
        setState((prevState) => ({
            ...prevState,
            productTags: cleanedOptions.map((option) => option.value),
        }));
    };
    

    const handleKeyDownProductTags = (event) => {
        const trimmedValue = productTags?.trim();
        if (!trimmedValue) return;    
        if (event.key === 'Enter' || event.key === 'Tab') {
            event.preventDefault();    
            const lowerValue = trimmedValue.toLowerCase();
            const existingTags = (state.productTags || []).map(tag => tag.toLowerCase());    
            if (existingTags.includes(lowerValue)) {
                setProductTags('');
                return; // Prevent duplicate (case-insensitive)
            }    
            const newOption = createOption(trimmedValue);    
            setProductTagsOptions((prev = []) => [...prev, newOption]);    
            setState((prevState) => ({
                ...prevState,
                productTags: [...(prevState.productTags || []), trimmedValue],
            }));    
            setProductTags('');
        }
    };
    
    

    //Handle feild Blur
    const handleBlurProductTags = (event) => {
        const trimmedValue = productTags?.trim();
        if (!trimmedValue) return;    
        const lowerValue = trimmedValue.toLowerCase();
        const existingTags = (state.productTags || []).map(tag => tag.toLowerCase());    
        if (existingTags.includes(lowerValue)) {
            setProductTags('');
            return; 
        }    
        const newOption = createOption(trimmedValue);    
        setProductTagsOptions((prev = []) => [...prev, newOption]);    
        setState((prevState) => ({
            ...prevState,
            productTags: [...(prevState.productTags || []), trimmedValue],
        }));    
        setProductTags('');
    };
    

    // Function to create a new email option
    const createOption = (value) => ({
        label: value,
        value: value,
    });

    //save all changes
    const manageToShipping = () => {
        setSearchParams({type: "shipping"});
        setSelectedTab(5);
    }

    return (
        <>
            {/* Save Bar with Discard and Save Buttons */}
            <SaveBar id="timeframe-save-bar">
                <button onClick={handleDiscard}>{t('Settings.timeframe.buttons.discard')}</button>
                <button variant="primary" onClick={handleSave}{...(saveBarLoading ? { loading: "" } : {})}>{t('Settings.timeframe.buttons.save')}</button>
            </SaveBar>           

            {/* Info Banner, shown conditionally */}
            {showBanner ? (
                <Box className="timeframe-info-banner">
                    <Banner onDismiss={() => { setShowBanner(false) }} tone="info">{<span dangerouslySetInnerHTML={{ __html: t("Settings.timeframe.banner.info") }}></span>}</Banner>
                </Box>
            ) : isStateEmpty ? (
                <Box className="timeframe-info-banner">
                    <Banner tone="warning">{<span dangerouslySetInnerHTML={{ __html: t("Settings.timeframe.banner.infoScond") }}></span>}</Banner>
                </Box>
            ) : null}
            <Layout>
                {/* Section: Edit Timeframe Settings */}
                <Layout.AnnotatedSection
                    id="edit-timeframe-settings"
                    title={t('Settings.timeframe.editTimeframeSettings.title')}
                    description={t('Settings.timeframe.editTimeframeSettings.description')}
                >
                    <BlockStack gap={400}>
                        <Card>
                            <FormLayout>
                                {/* Select Timeframe Dropdown */}
                                <BlockStack gap={200}>
                                    <Text fontWeight="semibold" as="h4">{t('Settings.timeframe.selectTime.title')}</Text>
                                    <BlockStack gap={100}>
                                        <Text as='p'>{t('Settings.timeframe.selectTime.description')}</Text>
                                        <Select
                                            options={timeOptions}
                                            onChange={handleStateChange('selectedTimeframe')}
                                            value={state.selectedTimeframe}
                                        />
                                    </BlockStack>
                                </BlockStack>
                            </FormLayout>
                        </Card>

                        {/* Custom Timeframe Settings - Visible only if 'custom' is selected and user is on 'professional' plan */}
                    {state.selectedTimeframe === 'custom' && !customTimeframeState && planStatus && (
                            <Box className="motion-appear-above-animation">
                                <Card>
                                    <FormLayout>
                                        <BlockStack gap={200}>
                                            <Text fontWeight="semibold" as="h4">{t('Settings.timeframe.customDuration.title')}</Text>
                                            <BlockStack gap={100}>
                                                <Text as='p'>{t('Settings.timeframe.customDuration.description')}</Text>
                                                <InlineGrid columns={2} gap={200}>
                                                    <TextField value={state.customValue} error={timeFrameError} onFocus={() => setTimeFrameError(false)} onChange={handleCustomValueChange} />
                                                    <Select
                                                        options={getCustomOptions()}
                                                        onChange={handleStateChange('customDuration')}
                                                        value={state.customDuration}
                                                    />
                                                </InlineGrid>
                                            </BlockStack>
                                        </BlockStack>
                                    </FormLayout>
                                </Card>
                            </Box>
                        )}
                    </BlockStack>
                </Layout.AnnotatedSection>

                {/* Divider */}
                <Box as="div" className="annotated-section">
                    <Divider borderWidth="050" />
                </Box>

                <Layout.AnnotatedSection
                    id="order-editing-settings"
                    title={t('Settings.timeframe.orderHolds.title')}
                    description={t('Settings.timeframe.orderHolds.description')}
                >
                    <BlockStack gap={400}>
                        {/* Contact Info Choice List */}
                        <Card>
                            <FormLayout>
                                <BlockStack gap={200}>
                                    <Text fontWeight="semibold" as="h4">{t('Settings.timeframe.orderHolds.settingSection.title')}</Text>
                                    <BlockStack gap={100}>
                                        <Checkbox
                                            label={t('Settings.timeframe.orderHolds.settingSection.lable')}
                                            checked={state.orderHolds}
                                            disabled={isDisabled}
                                            value="shipping_details"
                                            onChange={handleStateChange('orderHolds')}
                                        />
                                    </BlockStack>
                                </BlockStack>
                                {/* <Banner>{<span dangerouslySetInnerHTML={{ __html: t("Settings.timeframe.orderHolds.settingSection.banner") }}></span>}</Banner> */}
                            </FormLayout>
                        </Card>

                        <Card>
                            <FormLayout>
                                <BlockStack gap={200}>
                                    <Text fontWeight="semibold" as="h4">{t('Settings.timeframe.orderHolds.settingSection.title1')}</Text>
                                    <BlockStack gap={100}>
                                        <Checkbox
                                            label={t('Settings.timeframe.orderHolds.settingSection.lable1')}
                                            checked={state.orderChangesRevert}
                                            disabled={isDisabled}
                                            value="shipping_details"
                                            onChange={handleStateChange('orderChangesRevert')}
                                        />
                                    </BlockStack>
                                </BlockStack>
                            </FormLayout>
                        </Card>
                    </BlockStack>
                </Layout.AnnotatedSection>

                {/* Divider */}
                <Box as="div" className="annotated-section">
                    <Divider borderWidth="050" />
                </Box>

                {/* Section: Order Editing Settings */}
                <Layout.AnnotatedSection
                    id="order-editing-settings"
                    title={t('Settings.timeframe.orderEditingSettings.title')}
                    description={t('Settings.timeframe.orderEditingSettings.description')}
                >
                    <BlockStack gap={400}>
                        {/* Contact Info Choice List */}
                        <Card>
                            <FormLayout>
                                <BlockStack gap={200}>
                                    <Text fontWeight="semibold" as="h4">{t('Settings.timeframe.contactInfo.title')}</Text>
                                    <BlockStack gap={100}>
                                        <Text as='p'>{t('Settings.timeframe.contactInfo.description')}</Text>
                                        <ChoiceList
                                            allowMultiple
                                            choices={t('Settings.timeframe.contactInfo.choices', { returnObjects: true })}
                                            disabled={isDisabled}
                                            selected={state.contactInfo}
                                            onChange={handleStateChange('contactInfo')}
                                        />
                                    </BlockStack>
                                    <Banner>{<span dangerouslySetInnerHTML={{ __html: t("Settings.timeframe.contactInfo.bannerText") }}></span>}</Banner>
                                </BlockStack>
                            </FormLayout>
                        </Card>

                        {/* Shipping Details Checkbox */}
                        <Card>
                            <FormLayout>
                                <BlockStack gap={200}>
                                    <InlineStack align='space-between'>
                                        <Text fontWeight="semibold" as="h4">{t('Settings.timeframe.shippingDetails.title')}</Text>
                                        {/* <Button variant='plain' onClick={() =>manageToShipping()}>{t('Settings.timeframe.shippingDetails.link')}</Button> */}
                                    </InlineStack>                                    
                                    <Checkbox
                                        label={t('Settings.timeframe.shippingDetails.label')}
                                        checked={state.shippingDetails}
                                        disabled={isDisabled}
                                        value="shipping_details"
                                        onChange={handleStateChange('shippingDetails')}
                                    />
                                </BlockStack>
                            </FormLayout>
                        </Card>

                        {/* Contact Support Checkbox */}
                        <Card>
                            <FormLayout>
                                <BlockStack gap={200}>
                                    <Text fontWeight="semibold" as="h4">{t('Settings.timeframe.contactSupport.title')}</Text>
                                    <Checkbox
                                        label={t('Settings.timeframe.contactSupport.label')}
                                        checked={state.supportOptions}
                                        disabled={isDisabled}
                                        value="support"
                                        onChange={handleStateChange('supportOptions')}
                                    />
                                </BlockStack>
                            </FormLayout>
                        </Card>

                        {/* Order Items Choice List */}
                        <Card>
                            <FormLayout>
                                <BlockStack gap={200}>
                                    <Text fontWeight="semibold" as="h4">{t('Settings.timeframe.orderItems.title')}</Text>
                                    <BlockStack gap={100}>
                                        <Text as='p'>{t('Settings.timeframe.orderItems.description')}</Text>
                                        <ChoiceList
                                            allowMultiple
                                            disabled={isDisabled}
                                            choices={t('Settings.timeframe.orderItems.choices', { returnObjects: true })}
                                            selected={state.orderItemOptions}
                                            onChange={handleStateChange('orderItemOptions')}
                                        />
                                    </BlockStack>
                                </BlockStack>
                            </FormLayout>
                        </Card>
                    </BlockStack>
                </Layout.AnnotatedSection>

                {/* Divider */}
                <Box as="div" className="annotated-section">
                    <Divider borderWidth="050" />
                </Box>

                {/* Section: Order Editing Settings */}
                <Layout.AnnotatedSection
                    id="order-editing-settings"
                    title={t('Settings.timeframe.orderTags.title')}
                    description={t('Settings.timeframe.orderTags.description')}
                >
                    <BlockStack gap={400}>
                        <Card>
                            <FormLayout>
                                <BlockStack gap={200}>
                                    <Text fontWeight="semibold" as="h4">{t('Settings.timeframe.orderTags.sectionOne.title')}</Text>
                                    <BlockStack gap={100}>
                                        <Text as='p'>{t('Settings.timeframe.orderTags.sectionOne.description')}</Text>
                                        <CreatableSelect
                                            isClearable
                                            isMulti
                                            inputValue={orderTags ?? ""}
                                            onInputChange={(newValue) => setOrderTags(newValue)}
                                            onChange={handleChangeOrderTags}
                                            onKeyDown={handleKeyDownOrderTags}
                                            options={orderTagsOptions}
                                            placeholder={t('Settings.timeframe.orderTags.sectionOne.placeHolder')}
                                            value={orderTagsOptions ?? ""}
                                            menuIsOpen={false}
                                            className="custom-email-input"
                                            components={customComponents}
                                            onBlur={() => handleBlurOrderTags()}
                                            isDisabled={isDisabled}
                                        />
                                    </BlockStack>
                                </BlockStack>
                            </FormLayout>
                        </Card>

                        <Card>
                            <FormLayout>
                                <BlockStack gap={200}>
                                    <Text fontWeight="semibold" as="h4">{t('Settings.timeframe.orderTags.sectionTwo.title')}</Text>
                                    <BlockStack gap={100}>
                                        <Text as='p'>{t('Settings.timeframe.orderTags.sectionTwo.description')}</Text>
                                        <CreatableSelect
                                            isClearable
                                            isMulti
                                            inputValue={productTags ?? ""}
                                            onInputChange={(newValue) => setProductTags(newValue)}
                                            onChange={handleChangeProductTags}
                                            onKeyDown={handleKeyDownProductTags}
                                            options={productTagsOptions}
                                            placeholder={t('Settings.timeframe.orderTags.sectionTwo.placeHolder')}
                                            value={productTagsOptions ?? ""}
                                            menuIsOpen={false}
                                            className="custom-email-input"
                                            components={customComponents}
                                            onBlur={() => handleBlurProductTags()}
                                            isDisabled={isDisabled}
                                        />
                                    </BlockStack>
                                </BlockStack>
                            </FormLayout>
                        </Card>
                    </BlockStack>
                </Layout.AnnotatedSection>
            </Layout>
        </>
    );
}