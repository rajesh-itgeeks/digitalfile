import React, { useState, useEffect, useRef, useCallback } from "react";
import Sortable from "sortablejs";
import { useDispatch, useSelector } from "react-redux";
import { useTranslation } from "react-i18next";
import { Box, Card, InlineStack, Icon, Text, Image, useBreakpoints } from "@shopify/polaris";
import { DragHandleIcon } from '@shopify/polaris-icons';
import { map, orderedit, contact, ordercancel, supportIcon } from "../common/Images";
import APIServicess from "../../services/ApiServices";
import { setSettings } from "../store/SettingsSlice";

//Widget preview list
export default function WidgetPreviewList({ setShowSettingsList }) {
  const dispatch = useDispatch();
  const settings = useSelector((state) => state.settings);
  const { t } = useTranslation();
  const [items, setItems] = useState([]);
  const listRef = useRef(null);
  const sortable = useRef(null);
  const APIServ = new APIServicess();
  const { smDown } = useBreakpoints();

  //Function to manage settings order
  const manageSettingsOrder = useCallback(() => {
    const { orderManage = {}, contactInformation, shippingDetails, orderItems, cancelOrder, support } = settings;
    const dynamicItems = [];

    // Dynamic items based on enabled settings
    const settingsConfig = [
      { condition: contactInformation?.email?.isOn || contactInformation?.email?.phone, id: "3", title: t("Settings.previewWidget.editContact"), image: contact, positionKey: "contactInformation" },
      { condition: shippingDetails?.isOn, id: "4", title: t("Settings.previewWidget.updateContact"), image: map, positionKey: "updateAddress" },
      { condition: orderItems?.addItems?.isOn || orderItems?.removeItem?.isOn || orderItems?.quantity?.isOn || orderItems?.swap?.isOn, id: "5", title: t("Settings.previewWidget.editOrderItem"), image: orderedit, positionKey: "orderItems" },
      { condition: cancelOrder?.isOn, id: "6", title: t("Settings.previewWidget.cancelOrder"), image: ordercancel, positionKey: "cancelOrder" },
      { condition: support?.isOn, id: "2", title: t("Settings.previewWidget.contactSupport"), image: supportIcon, positionKey: "contactSupport" },
    ];

    // Add dynamic items to the list based on enabled settings
    settingsConfig.forEach(({ condition, id, title, image, positionKey }) => {
      if (condition) {
        dynamicItems.push({
          position: orderManage[positionKey] ?? dynamicItems.length,
          item: { id, title, image, positionKey }
        });
      }
    });

    // Sort items by position and update the state
    const updatedItems = dynamicItems
      .sort((a, b) => a.position - b.position)
      .map(({ item }) => item);
    setShowSettingsList(updatedItems.length > 0);
    // Update the state with the sorted items
    setItems(updatedItems);
  }, [settings, t]);

  //Fetch settings order on component mount
  useEffect(() => {
    manageSettingsOrder();
  }, [manageSettingsOrder]);

  //Handle drag and drop event
  const updateSettingsOrder = useCallback(async (data) => {
    try {
      shopify.toast.show(t("Settings.previewWidget.msg"), {
        duration: 2000,
      });
      let updateData = { orderManage: data }
      let response = await APIServ.UpdateShopSettings(updateData);
      if (response.status) {
        let getSettings = await APIServ.getShopSettings();
        if (getSettings.status) {
          dispatch(setSettings(getSettings.result));
        }
      }
    } catch (error) {
      console.error('Error saving upsell settings:', e);
    }
  }, []);

  //Initialize SortableJS only when items change
  useEffect(() => {
    if (!listRef.current) return;

    if (sortable.current) {
      sortable.current.destroy();
    }

    //Sortable content before
    sortable.current = new Sortable(listRef.current, {
      animation: 150,
      ghostClass: "sortable-ghost",
      onEnd: (event) => {
        if (event.oldIndex === event.newIndex) return;

        //Update the order of items in the state 
        setItems((prevItems) => {
          const updatedItems = [...prevItems];
          const [movedItem] = updatedItems.splice(event.oldIndex, 1);
          updatedItems.splice(event.newIndex, 0, movedItem);

          //Update the order of items in the state in the Redux store
          const orderManage = updatedItems.reduce((acc, item, index) => {
            acc[item.positionKey] = index;
            return acc;
          }, {});

          //Update the order of items in the Redux store
          updateSettingsOrder(orderManage);
          return updatedItems;
        });
      }
    });

    // Cleanup the SortableJS instance when the component unmounts
    return () => {
      if (sortable.current) {
        sortable.current.destroy();
        sortable.current = null;
      }
    };
  }, [items]);

  // Render the widget preview list with drag and drop functionality and sortable items
  return (
    <>
      {
        items?.length > 0 && <Box>
          <Card padding="0">
            <Box as={'ul'} ref={listRef} style={{ padding: 0, margin: 0, listStyle: "none" }} className="drag-handle">
              {items.map((item) => (
                <Box key={item.id} as="li" padding="400" data-id={item.id} borderStyle="solid" borderColor="bg" borderBlockEndWidth="0165">
                  <InlineStack as="span" align="space-between" blockAlign="center">
                    <InlineStack as="span" gap={ smDown ? "200" : "400" } blockAlign="center">
                      <Box as="span">
                        <Icon source={DragHandleIcon} tone="base" />
                      </Box>
                      <Text variant={ smDown ? "headingXs" : "headingMd" } as="span">{item.title}</Text>
                    </InlineStack>
                    <Image
                      src={item.image}
                      alt={item.title}
                      style={{ width: 24, height: 24 }}
                    />
                  </InlineStack>
                </Box>
              ))}
            </Box>
          </Card>
        </Box>
      }

    </>
  );
}