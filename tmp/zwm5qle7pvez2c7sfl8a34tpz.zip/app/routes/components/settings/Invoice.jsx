import React, { useState } from 'react';
import EditTemplate from "./invoice/EditTemplate";
const Settings = React.lazy(() => import("./invoice/Settings"));

export default function Invoice({ setSaveBarActive }) {
    const [screenShow, setScreenShow] = useState('settings');
    const [template, setTemplate] = useState('');
    const [templateLiquid, setTemplateLiquid] = useState('');
    return (
        <>
            { screenShow === 'settings' && <Settings setScreenShow={setScreenShow} setSaveBarActive={setSaveBarActive} setTemplate={setTemplate} setTemplateLiquid={setTemplateLiquid} template={template}/> }
            { screenShow === 'edit' && <EditTemplate setScreenShow={setScreenShow} setSaveBarActive={setSaveBarActive} templateLiquid={templateLiquid} setTemplateLiquid={setTemplateLiquid} setTemplate={setTemplate}/> }
        </> 
    );
}
