import { Layout, BlockStack, Card, FormLayout, Checkbox, Text, Box, Divider, TextField, InlineStack, Button, Icon, Link, Banner, Select } from '@shopify/polaris';
import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import APIServicess from '../../services/ApiServices';
import { useDispatch, useSelector } from "react-redux";
import { useAppBridge, SaveBar } from "@shopify/app-bridge-react";
import { setSettings } from "../store/SettingsSlice";
import Skeleton from './Skeleton';
export default function Discount({ setSaveBarActive}) {
    // Import necessary hooks and utilities
    const dispatch = useDispatch();
    const storeValue = useSelector((state) => state.store);
    const settings = useSelector((state) => state.settings);
    const shopify = useAppBridge();
    const { t } = useTranslation();
    const APIServ = new APIServicess();

    const [object, setObject] = useState({});
    const [initialState, setInitialState] = useState({});
    const [saveBarLoading, setSaveBarLoading] = useState(false);

    // Set initial state set
    useEffect(() => {
        const fetchSettings = async () => {
            if (!settings || Object.keys(settings).length === 0) {
                const setting = await APIServ.getShopSettings();
                if (setting.status) {
                    dispatch(setSettings(setting.result));
                    let discount = setting?.result?.discount;
                    let update = {
                        enableRecalculation: discount?.enableRecalculation?.isOn || false,
                        allowPostPurchase: discount?.allowPostPurchase?.isOn || false
                    };
                    setObject(update);
                    setInitialState(update);
                } else {
                    let discount = settings?.discount;
                    let update = {
                        enableRecalculation: discount?.enableRecalculation?.isOn || false,
                        allowPostPurchase: discount?.allowPostPurchase?.isOn || false
                    };
                    setObject(update);
                    setInitialState(update);
                }
            }
        }
        fetchSettings();
    }, [settings]);

    //save all changes
    const handleChangeChecked = (type, value) => {
        setObject((prev) => ({
            ...prev,
            [type]: value
        }));
    };

    //Handle discard all changes 
    const handleDiscard = () => {
        setObject(initialState);
    }

    //save all changes
    const handleSave = async () => {
        setSaveBarLoading(true);
        try {
            let updateData = {
                discount: {
                    enableRecalculation: {
                        isOn: object.enableRecalculation,
                    },
                    allowPostPurchase: {
                        isOn: object.allowPostPurchase,
                    }
                }
            }
            let response = await APIServ.UpdateShopSettings(updateData);
            if (response.status) {
                shopify.toast.show(t("Settings.success_message"), {
                    duration: 2000,
                });
                setSaveBarActive(false);
                shopify.saveBar.hide('timeframe-save-bar');
                let getSettings = await APIServ.getShopSettings();
                if (getSettings.status) {
                    dispatch(setSettings(getSettings.result));
                }
            }
        } catch (error) {
            console.log(error);
        } finally {
            setSaveBarLoading(false);
        }
    }

    //Check changes
    useEffect(() => {
        const isDataChanged = !areObjectsEqual(object, initialState);
        setSaveBarActive(isDataChanged);
        if (isDataChanged) {
            shopify.saveBar.show('timeframe-save-bar');
        } else {
            shopify.saveBar.hide('timeframe-save-bar');
        }
    }, [object, initialState]);

    // Compares two objects recursively to check for equality.
    const areObjectsEqual = (object1, object2) => {
        if (object1 === object2) return true;
        if (typeof object1 !== "object" || typeof object2 !== "object" || object1 === null || object2 === null) {
            return false;
        }
        const keys1 = Object.keys(object1);
        const keys2 = Object.keys(object2);

        if (keys1.length !== keys2.length) return false;
        return keys1.every(key => keys2.includes(key) && areObjectsEqual(object1[key], object2[key]));
    };

    return (
        <>
            <SaveBar id="timeframe-save-bar">
                <button onClick={handleDiscard}>{t('Settings.timeframe.buttons.discard')}</button>
                <button variant="primary" onClick={handleSave}{...(saveBarLoading ? { loading: "" } : {})}>{t('Settings.timeframe.buttons.save')}</button>
            </SaveBar>
            {
                !settings ? <Skeleton /> : <Box className="upsell-create motion-appear-above-animation">
                    <Layout>
                        <Layout.AnnotatedSection
                            id="edit-timeframe-settings"
                            title={t('Settings.discounts.sectionOne.title')}
                            description={t('Settings.discounts.sectionOne.description')}
                        >
                            <BlockStack gap={400}>
                                <Card>
                                    <FormLayout>
                                        <BlockStack gap={200}>
                                            <Text fontWeight="semibold" as="h4">
                                                {t('Settings.discounts.sectionOne.settingSection.sectionOne.title')}
                                            </Text>
                                            <BlockStack gap={100}>
                                                <Checkbox
                                                    label={t('Settings.discounts.sectionOne.settingSection.sectionOne.lable')}
                                                    checked={object.enableRecalculation}
                                                    onChange={() => handleChangeChecked('enableRecalculation', !object.enableRecalculation)}
                                                // disabled={!shippingEnable}
                                                />
                                            </BlockStack>
                                        </BlockStack>
                                    </FormLayout>
                                </Card>

                                <Card>
                                    <FormLayout>
                                        <BlockStack gap={200}>
                                            <Text fontWeight="semibold" as="h4">
                                                {t('Settings.discounts.sectionOne.settingSection.sectionTwo.title')}
                                            </Text>
                                            <BlockStack gap={100}>
                                                <Checkbox
                                                    label={t('Settings.discounts.sectionOne.settingSection.sectionTwo.lable')}
                                                    checked={object.allowPostPurchase}
                                                    onChange={() => handleChangeChecked('allowPostPurchase', !object.allowPostPurchase)}
                                                // disabled={!shippingEnable}
                                                />
                                            </BlockStack>
                                        </BlockStack>
                                    </FormLayout>
                                </Card>
                            </BlockStack>
                        </Layout.AnnotatedSection>
                    </Layout>
                </Box>
            }
        </>
    )
}