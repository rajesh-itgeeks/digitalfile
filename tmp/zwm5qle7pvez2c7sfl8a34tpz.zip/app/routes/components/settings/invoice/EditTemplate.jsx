import { BlockStack, Box, Button, Text, Page, Card, TextField, SkeletonBodyText  } from "@shopify/polaris";
import { useDispatch, useSelector } from "react-redux";
import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import APIServicess from "../../../services/ApiServices";
import { useAppBridge, SaveBar, Modal, TitleBar } from "@shopify/app-bridge-react";
import Preview from "./Preview";
import { setInvoices } from "../../store/InvoicesSlice";
export default function Settings({ setScreenShow, setSaveBarActive, templateLiquid, setTemplateLiquid, setTemplate }) {
    const { t } = useTranslation();
    const APIServ = new APIServicess();
    const shopify = useAppBridge();
    const [templateCode, setTemplateCode] = useState(templateLiquid?.previewTemplate);
    const [saveBarLoading, setSaveBarLoading] = useState(false);    
    const [revertLoading, setRevertLoading] = useState(false);    
    const [model, setModel] = useState(false);
    const [error, setError] = useState(false);
    const dispatch = useDispatch();

    //Preview template
    const templateUpdate = () => {
        const isDataChanged = !areObjectsEqual(templateCode, templateLiquid?.previewTemplate);
        if (!isDataChanged) {
            shopify.modal.show('preview-email-template');
            setModel(true);
        } else {
            shopify.saveBar.leaveConfirmation();
        } 
    }
    
    //Back to settings page
    const backToList = () => {
        const isDataChanged = !areObjectsEqual(templateCode, templateLiquid?.previewTemplate);
        if (!isDataChanged) {
            setScreenShow('settings');
            setSaveBarActive(false);
        } else {
            shopify.saveBar.leaveConfirmation();
        } 
    }

    //Handle change template code
    const handleChangeTemplate = (event) => {
        setTemplateCode(event);
        setError(false);
    }

    //Check changes
    useEffect(() => {
        const isDataChanged = !areObjectsEqual(templateCode, templateLiquid?.previewTemplate);
        setSaveBarActive(isDataChanged);
        if (isDataChanged) {
            shopify.saveBar.show('invoice-save-bar');
        } else {
            shopify.saveBar.hide('invoice-save-bar');
        }
    }, [templateCode]);

    // Compares two objects recursively to check for equality.
    const areObjectsEqual = (object1, object2) => {
        if (object1 === object2) return true;
        if (typeof object1 !== "object" || typeof object2 !== "object" || object1 === null || object2 === null) {
            return false;
        }
        const keys1 = Object.keys(object1);
        const keys2 = Object.keys(object2);

        if (keys1.length !== keys2.length) return false;
        return keys1.every(key => keys2.includes(key) && areObjectsEqual(object1[key], object2[key]));
    };

    //Handle discard all changes 
    const handleDiscard = () => {
        setTemplateCode(templateLiquid?.previewTemplate);
    }

     //Handle save
     const handleSave = async () => {
        setSaveBarLoading(true);
        try {
            if(!templateCode){
                setError(true);
                return;
            }            
            const newTemplateLiquid = { ...templateLiquid };
            newTemplateLiquid.previewTemplate = templateCode;
            delete newTemplateLiquid.htmlTemplate;
            delete newTemplateLiquid.createdAt;
            delete newTemplateLiquid.updatedAt;
            let invoiceData = await APIServ.saveAndGetInvoices(newTemplateLiquid);
            if(invoiceData.status){
                let getInvoiceDetails = await APIServ.getInvoiceDetails();                
                delete getInvoiceDetails.result.createdAt;
                delete getInvoiceDetails.result.updatedAt;
                setTemplateLiquid(getInvoiceDetails.result);
                setTemplate(getInvoiceDetails.result.htmlTemplate);
                setSaveBarActive(false);
                shopify.saveBar.hide('invoice-save-bar');
                shopify.toast.show(t('Settings.Invoice.settings.edit.saveMessage'), { duration: 1500 });
                dispatch(setInvoices(getInvoiceDetails.result));
            }
        } catch (error) {
            console.log(error);
        } finally {
            setSaveBarLoading(false);
        }
     }

     //Revert email template
    const revertEmailTemplate = async () => {
        setRevertLoading(true);
        try {
            let template = await APIServ.getDefaultTemplate();
            if(template.status){
                const newTemplateLiquid = { ...templateLiquid };
                newTemplateLiquid.previewTemplate = template?.result?.previewTemplate;
                delete newTemplateLiquid.htmlTemplate;
                delete newTemplateLiquid?.createdAt;
                delete newTemplateLiquid?.updatedAt;
                let invoiceData = await APIServ.saveAndGetInvoices(newTemplateLiquid);
                if(invoiceData.status){
                    let getInvoiceDetails = await APIServ.getInvoiceDetails();
                    if(getInvoiceDetails.status){                        
                        delete getInvoiceDetails.result.createdAt;
                        delete getInvoiceDetails.result.updatedAt;
                        setTemplateLiquid(getInvoiceDetails.result);
                        setTemplateCode(getInvoiceDetails.result.previewTemplate);
                        setTemplate(getInvoiceDetails.result.htmlTemplate);
                        setSaveBarActive(false);
                        shopify.saveBar.hide('invoice-save-bar');
                        shopify.toast.show(t('Settings.Invoice.settings.edit.revertMessage'), { duration: 1500 });
                        dispatch(setInvoices(getInvoiceDetails.result));
                    }
                }
            }
        } catch (error) {
            console.log(error);
        } finally {
            setRevertLoading(false);
        }
    }

    //Close model
    const onClose = () => {
        setModel(false);
    };
    
    //Render
    return (
        <>
            <SaveBar id="invoice-save-bar">
                <button onClick={handleDiscard}>{t('Settings.timeframe.buttons.discard')}</button>
                <button variant="primary" onClick={handleSave}{...(saveBarLoading ? { loading: "" } : {})}>{t('Settings.timeframe.buttons.save')}</button>
            </SaveBar>

            {/* Page Preview */}
            <Box className="upsell-create motion-appear-above-animation">
                <Page
                    backAction={{ onAction: () => backToList() }}
                    title={t('Settings.Invoice.settings.edit.title')}
                    fullWidth
                    secondaryActions={[
                        {content: t('Settings.Invoice.settings.edit.preview'), onAction: () => templateUpdate()},
                    ]}
                >
                    <Box>
                            <BlockStack gap="400">
                                <Card>
                                    <BlockStack gap="200">
                                        <TextField
                                            label={t('Settings.TemplateEdit.body')}
                                            value={templateCode}
                                            onChange={(event)=>handleChangeTemplate(event)}
                                            autoComplete="off"
                                            multiline={10}
                                            id="edit-email-template"
                                            error={error ? t('Settings.Invoice.settings.edit.error') : ""}
                                        />
                                        <Box>
                                            <Button variant="primary" onClick={revertEmailTemplate} loading={revertLoading}>{t('Settings.Invoice.settings.edit.revertBtn')}</Button>
                                        </Box> 
                                    </BlockStack>
                                </Card>
                            </BlockStack>
                        </Box>

                </Page>
            </Box>
            
            {/* Preview widget*/}
            <Modal id="preview-email-template" variant="max" onHide={onClose}>
                {
                    model && <Preview templateLiquid={templateLiquid}/>
                }
                <TitleBar title={t("Settings.previewWidget.title")}>
                </TitleBar>
            </Modal>  
        </>
    );
}