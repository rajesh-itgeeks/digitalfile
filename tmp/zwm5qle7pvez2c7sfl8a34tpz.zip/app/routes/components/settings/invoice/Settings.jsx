import { Layout, BlockStack, Card, FormLayout, Checkbox, Text, Box, Divider, TextField, InlineStack, Button, Icon, Link, DropZone, Thumbnail, LegacyStack, InlineGrid } from '@shopify/polaris';
import { useState, useEffect, useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import Skeleton from '../Skeleton';
import { useDispatch, useSelector } from "react-redux";
import APIServicess from "../../../services/ApiServices";
import { useAppBridge, SaveBar } from "@shopify/app-bridge-react";
import { setInvoices } from "../../store/InvoicesSlice";

export default function Settings({ setScreenShow, setSaveBarActive, setTemplate, setTemplateLiquid, template }) {
    const { t } = useTranslation();
    const APIServ = new APIServicess();
    const shopify = useAppBridge();
    const dispatch = useDispatch();
    const invoices = useSelector((state) => state.invoices);
    const [initialState, setInitialState] = useState({});
    const [object, setObject] = useState({});
    const [saveBarLoading, setSaveBarLoading] = useState(false);
    const [files, setFiles] = useState([]);
    const [emailError, setEmailError] = useState(false);
    const [websiteError, setWebsiteError] = useState(false);
    const [imageError, setImageError] = useState(false);
    const [imageErrorMessage, setimageErrorMessage] = useState(t('Settings.Invoice.settings.sectionFour.settingSection.error'));

    // Set initial state set
    useEffect(() => {
        const fetchInvoices = async () => {
            if (invoices) {
                let data = {
                    enableCustomerInvoice: true, //invoices?.enableCustomerInvoice,
                    storeInfo: {
                        name: invoices?.storeInfo?.name,
                        email: invoices?.storeInfo?.email,
                        websiteUrl: invoices?.storeInfo?.websiteUrl
                    },
                    hide: {
                        showTaxesItems: invoices?.hide?.showTaxesItems,
                        hideProductSkus: invoices?.hide?.hideProductSkus,
                        orderStatusInfo: invoices?.hide?.orderStatusInfo,
                        orderNotes: invoices?.hide?.orderNotes
                    },
                    logoUrl: invoices?.logoUrl
                }
                setTemplate(invoices?.htmlTemplate);
                setTemplateLiquid(invoices);
                setInitialState(data);
                setObject(data);
            } else {
                let invoicess = await APIServ.getInvoiceDetails();
                if (invoicess.status) {
                    let data = {
                        enableCustomerInvoice: true, //invoicess?.result?.enableCustomerInvoice,
                        storeInfo: {
                            name: invoicess?.result?.storeInfo?.name,
                            email: invoicess?.result?.storeInfo?.email,
                            websiteUrl: invoicess?.result?.storeInfo?.websiteUrl
                        },
                        hide: {
                            showTaxesItems: invoicess?.result?.hide?.showTaxesItems,
                            hideProductSkus: invoicess?.result?.hide?.hideProductSkus,
                            orderStatusInfo: invoicess?.result?.hide?.orderStatusInfo,
                            orderNotes: invoicess?.result?.hide?.orderNotes
                        },
                        logoUrl: invoicess?.result?.logoUrl
                    }
                    setTemplate(invoices?.htmlTemplate);
                    setTemplateLiquid(invoices);
                    setInitialState(data);
                    setObject(data);
                    dispatch(setInvoices(invoicess.result));
                }
            }
        }
        fetchInvoices();
    }, [invoices]);

    //Logo upload and verify validation
    const fileUpload = !files.length && <DropZone.FileUpload />;
    const logoFileName = object?.logoUrl && typeof object.logoUrl === "string"
        ? object.logoUrl.toString().split("/").pop()
        : "";
    const uploadedFiles = Array.isArray(files) && files.length > 0 ? (
        <Box style={{ height: "100%", display: "flex", justifyContent: "center", alignItems: "center" }}>
            {files[files.length - 1]?.name}
        </Box>
    ) : logoFileName ? (
        <Box style={{ height: "100%", display: "flex", justifyContent: "center", alignItems: "center" }}>
            {logoFileName}
        </Box>
    ) : null;
    const handleDropZoneDrop = useCallback(
        (_dropFiles, acceptedFiles, _rejectedFiles) => {
            const MAX_SIZE_MB = 1;
            const MAX_SIZE_BYTES = MAX_SIZE_MB * 1024 * 1024;

            const filteredFiles = acceptedFiles.filter((file) => {
                const isValidType = ["image/png", "image/jpeg"].includes(file.type);
                const isValidSize = file.size <= MAX_SIZE_BYTES;

                // Show specific message if something's wrong
                if (!isValidType) {
                    setImageError(true);
                    setimageErrorMessage(t('Settings.Invoice.settings.sectionFour.settingSection.error'));
                } else if (!isValidSize) {
                    setImageError(true);
                    setimageErrorMessage("Image too large. Maximum allowed size is 1MB.");
                }

                return isValidType && isValidSize;
            });

            setFiles((prevFiles) => {
                const updatedFiles = [...prevFiles, ...filteredFiles];

                if (filteredFiles.length > 0) {
                    const latestFileUrl = URL.createObjectURL(filteredFiles[filteredFiles.length - 1]);
                    setObject((prevState) => ({
                        ...prevState,
                        logoUrl: latestFileUrl,
                    }));
                    setImageError(false);
                    setimageErrorMessage("");
                }
                return updatedFiles;
            });
        },
        [setFiles, setObject]
    );

    //Handle settings on off
    const handleChangeSettingsOnOff = () => {
        setObject(prevState => ({
            ...prevState,
            enableCustomerInvoice: !prevState.enableCustomerInvoice
        }));
    };

    //Handle hide show
    const handleChangeHideShow = (type, value) => {
        setObject(prevState => ({
            ...prevState,
            hide: {
                ...prevState.hide,
                [type === 'taxes' ? 'showTaxesItems' :
                    type === 'sku' ? 'hideProductSkus' :
                        type === 'status' ? 'orderStatusInfo' :
                            type === 'notes' ? 'orderNotes' : '']: !value
            }
        }));
    };

    //Handle discard all changes 
    const handleDiscard = () => {
        setObject(initialState);
        setEmailError(false);
        setWebsiteError(false);
        setImageError(false);
        setFiles([]);
    }

    //Handle input change
    const handleChangeInput = (type, value) => {
        if (type === 'email') {
            setEmailError(false);
        }
        if (type === 'website') {
            setWebsiteError(false);
        }
        setObject(prevState => ({
            ...prevState,
            storeInfo: {
                ...prevState.storeInfo,
                [type === 'storeName' ? 'name' :
                    type === 'email' ? 'email' :
                        type === 'website' ? 'websiteUrl' : '']: value
            }
        }));
    };

    //Handle save
    const handleSave = async () => {
        setSaveBarLoading(true);
        setImageError(false);
        try {
            let continues = true;
            if (object?.storeInfo?.email) {
                const emailRegex = /^[\w.%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
                if (!emailRegex.test(object?.storeInfo?.email)) {
                    setEmailError(true);
                    continues = false;
                }
            }

            if (object?.storeInfo?.websiteUrl) {
                const urlRegex = /^(https?:\/\/)?([\da-z.-]+)\.([a-z.]{2,6})([/\w .-]*)*\/?$/;
                if (!urlRegex.test(object?.storeInfo?.websiteUrl)) {
                    setWebsiteError(true);
                    continues = false;
                }
            }

            if (continues) {
                if (files.length > 0) {
                    const formData = new FormData();
                    formData.append('image', files[0]);
                    const fileData = await APIServ.uploadImage(formData);
                    if (fileData.status) {
                        object.logoUrl = fileData?.result
                    } else {
                        console.log(fileData)
                    }
                }
                const invoices = await APIServ.saveAndGetInvoices(object);
                if (invoices.status) {
                    setFiles([]);
                    shopify.saveBar.hide('invoice-save-bar');
                    shopify.toast.show(t('Settings.Invoice.settings.save'), { duration: 1500 });
                    setSaveBarActive(false);
                    let invoicess = await APIServ.getInvoiceDetails();
                    dispatch(setInvoices(invoicess.result));
                } else {
                    if (invoices?.message) {
                        const message = invoices.message.toLowerCase();
                        console.log(message.includes('storeinfo.websiteurl'));
                        if (message.includes('storeinfo.email')) {
                            setEmailError(true);
                        }
                        if (message.includes('storeinfo.websiteurl')) {
                            setWebsiteError(true);
                        }
                    }
                }
            }
        } catch (error) {
            console.log(error.message);
        } finally {
            setSaveBarLoading(false);
        }
    }


    //Check changes
    useEffect(() => {
        const isDataChanged = !areObjectsEqual(object, initialState);
        setSaveBarActive(isDataChanged);
        if (isDataChanged) {
            shopify.saveBar.show('invoice-save-bar');
        } else {
            shopify.saveBar.hide('invoice-save-bar');
        }
    }, [object]);


    // Compares two objects recursively to check for equality.
    const areObjectsEqual = (object1, object2) => {
        if (object1 === object2) return true;
        if (typeof object1 !== "object" || typeof object2 !== "object" || object1 === null || object2 === null) {
            return false;
        }
        const keys1 = Object.keys(object1);
        const keys2 = Object.keys(object2);

        if (keys1.length !== keys2.length) return false;
        return keys1.every(key => keys2.includes(key) && areObjectsEqual(object1[key], object2[key]));
    };

    //Handle invoice screen
    const handleInvoiceScreen = () => {
        const isDataChanged = !areObjectsEqual(object, initialState);
        if (!isDataChanged) {
            setScreenShow('edit');
        } else {
            shopify.saveBar.leaveConfirmation();
        }
    }

    //Icon Component
    const iconContent = () => {
        return (
            <svg viewBox="0 0 20 20" focusable="false" aria-hidden="true" fill="#8e1f0b"><path d="M10 6a.75.75 0 0 1 .75.75v3.5a.75.75 0 0 1-1.5 0v-3.5a.75.75 0 0 1 .75-.75Z"></path><path d="M11 13a1 1 0 1 1-2 0 1 1 0 0 1 2 0Z"></path><path fillRule="evenodd" d="M17 10a7 7 0 1 1-14 0 7 7 0 0 1 14 0Zm-1.5 0a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0Z"></path></svg>
        );
    };

    //Render
    return (
        <>
            <SaveBar id="invoice-save-bar">
                <button onClick={handleDiscard}>{t('Settings.timeframe.buttons.discard')}</button>
                <button variant="primary" onClick={handleSave}{...(saveBarLoading ? { loading: "" } : {})}>{t('Settings.timeframe.buttons.save')}</button>
            </SaveBar>
            {
                !invoices ? <Skeleton /> : <> <Box className="upsell-create motion-appear-above-animation">
                    <Layout>
                        {/* <Layout.AnnotatedSection
                            id="edit-timeframe-settings"
                            title={t('Settings.Invoice.settings.sectionOne.title')}
                            description={t('Settings.Invoice.settings.sectionOne.description')}
                        >
                            <BlockStack gap={400}>
                                <Card>
                                    <FormLayout>
                                        <BlockStack gap={200}>
                                            <Text fontWeight="semibold" as="h4">
                                                {t('Settings.Invoice.settings.sectionOne.settingSection.title')}
                                            </Text>
                                            <BlockStack gap={100}>
                                                <Checkbox
                                                    label={t('Settings.Invoice.settings.sectionOne.settingSection.checkBoxLable')}
                                                    checked={object?.enableCustomerInvoice}
                                                    onChange={handleChangeSettingsOnOff}
                                                />
                                            </BlockStack>
                                        </BlockStack>
                                    </FormLayout>
                                </Card>
                            </BlockStack>
                        </Layout.AnnotatedSection> */}
                        {/* Divider */}
                        {/* <Box as="div" className="annotated-section">
                            <Divider borderWidth="050" />
                        </Box> */}
                        <Layout.AnnotatedSection
                            id="edit-timeframe-settings"
                            title={t('Settings.Invoice.settings.sectionTwo.title')}
                            description={t('Settings.Invoice.settings.sectionTwo.description')}
                        >
                            <BlockStack gap={400}>
                                <Card>
                                    <FormLayout>
                                        <BlockStack gap={200}>
                                            <Text fontWeight="semibold" as="h4">
                                                {t('Settings.Invoice.settings.sectionTwo.settingSection.title')}
                                            </Text>
                                            <BlockStack gap={200}>
                                                <TextField
                                                    label={t('Settings.Invoice.settings.sectionTwo.settingSection.feildOne.lable')}
                                                    placeholder={t('Settings.Invoice.settings.sectionTwo.settingSection.feildOne.placeholder')}
                                                    disabled={!object?.enableCustomerInvoice}
                                                    value={object?.storeInfo?.name ?? ''}
                                                    onChange={(event) => handleChangeInput('storeName', event)}
                                                />
                                                <TextField
                                                    label={t('Settings.Invoice.settings.sectionTwo.settingSection.feildTwo.lable')}
                                                    placeholder={t('Settings.Invoice.settings.sectionTwo.settingSection.feildTwo.placeholder')}
                                                    disabled={!object?.enableCustomerInvoice}
                                                    value={object?.storeInfo?.email ?? ''}
                                                    onChange={(event) => handleChangeInput('email', event)}
                                                    error={emailError ? t('Settings.Invoice.settings.sectionTwo.settingSection.feildTwo.error') : ''}
                                                />
                                                <TextField
                                                    label={t('Settings.Invoice.settings.sectionTwo.settingSection.feildThree.lable')}
                                                    placeholder={t('Settings.Invoice.settings.sectionTwo.settingSection.feildThree.placeholder')}
                                                    disabled={!object?.enableCustomerInvoice}
                                                    value={object?.storeInfo?.websiteUrl ?? ''}
                                                    onChange={(event) => handleChangeInput('website', event)}
                                                    error={websiteError ? t('Settings.Invoice.settings.sectionTwo.settingSection.feildThree.error') : ''}
                                                />
                                            </BlockStack>
                                        </BlockStack>
                                    </FormLayout>
                                </Card>
                            </BlockStack>
                        </Layout.AnnotatedSection>
                        {/* Divider */}
                        <Box as="div" className="annotated-section">
                            <Divider borderWidth="050" />
                        </Box>
                        <Layout.AnnotatedSection
                            id="edit-timeframe-settings"
                            title={t('Settings.Invoice.settings.sectionThree.title')}
                            description={t('Settings.Invoice.settings.sectionThree.description')}
                        >
                            <BlockStack gap={400}>
                                <Card>
                                    <FormLayout>
                                        <BlockStack gap={200}>
                                            <Text fontWeight="semibold" as="h4">
                                                {t('Settings.Invoice.settings.sectionThree.settingSection.title')}
                                            </Text>
                                            <BlockStack gap={200}>
                                                <Checkbox
                                                    label={t('Settings.Invoice.settings.sectionThree.settingSection.checkBoxLableOne')}
                                                    disabled={!object?.enableCustomerInvoice}
                                                    onChange={() => handleChangeHideShow('taxes', object?.hide?.showTaxesItems)}
                                                    checked={object?.hide?.showTaxesItems}
                                                />
                                                <Checkbox
                                                    label={t('Settings.Invoice.settings.sectionThree.settingSection.checkBoxLableTwo')}
                                                    disabled={!object?.enableCustomerInvoice}
                                                    onChange={() => handleChangeHideShow('sku', object?.hide?.hideProductSkus)}
                                                    checked={object?.hide?.hideProductSkus}
                                                />
                                                <Checkbox
                                                    label={t('Settings.Invoice.settings.sectionThree.settingSection.checkBoxLableThree')}
                                                    disabled={!object?.enableCustomerInvoice}
                                                    onChange={() => handleChangeHideShow('status', object?.hide?.orderStatusInfo)}
                                                    checked={object?.hide?.orderStatusInfo}
                                                />
                                                <Checkbox
                                                    label={t('Settings.Invoice.settings.sectionThree.settingSection.checkBoxLableFour')}
                                                    disabled={!object?.enableCustomerInvoice}
                                                    onChange={() => handleChangeHideShow('notes', object?.hide?.orderNotes)}
                                                    checked={object?.hide?.orderNotes}
                                                />
                                            </BlockStack>
                                        </BlockStack>
                                    </FormLayout>
                                </Card>
                            </BlockStack>
                        </Layout.AnnotatedSection>
                        {/* Divider */}
                        <Box as="div" className="annotated-section">
                            <Divider borderWidth="050" />
                        </Box>
                        <Layout.AnnotatedSection
                            id="edit-timeframe-settings"
                            title={t('Settings.Invoice.settings.sectionFour.title')}
                            description={t('Settings.Invoice.settings.sectionFour.description')}
                        >
                            <BlockStack gap={400}>
                                <Card>
                                    <FormLayout>
                                        <BlockStack gap={200}>
                                            <Text fontWeight="semibold" as="h4">
                                                {t('Settings.Invoice.settings.sectionFour.settingSection.title')}
                                            </Text>
                                            <BlockStack gap={200}>
                                                <DropZone
                                                    onDrop={handleDropZoneDrop}
                                                    disabled={!object?.enableCustomerInvoice}
                                                    accept="image/jpeg,image/png"
                                                    type="image"
                                                >
                                                    {uploadedFiles}
                                                    {fileUpload}
                                                </DropZone>
                                                {
                                                    imageError && <Box>
                                                        <InlineStack gap="200">
                                                            <Box className="error-icon">
                                                                <Icon source={iconContent} />
                                                            </Box><Text as='p' tone="critical" >{imageErrorMessage}</Text>
                                                        </InlineStack>
                                                    </Box>
                                                }
                                            </BlockStack>
                                        </BlockStack>
                                    </FormLayout>
                                </Card>
                            </BlockStack>
                        </Layout.AnnotatedSection>
                        {/* Divider */}
                        <Box as="div" className="annotated-section">
                            <Divider borderWidth="050" />
                        </Box>
                        <Layout.AnnotatedSection
                            id="edit-timeframe-settings"
                            title={t('Settings.Invoice.settings.sectionFive.title')}
                            description={t('Settings.Invoice.settings.sectionFive.description')}
                        >
                            <BlockStack gap={400}>
                                <Card>
                                    <FormLayout>
                                        <BlockStack gap={200}>
                                            <Box width="100%">
                                                <InlineStack align='space-between' blockAlign="center">
                                                    <Text fontWeight="semibold" as="h4">
                                                        {t('Settings.Invoice.settings.sectionFive.settingSection.title')}
                                                    </Text>
                                                    <Button onClick={handleInvoiceScreen} variant="plain" disabled={!object?.enableCustomerInvoice}>{t('Settings.Invoice.settings.sectionFive.settingSection.edit')}</Button>
                                                </InlineStack>
                                            </Box>
                                            {
                                                object?.enableCustomerInvoice && <Box>{<div dangerouslySetInnerHTML={{ __html: template }}></div>}</Box>
                                            }
                                        </BlockStack>
                                    </FormLayout>
                                </Card>
                            </BlockStack>
                        </Layout.AnnotatedSection>
                    </Layout>
                </Box>
                </>
            }
        </>

    )
}