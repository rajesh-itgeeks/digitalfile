import { Box, BlockStack, Text, Card, SkeletonBodyText } from "@shopify/polaris";
import { useTranslation } from 'react-i18next';

export default function Preview({templateLiquid}) {
    console.log(templateLiquid, "============");


    const { t } = useTranslation();
    return (
        <>
            <Box background="bg-surface-secondary" className="preview-emailtemplate-wrap">
                <Box className="preview-emailtemplate">
                    <Card>                            
                        <BlockStack gap="400">
                            <Text variant="headingMd" as="h6">{t('Settings.Template.preview')}</Text>
                            <Box borderRadius="100" borderStyle="solid" borderColor="bg-surface-brand" borderWidth="0165">
                                <Box padding="400">
                                    {<div dangerouslySetInnerHTML={{ __html: templateLiquid?.htmlTemplate }}></div>}                                    
                                </Box>
                            </Box>
                        </BlockStack>                        
                    </Card>
                </Box>
            </Box>
        </>
    )
}