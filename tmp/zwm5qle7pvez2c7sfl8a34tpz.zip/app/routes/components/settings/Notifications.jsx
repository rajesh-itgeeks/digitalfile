import React, { useState } from 'react';
import Template from "./notifications/Template";
import EditTemplate from "./notifications/EditTemplate";
const Settings = React.lazy(() => import("./notifications/Settings"));

export default function Notifications({ setSaveBarActive }) {
    const [screenShow, setScreenShow] = useState('settings');
    const [template, setTemplate] = useState('');
    return (
        <>
            { screenShow === 'settings' && <Settings setScreenShow={setScreenShow} setSaveBarActive={setSaveBarActive} setTemplate={setTemplate}/> }
            { screenShow === 'template' && <Template setScreenShow={setScreenShow} setSaveBarActive={setSaveBarActive} template={template}/> }
            { screenShow === 'edit' && <EditTemplate setScreenShow={setScreenShow} setSaveBarActive={setSaveBarActive} template={template}/> }
        </> 
    );
}
