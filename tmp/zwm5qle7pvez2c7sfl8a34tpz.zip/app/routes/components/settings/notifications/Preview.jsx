import { Box, BlockStack, Text, Card, SkeletonBodyText } from "@shopify/polaris";
import { useTranslation } from 'react-i18next';

export default function Preview({ previewTemplate, previewSubject }) {
    const { t } = useTranslation();
    return (
        <>
            <Box background="bg-surface-secondary" className="preview-emailtemplate-wrap">
                <Box className="preview-emailtemplate"> 
                    {
                        previewTemplate && previewSubject ? <Card>                            
                            <BlockStack gap="400">
                                <Text variant="headingMd" as="h6">{t('Settings.Template.preview')}</Text>
                                <Box borderRadius="100" borderStyle="solid" borderColor="bg-surface-brand" borderWidth="0165">
                                    <Box padding="400" borderBlockEndWidth="0165" borderStyle="solid" borderColor="bg-surface-brand">
                                        <Text variant="bodySm" as="p">{previewSubject}</Text>
                                    </Box>
                                    <Box padding="400">
                                        {<div dangerouslySetInnerHTML={{ __html: previewTemplate }}></div>}                                    
                                    </Box>
                                </Box>
                            </BlockStack>                        
                        </Card> : <Box>
                            <BlockStack gap="400">
                                <Card>
                                    <SkeletonBodyText />                      
                                </Card>
                                <Card>
                                    <BlockStack gap="400">
                                        <SkeletonBodyText />     
                                        <SkeletonBodyText />
                                        <SkeletonBodyText />
                                        <SkeletonBodyText />
                                        <SkeletonBodyText />
                                        <SkeletonBodyText />   
                                    </BlockStack>         
                                </Card>
                            </BlockStack>
                        </Box>
                    }

                                   
                </Box>
            </Box>
        </>
    )
}