import { BlockStack, Box, Button, InlineStack, Icon, Text, Page, Card, SkeletonBodyText  } from "@shopify/polaris";
import {
    ArrowLeftIcon, DeleteIcon
} from '@shopify/polaris-icons';
import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import APIServicess from "../../../services/ApiServices";

export default function Template({ setScreenShow, setSaveBarActive, template }) {
    const { t } = useTranslation();
    const APIServ = new APIServicess();
    const [emailTemplate, setEmailTemplate] = useState('');
    const [subject, setSubject] = useState('');    

    // Set initial state set
    useEffect(() => {
        const fetchTemplateDetails = async () => {
            if (template) {
                try {
                    const response = await APIServ.getTemplateDetails({type : template});
                    if(response.status){
                        const preview = await APIServ.getTemplatePreview({type : template, emailTemplate : response?.result?.emailTemplate, emailSubject : response?.result?.subject});
                        if(preview.status){
                            setEmailTemplate(preview?.result?.emailHtml);
                            setSubject(preview?.result?.emailSubject ?? 'Subject: Order #9999 confirmed');
                        }                        
                    }
                } catch (error) {
                    console.error("Error fetching template details:", error);
                }
            }
        };    
        fetchTemplateDetails();
    }, []);

    //String replace wwith number 
    const backToList = () => { 
        setScreenShow('settings');
    };

    const templateUpdate = () => { 
        setScreenShow('edit');
    };
    
    return (
        <>
            <Box className="upsell-create motion-appear-above-animation">
                <Page
                    backAction={{ onAction: () => backToList() }}
                    title={template == 'orderEdit' ? t('Settings.TemplateEdit.template1Title') : template == 'paymentPending' ? t('Settings.TemplateEdit.template2Title') : template == 'orderCancellation' ? t('Settings.TemplateEdit.template3Title') : t('Settings.TemplateEdit.template4Title')}
                    primaryAction={<Button variant="primary" onClick={()=>templateUpdate()}>{t('Settings.Template.btn2')}</Button>}
                    fullWidth
                >
                    {
                        (subject && emailTemplate) ? <Card>                            
                            <BlockStack gap="400">
                                <Text variant="headingMd" as="h6">{t('Settings.Template.preview')}</Text>
                                <Box borderRadius="100" borderStyle="solid" borderColor="bg" borderWidth="0165">
                                    <Box padding="400" borderBlockEndWidth="0165" borderStyle="solid" borderColor="bg">
                                        <Text variant="bodySm" as="p">{subject}</Text>
                                    </Box>
                                    <Box padding="400">
                                        {<div dangerouslySetInnerHTML={{ __html: emailTemplate }} style={{ overflowY: 'scroll', height : '360px'}}></div>}                                    
                                    </Box>
                                </Box>
                            </BlockStack>                        
                        </Card> : <Card>
                            <BlockStack gap="400">
                                <Box padding="200" background="bg"></Box>
                                <Box>
                                    <BlockStack gap="400">
                                        <Box padding="200">
                                            <SkeletonBodyText />
                                        </Box>
                                        <Box padding="200">
                                            <SkeletonBodyText />
                                        </Box>
                                        <Box padding="200">
                                            <SkeletonBodyText />
                                        </Box>
                                        <Box padding="200">
                                            <SkeletonBodyText />
                                        </Box>
                                    </BlockStack>
                                </Box>                                
                            </BlockStack>                        
                        </Card>
                    }
                </Page>
            </Box>
        </>
    )
}