import { BlockStack, Box, Button, Text, Page, Card, TextField, SkeletonBodyText  } from "@shopify/polaris";
import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import APIServicess from "../../../services/ApiServices";
import { useAppBridge, SaveBar, Modal, TitleBar } from "@shopify/app-bridge-react";
import Preview from "./Preview";

export default function EditTemplate({ setScreenShow, setSaveBarActive, template }) {
    const { t } = useTranslation();
    const APIServ = new APIServicess();
    const shopify = useAppBridge();
    const [emailTemplate, setEmailTemplate] = useState('');
    const [subject, setSubject] = useState('');
    const [initialState, setInitialState] = useState({});
    const [object, setObject] = useState({});
    const [saveBarLoading, setSaveBarLoading] = useState(false);
    const [revert, setRevert] = useState(false);
    const [model, setModel] = useState(false);
    const [previewTemplate, setPreviewTemplate] = useState('');   
    const [previewSubject, setPreviewSubject] = useState('');   

    // Set initial state set
    useEffect(() => {
        const fetchTemplateDetails = async () => {
            if (template) {
                try {
                    const response = await APIServ.getTemplateDetails({type : template});
                    if(response.status){
                        setEmailTemplate(response?.result?.emailTemplate);
                        setSubject(response?.result?.subject ?? 'Subject: Order #9999 confirmed');    
                        
                        setInitialState({subject : response?.result?.subject ?? 'Subject: Order #9999 confirmed', template : response?.result?.emailTemplate})
                        setObject({subject : response?.result?.subject ?? 'Subject: Order #9999 confirmed', template : response?.result?.emailTemplate})
                    }
                } catch (error) {
                    console.error("Error fetching template details:", error);
                }
            }
        };    
        fetchTemplateDetails();
    }, []);

    //String replace wwith number 
    const backToList = () => { 
        const isDataChanged = !areObjectsEqual(object, initialState);
        if(!isDataChanged){
            setScreenShow('template');
        } else {
            shopify.saveBar.leaveConfirmation();
        }        
    };

    // Update template priview
    const templateUpdate = async() => { 
        const isDataChanged = !areObjectsEqual(object, initialState);
        if(!isDataChanged){
            shopify.modal.show('preview-email-template');
            setModel(true);
            try {
                const response = await APIServ.getTemplateDetails({type : template});
                if(response.status){
                    const preview = await APIServ.getTemplatePreview({type : template, emailTemplate : response?.result?.emailTemplate, emailSubject : response?.result?.subject
                    });
                    if(preview.status){ 
                        setPreviewTemplate(preview?.result?.emailHtml);
                        setPreviewSubject(preview?.result?.emailSubject ?? 'Subject: Order #9999 confirmed');                    
                    }                        
                }
            } catch (error) {
                console.log(error);
            }
        }  else {
            shopify.saveBar.leaveConfirmation();
        }      
    };

    //Change content email body
    const handleChangeTemplate = (value) => { 
        setEmailTemplate(value);
        setObject(prevState => {
            const updatedState = { ...prevState };
            updatedState.template = value;
            return updatedState;
        });
    };

    //Change subject 
    const handleChangeSubject = (value) => { 
        setSubject(value);
        setObject(prevState => {
            const updatedState = { ...prevState };
            updatedState.subject = value;
            return updatedState;
        });
    };

    //Check changes
    useEffect(() => {
        const isDataChanged = !areObjectsEqual(object, initialState);
        setSaveBarActive(isDataChanged);
        if (isDataChanged) {
            shopify.saveBar.show('timeframe-save-bar');
        } else {
            shopify.saveBar.hide('timeframe-save-bar');
        }
    }, [object, initialState]);

    // Save email template
    const handleSave = async () => {
        try {
            setSaveBarLoading(true);
            const response = await APIServ.updateEmailTemplate({type : template, emailTemplate : object.template, subject : object.subject});
            if(response.status){
                setSaveBarLoading(false);   
                shopify.saveBar.hide('timeframe-save-bar');  
                shopify.toast.show(t('Settings.TemplateEdit.message'), {
                    duration: 1500,
                });
                setObject(initialState);
                const preview = await APIServ.getTemplatePreview({type : template, emailTemplate : object.template, emailSubject : object.subject});
                if(preview.status){
                    setPreviewTemplate(preview?.result?.emailHtml);
                    setPreviewSubject(preview?.result?.emailSubject ?? 'Subject: Order #9999 confirmed');                    
                } 
            }
        } catch (error) {
            console.log(error);
        } finally {
            setSaveBarActive(false);
        }
    }

    //Handle discard all changes 
    const handleDiscard = () => {
        setObject(initialState);
        setEmailTemplate(initialState?.template);
        setSubject(initialState?.subject); 
    }

    // Compares two objects recursively to check for equality.
    const areObjectsEqual = (object1, object2) => {
        if (object1 === object2) return true;
        if (typeof object1 !== "object" || typeof object2 !== "object" || object1 === null || object2 === null) {
            return false;
        }
        const keys1 = Object.keys(object1);
        const keys2 = Object.keys(object2);

        if (keys1.length !== keys2.length) return false;
        return keys1.every(key => keys2.includes(key) && areObjectsEqual(object1[key], object2[key]));
    };

    //Close model
    const onClose = () => {
        setModel(false);
    };

    //Revert email template
    const revertEmailTemplate = async () => {
        const isDataChanged = !areObjectsEqual(object, initialState);
        if(!isDataChanged){
            setRevert(true);
            try {
                const response = await APIServ.revertEmailTemplate({type : template});
                if(response.status){                    
                    let emailTemplate = response?.result?.emailTemplate;
                    let subject = response?.result?.subject ?? 'Order #9999 confirmed';
                    setEmailTemplate(emailTemplate);
                    setSubject(subject);    
                    
                    setInitialState({subject : subject, template : emailTemplate})
                    setObject({subject : subject, template : emailTemplate});

                    const updateResponse = await APIServ.updateEmailTemplate({type : template, emailTemplate : emailTemplate, subject : subject});
                    if(updateResponse.status){
                        setObject(initialState);
                        let templateNew = emailTemplate;
                        let subjectNew = subject;
                        const preview = await APIServ.getTemplatePreview({type : template, emailTemplate : templateNew, emailSubject : subjectNew});
                       
                        if(preview.status){
                            setPreviewTemplate(preview?.result?.emailHtml);
                            setPreviewSubject(preview?.result?.emailSubject);   
                            shopify.toast.show(t('Settings.TemplateEdit.revertMessage'), {
                                duration: 1500,
                            });                            
                        } 
                    }
                }
            } catch (error) {
                console.log(error);
            } finally {
                setRevert(false);
            }
        } else {
            shopify.saveBar.leaveConfirmation();
        } 
    }

    // Render
    return (
        <>
            <SaveBar id="timeframe-save-bar">
                <button onClick={handleDiscard}>{t('Settings.timeframe.buttons.discard')}</button>
                <button variant="primary" onClick={handleSave}{...(saveBarLoading ? { loading: "" } : {})}>{t('Settings.timeframe.buttons.save')}</button>
            </SaveBar>
            <Box className="upsell-create motion-appear-above-animation">
                <Page
                    backAction={{ onAction: () => backToList() }}
                    title={template == 'orderEdit' ? t('Settings.Template.template1Title') : template == 'paymentPending' ? t('Settings.Template.template2Title') : template == 'orderCancellation' ? t('Settings.Template.template3Title') : t('Settings.Template.template4Title')}
                    fullWidth
                    secondaryActions={[
                        {content: t('Settings.TemplateEdit.preview'), onAction: () => templateUpdate()},
                    ]}
                >
                    {
                        (emailTemplate && subject) ? <Box>
                            <BlockStack gap="400">
                                <Card>
                                    <BlockStack gap="200">
                                        <Text variant="headingMd" as="h6">{t('Settings.TemplateEdit.cardTitle')}</Text>
                                        <Text variant="bodyMd" as="p">{<span dangerouslySetInnerHTML={{ __html: t("Settings.TemplateEdit.cardDescription") }}></span>}</Text>
                                    </BlockStack>                        
                                </Card>
                                <Card>
                                    <BlockStack gap="400">
                                        <TextField
                                            label={t('Settings.TemplateEdit.subject')}
                                            value={subject}
                                            onChange={(event)=>handleChangeSubject(event)}
                                            autoComplete="off"
                                        />
                                        <TextField
                                            label={t('Settings.TemplateEdit.body')}
                                            value={emailTemplate}
                                            onChange={(event)=>handleChangeTemplate(event)}
                                            autoComplete="off"
                                            multiline={10}
                                            id="edit-email-template"
                                        />
                                        <Box>
                                            <Button variant="primary" onClick={revertEmailTemplate} disabled={revert} loading={revert}>{t('Settings.TemplateEdit.revertBtn')}</Button>
                                        </Box>                                    
                                    </BlockStack>                        
                                </Card>
                            </BlockStack>
                        </Box> : <Box>
                            <BlockStack gap="400">
                                <Card>
                                    <SkeletonBodyText />                      
                                </Card>
                                <Card>
                                    <BlockStack gap="400">
                                        <SkeletonBodyText />     
                                        <SkeletonBodyText />
                                        <SkeletonBodyText />
                                        <SkeletonBodyText />
                                        <SkeletonBodyText />
                                        <SkeletonBodyText />   
                                    </BlockStack>                                              
                                </Card>
                            </BlockStack>
                        </Box>
                    }                    
                </Page>
            </Box>   
            {/* Preview widget*/}
            <Modal id="preview-email-template" variant="max" onHide={onClose}>
                {
                    model && <Preview previewTemplate={previewTemplate} previewSubject={previewSubject}/>
                }
                <TitleBar title={t("Settings.previewWidget.title")}>
                </TitleBar>
            </Modal>         
        </>
    )
}