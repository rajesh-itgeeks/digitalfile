import { Layout, BlockStack, Card, FormLayout, Checkbox, Text, Box, Divider, TextField, InlineStack, Button, Icon, Link, Banner, Select, InlineGrid } from '@shopify/polaris';
import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import CreatableSelect from "react-select/creatable";
import { useAppBridge, SaveBar } from "@shopify/app-bridge-react";
import { useDispatch, useSelector } from "react-redux";
import APIServicess from "../../../services/ApiServices";
import { setNotification } from "../../store/NotificationSlice";
import Skeleton from '../Skeleton';
import {DeleteIcon, ClockIcon} from '@shopify/polaris-icons';

export default function Settings({ setScreenShow, setSaveBarActive, setTemplate }) {
    const { t } = useTranslation();
    const shopify = useAppBridge();
    const dispatch = useDispatch();
    const notification = useSelector((state) => state.notification);
    const APIServ = new APIServicess();
    // State for CreatableSelect
    const [inputValue, setInputValue] = useState('');
    const [selectedOptions, setSelectedOptions] = useState([]);
    const [error, setError] = useState(false);
    const [saveBarLoading, setSaveBarLoading] = useState(false);
    const [initialState, setInitialState] = useState({});
    const [object, setObject] = useState({});
    const [customerEmail, setCustomerEmail] = useState('');
    const [customerError, setcustomerError] = useState(false);
    const [notificationOnOff, setNotificationOnOff] = useState(false);
    const [validEmail, setValidEmail] = useState(false);
    const [checkVerified, setCheckVerified] = useState(false);
    const [verified, setVerified] = useState(true);
    const [customerErrorMsg, setcustomerErrorMsg] = useState('');
    const [showBanner, setShowBanner] = useState(true);
    const options = t('Settings.Notification.options', { returnObjects: true });
    const [errors, setErrors] = useState([]);
    const [editErrors, setEditErrors] = useState([]);

    let optionsTimeFrame = [
        {label: t('Settings.Notification.minutes'), value: 'minutes'},
        {label: t('Settings.Notification.hours'), value: 'hours'}
    ]

    // Set initial state set
    useEffect(() => {
        const fetchNotification = async () => {
            if (notification) {
                let timeframe = notification?.paymentPending?.times?.length ? notification.paymentPending.times : ["10minutes"];
                const objectArray = timeframe.map(str => {
                    const match = str.match(/^(\d+)([a-zA-Z]+)$/);
                    return {
                      time: parseInt(match[1], 10),
                      tenure: match[2]
                    };
                });

                let editTimeFrame = notification?.orderEditsTimeFrame?.times.length ? notification?.orderEditsTimeFrame?.times : ["10minutes"];
                const editTime = editTimeFrame.map(str => {
                    const match = str.match(/^(\d+)([a-zA-Z]+)$/);
                    return {
                      time: parseInt(match[1], 10),
                      tenure: match[2]
                    };
                });

                let initialData = {
                    enableMerchantNotification: notification?.enableMerchantNotification,
                    merchantEmails: notification?.merchantEmails,
                    customerSenderEmail: notification?.customerSenderEmail,
                    paymentPending: notification?.paymentPending?.status,
                    orderCancellation: notification?.orderCancellation?.status,
                    addUpSellItem: notification?.addUpSellItem?.status,
                    orderEdit: notification?.orderEdit?.status,
                    enableCustomerNotification : notification?.enableCustomerNotification,    
                    pendingTimeframe : objectArray,
                    orderEditsTimeFrame : notification?.orderEditsTimeFrame?.status,  
                    orderEditsTimes : editTime        
                }

                setInitialState(initialData);
                setObject(initialData);
                setCustomerEmail(notification?.customerSenderEmail);
                setNotificationOnOff(notification?.enableMerchantNotification);
                let emails = notification?.merchantEmails;
                const formattedEmails = emails.map(email => ({
                    label: email,
                    value: email
                }));
                setSelectedOptions(formattedEmails);
                setVerified(notification?.customerSenderEmail ? true : false)
            } else {
                // Get notification detail
                const notificationData = await APIServ.getNotification();
                if (notificationData.status && notificationData.result) {
                    dispatch(setNotification(notificationData.result));
                } else {
                    let notificationCreate = {
                        enableMerchantNotification : false,
                        merchantEmails : [],
                        enableCustomerNotification : true,
                        customerSenderEmail : null,
                        orderEdit : {
                            "status" : false
                        },
                        paymentPending : {
                            "status" : false,
                            "times" : []
                        },
                        orderCancellation : {
                            "status" : false
                        },
                        addUpSellItem : {
                            "status" : false
                        },
                        orderEditsTimeFrame : {
                            "status" : false,
                            "times" : []
                        }
                    }
                    const settingsCreate = await APIServ.saveNotification(notificationCreate);
                    if (settingsCreate.status && settingsCreate.result) {
                        dispatch(setNotification(settingsCreate.result));
                    }
                }
            }
        }
        fetchNotification();        
    }, [notification]);

    useEffect(() => {
        if (!verified && checkVerified) {
            console.log("🔄 Checking verification status...");
            const interval = setInterval(() => {
                checkVerifiedEmail(customerEmail);
            }, 10000);

            return () => clearInterval(interval);
        }
    }, [checkVerified, verified, customerEmail]); 

    // Function to validate email format
    const isValidEmail = (email) => {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    };

    // Function to create a new email option
    const createOption = (email) => ({
        label: email,
        value: email,
    });

    // Handle key press (Enter/Tab) to add only valid emails
    const handleKeyDown = (event) => {
        if (!inputValue) return;
        if (event.key === 'Enter' || event.key === 'Tab') {
            event.preventDefault();
            if (!isValidEmail(inputValue)) {
                setError(true);
                return;
            }
            setSelectedOptions((prev) => [...prev, createOption(inputValue)]);
            setObject((prevState) => ({
                ...prevState,
                merchantEmails: [...prevState.merchantEmails, inputValue],
            }));
            setInputValue('');
            setError(false);
        }
    };

    // Handle removal or clearing of selected emails
    const handleChange = (newValue) => {
        setSelectedOptions(newValue || []);
        setObject((prevState) => ({
            ...prevState,
            merchantEmails: (newValue || []).map((option) => option.value),
        }));
    };

    // Remove dropdown arrow
    const customComponents = {
        DropdownIndicator: null,
        IndicatorSeparator: null,
    };

    //Handle feild focus 
    const handleFocus = () => {
        setError(false);
    }

    //Handle feild Blur
    const handleBlur = (event) => {
        if (!inputValue) return; // Empty input ke liye kuch mat karo
    
        if (!isValidEmail(inputValue)) {
            setError(true); // Invalid email error show karo
            return;
        }
    
        // Valid email ko add karo
        setSelectedOptions((prev) => [...prev, createOption(inputValue)]);
        setObject((prevState) => ({
            ...prevState,
            merchantEmails: [...prevState.merchantEmails, inputValue],
        }));
        
        setInputValue('');
        setError(false);
    };

    //Handle discard all changes 
    const handleDiscard = () => {
        setObject(initialState);
        setCustomerEmail(initialState.customerSenderEmail);
        setNotificationOnOff(initialState.enableMerchantNotification);
        let emails = initialState.merchantEmails;
        const formattedEmails = emails.map(email => ({
            label: email,
            value: email
        }));
        setSelectedOptions(formattedEmails);
        setValidEmail(false);   
        setVerified(false);
        setCheckVerified(false);   
        setVerified(true);
        setEditErrors([]);
        setErrors([]);

    }

    //save all changes
    const handleSave = async () => {
        try {
            if (saveBarLoading) return; // Prevent double execution
            setSaveBarLoading(true);
    
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (object.customerSenderEmail && !emailRegex.test(object.customerSenderEmail)) {
                setcustomerError(true);
                setSaveBarLoading(false);
                setcustomerErrorMsg(t('Settings.Notification.customerEmail.settingSectionOne.error'));
                return;
            }
            if (!verified && object.customerSenderEmail) {
                setcustomerError(true);
                setSaveBarLoading(false);
                setcustomerErrorMsg(t('Settings.Notification.customerEmail.settingSectionOne.emailVerified'));
                return;
            }     

            let pendingTimeframe = [];

            if(object?.paymentPending){
                const newErrors = object.pendingTimeframe.map((item) => {
                    if (item.time === "" || item.time === null || item.time === 0) {
                      return t('Settings.Notification.customerEmail.settingSectionThree.timeFrame.error');
                    }
                    return null;
                  });
                  
                  if (newErrors.some(error => error !== null)) {
                    setErrors(newErrors);
                    return false;
                }
                pendingTimeframe =  object?.pendingTimeframe?.map(item => `${item.time}${item.tenure}`);
            }

            let emailTimeframe = [];
            if(object?.orderEditsTimeFrame){
                const newErrors = object.orderEditsTimes.map((item) => {
                    if (item.time === "" || item.time === null || item.time === 0) {
                      return t('Settings.Notification.customerEmail.settingSectionThree.timeFrame.error');
                    }
                    return null;
                  });
                  
                  if (newErrors.some(error => error !== null)) {
                    setEditErrors(newErrors);
                    return false;
                }
                emailTimeframe =  object?.orderEditsTimes?.map(item => `${item.time}${item.tenure}`);
            }

    
            const data = {
                enableMerchantNotification: object?.enableMerchantNotification,
                merchantEmails: object?.merchantEmails,
                customerSenderEmail: object?.customerSenderEmail,
                enableCustomerNotification: object?.enableCustomerNotification,
                paymentPending: { status: object?.paymentPending, times : pendingTimeframe},
                orderCancellation: { status: object?.orderCancellation },
                addUpSellItem: { status: object?.addUpSellItem },
                orderEdit: { status: object?.orderEdit },
                orderEditsTimeFrame : { status: object?.orderEditsTimeFrame, times : emailTimeframe},
            };
    
            const response = await APIServ.saveNotification(data);
            if (response.status) {                    
                const getSettings = await APIServ.getNotification();
                if (getSettings.status) {
                    dispatch(setNotification(getSettings.result));
                    shopify.toast.show(t('Settings.Notification.message'), { duration: 1500 });
                }
            }
        } catch (error) {
            console.error("Error saving notification:", error);
        } finally {
            setSaveBarLoading(false);
        }
    };  


    //Handle on off settings
    const handleOnOffSettings = (type) => {
        setObject(prevState => {
            const updatedState = { ...prevState };
            if (type === 'upsellEmail') {
                updatedState.addUpSellItem = !prevState.addUpSellItem;
            }
            if (type === 'cancellationMail') {
                updatedState.orderCancellation = !prevState.orderCancellation;
            }
            if (type === 'pendingMail') {
                updatedState.paymentPending = !prevState.paymentPending;
            }
            if (type === 'editedMail') {
                updatedState.orderEdit = !prevState.orderEdit;
            }
            if (type === 'timeLeft') {
                updatedState.orderEditsTimeFrame = !prevState.orderEditsTimeFrame;
            }            
            return updatedState;
        });
    };

    //Check changes
    useEffect(() => {
        const isDataChanged = !areObjectsEqual(object, initialState);
        setSaveBarActive(isDataChanged);
        if (isDataChanged) {
            shopify.saveBar.show('timeframe-save-bar');
        } else {
            shopify.saveBar.hide('timeframe-save-bar');
        }
    }, [object, initialState]);

    const handleCustomerEmail = (value) => {
        setCustomerEmail(value);
        setcustomerError(false);

        setObject(prevState => ({
            ...prevState,
            customerSenderEmail: value
        }));

        const isValid = isValidEmail(value);
        const isDataChanged = !areObjectsEqual({ ...object, customerSenderEmail: value }, initialState);
        setValidEmail(isValid && isDataChanged);
        setVerified(false);
        setCheckVerified(false);
    };
    

    //Handle notification on off
    const handleNotificationOnOff = (value) => {
        setNotificationOnOff(value);
        setObject(prevState => {
            const updatedState = { ...prevState };
            updatedState.enableMerchantNotification = value;
            return updatedState;
        });
    }

    // Compares two objects recursively to check for equality.
    const areObjectsEqual = (object1, object2) => {
        if (object1 === object2) return true;
        if (typeof object1 !== "object" || typeof object2 !== "object" || object1 === null || object2 === null) {
            return false;
        }
        const keys1 = Object.keys(object1);
        const keys2 = Object.keys(object2);

        if (keys1.length !== keys2.length) return false;
        return keys1.every(key => keys2.includes(key) && areObjectsEqual(object1[key], object2[key]));
    };

    //Icon Component
    const iconContent = () => {
        return (
            <svg viewBox="0 0 20 20" focusable="false" aria-hidden="true" fill="#8e1f0b"><path d="M10 6a.75.75 0 0 1 .75.75v3.5a.75.75 0 0 1-1.5 0v-3.5a.75.75 0 0 1 .75-.75Z"></path><path d="M11 13a1 1 0 1 1-2 0 1 1 0 0 1 2 0Z"></path><path fillRule="evenodd" d="M17 10a7 7 0 1 1-14 0 7 7 0 0 1 14 0Zm-1.5 0a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0Z"></path></svg>
        );
    };

    //Preview email temaplete
    const handleToShowTemplate = (template) => {
        const isDataChanged = !areObjectsEqual(object, initialState);
        if (!isDataChanged) {
            setScreenShow('template');
            setTemplate(template);
        } else {
            shopify.saveBar.leaveConfirmation();
        }
    }

    //Preview email temaplete
    const verifyEmail = async (value) => {
        setcustomerError(false);
        try {
            let data = { "email": value };
            const response = await APIServ.verifyEmail(data);
            if (response.status) {
                console.log("✅ Email verification started...");
                setCheckVerified(true);
                setVerified(false);
            }
        } catch (error) {
            console.error("Error verifying email:", error);
        }
    };

    //Preview email temaplete
    const checkVerifiedEmail = async (value) => {
        setcustomerError(false);
        try {
            if (value) {
                let data = { "emails": [value] };
                const response = await APIServ.checkVerified(data);
                if (response.status) {
                    const keyName = Object.keys(response?.result)[0];
                    if (keyName === value) {
                        const isVerified = response?.result?.[value];
                        if(isVerified){
                            setVerified(isVerified);
                            setCheckVerified(!isVerified);
                            setValidEmail(!isVerified);
                        }
                    }
                }
            }
        } catch (error) {
            console.error("Error checking verification:", error);
        }
    };   

    const addMoreTimeFrame = (type) => {
        const newObject = { time: 10, tenure: "minutes" };
        if(type == 'pendingMail'){
            setObject(prev => ({
                ...prev,
                pendingTimeframe: [...prev.pendingTimeframe, newObject]
              }));
        } else {
            setObject(prev => ({
                ...prev,
                orderEditsTimes: [...prev.orderEditsTimes, newObject]
            }));            
        }        
    };

    const handleTimeFrame = (index, type) => {
        if(type == 'pendingMail'){
            setObject(prev => ({
                ...prev,
                pendingTimeframe: prev.pendingTimeframe.filter((_, i) => i !== index)
            }));
        } else {
            setObject(prev => ({
                ...prev,
                orderEditsTimes: prev.orderEditsTimes.filter((_, i) => i !== index)
            }));
        }
    };

    const handleTimeFrameTime = (event, index) => {
        const value = parseInt(event);
      
        setObject(prev => ({
          ...prev,
          pendingTimeframe: prev.pendingTimeframe.map((item, i) =>
            i === index
              ? {
                  ...item,
                  time: isNaN(value) ? "" : value
                }
              : item
          )
        }));
      
        // Clear error for this index immediately (without checking value)
        setErrors(prevErrors => {
          const updated = [...prevErrors];
          updated[index] = null;
          return updated;
        });
      };
      
      
      

      const handleTimeLeftTimeFrameTime = (event, index) => {
        const value = parseInt(event);
      
        setObject(prev => ({
          ...prev,
          orderEditsTimes: prev.orderEditsTimes.map((item, i) =>
            i === index
              ? {
                  ...item,
                  time: isNaN(value) ? "" : value
                }
              : item
          )
        }));
      
        setEditErrors(prevErrors => {
          const updated = [...prevErrors];
          updated[index] = null;
          return updated;
        });
      };

      
      const handleTenureValue = (value, index, type) => {
        setObject(prev => {
            const updated = { ...prev };
    
            if (type === 'pendingMail') {
                const updatedPending = [...updated.pendingTimeframe];
                updatedPending[index] = { ...updatedPending[index], tenure: value };
                updated.pendingTimeframe = updatedPending;
            } else {
                const updatedTimeLeft = [...updated.orderEditsTimes];
                updatedTimeLeft[index] = { ...updatedTimeLeft[index], tenure: value };
                updated.orderEditsTimes = updatedTimeLeft;
            }
    
            return updated;
        });
      }

    function getOrdinal(n) {
        const suffixes = ["st", "nd", "rd"];
        const v = n % 100;
        return `${n + 1}${suffixes[(v - 20) % 10] || suffixes[v] || suffixes[0]}`;
    }
    
    function timeTextRender(index, type) {
        const number = getOrdinal(index);
        let time = '';
        if(type == 'pendingMail'){
            time = `${object.pendingTimeframe[index].time} ${object.pendingTimeframe[index].tenure}`;
        } else {
            time = `${object.orderEditsTimes[index].time} ${object.orderEditsTimes[index].tenure}`;
        }
    
        if (index === 0) {
            if(type == 'pendingMail') {
                return t("Settings.Notification.customerEmail.settingSectionThree.timeFrame.text1", {
                    number,
                    time
                });
            } else {
                return t("Settings.Notification.customerEmail.settingSectionSix.timeFrame.text1", {
                    number,
                    time
                });
            }            
        } else if (index === 1) {
            const first = getOrdinal(0);
            if(type == 'pendingMail') { 
                return t("Settings.Notification.customerEmail.settingSectionThree.timeFrame.text2", {
                    number,
                    time,
                    first
                });
            } else {
                return t("Settings.Notification.customerEmail.settingSectionSix.timeFrame.text2", {
                    number,
                    time,
                    first
                });
            }
        } else {
            const second = getOrdinal(index - 1);
            if(type == 'pendingMail') { 
                return t("Settings.Notification.customerEmail.settingSectionThree.timeFrame.text3", {
                    number,
                    time,
                    second
                });
            } else {
                return t("Settings.Notification.customerEmail.settingSectionSix.timeFrame.text3", {
                    number,
                    time,
                    second
                });
            }
            
        }
    }   
    

    return (
        <>
            <SaveBar id="timeframe-save-bar">
                <button onClick={handleDiscard}>{t('Settings.timeframe.buttons.discard')}</button>
                <button variant="primary" onClick={handleSave}{...(saveBarLoading ? { loading: "" } : {})}>{t('Settings.timeframe.buttons.save')}</button>
            </SaveBar>
            {
                showBanner && <Box className="timeframe-info-banner">
                        <Banner onDismiss={() => { setShowBanner(false) }} tone="info">{<span dangerouslySetInnerHTML={{ __html: t('Settings.Notification.bannerText') }}></span>}</Banner>
                </Box>
            }
                    
            {
                !notification ? <Skeleton /> : <> 
                    <Box className="upsell-create motion-appear-above-animation">
                        <Layout>
                            <Layout.AnnotatedSection
                                id="edit-timeframe-settings"
                                title={t('Settings.Notification.staffEmail.title')}
                                description={t('Settings.Notification.staffEmail.description')}
                            >
                                <BlockStack gap={400}>
                                    <Card>
                                        <FormLayout>
                                            <BlockStack gap={200}>
                                                <Text fontWeight="semibold" as="h4">
                                                    {t('Settings.Notification.staffEmail.settingSection.title')}
                                                </Text>
                                                <BlockStack gap={100}>
                                                    {/* Checkbox */}
                                                    <Checkbox
                                                        label={t('Settings.Notification.staffEmail.settingSection.checkBoxLable')}
                                                        checked={notificationOnOff}
                                                        onChange={() => handleNotificationOnOff(!notificationOnOff)}
                                                    />

                                                    {/* Email Input with Validation */}
                                                    <Text as='p'>{t('Settings.Notification.staffEmail.settingSection.feildTitle')}</Text>
                                                    <CreatableSelect
                                                        isClearable
                                                        isMulti
                                                        inputValue={inputValue ?? ""}
                                                        onInputChange={(newValue) => setInputValue(newValue)}
                                                        onChange={handleChange}
                                                        onKeyDown={handleKeyDown}
                                                        options={selectedOptions}
                                                        placeholder="Enter emails..."
                                                        value={selectedOptions ?? ""}
                                                        menuIsOpen={false}
                                                        className="custom-email-input"
                                                        components={customComponents}
                                                        onFocus={() => handleFocus()}
                                                        onBlur={() => handleBlur()}
                                                    />

                                                    {error && <Box>
                                                        <InlineStack gap="200">
                                                            <Box className="error-icon">
                                                                <Icon source={iconContent} />
                                                            </Box><Text as='p' tone="critical" >{t('Settings.Notification.staffEmail.settingSection.error')}</Text>
                                                        </InlineStack>
                                                    </Box>
                                                    }
                                                    <Text variant="bodySm" as="p">{t('Settings.Notification.staffEmail.settingSection.note')}</Text>
                                                </BlockStack>
                                            </BlockStack>
                                        </FormLayout>
                                    </Card>
                                </BlockStack>
                            </Layout.AnnotatedSection>
                            {/* Divider */}
                            <Box as="div" className="annotated-section">
                                <Divider borderWidth="050" />
                            </Box>
                            <Layout.AnnotatedSection
                                id="edit-timeframe-settings"
                                title={t('Settings.Notification.customerEmail.title')}
                                description={t('Settings.Notification.customerEmail.description')}
                            >
                                <BlockStack gap={400}>
                                    <Card>
                                        <FormLayout>
                                            <BlockStack gap={200}>
                                                <Text fontWeight="semibold" as="h4">
                                                    {t('Settings.Notification.customerEmail.settingSectionOne.title')}
                                                </Text>
                                                <BlockStack gap={100}>
                                                    <TextField
                                                        label={t('Settings.Notification.customerEmail.settingSectionOne.feildTitle')}
                                                        type="email"
                                                        suffix={verified ? "Verified" : ''}
                                                        value={customerEmail ?? ""}
                                                        onChange={(event) => handleCustomerEmail(event)}
                                                        placeholder={t('Settings.Notification.customerEmail.settingSectionOne.placeholder')}
                                                        error={customerError ? customerErrorMsg : ''}
                                                    />
                                                    {
                                                        validEmail && 
                                                            <InlineStack align="start" gap="100">
                                                                     
                                                                {
                                                                    checkVerified ? <>
                                                                        <Text variant="headingSm" fontWeight="regular" as="p">{t('Settings.Notification.customerEmail.settingSectionOne.text2')}</Text> 
                                                                    </>
                                                                     : <>
                                                                     <Text variant="headingSm" fontWeight="regular" as="p">{t('Settings.Notification.customerEmail.settingSectionOne.text1')}</Text> 
                                                                     <Link removeUnderline={true} onClick={() => verifyEmail(customerEmail)}><Text variant="headingSm" as="span" fontWeight="regular">{t('Settings.Notification.customerEmail.settingSectionOne.verifyEmail')}</Text></Link>
                                                                     </>
                                                                    
                                                                }                  
                                                            </InlineStack>
                                                    }
                                                    <Text variant="bodySm" as="p">{t('Settings.Notification.customerEmail.settingSectionOne.note')}</Text>                                          
                                                </BlockStack>
                                            </BlockStack>
                                        </FormLayout>
                                    </Card>

                                    <Card>
                                        <FormLayout>
                                            <BlockStack>
                                                <InlineStack blockAlign="center" align="space-between">
                                                    <Text fontWeight="semibold" as="h4">
                                                        {t('Settings.Notification.customerEmail.settingSectionTwo.title')}
                                                    </Text>
                                                    <Box>
                                                        <InlineStack blockAlign="center" gap="400">
                                                            <Button variant="plain" onClick={() => handleToShowTemplate('orderEdit')}>{t('Settings.Notification.customerEmail.edit')}</Button>
                                                            <Button variant="plain" onClick={() => handleOnOffSettings('editedMail')}>
                                                                <span className={`switch__button  ${object.orderEdit == true ? 'selected' : ''}`}>
                                                                    <span className="active-dot"></span>
                                                                </span>
                                                            </Button>
                                                        </InlineStack>
                                                    </Box>
                                                </InlineStack>
                                                <Text variant="bodySm" as="p">{t('Settings.Notification.customerEmail.settingSectionTwo.description')}</Text>
                                            </BlockStack>
                                        </FormLayout>
                                    </Card>

                                    <Card>
                                        <FormLayout>
                                            <BlockStack>
                                                <InlineStack blockAlign="center" align="space-between">
                                                    <Text fontWeight="semibold" as="h4">
                                                        {t('Settings.Notification.customerEmail.settingSectionThree.title')}
                                                    </Text>
                                                    <Box>
                                                        <InlineStack blockAlign="center" gap="400">
                                                            <Button variant="plain" onClick={() => handleToShowTemplate('paymentPending')}>{t('Settings.Notification.customerEmail.edit')}</Button>
                                                            <Button variant="plain" onClick={() => handleOnOffSettings('pendingMail')}>
                                                                <span className={`switch__button  ${object.paymentPending == true ? 'selected' : ''}`}>
                                                                    <span className="active-dot"></span>
                                                                </span>
                                                            </Button>
                                                        </InlineStack>
                                                    </Box>
                                                </InlineStack>
                                                <Text variant="bodySm" as="p">{t('Settings.Notification.customerEmail.settingSectionThree.description')}</Text>
                                            </BlockStack>
                                        </FormLayout>
                                    </Card>
                                    {
                                        object.paymentPending && <Card>
                                            <FormLayout>
                                                <BlockStack>
                                                    <InlineStack blockAlign="center" align="space-between">
                                                        <Text fontWeight="semibold" as="h4">
                                                            {t('Settings.Notification.customerEmail.settingSectionThree.timeFrame.title')}
                                                        </Text>                                                        
                                                    </InlineStack>
                                                    <Text variant="bodySm" as="p">{t('Settings.Notification.customerEmail.settingSectionThree.timeFrame.description')}</Text>
                                                    <Box className="notifiction-line-list">
                                                        <BlockStack>
                                                            {
                                                                object.pendingTimeframe.map((item, index) => (   
                                                                    <div className="notifiction-line-list-item" key={index}>
                                                                        <BlockStack key={index}>                                                      
                                                                            <InlineGrid columns={2} gap="200">
                                                                                <TextField
                                                                                    value={item.time}
                                                                                    onChange={(event) => handleTimeFrameTime(event, index)}
                                                                                    autoComplete="off"
                                                                                    error={errors[index] ? errors[index] : ""}
                                                                                />
                                                                                <InlineStack gap="200">
                                                                                    <Box width='86%'>
                                                                                        <Select
                                                                                            options={optionsTimeFrame}
                                                                                            onChange={(event) => handleTenureValue(event, index, "pendingMail")}
                                                                                            value={item.tenure}
                                                                                        />
                                                                                    </Box> 
                                                                                    <Button onClick={()=>handleTimeFrame(index, "pendingMail")} icon={DeleteIcon} disabled={index == 0}/>
                                                                                </InlineStack>                                                            
                                                                            </InlineGrid>{
                                                                                !errors[index] && <InlineGrid columns={1} gap="200">
                                                                                    <Box paddingBlockStart="100"><Text variant="bodyMd" as="p">{<span dangerouslySetInnerHTML={{ __html: timeTextRender(index, "pendingMail") }}></span>}</Text></Box>
                                                                                </InlineGrid>
                                                                            }                                                                             
                                                                            <Box className="timeline-icon"><Icon source={ClockIcon}tone="base"/></Box>
                                                                        </BlockStack>
                                                                    </div> 
                                                                ))
                                                            }                                                            
                                                        </BlockStack>
                                                        {
                                                            object.pendingTimeframe.length <= 2 && <Box paddingBlockStart="200"><Button onClick={()=>addMoreTimeFrame("pendingMail")}>{t('Settings.Notification.customerEmail.settingSectionThree.timeFrame.add')}</Button></Box>
                                                        }
                                                    </Box>
                                                </BlockStack>
                                            </FormLayout>
                                        </Card>
                                    }

                                    <Card>
                                        <FormLayout>
                                            <BlockStack>
                                                <InlineStack blockAlign="center" align="space-between">
                                                    <Text fontWeight="semibold" as="h4">
                                                        {t('Settings.Notification.customerEmail.settingSectionSix.title')}
                                                    </Text>
                                                    <Box>
                                                        <InlineStack blockAlign="center" gap="400">
                                                            <Button variant="plain" onClick={() => handleToShowTemplate('orderEditsTimeFrame')}>{t('Settings.Notification.customerEmail.edit')}</Button>
                                                            <Button variant="plain" onClick={() => handleOnOffSettings('timeLeft')}>
                                                                <span className={`switch__button  ${object.orderEditsTimeFrame == true ? 'selected' : ''}`}>
                                                                    <span className="active-dot"></span>
                                                                </span>
                                                            </Button>
                                                        </InlineStack>
                                                    </Box>
                                                </InlineStack>
                                                <Text variant="bodySm" as="p">{t('Settings.Notification.customerEmail.settingSectionSix.description')}</Text>
                                            </BlockStack>
                                        </FormLayout>
                                    </Card>

                                    {
                                        object.orderEditsTimeFrame && <Card>
                                            <FormLayout>
                                                <BlockStack>
                                                    <InlineStack blockAlign="center" align="space-between">
                                                        <Text fontWeight="semibold" as="h4">
                                                            {t('Settings.Notification.customerEmail.settingSectionSix.timeFrame.title')}
                                                        </Text>                                                        
                                                    </InlineStack>
                                                    <Text variant="bodySm" as="p">{t('Settings.Notification.customerEmail.settingSectionSix.timeFrame.description')}</Text>
                                                    
                                                    <Box className="notifiction-line-list">
                                                        <BlockStack>
                                                            {
                                                                object?.orderEditsTimes.map((item, index) => (   
                                                                    <div className="notifiction-line-list-item" key={index}>
                                                                        <BlockStack>                                                      
                                                                            <InlineGrid columns={2} gap="200">
                                                                                <TextField
                                                                                    value={item.time}
                                                                                    onChange={(event) => handleTimeLeftTimeFrameTime(event, index)}
                                                                                    autoComplete="off"
                                                                                    error={editErrors[index] ? editErrors[index] : ""}
                                                                                />
                                                                                <InlineStack gap="200">
                                                                                    <Box width='86%'>
                                                                                        <Select
                                                                                            options={optionsTimeFrame}
                                                                                            onChange={(event) => handleTenureValue(event, index, "timeLeftT")}
                                                                                            value={item.tenure}
                                                                                        />
                                                                                    </Box> 
                                                                                    <Button onClick={()=>handleTimeFrame(index, "timeLeftT")} icon={DeleteIcon} disabled={index == 0}/>
                                                                                </InlineStack>
                                                                            </InlineGrid>{
                                                                                !editErrors[index] && <InlineGrid columns={1} gap="200">
                                                                                    <Box paddingBlockStart="100"><Text variant="bodyMd" as="p">{<span dangerouslySetInnerHTML={{ __html: timeTextRender(index, "orderEditsTime") }}></span>}</Text></Box>
                                                                                </InlineGrid>
                                                                            }                                                                             
                                                                            <Box className="timeline-icon"><Icon source={ClockIcon}tone="base"/></Box>
                                                                        </BlockStack>
                                                                    </div> 
                                                                ))
                                                            }                                                            
                                                        </BlockStack>
                                                        {
                                                            object?.orderEditsTimes.length <= 2 && <Box paddingBlockStart="200"><Button onClick={()=>addMoreTimeFrame("timeLeftT")}>{t('Settings.Notification.customerEmail.settingSectionSix.timeFrame.add')}</Button></Box>
                                                        }
                                                    </Box>
                                                </BlockStack>
                                            </FormLayout>
                                        </Card>
                                    }

                                    <Card>
                                        <FormLayout>
                                            <BlockStack>
                                                <InlineStack blockAlign="center" align="space-between">
                                                    <Text fontWeight="semibold" as="h4">
                                                        {t('Settings.Notification.customerEmail.settingSectionFour.title')}
                                                    </Text>
                                                    <Box>
                                                        <InlineStack blockAlign="center" gap="400">
                                                            <Button variant="plain" onClick={() => handleToShowTemplate('orderCancellation')}>{t('Settings.Notification.customerEmail.edit')}</Button>
                                                            <Button variant="plain" onClick={() => handleOnOffSettings('cancellationMail')}>
                                                                <span className={`switch__button  ${object.orderCancellation == true ? 'selected' : ''}`}>
                                                                    <span className="active-dot"></span>
                                                                </span>
                                                            </Button>
                                                        </InlineStack>
                                                    </Box>
                                                </InlineStack>
                                                <Text variant="bodySm" as="p">{t('Settings.Notification.customerEmail.settingSectionFour.description')}</Text>
                                            </BlockStack>
                                        </FormLayout>
                                    </Card>

                                    <Card>
                                        <FormLayout>
                                            <BlockStack>
                                                <InlineStack blockAlign="center" align="space-between">
                                                    <Text fontWeight="semibold" as="h4">
                                                        {t('Settings.Notification.customerEmail.settingSectionFive.title')}
                                                    </Text>
                                                    <Box>
                                                        <InlineStack blockAlign="center" gap="400">
                                                            <Button variant="plain" onClick={() => handleToShowTemplate('addUpSellItem')}>{t('Settings.Notification.customerEmail.edit')}</Button>
                                                            <Button variant="plain" onClick={() => handleOnOffSettings('upsellEmail')}>
                                                                <span className={`switch__button  ${object.addUpSellItem == true ? 'selected' : ''}`}>
                                                                    <span className="active-dot"></span>
                                                                </span>
                                                            </Button>
                                                        </InlineStack>
                                                    </Box>                                                    
                                                </InlineStack>
                                                <Text variant="bodySm" as="p">{t('Settings.Notification.customerEmail.settingSectionFive.description')}</Text>
                                            </BlockStack>
                                        </FormLayout>
                                    </Card>


                                </BlockStack>
                            </Layout.AnnotatedSection>
                        </Layout>
                    </Box>
                </>
            }
        </>
    );
}
