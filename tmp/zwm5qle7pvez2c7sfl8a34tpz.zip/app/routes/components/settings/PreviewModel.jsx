import {BlockStack, Box, Card, InlineStack, Text, Icon, Button, InlineGrid, Thumbnail, Spinner, Banner, useBreakpoints} from '@shopify/polaris';
import {
    ArrowLeftIcon, InfoIcon, PackageReturnedIcon
} from '@shopify/polaris-icons';
import WidgetPreviewList from './WidgetPreviewList';
import React, { useState, useEffect, useRef } from "react";
import WidgetPreviewUpsell from "./WidgetPreviewUpsell";
import { useTranslation } from "react-i18next";
import { useDispatch, useSelector } from "react-redux";
import currencyJson from "../common/currencysymbols.json";
import { setSettings } from "../store/SettingsSlice";
import APIServicess from '../../services/ApiServices';

export default function PreviewModel() {
const [listShow, setListShow] = useState(false);
const [showSettingsList, setShowSettingsList] = useState(false);
const [showUpsellList, setShowUpsellList] = useState(false);
const [showBanner, setShowBanner] = useState(true);
const { t } = useTranslation();
const [symbol, setSymbol] = useState('');
const currentStore = useSelector((state) => state.currentStore);
const settings = useSelector((state) => state.settings);
const { lgUp } = useBreakpoints();
const APIServ = new APIServicess();
const dispatch = useDispatch();

useEffect(() => {
     setSymbol(currencyJson[currentStore?.currencyCode]);
     const fetchNotification = async () => {
        if (!settings) {
            const setting = await APIServ.getShopSettings();
            if (setting.status) {
                dispatch(setSettings(setting.result));
                setListShow(true);
            }
        } else {
            setListShow(true);
        }
    }
    fetchNotification();
}, [listShow, currentStore, settings]);
    return (
        <>
            <Box padding="200" background="bg">  
                <Box background="bg-surface-secondary" padding="0">
                    <Box id="preview-model">
                        <BlockStack gap="400">
                            <Box padding="400" position="relative" id="blur-box">
                                <InlineStack wrap={false} align="space-between"  blockAlign="center">
                                    <Box>
                                        <InlineStack wrap={false} gap="200" blockAlign="start">
                                            <Icon
                                                source={ArrowLeftIcon}
                                                tone="base"
                                            />
                                            <BlockStack>
                                                <Text variant="headingLg">Order #1228</Text>
                                                <Text variant="headingXs" as="p" fontWeight="regular">Confirmed Feb 24</Text>
                                            </BlockStack>
                                        </InlineStack>
                                    </Box>
                                    <Box>
                                        <Button size="large">Buy Now</Button>
                                    </Box>
                                    <Box position="absolute" width="100%" minHeight="100%" insetInlineStart="0"></Box>
                                </InlineStack>
                            </Box>
                            <Box padding="400" position="relative">
                                <InlineStack gap="200" align="space-between">
                                    <Box width={lgUp ? "59%" : "100%"}>
                                        <BlockStack gap="400">                                            
                                            {
                                                listShow ? <>
                                                    <WidgetPreviewList setShowSettingsList={setShowSettingsList}/>
                                                    <WidgetPreviewUpsell setShowUpsellList={setShowUpsellList}/>
                                                    {
                                                        (!showSettingsList && !showUpsellList && showBanner) && <Banner onDismiss={() => setShowBanner(!showBanner)}>
                                                            <span>{t("Settings.previewWidget.bannerText")}</span>
                                                        </Banner>
                                                    }
                                                </> : <Box style={{"display": "flex", "justifyContent": "center"}}><Spinner size="small"/></Box>
                                            }                                            
                                            <Box position="relative" id="blur-box">
                                                <Card>
                                                    <BlockStack gap="300">
                                                        <InlineStack>
                                                            <Box position="relative">
                                                                <Thumbnail
                                                                    source="https://cdn.shopify.com/s/files/1/0906/1076/2016/files/Main_0a40b01b-5021-48c1-80d1-aa8ab4876d3d.jpg"
                                                                    alt="Black choker necklace"
                                                                />
                                                                <Box position="absolute"insetInlineEnd="0" insetBlockStart="0" id="product-quantity">2</Box>
                                                            </Box>
                                                        </InlineStack>
                                                        <Box>
                                                            <InlineStack align="start" gap="100">
                                                                <Box>
                                                                    <Icon
                                                                        source={PackageReturnedIcon}
                                                                        tone="base"
                                                                    />
                                                                </Box>
                                                                <Text as="p" variant="headingMd">Return in progress</Text>
                                                            </InlineStack>
                                                        </Box>                                                        
                                                        <Box paddingInlineStart="600">
                                                            <BlockStack gap="400">
                                                                <Text as="p" variant="headingMd" fontWeight="regular" tone="success">15 Feb</Text>
                                                                <Text as="p" variant="headingMd" fontWeight="regular" tone="success">Your return was approved. We emailed you a return shipping lable, or you will receive one soon.</Text>
                                                            </BlockStack>
                                                        </Box>     
                                                    </BlockStack>
                                                </Card>
                                                <Box position="absolute" width="100%" minHeight="100%" insetInlineStart="0" insetBlockStart="0"></Box>
                                            </Box>    

                                            <Box position="relative" id="blur-box">
                                                <Card>
                                                    <InlineGrid gap="400" columns={{ "xs": 1, "lg": 2 }}>
                                                        <Box>
                                                            <BlockStack gap="600">
                                                                <BlockStack gap="300">
                                                                    <Text as="p" variant="headingMd">Contact information</Text>
                                                                    <BlockStack gap="100">
                                                                        <Text as="p" variant="headingMd" fontWeight="regular">Salvador Fahey</Text>
                                                                        <Text as="p" variant="headingMd" fontWeight="regular">Salvador.fahey@example.com</Text>                                                                    
                                                                    </BlockStack>                                                                    
                                                                </BlockStack>
                                                                <BlockStack gap="300">
                                                                    <Text as="p" variant="headingMd">Shipping address</Text>
                                                                    <BlockStack gap="100">
                                                                        <Text as="p" variant="headingMd" fontWeight="regular">Salvador Fahey</Text>
                                                                        <Text as="p" variant="headingMd" fontWeight="regular">1600 Pennsylvania Avenue NW</Text>
                                                                        <Text as="p" variant="headingMd" fontWeight="regular">Washington Washington DC 20500-0005</Text>
                                                                        <Text as="p" variant="headingMd" fontWeight="regular">United States</Text>
                                                                        <Text as="p" variant="headingMd" fontWeight="regular">+1 (202) 456-1414</Text>
                                                                    </BlockStack>                                                                    
                                                                </BlockStack>
                                                                <BlockStack gap="300">
                                                                <Text as="p" variant="headingMd">Shipping method</Text>
                                                                    <Text as="p" variant="headingMd">Standard Shipping</Text>
                                                                </BlockStack>
                                                            </BlockStack>
                                                        </Box>
                                                        <Box>
                                                            <BlockStack gap="600">
                                                                <BlockStack gap="300">                                                                    
                                                                    <Text as="p" variant="headingMd">Payment</Text>
                                                                    <BlockStack gap="100">
                                                                        <Text as="p" variant="headingMd" fontWeight="regular" tone="success">Visa ... 4242</Text>
                                                                        <Text as="p" variant="headingMd" fontWeight="regular" tone="success">$749.95</Text>
                                                                        <Text as="p" variant="headingMd" fontWeight="regular" tone="success">17 Feb</Text>
                                                                    </BlockStack>  
                                                                </BlockStack>
                                                                <BlockStack gap="300">
                                                                    <Text as="p" variant="headingMd">Billing address</Text>
                                                                    <BlockStack gap="100">
                                                                        <Text as="p" variant="headingMd" fontWeight="regular">Salvador Fahey</Text>
                                                                        <Text as="p" variant="headingMd" fontWeight="regular">1600 Pennsylvania Avenue NW</Text>
                                                                        <Text as="p" variant="headingMd" fontWeight="regular">Washington Washington DC 20500-0005</Text>
                                                                        <Text as="p" variant="headingMd" fontWeight="regular">United States</Text>
                                                                        <Text as="p" variant="headingMd" fontWeight="regular">+1 (202) 456-1414</Text>
                                                                    </BlockStack>
                                                                </BlockStack>
                                                                
                                                                
                                                            </BlockStack>
                                                        </Box>
                                                    </InlineGrid>
                                                </Card>
                                                <Box position="absolute" width="100%" minHeight="100%" insetInlineStart="0" insetBlockStart="0"></Box>
                                            </Box>
                                        </BlockStack>
                                        
                                    </Box>
                                    <Box position="relative" width={lgUp ? "40%" : "100%"}>
                                        <Box position="sticky" id="blur-box" insetBlockStart="0">
                                        <BlockStack gap="400">
                                            <Card>
                                                <BlockStack gap="400">
                                                    <Box padding="400" background="bg-surface-secondary" borderRadius="200">
                                                        <InlineStack align="start" blockAlign="center" gap="200">
                                                            <Box>
                                                                <Icon
                                                                    source={InfoIcon}
                                                                    tone="base"
                                                                />
                                                            </Box>
                                                            <Text as="p" tone="success">Your payment is due in 7 days</Text>
                                                        </InlineStack>                                                        
                                                    </Box>
                                                    <Box>
                                                        <InlineStack align="space-between" blockAlign="center">
                                                            <BlockStack>
                                                                <Text as="p" tone="success">$4000 USD</Text>
                                                                <Text as="p" tone="success">Payment due 24 Feb</Text>
                                                            </BlockStack>
                                                            <Button size="large">Pay Now</Button>
                                                        </InlineStack>
                                                    </Box>
                                                </BlockStack>
                                            </Card> 

                                            <Card>
                                                <BlockStack gap="400">
                                                    <InlineStack align="space-between" blockAlign="center">
                                                        <InlineStack blockAlign="center" gap="200">
                                                            <Box position="relative">
                                                                <Thumbnail
                                                                    source="https://cdn.shopify.com/s/files/1/0906/1076/2016/files/Main_0a40b01b-5021-48c1-80d1-aa8ab4876d3d.jpg?v=1728464200"
                                                                    alt="Black choker necklace"
                                                                />
                                                                <Box position="absolute"insetInlineEnd="0" insetBlockStart="0" id="product-quantity">2</Box>
                                                            </Box>
                                                            <BlockStack>
                                                                <Text as="p" fontWeight="medium">Black Leather Choker Necklace</Text>
                                                                <Text as="p" fontWeight="regular">Size: M</Text>
                                                            </BlockStack>
                                                        </InlineStack>
                                                        <Text as="p" tone="success">$200</Text>
                                                    </InlineStack>
                                                    <InlineStack align="space-between" blockAlign="center">
                                                        <InlineStack blockAlign="center" gap="200">
                                                            <Box position="relative">
                                                                <Thumbnail
                                                                    source="https://cdn.shopify.com/s/files/1/0906/1076/2016/files/Main_0a40b01b-5021-48c1-80d1-aa8ab4876d3d.jpg?v=1728464200"
                                                                    alt="Black choker necklace"
                                                                />
                                                                <Box position="absolute"insetInlineEnd="0" insetBlockStart="0" id="product-quantity">2</Box>
                                                            </Box>
                                                            <BlockStack>
                                                                <Text as="p" fontWeight="medium">The Videographer Snowboard</Text>
                                                                <Text as="p" fontWeight="regular">Size: M</Text>
                                                            </BlockStack>
                                                        </InlineStack>
                                                        <Text as="p" tone="success">$200</Text>
                                                    </InlineStack>
                                                    <InlineStack align="space-between" blockAlign="center">
                                                        <InlineStack blockAlign="center" gap="200">
                                                            <Box position="relative">
                                                                <Thumbnail
                                                                    source="https://cdn.shopify.com/s/files/1/0906/1076/2016/files/Main_0a40b01b-5021-48c1-80d1-aa8ab4876d3d.jpg?v=1728464200"
                                                                    alt="Black choker necklace"
                                                                />
                                                                <Box position="absolute"insetInlineEnd="0" insetBlockStart="0" id="product-quantity">2</Box>
                                                            </Box>
                                                            <BlockStack>
                                                                <Text as="p" fontWeight="medium">The Collection Snowboard: Hydrogen</Text>
                                                                <Text as="p" fontWeight="regular">Size: M</Text>
                                                            </BlockStack>
                                                        </InlineStack>
                                                        <Text as="p" tone="success">$200</Text>
                                                    </InlineStack>
                                                    <InlineStack align="space-between" blockAlign="center">
                                                        <Text as="p" fontWeight="medium">Subtotal</Text>
                                                        <Text as="p" fontWeight="regular">$600</Text>
                                                    </InlineStack>
                                                    <InlineStack align="space-between" blockAlign="center">
                                                        <Text as="p" fontWeight="medium">Shipping</Text>
                                                        <Text as="p" fontWeight="regular">Free</Text>
                                                    </InlineStack>
                                                    <InlineStack align="space-between" blockAlign="center">
                                                        <Text as="h5" fontWeight="medium" variant="headingLg">Total</Text>
                                                        <Text as="p" fontWeight="regular" variant="headingLg"><Text as="span" fontWeight="regular" variant="bodyXs">USD</Text> $600</Text>
                                                    </InlineStack>
                                                </BlockStack>
                                            </Card>
                                        </BlockStack>                                         
                                        <Box position="absolute" width="100%" minHeight="100%" insetInlineStart="0" insetBlockStart="0"></Box>                                      
                                    </Box>
                                    </Box>
                                </InlineStack>
                            </Box>
                        </BlockStack>
                    </Box>
                </Box>
            </Box>
        </>
    )
}