import React from "react";
// import LangLayout from '../adminComponents/LanguageComponent/LangLayout/index.jsx'
import MessageLayout from '../adminComponents/LanguageComponent/Message/MessageLayout/index.jsx'
import { useSelector } from "react-redux";
import LoginForm from "../app.login/route.jsx";
import Layout from "../adminComponents/Layout/Layout.jsx";

const AppRoutes = () => {
  const { isLoggedIn, shop } = useSelector((state) => state.auth);
  const stores = ["itgdev.myshopify.com","rajesh-choudhary-dev.myshopify.com", "productionae.myshopify.com", "account-editor-flow.myshopify.com", "quickstart-1add1160.myshopify.com"]

  if (stores.includes(shop)) {
    return (
      <>
        {isLoggedIn ? (
          <Layout>
            <MessageLayout />
          </Layout>
        ) : (
          <LoginForm />
        )}
      </>
    )
  } else {
    return (
      <>
        <h1 style={{ fontSize: '24px', fontWeight: '700', margin: '20px' }}> 404 Not Found</h1>    </>
    )
  }
};

export default AppRoutes;


