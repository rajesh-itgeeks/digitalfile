import { useNavigate } from '@remix-run/react';
import React from 'react';

const Check = () => {
  const navigate=useNavigate();
  // window.open('/download_invoice', '_blank');
  // const htmlContent = `
  // <body style="margin: 0; padding: 0; font-family: 'Inter', sans-serif;">
  //   <div style="width: 100%; max-width: 600px; margin: 0 auto;">
  //     <table class="email" width="100%" border="0" cellspacing="0" cellpadding="0" style="border-radius: 8px;">
  //       <tr>
  //         <td>
  //           <table border="0" style="width: 100%; padding: 16px;" cellspacing="0" cellpadding="0">
  //             <tbody>
  //               <tr>
  //                 <td>
  //                   <table border="0" cellspacing="0" cellpadding="0" style="width: 100%;">
  //                     <tbody>
  //                       <tr>
  //                         <td>
  //                           <div><img src="" alt="img" width="133" /></div>
  //                         </td>
  //                         <td>
  //                           <p style="text-align: right; margin: 0; font-size: 14px; line-height: 20px; color: #777777;">Receipt / Tax Invoice ODID#1156</p>
  //                           <p style="text-align: right; margin: 0; font-size: 14px; line-height: 20px; color: #777777;">Created 2025-04-08T01:28:32-04:00</p>
  //                           <p style="text-align: right; margin: 0; font-size: 14px; line-height: 20px; color: #777777;">Last Updated 2025-04-08T01:29:16-04:00</p>
  //                         </td>
  //                       </tr>
  //                     </tbody>
  //                   </table>
  //                 </td>
  //               </tr>
  
  //               <tr>
  //                 <td>
  //                   <table border="0" cellspacing="0" cellpadding="0" style="width: 100%; text-align: left; margin-top: 24px;">
  //                     <tbody>
  //                       <tr>
  //                         <th style="width: 500px; color: #303030; font-size: 13px;">Shipping address</th>
  //                         <th style="width: 500px; color: #303030; font-size: 13px;">Customer</th>
  //                         <th align="right" style="width: 500px; color: #303030; font-size: 13px;">Order</th>
  //                       </tr>
  //                       <tr style="width: 100%;">
  //                         <td>
  //                           <div style="color: #777777; font-size: 13px; line-height: 22px; font-weight: 500; margin-top: 13px;">
  //                             <p style="margin: 0;">1250 Hospital Shivaji Nagar</p>
  //                             <p style="margin: 0;">Bhopal</p>
  //                             <p style="margin: 0;">462016</p>
  //                             <p style="margin: 0;">India</p>
  //                           </div>
  //                         </td>
  //                         <td>
  //                           <div style="color: #777777; font-size: 13px; line-height: 22px; font-weight: 500; margin-top: 13px;">
  //                             <!-- Customer details can be filled here -->
  //                           </div>
  //                         </td>
  //                         <td align="right" style="vertical-align: top;">
  //                           <div style="color: #777777; font-size: 13px; line-height: 22px; font-weight: 500; margin-top: 13px;">
  //                             <p style="margin: 0;">paid</p>
  //                             <p style="margin: 0;">mayurirajput@itgeeks.com</p>
  //                           </div>
  //                         </td>
  //                       </tr>
  //                     </tbody>
  //                   </table>
  //                 </td>
  //               </tr>
  
  //               <tr>
  //                 <td>
  //                   <table border="0" cellspacing="0" cellpadding="0" style="width: 100%; margin-top: 24px; border: 1px solid #EBEBEB;">
  //                     <tbody>
  //                       <tr>
  //                         <th align="left" style="width: 25%; padding: 12px; background-color: #F9FAFB; font-size: 13px; color: #303030;">Items</th>
  //                         <th align="left" style="width: 25%; background-color: #F9FAFB; font-size: 13px; color: #303030;">Price</th>
  //                         <th align="left" style="width: 25%; background-color: #F9FAFB; font-size: 13px; color: #303030;">Qty</th>
  //                         <th align="left" style="width: 25%; background-color: #F9FAFB; font-size: 13px; color: #303030;">Total</th>
  //                       </tr>
  //                       <tr>
  //                         <td style="width: 25%; padding: 16px; color: #777777; font-size: 13px; line-height: 22px;">
  //                           <strong>The Multi-location Snowboard</strong><br>/ 32SKU:
  //                         </td>
  //                         <td style="width: 25%; color: #777777; font-size: 13px;">729.95 INR</td>
  //                         <td style="width: 25%; color: #777777; font-size: 13px;">1</td>
  //                         <td style="width: 25%; padding-right: 16px; color: #777777; font-size: 13px;">729.95 INR</td>
  //                       </tr>
  //                     </tbody>
  //                   </table>
  //                 </td>
  //               </tr>
  
  //               <tr>
  //                 <td>
  //                   <table align="right" border="0" cellspacing="0" cellpadding="0" style="width: 46%; margin-top: 20px;">
  //                     <tbody>
  //                       <tr>
  //                         <td style="font-size: 13px; color: #777777; line-height: 16px; padding-top: 16px;">Order discount</td>
  //                         <td style="text-align: right; color: #777777; font-size: 13px; padding-top: 16px;">-500.00 INR</td>
  //                       </tr>
  //                       <tr>
  //                         <td style="font-size: 13px; color: #777777; line-height: 16px; padding-top: 16px;">Subtotal</td>
  //                         <td style="text-align: right; color: #777777; font-size: 13px; padding-top: 16px;">229.95 INR</td>
  //                       </tr>
  //                       <tr>
  //                         <td style="font-size: 13px; color: #777777; line-height: 16px; padding-top: 16px;">Shipping</td>
  //                         <td style="text-align: right; color: #777777; font-size: 13px; padding-top: 16px;">0.00 INR</td>
  //                       </tr>
  //                       <tr>
  //                         <td style="font-size: 13px; color: #777777; line-height: 16px; padding-top: 16px;">VAT</td>
  //                         <td style="text-align: right; color: #777777; font-size: 13px; padding-top: 16px;">41.39 INR</td>
  //                       </tr>
  //                       <tr>
  //                         <td colspan="2" style="padding-top: 16px; font-size: 13px; color: #777777; line-height: 22px;">Los Angeles <br>County Tax 0.25%</td>
  //                       </tr>
  //                       <tr>
  //                         <td colspan="2" style="padding-top: 16px; font-size: 13px; color: #777777; line-height: 22px;">Los Angeles <br>County District Tax <br>Sp 2.25%</td>
  //                       </tr>
  //                       <tr>
  //                         <td colspan="2" style="padding-top: 16px; font-size: 13px; color: #777777; line-height: 22px;">Los Angeles Co <br>Local Tax Sl 1%</td>
  //                       </tr>
  //                       <tr>
  //                         <td colspan="2" style="padding-top: 16px; font-size: 13px; color: #777777; line-height: 22px;">California State <br>Tax 6%</td>
  //                       </tr>
  //                       <tr>
  //                         <td style="border-bottom: 1px solid #303030; color: #303030; font-size: 13px; padding-top: 16px; padding-bottom: 20px;">Total</td>
  //                         <td style="border-bottom: 1px solid #303030; color: #303030; font-size: 13px; padding-top: 16px; padding-bottom: 20px;">271.34 INR</td>
  //                       </tr>
  //                     </tbody>
  //                   </table>
  //                 </td>
  //               </tr>
  
  //               <tr>
  //                 <td>
  //                   <table border="0" cellspacing="0" cellpadding="0" style="width: 100%; margin-top: 24px; text-align: center;">
  //                     <tbody>
  //                       <tr>
  //                         <td>
  //                           <p style="color:#8A8A8A; font-size: 13px; line-height: 22px; margin: 0;">Thank you for shopping with us!</p>
  //                           <p style="margin-top: 24px; margin-bottom: 0;">
  //                             <a href="mailto:mayurirajput@itgeeks.com" style="color: #1990C6; font-size: 13px; text-decoration: none;">mayurirajput@itgeeks.com</a>
  //                           </p>
  //                         </td>
  //                       </tr>
  //                     </tbody>
  //                   </table>
  //                 </td>
  //               </tr>
  
  //             </tbody>
  //           </table>
  //         </td>
  //       </tr>
  //     </table>
  //   </div>
  // </body>
  // `;
  const orderId="5541361680539";
  const shop="antim-fulwere-dev.myshopify.com"
  const openInvoice = () => {
    navigate(`/download_invoice?orderId=${orderId}&shop=${shop}`);


  };

  // const openInvoiceWindow = (orderId,shop) => {
  //   console.log("orderId cc",orderId)
  //   console.log("shop cc",shop)
  //   const newWindow = window.open('/download_invoice', '_blank');
  
  //   const interval = setInterval(() => {
  //     if (newWindow && newWindow.postMessage) {
  //       newWindow.postMessage({ orderId,shop }, window.location.origin);
  //       clearInterval(interval);
  //     }
  //   }, 100);
  // };
  


  return (
    <div style={{ textAlign: 'center', paddingTop: '50px' }}>
      <button onClick={()=>openInvoice(orderId,shop)}>Download Invoice</button>
    </div>
  );
};

export default Check;

