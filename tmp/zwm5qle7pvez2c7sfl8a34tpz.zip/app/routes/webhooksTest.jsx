import { authenticate } from '../shopify.server';
import { ShopifySessions } from '../api/server/models/shopifySessions.model';
import { removeCustomer, removePartnerDetails, unInstalled } from '../api/server/services/partner/index.server';
import { orderCancellation, orderCreate } from '../api/server/services/webhooks';

export const action = async ({ request }) => {
    const { topic, shop, session, payload } = await authenticate.webhook(request);
    console.log(`:::---Received ${topic} webhook for ${shop}---:::`);
    // const body = JSON.parse(payload);
    process.env.ENV_SERVER !== "production" ? console.log(payload, '------------------payload') : null;

    switch (topic) {
        case 'APP_UNINSTALLED':
            console.log("executing ::: APP_UNINSTALLED webhook");
            await unInstalled(payload.id);
            if (session) {
                await ShopifySessions.deleteMany({ shop });
            }
            break;
        case 'CUSTOMERS_DATA_REQUEST':
            break;
        case 'CUSTOMERS_REDACT':
            console.log("executing ::: CUSTOMERS_REDACT webhook");
            const costumerId = `gid://shopify/customer/${payload.customer.id}`;
            await removeCustomer(costumerId);
            break;
        case 'SHOP_REDACT':
            console.log("executing ::: SHOP_REDACT webhook");
            await removePartnerDetails(payload.myshopify_domain);
            break;
        case 'ORDERS_CREATE':
            console.log("executing ::: ORDERS_CREATE webhook");
            await orderCreate(payload);
            break;
        case 'ORDER_TRANSACTIONS_CREATE':
            console.log("executing ::: ORDERS_EDITED webhook");
            await orderTransactions(payload);
            break;
        case 'ORDERS_CANCELLED':
            console.log("executing ::: ORDERS_CANCELLED webhook");
            await orderCancellation(payload);
            break;
        default:
            throw new Response('Unhandled webhook topic', { status: 404 });
    }

    throw new Response();
};
