import { useNavigate } from '@remix-run/react';
import {
    IndexTable,
    Card,
    Button,
    Badge,
    Page,
    Divider,
    Box,
    Tooltip,
    ButtonGroup,
    Text,
    BlockStack,
    InlineStack,
    TextField,
    Icon
} from '@shopify/polaris';
import { useEffect, useState } from 'react';
import APIServices from './services/ApiServices';
import { useTranslation } from 'react-i18next';
import { DeleteIcon, EditIcon, SearchIcon, CheckIcon } from '@shopify/polaris-icons';
import "./assets/settings.css";
import Skeleton from './components/settings/Skeleton';
import { useDispatch, useSelector } from "react-redux";
import { setPageId } from "./components/store/PageSlice";
import { useAppBridge, SaveBar } from "@shopify/app-bridge-react";

export default function Localization() {
    const ApiServ = new APIServices();
    const navigate = useNavigate();
    const [languages, setLanguages] = useState([]);
    const [loading, setLoading] = useState(false);
    const [detail, setDetail] = useState({});
    const [detailData, setDetailData] = useState([]);
    const [offset, setOffset] = useState(0);
    const [searchValue, setSearchValue] = useState("");
    const [editingIndex, setEditingIndex] = useState(null);
    const [editingValue, setEditingValue] = useState("");
    const [totalPage, setTotalPage] = useState(0);
    const [currentPage, setCurrentPage] = useState(null);
    const [btnLoader, setBtnLoader] = useState(false);
    const [limit, setLimit] = useState(10);
    const pageId = useSelector((state) => state.pageId);
    const dispatch = useDispatch();
    const { t } = useTranslation();
    const shopify = useAppBridge();
    const [saveBarLoading, setSaveBarLoading] = useState(false);
    const [initialState, setInitialState] = useState({});
    const [saveBarActive, setSaveBarActive] = useState(false);
    const [updateObject, setUpdateObject] = useState({});

    //Initial load data langauge
    useEffect(() => {
        async function fetchLanguages() {
            setLoading(true);
            try {
                const response = await ApiServ.getDefaultLanguage();
                if (response?.status) {
                    const fetchedLanguages = response?.result?.map((lang) => ({
                        id: lang?._id,
                        name: lang?.name?.charAt(0).toUpperCase() + lang?.name?.slice(1),
                        code: lang?.lang,
                        active: lang?.status,
                        isDefault: lang?.isDefault || false,
                    }));
                    setLanguages(fetchedLanguages);
                } else {
                    console.error('Failed to fetch languages:', response.message);
                }
            } catch (error) {
                console.error('Error fetching languages:', error);
            } finally {
                setLoading(false);
            }
        }
        fetchLanguages();
    }, []);

    //Toggle language on off
    const toggleLanguage = async (index) => {
        const selectedLang = languages[index];
        const newStatus = !selectedLang.active;

        try {
            const payload = {
                lang: selectedLang.code,
                status: newStatus,
                name: selectedLang?.name
            };

            const response = await ApiServ.addLanguageJson(payload);
            if (response.status) {
                setLanguages((prev) =>
                    prev.map((lang, i) =>
                        i === index ? { ...lang, active: newStatus } : lang
                    )
                );

                const responses = await ApiServ.getDefaultLanguage();
                if (responses?.status) {
                    const fetchedLanguages = responses?.result?.map((lang) => ({
                        id: lang?._id,
                        name: lang?.name?.charAt(0).toUpperCase() + lang?.name?.slice(1),
                        code: lang?.lang,
                        active: lang?.status,
                        isDefault: lang?.isDefault || false,
                    }));
                    setLanguages(fetchedLanguages);
                } else {
                    console.error('Failed to fetch languages:', responses.message);
                }
            } else {
                console.error("Failed to update status:", response.message);
            }
        } catch (error) {
            console.error("Error toggling language status:", error);
        }
    };

    //Handle edit button click
    const handleEditClick = async (id, code, status, name) => {
        try {
            let objects = {
                id,
                code,
                status,
                name
            };
            setDetail(objects);
            setLoading(true);

            const body = {
                id: id,
                lang: code,
                searchKey: "",
                offset: offset,
                limit: 10,
            };
            const response = await ApiServ.getSpecificLanguageDetails(body);
            if (response.status) {
                const langJson = response?.result?.languageData?.langJson;
                const langRows = Object.entries(langJson);
                const result = langRows.map(([key, value]) => ({ key, value }));
                setDetailData(result);
                setInitialState(result);
                setTotalPage(response?.result?.totalKeysCount);
            }
        } catch (error) {
            console.error("Error toggling language status:", error);
        } finally {
            setLoading(false);
        }
    };

    //Handle search
    const handleSearchChange = (value) => {
        setSearchValue(value);
        clearTimeout(handleSearchChange.timer);
        handleSearchChange.timer = setTimeout(async () => {
            try {
                const body = {
                    id: detail?.id,
                    lang: detail?.code,
                    searchKey: value,
                    offset: 0,
                    limit: 10,
                };
                const response = await ApiServ.getSpecificLanguageDetails(body);
                if (response.status) {
                    const langJson = response?.result?.languageData?.langJson;
                    const langRows = Object.entries(langJson);
                    const result = langRows.map(([key, value]) => ({ key, value }));
                    setDetailData(result);
                    setInitialState(result);
                    setTotalPage(response?.result?.searchKeysCount || response?.result?.totalKeysCount );
                    setOffset(0);
                }
            } catch (error) {
                console.error("Error fetching language details:", error);
            }
        }, 500);
    };

    //Handle Pagination
    const handlePagination = async (offsetValue) => {
        const isDataChanged = !areObjectsEqual(detailData, initialState);
        if (!isDataChanged) {
            try {
                const body = {
                    id: detail?.id,
                    lang: detail?.code,
                    searchKey: searchValue,
                    offset: offsetValue,
                    limit: 10,
                };
                const response = await ApiServ.getSpecificLanguageDetails(body);
                if (response.status) {
                    const langJson = response?.result?.languageData?.langJson;
                    const langRows = Object.entries(langJson);
                    const result = langRows.map(([key, value]) => ({ key, value }));
                    setDetailData(result);
                    setInitialState(result);
                    setEditingIndex("");
                    setEditingValue("");
                    setBtnLoader(false);
                    setTotalPage(response?.result?.totalKeysCount);
                    setOffset(offsetValue);
                }
            } catch (error) {
                console.error("Error fetching language details:", error);
            }
        } else {
            shopify.saveBar.leaveConfirmation();
        }
    }

    //Handle edit text for edit text
    const handleEditTextClick = (index) => {
        setEditingIndex(index);
        setEditingValue(detailData[index]?.value);        
    };

    //Handle edit text save
    const handleEditTextSave = async (index, key) => {
        if(!editingValue) return false;
        const updated = [...detailData];
        updated[index] = { ...updated[index], value: editingValue };
        setDetailData(updated);
        setEditingIndex("");
        setEditingValue("");

        const newObject = { ...updateObject };
        newObject[key] = editingValue;
        setUpdateObject(newObject);
    };

    //Page component action 
    const redirectEditor = async (type) => {
        try {
            let checkoutId = pageId;
            if (!pageId) {
                const pagesdata = await ApiServ.getShopPagePreviewing();
                if (pagesdata.status) {
                    const idString = pagesdata.data[0]?.id;
                    checkoutId = idString?.match(/\d+$/)?.[0];
                    if (checkoutId) dispatch(setPageId(checkoutId));
                }
            }

            const pageType = type === 'orderStatus' ? 'order-status' : 'thank-you';
            const url = `https://admin.shopify.com/store/${shopName}/settings/checkout/editor/profiles/${checkoutId}?page=${pageType}&context=apps`;

            window.open(url, '_blank');
        } catch (error) {
            console.error("Redirect error:", error);
        }
    };

    //Back to language action
    function backActionPage() {
        const isDataChanged = !areObjectsEqual(detailData, initialState);
        if (!isDataChanged) {
            setDetail({});
            setOffset(0);
            setDetailData([]);
            setSearchValue("");
            setSearchValue("");
            setEditingIndex("");
            setEditingValue("");
            setTotalPage(0);
            setInitialState([]);
        } else {
            shopify.saveBar.leaveConfirmation();
        }
    }

    const handleDiscard = () => {
        setDetailData(initialState);
        setUpdateObject({});
    }

    const handleSave = async (type) => {
        try {
            if (saveBarLoading || editingIndex || editingValue) return;            
            setSaveBarLoading(true);
            const updateData = {
                lang: detail?.code,
                name: detail?.name,
                langJson: updateObject
            };
            const saveResponse = await ApiServ.addLanguageJson(updateData);
            if (saveResponse.status) {
                const body = {
                    id: detail.id,
                    lang: detail.code,
                    searchKey: searchValue,
                    offset: 0,
                    limit: 10,
                };
                const response = await ApiServ.getSpecificLanguageDetails(body);
                if (response?.status) {
                    const langJson = response?.result?.languageData?.langJson;
                    const langRows = Object.entries(langJson);
                    const result = langRows.map(([key, value]) => ({ key, value }));
                    setDetailData(result);
                    setInitialState(result);
                    setEditingIndex("");
                    setEditingValue("");
                    setBtnLoader(false);
                    setTotalPage(response?.result?.totalKeysCount);
                    shopify.saveBar.hide('timeframe-save-bar');
                    shopify.toast.show(t('Settings.Notification.message'), { duration: 1500 });
                }
            }
        }  catch (error) {
            console.error("Error saving notification:", error);
        } finally {
            setSaveBarLoading(false);
        }
    }

    //Check changes
    useEffect(() => {
        const isDataChanged = !areObjectsEqual(detailData, initialState);
        setSaveBarActive(isDataChanged);
        if (isDataChanged) {
            shopify.saveBar.show('timeframe-save-bar');
        } else {
            shopify.saveBar.hide('timeframe-save-bar');
        }
    }, [detailData, initialState]);

    // Compares two objects recursively to check for equality.
    const areObjectsEqual = (object1, object2) => {
        if (object1 === object2) return true;
        if (typeof object1 !== "object" || typeof object2 !== "object" || object1 === null || object2 === null) {
            return false;
        }
        const keys1 = Object.keys(object1);
        const keys2 = Object.keys(object2);

        if (keys1.length !== keys2.length) return false;
        return keys1.every(key => keys2.includes(key) && areObjectsEqual(object1[key], object2[key]));
    };

    function handleSearchBlur(){
        setEditingIndex("");
        setEditingValue("");
    }

    return (
        <>
            <SaveBar id="timeframe-save-bar">
                <button onClick={handleDiscard}>{t('Settings.timeframe.buttons.discard')}</button>
                <button variant="primary" onClick={handleSave}{...(saveBarLoading ? { loading: "" } : {})}>{t('Settings.timeframe.buttons.save')}</button>
            </SaveBar>
            <Page
                fullWidth
                backAction={
                    detail?.name
                        ? {
                            content: "Back",
                            onAction: backActionPage
                        }
                        : undefined
                }
                title={
                    <>
                        {detail?.name ? `${detail.name.charAt(0).toUpperCase() + detail.name.slice(1)}` : t("Localization.pageTitle")}
                        {detail?.name && <Box as={'span'} paddingInlineStart="200"><Badge status={detail.status ? 'success' : 'default'} tone={detail.status ? 'success' : 'default'}> {detail.status ? t("Localization.active") : t("Localization.inactive")}</Badge></Box>}
                    </>
                }
                actionGroups={[
                    {
                        title: t('Settings.page.actionGroup.title'),
                        actions: [
                            {
                                content: t('Settings.page.actionGroup.orderStatus'),
                                accessibilityLabel: t('Settings.page.actionGroup.orderStatusLabel'),
                                onAction: () => redirectEditor('orderStatus'),
                            },
                            {
                                content: t('Settings.page.actionGroup.thankYou'),
                                accessibilityLabel: t('Settings.page.actionGroup.thankYouLabel'),
                                onAction: () => redirectEditor('thankyou'),
                            },
                        ],
                    },
                ]}
            >
                <Divider borderWidth="050" />
                <Box as="div" className="main-container tab-hide">
                    {
                        loading ? (
                            <Skeleton />
                        ) : (
                            detail?.name && detailData.length > 0 ? (
                                <Card padding="0">
                                    <Box className="searchbar-with__filters">
                                        <TextField
                                            prefix={<Icon source={SearchIcon} />}
                                            value={searchValue}
                                            onChange={handleSearchChange}
                                            placeholder="Search"
                                            clearButton
                                            onClearButtonClick={() => handleSearchChange("")}
                                            onFocus={handleSearchBlur}
                                        />
                                    </Box>
                                    <Box className="table-language_text_td">
                                        <IndexTable
                                            itemCount={detailData.length}
                                            headings={[
                                                { title: t("Localization.no") },
                                                { title: t("Localization.label"), alignment: "start" },
                                                { title: t("Localization.value"), alignment: "start" },
                                                { title: '', alignment: "end" },
                                            ]}
                                            selectable={false}
                                            padding={true}
                                            pagination={
                                                detailData.length > 0
                                                    ? {
                                                        hasPrevious: offset > 0,
                                                        hasNext: offset + limit < totalPage,
                                                        onNext: () => handlePagination(offset + limit),
                                                        onPrevious: () => handlePagination(offset - limit),
                                                    }
                                                    : undefined
                                            }
                                        >
                                            {detailData.map((item, index) => {
                                                return (
                                                    <IndexTable.Row id={index} key={index}>
                                                        <IndexTable.Cell>{(offset + index + 1).toString().padStart(2, '0')}</IndexTable.Cell>
                                                        <IndexTable.Cell>
                                                            <Box width="250px">{item.key}</Box></IndexTable.Cell>
                                                        <IndexTable.Cell>
                                                            <BlockStack inlineAlign="start">
                                                                {
                                                                    editingIndex === index ? (
                                                                        <Box className="language_edit_feild">
                                                                            <TextField
                                                                                value={editingValue}
                                                                                onChange={(event) => setEditingValue(event)}
                                                                                autoComplete="off"
                                                                                fullWidth
                                                                                onBlur={() =>
                                                                                    setEditingValue((prev) =>
                                                                                      prev
                                                                                        .trim()
                                                                                        .replace(/\s+/g, ' ')
                                                                                    )
                                                                                  }
                                                                            />
                                                                        </Box>
                                                                    ) : (
                                                                        item.value
                                                                    )
                                                                }
                                                            </BlockStack>
                                                        </IndexTable.Cell>
                                                        <IndexTable.Cell>
                                                            <BlockStack inlineAlign="end">
                                                                {
                                                                    (editingIndex === index && !btnLoader) ? (
                                                                        <Button
                                                                            size="large" variant="secondary"
                                                                            icon={CheckIcon}
                                                                            onClick={() => handleEditTextSave(index, item.key)}
                                                                            loading={btnLoader}
                                                                            disabled={!editingValue ? true : false}
                                                                        />
                                                                    ) : (
                                                                        <ButtonGroup>
                                                                            <Tooltip content={t("Settings.upsellList.editTooltip")}>
                                                                                <Button
                                                                                    variant="tertiary"
                                                                                    size="large"
                                                                                    icon={EditIcon}
                                                                                    onClick={() => handleEditTextClick(index)}
                                                                                />
                                                                            </Tooltip>
                                                                        </ButtonGroup>
                                                                    )
                                                                }
                                                            </BlockStack>
                                                        </IndexTable.Cell>
                                                    </IndexTable.Row>
                                                );
                                            })}
                                        </IndexTable>
                                    </Box>
                                </Card>
                            ) : (
                                <Card padding="0">
                                    <IndexTable
                                        itemCount={languages.length}
                                        headings={[
                                            { title: t("Localization.language") },
                                            { title: t("Localization.code"), alignment: "center" },
                                            { title: t("Localization.toggle"), alignment: "center" },
                                            { title: t("Localization.status"), alignment: "center" },
                                            { title: t("Localization.actions"), alignment: "end" },
                                        ]}
                                        selectable={false}
                                        padding={true}
                                    >
                                        {languages.map((lang, index) => {
                                            return (
                                                <IndexTable.Row id={lang.id} key={lang.id}>
                                                    <IndexTable.Cell>
                                                        <Text variant="bodyMd" fontWeight="bold" as="span">{lang.name}</Text>
                                                    </IndexTable.Cell>
                                                    <IndexTable.Cell><BlockStack inlineAlign="center">{lang.code}</BlockStack></IndexTable.Cell>
                                                    <IndexTable.Cell>
                                                        <BlockStack inlineAlign="center">
                                                            <Button variant="plain" onClick={() => toggleLanguage(index)}>
                                                                <span className={`switch__button ${lang.active ? 'selected' : ''}`}>
                                                                    <span className="active-dot"></span>
                                                                </span>
                                                            </Button>
                                                        </BlockStack>
                                                    </IndexTable.Cell>
                                                    <IndexTable.Cell>
                                                        <Box style={{ margin: 'auto', width: '60px' }}>
                                                            <BlockStack inlineAlign="center">
                                                                <Badge status={lang.active ? 'success' : 'default'} tone={lang.active ? 'success' : 'default'}>
                                                                    {lang.active ? t("Localization.active") : t("Localization.inactive")}
                                                                </Badge>
                                                            </BlockStack>
                                                        </Box>
                                                    </IndexTable.Cell>
                                                    <IndexTable.Cell>
                                                        {
                                                            lang.active ? <BlockStack inlineAlign="end">
                                                                <ButtonGroup>
                                                                    <Tooltip content={t("Settings.upsellList.editTooltip")}>
                                                                        <Button
                                                                            variant="tertiary"
                                                                            size="micro"
                                                                            icon={EditIcon}
                                                                            onClick={() => handleEditClick(lang.id, lang.code, lang.active, lang.name)}
                                                                        />
                                                                    </Tooltip>
                                                                </ButtonGroup>
                                                            </BlockStack> : <Box minHeight='45px'></Box>
                                                        }
                                                    </IndexTable.Cell>
                                                </IndexTable.Row>
                                            );
                                        })}
                                    </IndexTable>
                                </Card>
                            )
                        )
                    }
                </Box>
            </Page>
        </>
    );
}
