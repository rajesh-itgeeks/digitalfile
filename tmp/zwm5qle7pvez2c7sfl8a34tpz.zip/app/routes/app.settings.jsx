import React, {useState, useCallback, useEffect, Suspense} from 'react';
import { Page, BlockStack, Divider, Tabs, Card, Box } from "@shopify/polaris";
import { useAppBridge, Modal, TitleBar } from "@shopify/app-bridge-react";
import { useTranslation } from 'react-i18next';
import APIServicess from "./services/ApiServices";
import { useSelector, useDispatch } from "react-redux";
import { useSearchParams } from "@remix-run/react";
import "./assets/settings.css";
import Skeleton from './components/settings/Skeleton';
import { setPageId } from "./components/store/PageSlice";
const Timeframe = React.lazy(() => import("./components/settings/Timeframe"));
const Cancellations = React.lazy(() => import("./components/settings/Cancellations"));
const Footer = React.lazy(() => import("./components/common/Footer"));
const PaymentFailed = React.lazy(() => import("./components/common/PaymentFailed"));
const Upsell = React.lazy(() => import("./components/settings/Upsell"));
const Notifications = React.lazy(() => import("./components/settings/Notifications"));
const Invoice = React.lazy(() => import("./components/settings/Invoice"));
const Shipping = React.lazy(() => import("./components/settings/Shipping"));
const Discount = React.lazy(() => import("./components/settings/Discount"));
const PreviewModel = React.lazy(() => import("./components/settings/PreviewModel"));

export default function Settings() {
    // Initialize translation and app state
    const { t } = useTranslation();
    const [selectedTab, setSelectedTab] = useState('');
    const [searchParams, setSearchParams] = useSearchParams();
    const checkoutId = useSelector((state) => state.pageId);
    const planStatus = useSelector((state) => state.planStatus);
    const type = searchParams.get("type");
    const [saveBarActive, setSaveBarActive] = useState(false);
    const tabs = t('Settings.tabs', { returnObjects: true });
    const shopify = useAppBridge();
    const [shopName, setShopName] = useState(null);
    const [model, setModel] = useState(false);
    const APIServ = new APIServicess();
    const dispatch = useDispatch();

    useEffect(() => {
        if (shopify && shopify.config) {
            setShopName(shopify.config?.shop.replace(".myshopify.com", ""));
        }
    }, [checkoutId]);

    const handleTabChange = useCallback((selectedTabIndex) => {
        if (saveBarActive) {
            shopify.saveBar.leaveConfirmation(); 
        } else {
            setSelectedTab(selectedTabIndex);
            setSearchParams({ type: selectedTabIndex === 1 ? 'cancel' : selectedTabIndex === 2 ? 'upsell' : selectedTabIndex === 3 ? 'notification' : selectedTabIndex === 4 ? 'invoice' :  selectedTabIndex === 5 ? 'shipping' : selectedTabIndex === 6 ? 'discount' : 'editing' });
        }
    }, [saveBarActive, shopify]);

    // Set initial tab based on URL parameters
    useEffect(() => {
        if (type) {
            const settings = type === 'cancel' ? 1 : type === 'upsell' ? 2 : type === 'notification' ? 3 : type === 'invoice' ? 4 : type === 'shipping' ? 5 : type === 'discount' ? 6 : 0;
            setSelectedTab(settings);
        } else {
            setSelectedTab(0);
        }
    }, [type],[shopify]);

    const redirectEditor = async (type) => {
        if (saveBarActive) {
            shopify.saveBar.leaveConfirmation(); 
            return;
        }
        let ids = checkoutId;
        if(!checkoutId){
            const pagesdata = await APIServ.getShopPagePreviewing();
            if (pagesdata.status) {
                const idString = pagesdata.data[0]?.id;
                ids = idString?.match(/\d+$/)?.[0];
                if (ids) dispatch(setPageId(ids));
            }
        }

        if(type == 'orderStatus'){
            const orderStatusUrl = `https://admin.shopify.com/store/${shopName}/settings/checkout/editor/profiles/${ids}?page=order-status&context=apps`;
            window.open(orderStatusUrl, '_blank');
        } else{
            const thankyouPageUrl = `https://admin.shopify.com/store/${shopName}/settings/checkout/editor/profiles/${ids}?page=thank-you&context=apps`;
            window.open(thankyouPageUrl, '_blank');
        }
    }

    const handlePreviewWidgetModal = useCallback(() => {
        if (saveBarActive) {
            shopify.saveBar.leaveConfirmation(); 
            return;
        }
        shopify.modal.show('preview-widget');
        setModel(true);
    },[saveBarActive]);

    const onClose = useCallback(() => {
        setModel(false);
    },[]);
    
    return (
        <>
            <Page
                fullWidth
                title={t('Settings.page.title')}
                actionGroups={[
                    {
                        title: t('Settings.page.actionGroup.title'),
                        actions: [
                            {
                                content: t('Settings.page.actionGroup.orderStatus'),
                                accessibilityLabel: t('Settings.page.actionGroup.orderStatusLabel'),
                                onAction: () => redirectEditor('orderStatus'),
                      
                            },
                            {
                                content: t('Settings.page.actionGroup.thankYou'),
                                accessibilityLabel: t('Settings.page.actionGroup.thankYouLabel'),
                                onAction: () => redirectEditor('thankyou'),
                            },
                        ],
                    },
                ]}
                secondaryActions={[
                    {content: t('Settings.page.actionGroup.preview_widget'), onAction: () => handlePreviewWidgetModal()}
                ]}
            > 
                <Divider borderWidth="050" />
                <Box as="div" className="main-container tab-hide">
                    <BlockStack gap={400}>
                        {/* Payment failed banner */}
                        {
                            !planStatus &&  <Suspense fallback={<Skeleton />}><PaymentFailed /></Suspense>
                        }                        
                        {/* Payment failed banner */}

                        <Card padding="025">
                            <Tabs tabs={tabs} selected={selectedTab} onSelect={handleTabChange} />
                        </Card>

                        {/* Render the respective component based on the selected tab */}
                        {selectedTab === 0 && (
                            <Suspense fallback={<Skeleton />}>
                                <Box className="motion-appear-above-animation timeframe-tab">
                                    <Timeframe setSaveBarActive={setSaveBarActive} setSearchParams={setSearchParams} setSelectedTab={setSelectedTab}/>
                                </Box>
                            </Suspense>
                            
                        )}
                        {selectedTab === 1 && (
                            <Box className="motion-appear-above-animation">
                                <Suspense fallback={<Skeleton />}>
                                    <Cancellations setSaveBarActive={setSaveBarActive} />
                                </Suspense>
                            </Box>
                        )}
                        {selectedTab === 2 && (
                            <Box className="motion-appear-above-animation">
                                <Suspense fallback={<Skeleton />}>
                                    <Upsell setSaveBarActive={setSaveBarActive}/>
                                </Suspense>                                
                            </Box>
                        )}
                        {selectedTab === 3 && (
                            <Box className="motion-appear-above-animation">
                                <Suspense fallback={<Skeleton />}>
                                    <Notifications setSaveBarActive={setSaveBarActive}/>
                                </Suspense>                                
                            </Box>
                        )}
                        {selectedTab === 4 && (
                            <Box className="motion-appear-above-animation">
                                <Suspense fallback={<Skeleton />}>
                                    <Invoice setSaveBarActive={setSaveBarActive}/>
                                </Suspense>                                
                            </Box>
                        )}
                        {selectedTab === 5 && (
                            <Box className="motion-appear-above-animation">
                                <Suspense fallback={<Skeleton />}>
                                    <Shipping setSaveBarActive={setSaveBarActive} setSearchParams={setSearchParams} setSelectedTab={setSelectedTab} />
                                </Suspense>                                
                            </Box>
                        )}
                         {selectedTab === 6 && (
                            <Box className="motion-appear-above-animation">
                                <Suspense fallback={<Skeleton />}>
                                    <Discount setSaveBarActive={setSaveBarActive} />
                                </Suspense>                                
                            </Box>
                        )}

                        {/* Footer component */}
                        <Suspense fallback={<div></div>}>
                            <Footer />
                        </Suspense>                        
                    </BlockStack>
                </Box>

                {/* Preview widget*/}
                <Modal id="preview-widget" variant="max" onHide={onClose}>
                    {
                        model && <Suspense fallback={<div></div>}><PreviewModel /></Suspense>
                    }
                    <TitleBar title={t("Settings.previewWidget.title")}></TitleBar>
                </Modal>
            </Page>
        </>
    );
}
