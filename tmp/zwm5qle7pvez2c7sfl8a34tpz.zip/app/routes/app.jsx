import React, { Suspense } from "react";
import { Outlet, useLoaderData, useRouteError } from "@remix-run/react";
import { boundary } from "@shopify/shopify-app-remix/server";
import { AppProvider } from "@shopify/shopify-app-remix/react";
import { NavMenu } from "@shopify/app-bridge-react";
import polarisStyles from "@shopify/polaris/build/esm/styles.css?url";
import { authenticate } from "../shopify.server";
import { I18nextProvider } from "react-i18next";
import i18n from "../i18n";
import "./assets/style.css";
import { Provider } from "react-redux";
import store from "./components/store/store";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import StoreContext from "./context/StoreContext";
import { useSelector } from "react-redux";
import { Link } from "./components/common/Link";

export const links = () => [{ rel: "stylesheet", href: polarisStyles }];

export const loader = async ({ request }) => {
  await authenticate.admin(request);
  const url = new URL(request.url);
  const shop = url.searchParams.get("shop");
  return { apiKey: process.env.SHOPIFY_API_KEY || "", shop };
};

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5,
      cacheTime: 1000 * 60 * 10,
    },
  },
});

function InnerApp() {
  const { shop } = useLoaderData();
  const storeValue = useSelector((state) => state.store);

  return (
    <QueryClientProvider client={queryClient}>
      <StoreContext />
      <NavMenu>
        <Link to="/app" rel="home">Dashboard</Link>
        <Link to="/app/settings">Settings</Link>
        <Link to="/app/pricing">Pricing</Link>
        <Link to="/app/analytics">Analytics</Link>
        <Link to="/app/localization">Localization</Link>
        {["productionae.myshopify.com", "account-editor-flow.myshopify.com", "quickstart-1add1160.myshopify.com", "itgdev.myshopify.com", "itgeeks-test.myshopify.com"].includes(shop) && (
          <Link to="/app/admin">Admin</Link>
        )}
      </NavMenu>
      <Outlet />
    </QueryClientProvider>
  );
}

export default function App() {
  const { apiKey } = useLoaderData();

  return (
    <I18nextProvider i18n={i18n}>
      <AppProvider isEmbeddedApp apiKey={apiKey}>
        <Provider store={store}>
          <InnerApp />
        </Provider>
      </AppProvider>
    </I18nextProvider>
  );
}

export function ErrorBoundary() {
  return boundary.error(useRouteError());
}

export const headers = (headersArgs) => {
  return boundary.headers(headersArgs);
};