import React, { useState, useEffect, useCallback, Suspense } from 'react';
import { Page, BlockStack, Tabs, Card, Box, InlineGrid, InlineStack, Text, Banner, Button, Badge, Divider, Icon } from "@shopify/polaris";
import { useTranslation } from 'react-i18next';
import { XIcon, CheckIcon } from '@shopify/polaris-icons';
import APIServicess from "./services/ApiServices";
import { useDispatch, useSelector } from "react-redux";
import { setStoreValue } from "./components/store/StoreSlice";
import { setSetup } from "./components/store/SetupSlice";
import { setSettings } from "./components/store/SettingsSlice";
import { Modal, TitleBar, useAppBridge } from '@shopify/app-bridge-react';
import { json } from "@remix-run/node";
import { useLoaderData } from "@remix-run/react";
const CustomPlan = React.lazy(() => import("./components/pricing/CustomPlan"));
const Footer = React.lazy(() => import("./components/common/Footer"));
const PaymentFailed = React.lazy(() => import("./components/common/PaymentFailed"));

export const loader = async () => {
    return json({ appUrl: process.env.APP_HANDLE });
};
//Pricing
export default function Pricing() {
    const { appUrl } = useLoaderData();
    const { t } = useTranslation();
    const [selectedTab, setSelectedTab] = useState(0);
    const [current, setCurrent] = useState('essential');
    const [billingPeriod, setBillingPeriod] = useState('month');
    const [buttonLoading, setButtonLoading] = useState(false);
    const [buttonPlanLoading, setButtonPlanLoading] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [currentChargeId, setCurrentChargeId] = useState('');
    const [dismissBanner, setDismissBanner] = useState(true);
    const plans = t("Pricing.plan", { returnObjects: true });
    const APIServ = new APIServicess();
    const dispatch = useDispatch();
    const storeValue = useSelector((state) => state.store);
    const planStatus = useSelector((state) => state.planStatus);
    const shopify = useAppBridge();

    //Load all the primary state objects
    useEffect(() => {
        const isValidNumber = (chargeId) => {
            const id = Number(chargeId);
            return !isNaN(id) && id.toString().length === 11;
        };

        const handleChangeCartId = async () => {
            const params = new URLSearchParams(location.search);
            const chargeId = params.get('charge_id');

            if (chargeId && isValidNumber(chargeId)) {
                let data = { "chargeId": chargeId, "planName": "professional" };
                try {
                    const response = await APIServ.updateStoreData(data);
                    if (response?.status) {
                        const shopResonse = await APIServ.getStoreData();
                        if (shopResonse.status) {
                            dispatch(setStoreValue(shopResonse.result));
                            const url = new URL(window.location.href);
                            url.searchParams.delete('charge_id');
                            window.history.replaceState(null, '', url);
                            handleSetupGuidePlan('upgrade');
                        }
                    }
                } catch (error) {
                    console.error("Error updating store data:", error);
                }
            } else {
                setCurrent(storeValue?.planName);
                setBillingPeriod(storeValue?.interval == 'ANNUAL' ? 'year' : 'month');
                setSelectedTab(storeValue?.interval == 'ANNUAL' ? 1 : 0);
                setCurrentChargeId(storeValue?.chargeId);
            }
        };
        handleChangeCartId();
    }, [storeValue, setStoreValue]);


    //Hnadle Tab Change
    const handleTabChange = useCallback(
        (selectedTabIndex) => setSelectedTab(selectedTabIndex), []
    );

    //Tab Settings
    const tabs = [
        {
            id: 'month',
            content: t("Free"),
        },
        // {
        //     id: 'yearly',
        //     content: t("Pricing.btn2")
        // },
        {
            id: 'custom',
            content: t("Pricing.btn3")
        }
    ];

    //Handle plan selection
    const handlePlanChange = useCallback(async (planName, interval, id) => {
        try {
            if (planName === 'essential') {
                shopify.modal.show('downgrade-modal')
            } else {
                if (id) {
                    const data = {
                        planId: `gid://shopify/AppSubscription/${id}`,
                        enableFreePlan: false
                    };
                    await APIServ.planUnSubscribe(data);
                }
                setButtonPlanLoading(planName);
                setButtonLoading(true);
                const shopifyConfig = window?.shopify?.config;
                let shop = shopifyConfig.shop;
                const shopName = shop.replace(".myshopify.com", "");
                const data = {
                    plan: planName,
                    amount: interval === 'month' ? 39 : 421,
                    currency: "USD",
                    interval: interval === 'month' ? "EVERY_30_DAYS" : "ANNUAL",
                    trial: true,
                    trialDays: 30,
                    returnUrl: `https://admin.shopify.com/store/${shopName}/apps/${appUrl}/app/pricing`
                };
                const resp = await APIServ.planSubscribe(data);
                if (resp?.status) {
                    const confirmationUrl = resp?.result?.data?.appSubscriptionCreate?.confirmationUrl;
                    if (confirmationUrl) {
                        window.open(confirmationUrl, '_parent');
                    } else {
                        console.error('No confirmation URL received');
                    }
                } else {
                    console.error('Failed to activate the plan');
                }
            }
        } catch (e) {
            console.log(e);
        }
    }, []);

    //Handle plan downgrade
    const downgradeSubscriptionPlan = useCallback(async (id) => {
        try {
            setIsLoading(true);
            const data = {
                planId: `gid://shopify/AppSubscription/${id}`,
                enableFreePlan: true
            };
            setButtonPlanLoading('essential');
            const planUnSubscribe = await APIServ.planUnSubscribe(data);
            if (planUnSubscribe.status) {
                const shopResonse = await APIServ.getStoreData();
                const settings = await APIServ.getShopSettings();
                if (shopResonse.status) {
                    dispatch(setStoreValue(shopResonse.result));
                    setCurrent('essential');
                    setBillingPeriod('month');
                    setSelectedTab(0);
                    setCurrentChargeId('');
                    shopify.modal.hide('downgrade-modal')
                    handleSetupGuidePlan('downgrade');
                }

                if(settings.status){
                    dispatch(setSettings(settings.result));
                }
            }
        } catch (error) {
            console.log(error);
        }
    }, []);


    //Hnadle Tab Change
    const handleSetupGuidePlan = useCallback(async (type) => {
        try {
            let data = { plan: type == 'downgrade' ? false : true };
            let response = await APIServ.setupGuideFetch(data);
            dispatch(setSetup(response.result));
        } catch (error) {
            console.log(error);
        }
    }, []);


    return (
        <>
            <Page title={t("Pricing.pageTitle")} fullWidth>
                <Divider borderWidth="050" />                
                <Box as="div" className="main-container">
                    <BlockStack gap={400}>
                        {/* Payment failed banner */}
                        {
                            !planStatus &&  <Suspense fallback={<div></div>}><PaymentFailed /></Suspense>
                        }                        
                        {/* Payment failed banner */}

                        {/* Offer banner */}
                        {/* {
                            (billingPeriod !== 'year') && (
                                dismissBanner && <Box as={'div'}>
                                    <Banner tone="info" onDismiss={() => setDismissBanner(false)}><span dangerouslySetInnerHTML={{ __html: t("Pricing.bannerText") }}></span></Banner>
                                </Box>
                            )
                        } */}
                        {/* Offer banner */}                        

                        {/* Tabs */}
                        <Tabs tabs={tabs} selected={selectedTab} onSelect={handleTabChange} />
                        {/* Monthly plan and yearly plan tab content*/}
                        <Box as={'div'}>
                            {
                                (selectedTab == 0 ) ? <InlineGrid gap="400" columns={{ "xs": 1, "lg": 1 }}>
                                    {
                                        plans
                                        .filter((_, index) => index === 0)
                                        .map((plan, index) => (
                                            <Box as={'div'} className="motion-appear-above-animation" key={index}>
                                                <Box className="only-free-plan">
                                                <Card>
                                                    <BlockStack gap={400}>
                                                        <InlineStack wrap={false} blockAlign="center" align="space-between">
                                                            <Text variant="headingLg" as="h5" fontWeight="regular">{plan.planname}</Text>
                                                            {
                                                                index === 1 && <Badge tone="info" align="space-between">
                                                                    {index === 1 && (selectedTab === 0 ? t("Pricing.savemonth") : t("Pricing.saveyear"))}
                                                                </Badge>
                                                            }
                                                        </InlineStack>
                                                        <BlockStack gap={300}>
                                                            <InlineStack wrap={false} blockAlign="baseline">
                                                                <Text variant="headingXl" as="span">
                                                                    {
                                                                        index == 1 && "$"
                                                                    }
                                                                    {index === 0 ? t("Pricing.free") : selectedTab === 1 ? '421' : '39'}
                                                                </Text>
                                                                {
                                                                    index == 1 && <>
                                                                        <Text variant="headingLg" as="span">&nbsp;/</Text>
                                                                        <Text variant="headingSm" as="span" fontWeight="regular">
                                                                            {selectedTab === 0 ? t("Pricing.month") : t("Pricing.year")}
                                                                        </Text>
                                                                    </>
                                                                }

                                                            </InlineStack>
                                                            <Button
                                                                variant="primary"
                                                                fullWidth
                                                                loading={
                                                                    (buttonPlanLoading === plan.key) && (
                                                                        (selectedTab == 0) ? buttonLoading
                                                                            : ((selectedTab == 1) ? buttonLoading
                                                                                : false)
                                                                    )
                                                                }
                                                                disabled={
                                                                    index === 0 ? (
                                                                        current === 'essential' ? true : false
                                                                    ) : (
                                                                        current === 'professional' && (
                                                                            ((billingPeriod === 'month' && selectedTab === 0) ||
                                                                                (billingPeriod === 'year' && selectedTab === 1)) ? true : false
                                                                        )
                                                                    )
                                                                }
                                                                onClick={() => handlePlanChange(plan.key, selectedTab === 0 ? 'month' : 'year', currentChargeId)}
                                                            >
                                                                {
                                                                    index === 0
                                                                        ? (current === plan.key ? t("Pricing.current") : t("Pricing.downgrad"))
                                                                        : (current === plan.key && billingPeriod === (selectedTab === 0 ? 'month' : 'year')
                                                                            ? t("Pricing.current")
                                                                            : t("Pricing.freetrial"))
                                                                }
                                                            </Button>
                                                        </BlockStack>
                                                        <BlockStack gap="400">
                                                            <Divider />
                                                        </BlockStack>
                                                        <BlockStack gap="300">
                                                            <Text variant="headingSm" as="span">{t("Pricing.features")}</Text>
                                                            <BlockStack gap={300}>
                                                                {
                                                                    plan.features.map((feature, i) => (
                                                                        <InlineStack wrap={false} blockAlign="center" align="start" gap="400" key={i}>
                                                                            <Box as={'span'}>
                                                                                <Icon
                                                                                    source={feature.available == 'yes' ? CheckIcon : XIcon}
                                                                                    tone="base"
                                                                                />
                                                                            </Box>
                                                                            <Text key={i} variant="headingSm" as="span" fontWeight="regular">{feature.text}</Text>
                                                                        </InlineStack>
                                                                    ))
                                                                }
                                                            </BlockStack>
                                                        </BlockStack>
                                                    </BlockStack>
                                                </Card>
                                                </Box>
                                            </Box>
                                        ))
                                    }
                                </InlineGrid> : <Suspense fallback={<div></div>}><CustomPlan /></Suspense>
                            }
                        </Box>

                        {/* Downgrade model */}
                        <Modal id="downgrade-modal">
                            <Box padding="200">
                                <p>{t("Pricing.model.description")}</p>
                            </Box>
                            <TitleBar title={t("Pricing.model.title")}>
                                <button variant="primary" onClick={() => downgradeSubscriptionPlan(currentChargeId)} {...(isLoading ? { loading: "" } : {})}>{t("Pricing.model.yes")}</button>
                                <button onClick={() => shopify.modal.hide('downgrade-modal')}>{t("Pricing.model.no")}</button>
                            </TitleBar>
                        </Modal>

                        {/* Footer */}
                        <Suspense fallback={<div></div>}><Footer /></Suspense>                       
                        
                    </BlockStack>
                </Box>
            </Page>
        </>
    );
}