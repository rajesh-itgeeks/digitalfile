import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { login } from "../components/store/AuthSlice.jsx";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import "./login.css";
import OverlayLoader from "../adminComponents/utils/Loaderr/overlayLoader/route.jsx";

const LoginForm = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loader, setLoader] = useState(false);
  const dispatch = useDispatch();

  const validateEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoader(true);

    if (!email || !password) {
      toast.error("Please fill in all fields");
      setLoader(false);
      return;
    }

    if (!validateEmail(email)) {
      toast.error("Please enter a valid email address");
      setLoader(false);
      return;
    }

    try {
      const response = await fetch("/api/admin/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });

      const data = await response.json();
      setLoader(false);

      if (data.status) {
        dispatch(login());
        toast.success("Login successful!");
      } else {
        toast.error(data.message || "Login failed");
      }
    } catch (error) {
      console.error("Fetch Error:", error);
      toast.error("Server error, try again.");
      setLoader(false);
    }
  };

  return (
    <div className="login-body">
      <div className="container">
        <div className="card">
          <h2>Login</h2>
          <form onSubmit={handleSubmit}>
            <input
              type="text"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <button type="submit">{loader ? "Processing..." : "Login"}</button>
          </form>
        </div>
      </div>

      <ToastContainer position="top-center" autoClose={3000} hideProgressBar />
      {loader && <OverlayLoader />}
    </div>
  );
};

export default LoginForm;
