// import { useLocation, useNavigate } from '@remix-run/react';
// import React, { useEffect, useRef, useState } from 'react';
// import Loader from "./adminComponents/utils/Loaderr/CommonLoader/Loader";
// // import './adminComponents/downloadinvoice.css';

// function DownloadInvoice() {
//   // const hiddenDivRef = useRef(null);

//   const location = useLocation();
//   const { htmlContent } = location.state || {};
//   const [downloading, setDownloading] = useState(true);
//   const navigate = useNavigate();
//   useEffect(() => {
// //     const htmlContent = `
// // <body style="margin: 0; padding: 0; font-family: 'Inter', sans-serif;">
// //   <div style="width: 100%; max-width: 600px; margin: 0 auto;">
// //     <table class="email" width="100%" border="0" cellspacing="0" cellpadding="0" style="border-radius: 8px;">
// //       <tr>
// //         <td>
// //           <table border="0" style="width: 100%; padding: 16px;" cellspacing="0" cellpadding="0">
// //             <tbody>
// //               <tr>
// //                 <td>
// //                   <table border="0" cellspacing="0" cellpadding="0" style="width: 100%;">
// //                     <tbody>
// //                       <tr>
// //                         <td>
// //                           <div><img src="" alt="img" width="133" /></div>
// //                         </td>
// //                         <td>
// //                           <p style="text-align: right; margin: 0; font-size: 14px; line-height: 20px; color: #777777;">Receipt / Tax Invoice ODID#1156</p>
// //                           <p style="text-align: right; margin: 0; font-size: 14px; line-height: 20px; color: #777777;">Created 2025-04-08T01:28:32-04:00</p>
// //                           <p style="text-align: right; margin: 0; font-size: 14px; line-height: 20px; color: #777777;">Last Updated 2025-04-08T01:29:16-04:00</p>
// //                         </td>
// //                       </tr>
// //                     </tbody>
// //                   </table>
// //                 </td>
// //               </tr>

// //               <tr>
// //                 <td>
// //                   <table border="0" cellspacing="0" cellpadding="0" style="width: 100%; text-align: left; margin-top: 24px;">
// //                     <tbody>
// //                       <tr>
// //                         <th style="width: 500px; color: #303030; font-size: 13px;">Shipping address</th>
// //                         <th style="width: 500px; color: #303030; font-size: 13px;">Customer</th>
// //                         <th align="right" style="width: 500px; color: #303030; font-size: 13px;">Order</th>
// //                       </tr>
// //                       <tr style="width: 100%;">
// //                         <td>
// //                           <div style="color: #777777; font-size: 13px; line-height: 22px; font-weight: 500; margin-top: 13px;">
// //                             <p style="margin: 0;">1250 Hospital Shivaji Nagar</p>
// //                             <p style="margin: 0;">Bhopal</p>
// //                             <p style="margin: 0;">462016</p>
// //                             <p style="margin: 0;">India</p>
// //                           </div>
// //                         </td>
// //                         <td>
// //                           <div style="color: #777777; font-size: 13px; line-height: 22px; font-weight: 500; margin-top: 13px;">
// //                             <!-- Customer details can be filled here -->
// //                           </div>
// //                         </td>
// //                         <td align="right" style="vertical-align: top;">
// //                           <div style="color: #777777; font-size: 13px; line-height: 22px; font-weight: 500; margin-top: 13px;">
// //                             <p style="margin: 0;">paid</p>
// //                             <p style="margin: 0;">mayurirajput@itgeeks.com</p>
// //                           </div>
// //                         </td>
// //                       </tr>
// //                     </tbody>
// //                   </table>
// //                 </td>
// //               </tr>

// //               <tr>
// //                 <td>
// //                   <table border="0" cellspacing="0" cellpadding="0" style="width: 100%; margin-top: 24px; border: 1px solid #EBEBEB;">
// //                     <tbody>
// //                       <tr>
// //                         <th align="left" style="width: 25%; padding: 12px; background-color: #F9FAFB; font-size: 13px; color: #303030;">Items</th>
// //                         <th align="left" style="width: 25%; background-color: #F9FAFB; font-size: 13px; color: #303030;">Price</th>
// //                         <th align="left" style="width: 25%; background-color: #F9FAFB; font-size: 13px; color: #303030;">Qty</th>
// //                         <th align="left" style="width: 25%; background-color: #F9FAFB; font-size: 13px; color: #303030;">Total</th>
// //                       </tr>
// //                       <tr>
// //                         <td style="width: 25%; padding: 16px; color: #777777; font-size: 13px; line-height: 22px;">
// //                           <strong>The Multi-location Snowboard</strong><br>/ 32SKU:
// //                         </td>
// //                         <td style="width: 25%; color: #777777; font-size: 13px;">729.95 INR</td>
// //                         <td style="width: 25%; color: #777777; font-size: 13px;">1</td>
// //                         <td style="width: 25%; padding-right: 16px; color: #777777; font-size: 13px;">729.95 INR</td>
// //                       </tr>
// //                     </tbody>
// //                   </table>
// //                 </td>
// //               </tr>

// //               <tr>
// //                 <td>
// //                   <table align="right" border="0" cellspacing="0" cellpadding="0" style="width: 46%; margin-top: 20px;">
// //                     <tbody>
// //                       <tr>
// //                         <td style="font-size: 13px; color: #777777; line-height: 16px; padding-top: 16px;">Order discount</td>
// //                         <td style="text-align: right; color: #777777; font-size: 13px; padding-top: 16px;">-500.00 INR</td>
// //                       </tr>
// //                       <tr>
// //                         <td style="font-size: 13px; color: #777777; line-height: 16px; padding-top: 16px;">Subtotal</td>
// //                         <td style="text-align: right; color: #777777; font-size: 13px; padding-top: 16px;">229.95 INR</td>
// //                       </tr>
// //                       <tr>
// //                         <td style="font-size: 13px; color: #777777; line-height: 16px; padding-top: 16px;">Shipping</td>
// //                         <td style="text-align: right; color: #777777; font-size: 13px; padding-top: 16px;">0.00 INR</td>
// //                       </tr>
// //                       <tr>
// //                         <td style="font-size: 13px; color: #777777; line-height: 16px; padding-top: 16px;">VAT</td>
// //                         <td style="text-align: right; color: #777777; font-size: 13px; padding-top: 16px;">41.39 INR</td>
// //                       </tr>
// //                       <tr>
// //                         <td colspan="2" style="padding-top: 16px; font-size: 13px; color: #777777; line-height: 22px;">Los Angeles <br>County Tax 0.25%</td>
// //                       </tr>
// //                       <tr>
// //                         <td colspan="2" style="padding-top: 16px; font-size: 13px; color: #777777; line-height: 22px;">Los Angeles <br>County District Tax <br>Sp 2.25%</td>
// //                       </tr>
// //                       <tr>
// //                         <td colspan="2" style="padding-top: 16px; font-size: 13px; color: #777777; line-height: 22px;">Los Angeles Co <br>Local Tax Sl 1%</td>
// //                       </tr>
// //                       <tr>
// //                         <td colspan="2" style="padding-top: 16px; font-size: 13px; color: #777777; line-height: 22px;">California State <br>Tax 6%</td>
// //                       </tr>
// //                       <tr>
// //                         <td style="border-bottom: 1px solid #303030; color: #303030; font-size: 13px; padding-top: 16px; padding-bottom: 20px;">Total</td>
// //                         <td style="border-bottom: 1px solid #303030; color: #303030; font-size: 13px; padding-top: 16px; padding-bottom: 20px;">271.34 INR</td>
// //                       </tr>
// //                     </tbody>
// //                   </table>
// //                 </td>
// //               </tr>

// //               <tr>
// //                 <td>
// //                   <table border="0" cellspacing="0" cellpadding="0" style="width: 100%; margin-top: 24px; text-align: center;">
// //                     <tbody>
// //                       <tr>
// //                         <td>
// //                           <p style="color:#8A8A8A; font-size: 13px; line-height: 22px; margin: 0;">Thank you for shopping with us!</p>
// //                           <p style="margin-top: 24px; margin-bottom: 0;">
// //                             <a href="mailto:mayurirajput@itgeeks.com" style="color: #1990C6; font-size: 13px; text-decoration: none;">mayurirajput@itgeeks.com</a>
// //                           </p>
// //                         </td>
// //                       </tr>
// //                     </tbody>
// //                   </table>
// //                 </td>
// //               </tr>

// //             </tbody>
// //           </table>
// //         </td>
// //       </tr>
// //     </table>
// //   </div>
// // </body>
// // `;
//     const tempDiv = document.createElement('div');
//     tempDiv.innerHTML = htmlContent;



//     const generatePDF = async () => {
//       const html2pdf = await import('html2pdf.js');
//       const opt = {
//         margin: 0.2,
//         filename: 'invoice.pdf',
//         image: { type: 'jpeg', quality: 0.98 },
//         html2canvas: { scale: 2 },
//         jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' },
//       };

//       requestAnimationFrame(() => {
//         html2pdf.default()
//           .set(opt)
//           .from(tempDiv)
//           .save()
//           .then(() => {
//             setDownloading(false);
//             setTimeout(() => {
//               // window.opener = null;
//               // window.open("", "_self");
//               window.close()

//               navigate('/check');
//               // window.close();
//               // window.location.href = '/app/pricing';

//             }, 1000);
//           });
//       });
//     };

//     generatePDF();
//   }, []);

//   return (
//     <div className='invoice-container'>

//       <h4 style={{textAlign:"center"}}>{downloading ? 'Invoice download in progress...' : 'Download complete'}</h4>
//       {downloading && <Loader/>}

//     </div>
//   );
// }

// export default DownloadInvoice;
import { useEffect, useState, useRef } from "react";
import Loader from "./adminComponents/utils/Loaderr/CommonLoader/Loader";
import { useLocation, useNavigate } from "@remix-run/react";

const DownloadInvoice = () => {
  const [downloading, setDownloading] = useState(true);
  const [showError, setShowError] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const hasDownloaded = useRef(false);
  const location = useLocation();
  const navigate = useNavigate();

  const queryParams = new URLSearchParams(location.search);
  const orderId = queryParams.get("orderId");
  const shop = queryParams.get("shop");

  const fetchData = async () => {
    try {
      const response = await fetch(`/api/invoice/download-invoice?shop=${shop}&orderId=${orderId}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({}),
      });

      const json = await response.json();

      if (!response.ok || !json.status) {
        setShowError(true);
        setErrorMessage(json?.message || "Something went wrong while generating the invoice.");
        setDownloading(false);
        return null;
      }
      fetch(json?.result.logoUrl, {
        mode: "cors"
      }).then(res => console.log("✅ CORS OK")).catch(err => console.error("❌ CORS ERROR", err));


      return json?.result?.htmlContent;
    } catch (error) {
      console.error("Fetch error:", error);
      setShowError(true);
      setErrorMessage("Internal error while downloading invoice.");
      setDownloading(false);
      return null;
    }
  };

  useEffect(() => {
    const downloadPDF = async () => {
      if (!orderId || !shop || hasDownloaded.current) return;
      hasDownloaded.current = true;

      const htmlContent = await fetchData();
      if (!htmlContent) return;

      const html2pdf = (await import("html2pdf.js")).default;
      const tempDiv = document.createElement("div");
      tempDiv.innerHTML = htmlContent;

      const opt = {
        margin: 0.2,
        filename: "invoice.pdf",
        image: { type: "jpeg", quality: 0.98 },
        html2canvas: {
          scale: 2,
          useCORS: true,
          allowTaint: true,
        },
        jsPDF: { unit: "in", format: "letter", orientation: "portrait" },
      };


      html2pdf()
        .set(opt)
        .from(tempDiv)
        .save()
        .then(() => {
          setDownloading(false);
          //window.close();
          navigate(-1);
        });
    };

    downloadPDF();
  }, [orderId, shop]);

  return (
    <div style={{ textAlign: "center", marginTop: "100px" }}>
      <h4>
        {showError
          ? "Failed to download invoice"
          : downloading
            ? "Invoice download in progress..."
            : "Download complete"}
      </h4>
      {downloading && <Loader />}
      {showError && (
        <p style={{ color: "red", marginTop: "20px" }}>{errorMessage}</p>
      )}
    </div>
  );
};

export default DownloadInvoice;
