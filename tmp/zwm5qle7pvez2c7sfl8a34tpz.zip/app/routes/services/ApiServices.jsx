
export default class APIServices {
    //Get shop info and create
    async getStoreData() {
        const response = await fetch(`/api/store/info`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            }
        });
        const result = await response.json();
        return result;
    }

    //Update shop info
    async updateStoreData(data) {
        const response = await fetch(`/api/store/update`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data),
        });
        const result = await response.json();
        return result;
    }

    //Get shop PagePreviewing
    async getShopPagePreviewing() {
        const response = await fetch(`/graphqlfrontend/pagepreview`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
            }, 
            body: JSON.stringify(),
        });
        const result = await response.json();
        return result;
    }

    //Plan Subscribe
    async planSubscribe(data) {
        const response = await fetch(`/api/plan/subscribe`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            }, 
            body: JSON.stringify(data),
        });
        const result = await response.json();
        return result;
    }

    //Plan un subscribe
    async planUnSubscribe(data) {
        const response = await fetch(`/api/plan/un-subscribe`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            }, 
            body: JSON.stringify(data),
        });
        const result = await response.json();
        return result;
    }

    // Get shop settings
    async getShopSettings(data) {
        const response = await fetch(`/api/store/settings`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data),
        });
        const result = await response.json();
        return result;
    }

    // Update shop settings
    async UpdateShopSettings(data) {
        const response = await fetch(`/api/store/settings`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data),
        });
        const result = await response.json();
        return result;
    }

    // Collection get
    async getCollections() {
        const response = await fetch(`/graphqlfrontend/collections`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(),
        });
        const result = await response.json();
        return result;
    }

    // Segment get
    async getSegment() {
        const response = await fetch(`/graphqlfrontend/segment`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(),
        });
        const result = await response.json();
        return result;
    }

    // Handle setup guide
    async setupGuideFetch(data) {
        const response = await fetch(`/api/dashboard/setup-guide`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data),
        });
        const result = await response.json();
        return result;
    }

    //Handle custom plan request
    async appyForCustomPlan(data) {
        const response = await fetch(`/api/support/custom-plan`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data),
        });
        const result = await response.json();
        return result;
    }

    // Get upsellList
    async getUpsellList(requestBody) {
        const response = await fetch(`/api/up-sell/list`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(requestBody),
        });
        const result = await response.json();
        return result;
    }
    
    //Delete Upsell list by id
    async upsellItemDelete(id) {
        const response = await fetch(`/api/up-sell/delete?id=${id}`, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
            }
        }); 
        const result = await response.json();
        return result;
    }    

    //Update Upsell list by id
    async upsellListUpdate(data) {
        const response = await fetch(`/api/up-sell/active?id=${data.id}`, {
            method: 'PUT',
            body: JSON.stringify({type: data.type}),
            headers: {
                'Content-Type': 'application/json',
            }
        }); 
        const result = await response.json();
        return result;
    }

    // Create a new upsell Item
    async createUpsellRecord(data) {
        const response = await fetch(`/api/up-sell/create`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data),
        });
        const result = await response.json();
        return result;
    }

    // // Upsell get by id
    async getUpsellByid(id) {
        const response = await fetch(`/api/up-sell/details?id=${id}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
            }
        });
        const result = await response.json();
        return result;
    }

    //Update Upsell By id
    async upsellUpdateById(id, data) {
        const response = await fetch(`/api/up-sell/update?id=${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data), 
        });
        const result = await response.json();
        return result; 
    }

    // Get publication online store id
    async getPublication() {
        const response = await fetch(`/graphqlfrontend/publication`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(),
        });
        const result = await response.json();
        return result;
    }

    //Get current shop data
    async getCurrentStoreInfo() {
        const response = await fetch(`/graphqlfrontend/store`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
            }, 
            body: JSON.stringify(),
        });
        const result = await response.json();
        return result;
    }

    //Get current shop data
    async getStatistics(data) {
        const response = await fetch(`/api/analytics/dashboard-status`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            }, 
            body: JSON.stringify(data), 
        });
        const result = await response.json();
        return result;
    }

    //Get plan status
    async getPlanStatus() {
        const response = await fetch(`/api/plan/status`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            }, 
        });
        const result = await response.json();
        return result;
    }

    //Get plan status
    async getNotification() {
        const response = await fetch(`/api/notifications/details`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
            }, 
        });
        const result = await response.json();
        return result;
    }

    //Update notification settings
    async saveNotification(data) {
        const response = await fetch(`/api/notifications/save`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            }, 
            body: JSON.stringify(data), 
        });
        const result = await response.json();
        return result;
    }

    //Get template detail
    async getTemplateDetails(data) {
        const response = await fetch(`/api/notifications/template-details`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            }, 
            body: JSON.stringify(data), 
        });
        const result = await response.json();
        return result;
    }

    //Get template preview
    async getTemplatePreview(data) {
        const response = await fetch(`/api/notifications/template-preview`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            }, 
            body: JSON.stringify(data), 
        });
        const result = await response.json();
        return result;
    }

    //Get template preview
    async updateEmailTemplate(data) {
        const response = await fetch(`/api/notifications/type`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            }, 
            body: JSON.stringify(data), 
        });
        const result = await response.json();
        return result;
    }

    //Revert defult email template
    async revertEmailTemplate(data) {
        const response = await fetch(`/api/notifications/default`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            }, 
            body: JSON.stringify(data), 
        });
        const result = await response.json();
        return result;
    }

    //Verify email
    async verifyEmail(data) {
        const response = await fetch(`/api/notifications/send-email-verify`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            }, 
            body: JSON.stringify(data), 
        });
        const result = await response.json();
        return result;
    }

    //Verify email
    async checkVerified(data) {
        const response = await fetch(`/api/notifications/check-verify-email`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            }, 
            body: JSON.stringify(data), 
        });
        const result = await response.json();
        return result;
    }

     //Invoice save and get
     async saveAndGetInvoices(data) {
        const response = await fetch(`/api/invoice/save`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            }, 
            body: JSON.stringify(data), 
        });
        const result = await response.json();
        return result;
    }

    //Get invoices details
    async getInvoiceDetails() {
        const response = await fetch(`/api/invoice/details`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
            }
        });
        const result = await response.json();
        return result;
    }

    //Get invoices details
    async uploadImage(data) {
        const response = await fetch(`/api/image/upload`, {
            method: 'POST',
            body: data, 
            redirect: "follow"
        });
        const result = await response.json();
        return result;
    }

    //Revert invoices details
    async getDefaultTemplate(data) {
        const response = await fetch(`/api/invoice/default-template`, {
            method: 'GET',
            body: data, 
            redirect: "follow"
        });
        const result = await response.json();
        return result;
    }

    //Get and update shipping settings
    async getShopShipping(data) {
        const response = await fetch(`/api/invoice/default-template`, {
            method: 'GET',
            body: data, 
            redirect: "follow"
        });
        const result = await response.json();
        return result;
    }

    //Get analytics screen api
    async getAnalyticsData(data) {
        const response = await fetch(`/api/analytics/dashboard-data`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data)
        });
        const result = await response.json();
        return result;
    }
    // get default language
    async getDefaultLanguage() {
        const response = await fetch(`/api/language/list`, {
            method: 'GET',
            redirect: "follow"
        });
        const result = await response.json();
        return result;
    }
    // specific language json
    async getSpecificLanguageDetails(data) {
        const response = await fetch(`/api/language/details`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data)
        });
        const result = await response.json();
        return result;
    }
    // save language json
    async addLanguageJson(data) {
        const response = await fetch(`/api/language/save`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data)
        });
        const result = await response.json();
        return result;
    }
}
// get default language
   