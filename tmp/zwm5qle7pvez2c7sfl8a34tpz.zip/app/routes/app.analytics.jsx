import React, { lazy, Suspense , useState, useEffect, useMemo, useRef } from "react";

import { Page, Layout, BlockStack, Box, Divider, Spinner } from "@shopify/polaris";

import APIServicess from "./services/ApiServices";
import { useDispatch, useSelector } from "react-redux";
import { setStoreValue } from "./components/store/StoreSlice";
import { useMutation } from "@tanstack/react-query";
import { setPageId } from "./components/store/PageSlice";
import Skeleton from "./components/index/Skeleton";
import { useTranslation } from "react-i18next";

import "./assets/analytics.css";

import Footer from "./components/common/Footer";
import Statistic from "./components/analytics/Statistic";

export default function Analytics() {
    const { t } = useTranslation();
    const storeValue = useSelector((state) => state.store);
    const planStatus = useSelector((state) => state.planStatus);
    const pageId = useSelector((state) => state.pageId);
    const dispatch = useDispatch();
    const [shopName, setShopName] = useState(null);

    // Properly memoize API service instance
    const APIServ = useMemo(() => new APIServicess(), []);
    const apiCalledRef = useRef(false);

    // Fetch store data mutation
    const fetchStoreData = useMutation({
        mutationFn: async () => {
            const response = await APIServ.getStoreData();
            return response;
        },
        onSuccess: async (response) => {
            if (response?.status) {
                dispatch(setStoreValue(response.result));
                setShopName(response?.result?.domain?.replace(".myshopify.com", ""));
            }
        },
        onError: (error) => {
            console.error("❌ Error fetching store data:", error);
        }
    });

    // Main API call effect - runs only once
    useEffect(() => {
        if (!storeValue && !apiCalledRef.current) {
            apiCalledRef.current = true;
            fetchStoreData.mutate();
        } else if (storeValue) {
            setShopName(storeValue?.domain?.replace(".myshopify.com", ""));
        }
    }, [storeValue, fetchStoreData]);


    const redirectEditor = async (type) => {
        try {
            let checkoutId = pageId;

            if (!pageId) {
                const pagesdata = await APIServ.getShopPagePreviewing();
                if (pagesdata.status) {
                    const idString = pagesdata.data[0]?.id;
                    checkoutId = idString?.match(/\d+$/)?.[0];
                    if (checkoutId) dispatch(setPageId(checkoutId));
                }
            }

            const pageType = type === 'orderStatus' ? 'order-status' : 'thank-you';
            const url = `https://admin.shopify.com/store/${shopName}/settings/checkout/editor/profiles/${checkoutId}?page=${pageType}&context=apps`;

            window.open(url, '_blank');
        } catch (error) {
            console.error("Redirect error:", error);
        }
    };


    return (
        <Page
            title={t("Analytics.pageTitle")}
            fullWidth
            actionGroups={
                [
                    {
                        title: t('Settings.page.actionGroup.title'),
                        actions: [
                            {
                                content: t('Settings.page.actionGroup.orderStatus'),
                                accessibilityLabel: t('Settings.page.actionGroup.orderStatusLabel'),
                                onAction: () => redirectEditor('orderStatus'),
                            },
                            {
                                content: t('Settings.page.actionGroup.thankYou'),
                                accessibilityLabel: t('Settings.page.actionGroup.thankYouLabel'),
                                onAction: () => redirectEditor('thankyou'),
                            },
                        ],
                    },
                ]
            }
        >
            <Divider borderWidth="050" />
            <Layout gap="200px">
                <Layout.Section>
                    <Box as="div" className="main-container-full">
                        <BlockStack gap="400">
                            <Statistic storeValue={storeValue} planStatus={planStatus}/>                                
                            <Footer />
                        </BlockStack>
                    </Box>
                </Layout.Section>
            </Layout>
        </Page>
    )
}

