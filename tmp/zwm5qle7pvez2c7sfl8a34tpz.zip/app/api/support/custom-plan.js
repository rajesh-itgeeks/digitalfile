import { sendResponse } from "../server/utils/sendResponse.js";
import { ErrorMessage, SuccessMessage } from "../server/constants/messages.js";
import { statusCode } from "../server/constants/statusCodes.js";
import { authenticateUser } from "../server/middlewares/auth.middleware.server.js";
import * as supportService from "../server/services/support/index.server";
import * as supportValidation from "../server/validations/support.validation.js";
// Loader function for GET requests.
export const loader = async (request) => {
    const result = "result"
    return sendResponse(statusCode.OK, true, SuccessMessage.FETCHED, result);
};

// Action function for handling POST , PUT and DELETE requests.
export const action = async ({ request }) => {
    const method = request.method;
    // Handle POST requests
    if (method === "POST") {
        try {
            // Middleware to authenticate user 
            const isAuthenticated = await authenticateUser(request);
            console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
            // Return if request is not authenticated
            if (!isAuthenticated.status) {
                return sendResponse(statusCode.BAD_REQUEST, false, isAuthenticated.message);
            }
            const details = await request.json();
            // Validation
            const isValidated = await supportValidation.customSupport(details)
            if (isValidated.status === false) {
                return sendResponse(statusCode.BAD_REQUEST, false, isValidated.message);
            }

            // Call service to create partner
            const result = await supportService.customPlanSupport(details);

            // Handle service response
            if (!result.status) {
                return sendResponse(statusCode.BAD_REQUEST, false, result?.message);
            }
            return sendResponse(statusCode.CREATED, true, result?.message, result.data);
        } catch (error) {
            console.error("Error in customPlanSupport:", error);
            return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
        }
    }


    return sendResponse(statusCode.NOT_FOUND, false, ErrorMessage.NOT_FOUND);
};
