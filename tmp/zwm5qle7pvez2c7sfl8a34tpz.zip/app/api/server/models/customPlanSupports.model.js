import mongoose from "mongoose";

const customPlanSupportsSchema = new mongoose.Schema({
    firstName: {
        type: String,
    },
    lastName: {
        type: String,
    },
    phone: {
        type: String,
    },
    email: {
        type: String,
    },
    storeUrl: {
        type: String,
    },
    message: {
        type: String,
    },
    merchantEmail: {
        type: String,
    },
},
    { 'timestamps': true }

);
 
export const CustomPlanSupports = mongoose.models.customPlanSupports || mongoose.model("customPlanSupports", customPlanSupportsSchema);


