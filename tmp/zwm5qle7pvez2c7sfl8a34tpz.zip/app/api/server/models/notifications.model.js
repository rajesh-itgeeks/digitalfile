import mongoose from "mongoose";

const notificationsSchema = new mongoose.Schema({
    partnerId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Partner"
    },
    enableMerchantNotification: {
        type: Boolean,
    },
    enableCustomerNotification: {
        type: Boolean,
    },
    merchantEmails: {
        type: Array,
    },
    customerSenderEmail: {
        type: String,
    },
    orderEdit: {
        type: JSON,
    },
    paymentPending: {
        type: JSON,
    },
    orderCancellation: {
        type: JSON,
    },
    addUpSellItem: {
        type: JSON,
    },
    orderEditsTimeFrame: {
        type: JSON,
    },
},
    { 'timestamps': true }

);

export const Notifications = mongoose.models.notifications || mongoose.model("notifications", notificationsSchema);
