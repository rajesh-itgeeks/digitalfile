import mongoose from "mongoose";

const emailNotificationSchema = new mongoose.Schema({
    partnerId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Partner"
    },
    orderId: {
        type: String,
    },
    merchantData: {
        type: JSON,
    },
    customerData: {
        type: JSON,
    },
    isCancelled: {
        type: Boolean,
        default:false
    },
    isMarketing: {
        type: Boolean,
        default:false
    },
    isPaymentPending: {
        type: Boolean,
        default:false
    },
    isOrderEditsTimeFrame: {
        type: Boolean,
        default:false
    },
    dueDate: {
        type: Date    },
},
    { 'timestamps': true }

);

export const EmailNotification =mongoose.models.emailNotification || mongoose.model("emailNotification", emailNotificationSchema);


