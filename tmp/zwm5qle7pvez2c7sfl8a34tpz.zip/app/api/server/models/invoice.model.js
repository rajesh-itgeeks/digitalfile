import mongoose from "mongoose";

const invoiceSchema = new mongoose.Schema(
  {
    partnerId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Partner"
    },
    enableCustomerInvoice: {
      type: Boolean,
      default: false,
    },
    storeInfo: {
      name: { type: String, default: null },
      email: { type: String, default: null },
      websiteUrl: { type: String, default: null },
    },
    hide: {
      showTaxesItems: { type: Boolean, default: false },
      hideProductSkus: { type: Boolean, default: false },
      orderStatusInfo: { type: Boolean, default: false },
      orderNotes: { type: Boolean, default: false },
    },
    logoUrl: {
      type: String,
      default: null,
    },
    previewTemplate:{ type: String, default: null },
  },
  { timestamps: true }
);  

export const Invoice =
  mongoose.models.Invoice ||
  mongoose.model("Invoice", invoiceSchema);
