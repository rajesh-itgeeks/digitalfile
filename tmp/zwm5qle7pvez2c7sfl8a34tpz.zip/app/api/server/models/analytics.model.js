import mongoose from "mongoose";

const AnalyticsSchema = new mongoose.Schema({
  partnerId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Partner",
  },
  extensions: {
    type: Array,
    required: true
  }
}, {
  timestamps: true
});

export const Analytics = mongoose.models.Analytics || mongoose.model("Analytics", AnalyticsSchema);
