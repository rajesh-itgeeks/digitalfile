import mongoose from "mongoose";
const failedQueuesSchema = new mongoose.Schema({
    payload: {
        type: JSON,
    },
},
    { 'timestamps': true }

);

export const FailedQueues = mongoose.models.failedQueues || mongoose.model("failedQueues", failedQueuesSchema);

