import mongoose from "mongoose";


const shopifySessionsSchema = new mongoose.Schema({
    id: {
        type: String,
    },
    shop: {
        type: String,
    },
    state: {
        type: String,
    },
    isOnline: {
        type: Boolean,
    },
    scope: {
        type: String,
    },
    accessToken: {
        type: String,
    }
},
    { 'timestamps': true }

);

export const ShopifySessions = mongoose.models.shopify_sessions || mongoose.model("shopify_sessions", shopifySessionsSchema);
