import mongoose from "mongoose";

const partnerSchema = new mongoose.Schema({
    shopJson: {
        type: JSON
    },
    myshopify_domain: {
        type: String
    },
    subscribeId: {
        type: String
    },
    interval: {
        type: String
    },
    isTrail: {
        type: Boolean
    },
    chargeId: {
        type: Number
    },
    amount: {
        type: Number
    },
    isStarted: {
        type: Boolean
    },
    planName: {
        type: String
    },
    isFreePlan: {
        type: Boolean
    },
    hidingFeatures: {
        type: Array
    },

},
    { 'timestamps': true }
);

export const Partner = mongoose.models.Partner || mongoose.model("Partner", partnerSchema);
