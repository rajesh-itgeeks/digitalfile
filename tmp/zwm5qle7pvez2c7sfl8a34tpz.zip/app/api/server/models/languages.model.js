import mongoose from "mongoose";

const LanguagesSchema = new mongoose.Schema({
  partnerId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Partner",
  },
  isDefault: {
    type: Boolean
  },
  name: {
    type: String
  },
  lang: {
    type: String
  },
  langJson: {
    type: JSON
  },
  status: {
    type: Boolean
  },
}, {
  timestamps: true
});

export const Languages = mongoose.models.Languages || mongoose.model("Languages", LanguagesSchema);
