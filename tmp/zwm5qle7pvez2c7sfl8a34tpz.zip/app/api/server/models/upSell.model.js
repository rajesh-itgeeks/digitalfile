import mongoose from "mongoose";

const upSellsSchema = new mongoose.Schema({
    partnerId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Partner"
    },
    name: {
        type: String,
    },
    condition: {
        type: JSON,
    },
    productLimit: {
        type: Number
    },
    productMustMatch: {
        type: String
    },
    selectView: {
        type: String
    },
    productVariants: {
        type: Array
    },
    products: {
        type: Array
    },
    variantsIds: {
        type: Array
    },
    discount: {
        type: Number
    },
    isActive: {
        type: Boolean,
        default: false
    },
},
    { 'timestamps': true }

);

export const UpSells = mongoose.models.upSells || mongoose.model("upSells", upSellsSchema);
