import mongoose from "mongoose";

const flowSchema = new mongoose.Schema({
  payload:{
    type:JSON
  },
},{'timestamps': true});

export const flowTrigger = mongoose.models.flowTrigger || mongoose.model("flowTrigger", flowSchema);


