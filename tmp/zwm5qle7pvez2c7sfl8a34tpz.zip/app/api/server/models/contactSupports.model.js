import mongoose from "mongoose";
const contactSupportsSchema = new mongoose.Schema({
    customerId: {
        type: String,
    },
    orderId: {
        type: String,
    },
    orderNumber: {
        type: String,
    },
    orderLink: {
        type: String,
    },
    country: {
        type: String,
    },
    merchantEmail: {
        type: String,
    },
    customerEmail: {
        type: String,
    },
    phone: {
        type: String,
    },
    message: {
        type: String,
    },
},
    { 'timestamps': true }

);

export const ContactSupports =mongoose.models.contactSupports || mongoose.model("contactSupports", contactSupportsSchema);

