import mongoose from "mongoose";
const ordersSchema = new mongoose.Schema({
    orderId: {
        type: String,
    },
    shop: {
        type: String,
    },
    orderDetails: {
        type: JSON
    },
    partnerId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Partner"
    },
},
    { 'timestamps': true }

);

export const Orders =mongoose.models.orders || mongoose.model("orders", ordersSchema);

