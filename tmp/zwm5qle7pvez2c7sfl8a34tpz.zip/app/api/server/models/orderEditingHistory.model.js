import mongoose from "mongoose";

const orderEditingHistorySchema = new mongoose.Schema({
    partnerId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Partner"
    },
    orderAction: {
        type: JSON,
    },
    customerId: {
        type: JSON,
    },
    orderId: {
        type: String,
    },
    amount: {
        type: String,
    },
    discountAmount: {
        type: String,
    },
    productVariantId: {
        type: String,
    },
    isRemoved: {
        type: Boolean,
        default:false
    },
},
    { 'timestamps': true }

);

export const OrderEditingHistory =mongoose.models.orderEditingHistory || mongoose.model("orderEditingHistory", orderEditingHistorySchema);


