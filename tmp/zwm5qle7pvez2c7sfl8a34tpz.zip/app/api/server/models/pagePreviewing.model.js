import mongoose from "mongoose";

const pagePreviewingSchema = new mongoose.Schema({
    partnerId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Partner"
    },
    thankyouPage: {
        type: JSON,
    },
    orderStatusPage: {
        type: JSON,
    },
    upSellOrderStatus: {
        type: JSON,
    },
    upSellThankyouPage: {
        type: JSON,
    },
    checkoutPageId: {
        type: String
    }
},
    { 'timestamps': true }

);

export const PagePreviewing =mongoose.models.pagePreviewing || mongoose.model("pagePreviewing", pagePreviewingSchema);

