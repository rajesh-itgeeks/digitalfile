import mongoose from "mongoose";

const reversOrdersSchema = new mongoose.Schema({
    orderId: {
        type: String,
    },
    partnerId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Partner"
    },
    orderJson: {
        type: JSON,
    },
    shopName: {
        type: String,
    },
},
    { 'timestamps': true }

);

export const ReversOrders = mongoose.models.reversOrders || mongoose.model("reversOrders", reversOrdersSchema);
