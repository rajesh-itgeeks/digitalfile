import mongoose from "mongoose";

const appSettingsSchema = new mongoose.Schema({
    partnerId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Partner"
    },
    contactInformation: {
        type: JSON,
    },
    shippingDetails: {
        type: JSON,
    },
    orderItems: {
        type: JSON,
    },
    presetTimeFrame: {
        type: JSON,
    },
    orderManage: {
        type: JSON,
    },
    cancelOrder: {
        type: JSON,
    },
    support: {
        type: JSON,
    },
    notifications: {
        type: JSON,
    },
    orderTags: {
        type: Array,
    },
    productTags: {
        type: Array,
    },
    shipping: {
        type: JSON,
    },
    orderHolds: {
        type: JSON,
    },
    orderChangesRevert: {
        type: JSON,
    },
    discount: {
        type: JSON,
    },

},
    { 'timestamps': true }

);

export const AppSettings = mongoose.models.appSettings || mongoose.model("appSettings", appSettingsSchema);
