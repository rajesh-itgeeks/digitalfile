import mongoose from "mongoose";

const webVitalsMatricsSchema = new mongoose.Schema({
  data:{
    type:JSON
  },
},{'timestamps': true});

export const webVitalsMatrics = mongoose.models.webVitalsMatrics || mongoose.model("webVitalsMatrics", webVitalsMatricsSchema);


