import mongoose from "mongoose";

const defaultInvoiceSchema = new mongoose.Schema({
    template: {
        type: String
    }
   
    
},
    { 'timestamps': true }

);

export const DefaultInvoices = mongoose.models.defaultInvoices || mongoose.model("defaultInvoices", defaultInvoiceSchema);
