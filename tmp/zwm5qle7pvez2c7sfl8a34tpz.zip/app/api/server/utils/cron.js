import { CronJob } from 'cron';
import { EmailNotification } from '../models/emailNotification.model';
import { ShopifySessions } from '../models/shopifySessions.model';
import { sendEmail } from './shootEmail';
import { ReversOrders } from '../models/reversOrders.model';
import { isOrderChangesRevertEnable, orderAdmin } from '../services/order/utils';
import { unauthenticated } from '../../../shopify.server';
import { validateOrder } from '../middlewares/orderEditing.middleware';
import { convertLiquidToHtml, getShopInfoGraphQl, remainingTimeForEdit } from './utils';
import { templateDetails } from '../services/notifications';
import { NOTIFICATION_TYPES } from '../constants/constants';
import { Partner } from '../models/partner.model';
import { deleteDetailsFromReverse, removeInReversOrders, reverseOrderFromShopify } from '../services/order/holdOrder';

const createCronJob = (cronExpression, jobFunction) => {
    const cronJob = new CronJob(cronExpression, jobFunction);
    cronJob.start();
    return cronJob;
};

const cronExpression1 = '*/10 * * * *';
const jobFunction1 = async () => {
    console.log('Cron job running : Notification');
    const now = new Date();
    const tenMinutesAgo = new Date(now.getTime() - 10 * 60 * 1000); // 10 minutes ago
    const twentyMinutesAgo = new Date(now.getTime() - 20 * 60 * 1000); // 20 minutes ago

    console.log("now--", now, "tenMinutesAgo--", tenMinutesAgo, "twentyMinutesAgo--", twentyMinutesAgo);

    const pendingEmails = await EmailNotification.find({
        dueDate: {
            $gte: twentyMinutesAgo, // Greater than or equal to 20 minutes ago
            $lte: tenMinutesAgo,    // Less than or equal to 10 minutes ago
        },
    })
    pendingEmails.forEach(async (pendingData) => {
        try {
            if (pendingData?.isMarketing) {
                console.log("Sending Marketing Email");
                const senderEmail = pendingData?.merchantData?.senderEmail
                const receiverEmail = pendingData?.merchantData?.receiverEmail
                const emailHtml = pendingData?.merchantData?.summary
                const subject = pendingData?.merchantData?.subject

                await sendEmail(senderEmail, receiverEmail, emailHtml, subject);
            }
            else {
                if (pendingData?.customerData?.orderActions?.length) {
                    console.log("creating customer email")
                    let combinedSummary = '<ul>'
                    await pendingData?.customerData?.orderActions.map((action) => {
                        combinedSummary += `<li>${action.editSummary}</li>`
                    })
                    combinedSummary += "</ul>";
                    const customerHtml = pendingData?.customerData?.summary.replace('EDIT_SUMMARY_TEXT_HERE', combinedSummary)
                    const detailsToSend = {
                        senderEmail: pendingData?.customerData?.senderEmail,
                        receiverEmail: pendingData?.customerData?.receiverEmail,
                        emailHtml: customerHtml,
                        subject: pendingData?.customerData?.subject
                    }
                    await sendEmail(detailsToSend?.senderEmail, detailsToSend?.receiverEmail, detailsToSend?.emailHtml, detailsToSend?.subject);
                }
                if (pendingData?.merchantData?.orderActions?.length) {
                    console.log("creating merchant email")
                    let combinedSummary = '<ul>'
                    await pendingData?.merchantData?.orderActions.map((action) => {
                        combinedSummary += `<li>${action.editSummary}</li>`
                    })
                    combinedSummary += "</ul>";
                    const htmlToSend = pendingData?.merchantData?.header + combinedSummary + pendingData?.merchantData?.summary
                    const detailsToSend = {
                        senderEmail: pendingData?.merchantData?.senderEmail,
                        receiverEmail: pendingData?.merchantData?.receiverEmail,
                        emailHtml: htmlToSend,
                        subject: pendingData?.merchantData?.subject
                    }
                    await sendEmail(detailsToSend?.senderEmail, detailsToSend?.receiverEmail, detailsToSend?.emailHtml, detailsToSend?.subject);
                }
            }
        } catch (error) {
            console.log("Error in  email notification cron", error);
        }
    })

    await EmailNotification.deleteMany({
        dueDate: {
            $gte: twentyMinutesAgo, // Greater than or equal to 20 minutes ago
            $lte: tenMinutesAgo,    // Less than or equal to 10 minutes ago
        },
    })


};

const cronExpression2 = '*/1 * * * *';
const jobFunction2 = async () => {
    console.log('Cron job running : reverse order');
    // get all order from reversOrder collection 
    const reverseOrders = await ReversOrders.find();
    // check orders details exist or not 
    if (reverseOrders.length) {
        for (const orderDetails of reverseOrders) {
            // check isOrderChangesRevertEnable 
            const isOrderRevert = await isOrderChangesRevertEnable(orderDetails.partnerId);
            if (isOrderRevert) {
                // check session details
                const sessionDetails = await ShopifySessions.findOne({ shop: orderDetails.shopName });
                if (!sessionDetails) continue
                // check order have outstanding amount or not
                const { admin, session } = await unauthenticated.admin(orderDetails.shopName);
                if (admin && session) {
                    // check order time exceed or not 
                    const timeExceedResult = await validateOrder(orderDetails.orderId, orderDetails.partnerId, admin, session);
                    if (!timeExceedResult.status) {
                        // check if outStandingAmount is 0 then only release order 
                        const orderAdminDetails = await orderAdmin(orderDetails.orderId, admin);
                        const outStandingAmount = orderAdminDetails?.totalOutstandingSet?.presentmentMoney?.amount || 0;
                        if (outStandingAmount > 0) {
                            console.log('logic to check order time exe');
                            await reverseOrderFromShopify(orderDetails.orderId, admin, session);
                        }
                        // release order 
                        await removeInReversOrders(orderDetails.orderId, admin);
                    }
                } else {
                    console.log("Admin or Session not found for shop :", orderDetails?.shopName);
                }
            } else {
                console.log("Order changes revert off for shop :", orderDetails?.shopName);
                await deleteDetailsFromReverse(orderDetails.orderId);
            }
        }
    }
};

const cronExpression3 = '*/1 * * * *';
const jobFunction3 = async () => {
    console.log('Cron job running : paymentPending');
    const now = new Date();
    console.log("Time now", now)
    const pendingEmails = await EmailNotification.find({
        $or: [
            { isPaymentPending: true },
            { isOrderEditsTimeFrame: true }
        ],
        dueDate: { $lte: now }  // Still apply the dueDate filter
    });
    console.log("pendingEmails?.length", pendingEmails?.length)
    if (pendingEmails?.length) {
        for (let pendingEmail of pendingEmails) {
            try {
                const orderId = pendingEmail.orderId
                const partnerId = pendingEmail.partnerId
                console.log("orderId : ", orderId)
                const partnerData = await Partner.findById(partnerId);
                if (!partnerData) continue
                // check if session not exist 
                const sessionDetails = await ShopifySessions.findOne({ shop: partnerData.myshopify_domain });
                if (!sessionDetails) continue
                const { admin, session } = await unauthenticated.admin(partnerData.myshopify_domain);
                const shopInfo = await getShopInfoGraphQl(admin)
                shopInfo?.data.shop.email
                const shopData = {
                    ...shopInfo?.data
                }
                if (partnerData) {

                    if (pendingEmail.isPaymentPending) {
                        const result = await templateDetails({ type: NOTIFICATION_TYPES.PAYMENT_PENDING, partnerId });
                        const template = result?.data?.emailTemplate;
                        const emailSubject = result?.data?.subject;
                        const { emailHtml, subject, total_outstanding } = await convertLiquidToHtml({ admin, session, id: orderId, emailTemplate: template, emailSubject, merchantEmail: shopData?.shop?.email, shopData }, partnerId)
                        console.log("Total outstanding Amount: ", Number(total_outstanding))
                        if (Number(total_outstanding) > 0) {
                            console.log("Sending mail due amount", Number(total_outstanding))
                            await sendEmail(pendingEmail?.customerData?.senderEmail, pendingEmail?.customerData?.receiverEmail, emailHtml, subject);
                        }
                    }
                    else if (pendingEmail.isOrderEditsTimeFrame) {
                        const result = await templateDetails({ type: NOTIFICATION_TYPES.ORDER_EDITS_TIME_FRAME, partnerId });
                        const template = result?.data?.emailTemplate;
                        const emailSubject = result?.data?.subject;
                        let { emailHtml, subject, orderData } = await convertLiquidToHtml({ admin, session, id: orderId, emailTemplate: template, emailSubject, merchantEmail: shopData?.shop?.email, shopData }, partnerId)
                        const restTime = await remainingTimeForEdit(partnerId, orderData.created_at)
                        console.log("restTime : ", restTime);
                        if (restTime) {
                            emailHtml = emailHtml.replace("REMAINING_TIME_HERE", restTime);
                            await sendEmail(pendingEmail?.customerData?.senderEmail, pendingEmail?.customerData?.receiverEmail, emailHtml, subject);
                        }
                    }
                    await EmailNotification.deleteOne({ _id: pendingEmail._id })
                }
            } catch (error) {
                console.log("Error in paymentPending cron : ", error);
                await EmailNotification.deleteOne({ _id: pendingEmail._id })
                continue
            }
        }
    }
};

// createCronJob(cronExpression1, jobFunction1);
// createCronJob(cronExpression2, jobFunction2);
// createCronJob(cronExpression3, jobFunction3);

console.log('Cron job initialized');


