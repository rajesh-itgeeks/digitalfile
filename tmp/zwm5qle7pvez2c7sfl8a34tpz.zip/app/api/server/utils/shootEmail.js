import { emailConfig } from "../config/email";
import * as emailTemplates from "../utils/emailTemplate"
import nodemailer from "nodemailer";
// Function to send an email to merchants
export const shootEmail = async (type, details, merchantEmails) => {
  console.log("merchantEmail",merchantEmails)
  const recipients = Array.isArray(merchantEmails) ? merchantEmails.join(",") : merchantEmails;
   // Create email transporter using the configured settings
  const transporter = nodemailer.createTransport(emailConfig);
  // Generate email options using the email template utility
  const mailOptions = await emailTemplates.updateOrder(details, recipients, type);
  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.error(`Error in ${type} email send :`, error);
    } else {
      console.log(`${type} email send success merchant:`, info.response);
    }
  });
  return {
    status: true
  }
};
// Function to send an email to customer
export const shootCustomerEmail = async (senderEmail, receiverEmail, emailHtml, subject) => {
  // Create email transporter using the configured settings
  const transporter = nodemailer.createTransport(emailConfig);
  // Define email options for sending to customers
  const mailOptions = {
    from: senderEmail,
    to: receiverEmail,
    subject: subject,
    replyTo: senderEmail,
    html: emailHtml
  }
    // Send email
  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.error(`Error in  email send :`, error);
    } else {
      console.log(`email send success customer:`, info.response);
    }
  });
  return {
    status: true
  }
};
export const sendEmail = async (senderEmail, receiverEmail, emailHtml, subject) => {
  console.log("senderEmail---",senderEmail,"receiverEmail---",receiverEmail,"subject---",subject)
  // Create email transporter using the configured settings
  const transporter = nodemailer.createTransport(emailConfig);
  // Define email options for sending to customers
  const mailOptions = {
    from: senderEmail,
    to: receiverEmail,
    subject: subject,
    replyTo: senderEmail,
    html: emailHtml
  }
    // Send email
  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.error(`Error in  email send :`, error);
    } else {
      console.log(`email send success:`, info.response);
    }
  });
  return {
    status: true
  }
};

export const shootMarketingEmail = async ( templateType,merchantEmail,details) => {
  console.log("shootMarketingEmail===","=merchantEmail========",merchantEmail)

  const transporter = nodemailer.createTransport(emailConfig);
  const mailOptions = emailTemplates[templateType](details,merchantEmail)
  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.error(`Error in  email send :`, error);
    } else {
      console.log(`email send success customer:`, info.response);
    }
  });
  return {
    status: true
  }
};

