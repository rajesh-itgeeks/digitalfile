
export const getZohoAccessToken = async () => {
    try {
        const urlencoded = new URLSearchParams();
        urlencoded.append("grant_type", "refresh_token");
        urlencoded.append("client_id", process.env.ZOHO_CLIENT_ID);
        urlencoded.append("client_secret", process.env.ZOHO_CLIENT_SECRET);
        urlencoded.append("refresh_token", process.env.ZOHO_CLIENT_REFRESH_TOKEN);

        const requestOptions = {
            method: "POST",
            body: urlencoded,
            redirect: "follow"
        };

        const res = await fetch("https://accounts.zoho.in/oauth/v2/token", requestOptions)

        const data = await res.json();
        return data?.access_token;
    } catch (error) {
        console.log("Error in getZohoAccessToken", error);
        return false
    }

};
export const addLeadToZoho = async (payload) => {
    try {

        const accessToken = await getZohoAccessToken();
        if (!accessToken) {
            console.log("Could get not zoho  access token");
            return {
                status: false,
                message: "Could get not zoho  access token",
            };
        }

        const myHeaders = new Headers();
        myHeaders.append("Authorization", `Zoho-oauthtoken ${accessToken}`);
        myHeaders.append("Content-Type", "application/json");

        const raw = JSON.stringify({
            "data": [payload]
        });

        const requestOptions = {
            method: "POST",
            headers: myHeaders,
            body: raw,
            redirect: "follow"
        };

        let res;
        if (payload?.Lead_Status == "Pre-Qualified")
            res = await fetch("https://www.zohoapis.in/crm/v2/Leads/upsert", requestOptions)
        else
            res = await fetch("https://www.zohoapis.in/crm/v2/Contacts/upsert", requestOptions)

        const data = await res.json();
        if (data?.data?.[0]?.code === "SUCCESS") {
            console.log("Lead add Success To Zoho", data);
            return ({
                status: true,
                message: "Lead add Success",
                data
            });
        }
        else {
            console.log("Error in addLeadToZoho", data);
            return ({
                status: false,
                message: "Could not add lead to Zoho",
                data
            });
        }

    } catch (error) {
        console.log("Error in addLeadToZoho", error);
        return {
            status: false,
            message: error?.message || "Error in addLeadToZoho",
        }
    }

};
export const updateLeadToZoho = async (storeEmail) => {
    try {
        const accessToken = await getZohoAccessToken();
        if (!accessToken) {
            console.log("Could get not zoho  access token");
            return {
                status: false,
                message: "Could get not zoho  access token",
            };
        }
        console.log("accessToken", accessToken);
        const leadDetails = await getLeadDetails(accessToken, storeEmail)
        const leadId = leadDetails?.data?.data?.[0]?.id
        if (!leadId) {
            console.log("Lead Id not found ,lead Details : ", leadDetails);
            return {
                status: false,
                message: "Lead Id not found",
            }
        }
        const myHeaders = new Headers();
        myHeaders.append("Authorization", `Zoho-oauthtoken ${accessToken}`);
        const now = new Date();
        const formattedDate = now.toISOString().split('T')[0];
        const raw = JSON.stringify({
            "data": [
                {
                    "Current_App_Status": "Uninstalled",
                    "Uninstall_Date": formattedDate
                }
            ]
        });

        const requestOptions = {
            method: "PUT",
            headers: myHeaders,
            body: raw,
            redirect: "follow"
        };

        const res = await fetch(`https://www.zohoapis.in/crm/v2/Contacts/${leadId}`, requestOptions)
        const data = await res.json();

        if (data?.data?.[0]?.code === "SUCCESS") {
            console.log("Lead updated successfully to Zoho");
        } else {
            console.log("Error in lead update to Zoho", data);
        }
        return ({
            status: true,
            data
        });
    } catch (error) {
        console.log("Error in updateLeadToZoho", error);
        return {
            status: false,
            message: error?.message || "Error in updateLeadToZoho",
        }
    }

};

export const getLeadDetails = async (accessToken, email) => {
    try {
        const myHeaders = new Headers();
        myHeaders.append("Authorization", `Zoho-oauthtoken ${accessToken}`);

        const requestOptions = {
            method: "GET",
            headers: myHeaders,
            redirect: "follow"
        };

        const res = await fetch(`https://www.zohoapis.in/crm/v2/Contacts/search?email=${email}`, requestOptions)

        const data = await res.json();
        return ({
            status: true,
            data
        });
    } catch (error) {
        return {
            status: false,
            message: error?.message || "Error in getLeadDetails",
        }
    }

};

