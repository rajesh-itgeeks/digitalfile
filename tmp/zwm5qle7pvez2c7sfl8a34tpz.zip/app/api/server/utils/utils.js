import { Liquid } from "liquidjs"
import { sendEmail, shootCustomerEmail, shootEmail } from "./shootEmail.js";
import { notificationDetailsById, templateDetails } from "../services/notifications/index.js";
import { EmailNotification } from "../models/emailNotification.model.js";
import { orderSummary } from "./emailTemplate.js";
import { EMAIL_HANDLES, NOTIFICATION_TYPES } from "../constants/constants.js";
import { getLatestOrderId, orderAdmin, timeStringToMs } from "../services/order/utils.js";
import { AppSettings } from "../models/appSettings.model.js";

// Function to send email based on receiver type (merchant or customer)
export const emailSender = async (details, notificationType, receiverType) => {
    console.log("Receiver Type:", receiverType, process.env.ENV_SERVER);
    // if (process.env.ENV_SERVER === "development") return
    const { partnerId, type, editSummary } = details;
    const orderId = details.id;
    // Fetch notification settings
    const notificationDetails = await notificationDetailsById(partnerId);
    if (!notificationDetails?.data) return;

    const isMerchant = receiverType === 'merchant';
    // Check if notification is enabled for the receiver type

    let detailsToSend = {};
    const shopData = await getShopInfoGraphQl(details.admin);
    if (isMerchant) {
        if (!notificationDetails.data.enableMerchantNotification) return;
        // Fetch shop and order details
        const orderData = await orderAdmin(details.id, details.admin);

        const merchantEmail = notificationDetails.data.merchantEmails?.length
            ? notificationDetails.data.merchantEmails
            : shopData?.data?.shop?.email;
        const { admin, session, ...filterDetails } = details;
        // Prepare email data
        detailsToSend = {
            order: orderData,
            shopName: shopData?.data.shop.name,
            redirectUrl: `${shopData?.data.shop.url}/admin/orders/${details.id}`,
            receiverType,
            ...filterDetails
        };
        console.log('merchantEmail :', merchantEmail);
        let changesMade
        let emailHeader
        if (notificationType === EMAIL_HANDLES.CANCEL_ORDER_EMAIL) {
            console.log("is cancellation merchant----")

            emailHeader = `<hr style="border: 0; height: 1px; background: #ddd; margin-top: 20px; margin-bottom: 10px;"/>
            <h2 style="font-size: 30px;">${detailsToSend?.shopName}</h2>
            <h3 style="font-size: 22px;"> ${detailsToSend?.order?.customer?.firstName} ${detailsToSend?.order?.customer?.lastName} Cancelled Order ${detailsToSend?.order?.name} on ${new Date(detailsToSend?.order?.cancelledAt).toDateString()}.</h3>
            <p style="text-align: left; font-size: 21px; margin:0px">Changes Made </p> `

            changesMade = `<p style="margin: 0; padding:5px;"> ${detailsToSend?.order?.customer?.firstName} ${detailsToSend?.order?.customer?.lastName} cancelled order ${detailsToSend?.order?.name} on ${new Date(detailsToSend?.order?.cancelledAt).toDateString()}</p>
            <p style="margin: 0; padding:7px 0px;"><strong>Refund Amount:</strong>${detailsToSend?.order?.totalRefundedSet?.presentmentMoney?.currencyCode} ${detailsToSend?.order?.totalRefundedSet?.presentmentMoney?.amount}</p>
          ${detailsToSend?.restock ? `<p style="margin: 0; padding:7px 0px;"><strong>Restocking Fee:</strong> ${detailsToSend?.restokingFee ? detailsToSend?.restokingFee : "0.0"}</p>` : ""} 
            <p style="margin: 0; padding:7px 0px;"><strong>Cancellation Reason :</strong> ${detailsToSend?.staffNote ? detailsToSend?.staffNote : ""}</p> `

            const merchantSummary = await orderSummary(detailsToSend)
            const merchantSubject = `Order cancelled in ${detailsToSend?.shopName} order ${detailsToSend?.order?.name}`
            await EmailNotification.findOneAndUpdate(
                { orderId, partnerId, isCancelled: true }, // Query: Find by orderId and partnerId
                {
                    $push: {
                        "merchantData.orderActions": {
                            actionType: notificationType,
                            editSummary: changesMade,
                        },
                    },
                    $set: {
                        "merchantData.header": emailHeader, // Update summary every time
                        "merchantData.summary": merchantSummary, // Update summary every time
                        "merchantData.receiverEmail": merchantEmail, // Update summary every time
                        "merchantData.senderEmail": process.env.SMTP_USER_EMAIL, // Update summary every time
                        "merchantData.replyToEmail": process.env.SMTP_USER_EMAIL, // Update summary every time
                        "merchantData.subject": merchantSubject, // Update summary every time
                        "dueDate": new Date()
                    },

                },
                {
                    upsert: true, // Create if not exists
                    new: true, // Return updated document
                }
            );


        }
        else {
            switch (notificationType) {
                case EMAIL_HANDLES.ADD_ITEM_EMAIL: {
                    changesMade = `<p style="margin: 0;  padding:10px 0px;">  ${detailsToSend?.order?.customer?.firstName} ${detailsToSend?.order?.customer.lastName} added ${details?.productNames} to order ${detailsToSend?.order?.name} .</p>
                  `
                    break;
                }
                case EMAIL_HANDLES.REMOVE_ITEM_EMAIL: {
                    changesMade = `<p style="margin: 0;  padding:10px 0px;"> ${detailsToSend?.order?.customer?.firstName} ${detailsToSend?.order?.customer?.lastName} Removed Item ${detailsToSend?.itemTitle} from order  ${detailsToSend?.order?.name} .</p>`
                    break;
                }
                case EMAIL_HANDLES.UPSELL_DISCOUNT: {
                    changesMade = `<p style="margin: 0; padding:5px;">  ${detailsToSend?.order?.customer?.firstName} ${detailsToSend?.order?.customer?.lastName} added ${detailsToSend?.productName} to order ${detailsToSend?.order?.name} through upsell list.</p>
                    <p style="margin: 0;  padding:7px 0px;"><strong>Product name:</strong> ${detailsToSend?.productName}</p>
                    <p style="margin: 0;  padding:7px 0px;"><strong>Upsell revenue:</strong> ${detailsToSend?.upsellAmount}</p>        `
                    break;
                }
                case EMAIL_HANDLES.UPDATE_CONTACT_INFO: {
                    changesMade = `<p style="margin: 0; padding:10px 0px;"><strong>Updated Email Address :</strong> ${detailsToSend?.email}</p>`
                    break;
                }
                case EMAIL_HANDLES.SWAP_ITEM: {
                    changesMade = `<p style="margin: 0; padding:7px 0px"> ${detailsToSend?.order?.customer?.firstName} ${detailsToSend?.order?.customer?.lastName} changed item in order ${detailsToSend?.order?.name} on ${new Date(detailsToSend?.order?.updatedAt).toDateString()}</p>
                         <p style="margin: 0;  padding:10px 0px;">  ${detailsToSend?.order?.customer?.firstName} ${detailsToSend?.order?.customer?.lastName} Changed ${detailsToSend?.removedTitle} to variant ${detailsToSend?.addedTitle} in order ${detailsToSend?.order?.name} .</p> `
                    break;

                }
                case EMAIL_HANDLES.UPDATE_SHIPPING: {
                    changesMade = `
                                <p style="margin: 0; padding:10px 0px;"><strong>Updated Shipping Address:</strong> </p>
            
                  ${detailsToSend?.order?.shippingAddress?.name ? ` <p style="font-size: 15px;margin: 0;">${detailsToSend?.order?.shippingAddress?.name}</p>` : ''}
                  ${detailsToSend?.order?.shippingAddress?.company ? ` <p style="font-size: 15px;margin: 0;">${detailsToSend?.order?.shippingAddress?.company}</p>` : ''}
                  ${detailsToSend?.order?.shippingAddress?.address1 ? ` <p style="font-size: 15px;margin: 0;">${detailsToSend?.order?.shippingAddress?.address1}</p>` : ''}
                  ${detailsToSend?.order?.shippingAddress?.city ? ` <p style="font-size: 15px; margin: 0;">${detailsToSend?.order?.shippingAddress?.city}</p>` : ''}
                  ${detailsToSend?.order?.shippingAddress?.provinceCode ? ` <p style="font-size: 15px;margin: 0;">${detailsToSend?.order?.shippingAddress?.provinceCode}</p>` : ''}
                  ${detailsToSend?.order?.shippingAddress?.phone ? ` <p style="font-size: 15px;margin: 0;">${detailsToSend?.order?.shippingAddress?.phone}</p>` : ''}
                  ${detailsToSend?.order?.shippingAddress?.zip ? ` <p style="font-size: 15px; margin: 0;">${detailsToSend?.order?.shippingAddress?.zip}</p>` : ''}
                  ${detailsToSend?.order?.shippingAddress?.country ? ` <p style="font-size: 15px; margin: 0;">${detailsToSend?.order?.shippingAddress?.country}</p>` : ''} `
                    break;

                }
                case EMAIL_HANDLES.EDIT_ORDER: {

                    const editedList = detailsToSend?.updatedList.map((nodes) => {
                        return `<p style="margin: 0; padding:4px 0px"><strong>Title :</strong>  ${nodes?.title} <strong>Quantity : </strong>${nodes?.quantity} </p>`
                    })
                    changesMade = `<p style="margin: 0; padding:7px 0px;"> ${detailsToSend?.order?.customer?.firstName} ${detailsToSend?.order?.customer?.lastName} edited order ${detailsToSend?.order?.name} on ${new Date(detailsToSend?.order?.updatedAt).toDateString()}</p>
                                <p style="margin: 0;padding:7px 0px"><strong>Updated Quantity:</strong> </p>
                                <p style="margin: 0; padding:0px 0px">${editedList.join(" ")}</p> `
                    break;
                }

            }
            emailHeader = `<hr style="border: 0; height: 1px; background: #ddd; margin-top: 20px; margin-bottom: 10px;"/>
            <h2 style="font-size: 30px;">${detailsToSend?.shopName}</h2>
            <h3 style="font-size: 22px;"> ${detailsToSend?.order?.customer?.firstName} ${detailsToSend?.order?.customer?.lastName} edited order ${detailsToSend?.order?.name} on ${new Date(detailsToSend?.order?.updatedAt).toDateString()}.</h3>
            <p style="text-align: left; font-size: 21px; margin:0px">Changes Made </p> `
            const merchantSummary = await orderSummary(detailsToSend)
            const merchantSubject = `Order Edit in ${detailsToSend?.shopName} order ${detailsToSend?.order?.name}`
            await EmailNotification.findOneAndUpdate(
                { orderId, partnerId, isCancelled: false }, // Query: Find by orderId and partnerId
                {
                    $push: {
                        "merchantData.orderActions": {
                            actionType: notificationType,
                            editSummary: changesMade,
                        },
                    },
                    $set: {
                        "merchantData.header": emailHeader, // Update summary every time
                        "merchantData.summary": merchantSummary, // Update summary every time
                        "merchantData.receiverEmail": merchantEmail, // Update summary every time
                        "merchantData.senderEmail": process.env.SMTP_USER_EMAIL, // Update summary every time
                        "merchantData.replyToEmail": process.env.SMTP_USER_EMAIL, // Update summary every time
                        "merchantData.subject": merchantSubject, // Update summary every time
                        "dueDate": new Date()
                    },

                },
                {
                    upsert: true, // Create if not exists
                    new: true, // Return updated document
                }
            );

        }
    } else {
        if (!notificationDetails.data.enableCustomerNotification || !notificationDetails.data[type]?.status) return;
        // Fetch email template
        const result = await templateDetails({ type, partnerId });
        const template = result?.data?.emailTemplate;
        const emailSubject = result?.data?.subject;
        // Set sender email
        const senderEmail = notificationDetails?.data?.customerSenderEmail || process.env.SMTP_USER_EMAIL;

        details.emailTemplate = template;
        details.merchantEmail = senderEmail
        details.emailSubject = emailSubject
        details.shopData = shopData?.data
        // Convert Liquid template to HTML
        const { emailHtml, subject, receiverEmail } = await convertLiquidToHtml(details);
        console.log('senderEmail, receiverEmail :', senderEmail, receiverEmail);

        detailsToSend = { senderEmail, receiverEmail, emailHtml, emailSubject: subject, receiverType };
        if (type === NOTIFICATION_TYPES.ORDER_CANCELLATION) {
            console.log("is cancellation customer----")
            await EmailNotification.findOneAndUpdate(
                { orderId, partnerId, isCancelled: true }, // Query: Find by orderId and partnerId
                {
                    $push: {
                        "customerData.orderActions": {
                            actionType: type,
                            editSummary: editSummary,
                        },
                    },
                    $set: {
                        "customerData.summary": emailHtml, // Update summary every time
                        "customerData.receiverEmail": receiverEmail, // Update summary every time
                        "customerData.senderEmail": senderEmail, // Update summary every time
                        "customerData.replyToEmail": senderEmail, // Update summary every time
                        "customerData.subject": subject, // Update summary every time
                        "dueDate": new Date()
                    },

                },
                {
                    upsert: true, // Create if not exists
                    new: true, // Return updated document
                }
            );
        }
        else {
            await EmailNotification.findOneAndUpdate(
                { orderId, partnerId, isCancelled: false }, // Query: Find by orderId and partnerId
                {
                    $push: {
                        "customerData.orderActions": {
                            actionType: type,
                            editSummary: editSummary,
                        },
                    },
                    $set: {
                        "customerData.summary": emailHtml, // Update summary every time
                        "customerData.receiverEmail": receiverEmail, // Update summary every time
                        "customerData.senderEmail": senderEmail, // Update summary every time
                        "customerData.replyToEmail": senderEmail, // Update summary every time
                        "customerData.subject": subject, // Update summary every time
                        "dueDate": new Date()
                    },

                },
                {
                    upsert: true, // Create if not exists
                    new: true, // Return updated document
                }
            );
        }
    }
};

// Function to fetch shop details using GraphQL
export const getShopInfoGraphQl = async (admin) => {
    const details = await admin.graphql(
        ` #graphql
        { 
        shop {
                name
                url
                myshopifyDomain
                email
                plan {
                displayName
                partnerDevelopment
                shopifyPlus
                }
             }
    }
        `
    );
    const data = await details.json()
    return data;
}

// Function to convert Liquid template to HTML
export const convertLiquidToHtml = async (details) => {
    const engine = new Liquid();
    try {
        const { id, admin, session, emailSubject, emailTemplate, merchantEmail, restock, restokingFee, customerRefundedAmount, totalAmount, editSummary, shopData } = details;
        // order data to render
        const variableData = await orderRestDetails(id, session, admin);
        const receiverEmail = variableData?.email
        // Render Liquid template into HTML
        const emailHtml = await engine.parseAndRender(emailTemplate, { ...variableData, merchant_email: merchantEmail, restock, restokingFee, customerRefundedAmount, totalAmount, editSummary, ...shopData });
        let subject;
        if (emailSubject) {
            subject = await engine.parseAndRender(emailSubject, variableData);
        }
        return { emailHtml, receiverEmail, subject, total_outstanding: variableData.total_outstanding, orderData: variableData }
    } catch (err) {
        console.log("Error catch in convertLiquidHtml", err);
    }
}



export const convertLiquidToHtmlInvoice = async (template, admin, session, data, partnerId, partnerData) => {
    const engine = new Liquid();

    try {
        const { data: id } = await getLatestOrderId(admin);
        const orderId = await extractShopifyId(id);
        const variableData = await orderRestDetails(orderId, session, admin);
        
        variableData.orderStatus = variableData.financial_status.replace("_", " "); 
        variableData.hideProductSkus = data?.hide?.hideProductSkus;
        variableData.orderStatusInfo = data?.hide?.orderStatusInfo;
        variableData.orderNotes = data?.hide?.orderNotes;
        variableData.showTaxesItems = data?.hide?.showTaxesItems;
        variableData.storeLogo = data?.logoUrl || "https://placehold.co/100x100";
        variableData.storeName = data?.storeInfo?.name || partnerData?.shopJson?.name;
        variableData.storeEmail = data?.storeInfo?.email || partnerData?.shopJson?.email;
        variableData.storeWebsite = data?.storeInfo?.websiteUrl || `https://${partnerData?.shopJson?.domain}`;

        const createdAt = variableData?.created_at;
        if (createdAt) {
            const formattedDate = new Intl.DateTimeFormat('en-GB', {
                day: '2-digit',
                month: 'long',
                year: 'numeric',
            }).format(new Date(createdAt));

            // Add formatted date to the order object so it's available in Liquid
            variableData.formattedCreatedAt = formattedDate;
        }

        const updated_at = variableData?.updated_at;
        if (updated_at) {
            const formattedDate = new Intl.DateTimeFormat('en-GB', {
                day: '2-digit',
                month: 'long',
                year: 'numeric',
            }).format(new Date(updated_at));

            // Add formatted date to the order object so it's available in Liquid
            variableData.formattedUpdatedAt = formattedDate;
        }

        const emailHtml = await engine.parseAndRender(template, variableData);

        return { emailHtml };
    } catch (err) {
        console.error("Error catch in convertLiquidHtml:", err);
        return { error: err.message };
    }
};

export const convertLiquidToHtmlForEmail = async (details, type, receiverType) => {
    const engine = new Liquid();
    try {
        console.log("Receiver Type upsell:", receiverType, process.env.ENV_SERVER);
        const { partnerId } = details;
        // Fetch notification settings
        const notificationDetails = await notificationDetailsById(partnerId);
        if (!notificationDetails?.data) return;

        // Check if notification is enabled for the receiver type
        const enableNotification = notificationDetails?.data?.enableCustomerNotification;

        if (!enableNotification || !notificationDetails.data[type]?.status) return;

        const result = await templateDetails({ type, partnerId });
        const template = result?.data?.emailTemplate;
        const emailSubject = result?.data?.subject;
        // Set sender email
        const senderEmail = notificationDetails?.data?.customerSenderEmail || process.env.SMTP_USER_EMAIL;
        // Convert Liquid template to HTML
        const emailHtml = await engine.parseAndRender(template, { ...details, merchant_email: details?.shop?.email });
        let subject;
        if (emailSubject) {
            subject = await engine.parseAndRender(emailSubject, details);
            subject ? subject : subject = "Upsell Notification";
        }
        const receiverEmail = details?.customer?.email
        if (type === NOTIFICATION_TYPES.ADD_UPSELL_ITEM) {
            await sendEmail(senderEmail, receiverEmail, emailHtml, subject);
        }
        else {
            return { receiverEmail, senderEmail, emailSubject }
        }
    }

    catch (err) {
        console.error("Error catch in convertLiquidToHtmlPaymentPending:", err);
        return { error: err.message };
    }
};

// get invoice pdf
export const getInvoicePdfContent = async (data, template, admin, session, orderId, partnerData) => {
    const engine = new Liquid();
    try {
        const currentPartnerInfo = await getShopInfoGraphQl(admin);
        const email = data?.storeInfo?.email || currentPartnerInfo?.data?.shop?.email || partnerData?.email;
        const variableData = await orderRestDetails(orderId, session, admin);
        if (!variableData) {
            return { status: false, message: "orderId is not found" };
        }
        variableData.orderStatus = variableData.financial_status.replace("_", " ");
        variableData.hideProductSkus = data?.hide?.hideProductSkus;
        variableData.orderStatusInfo = data?.hide?.orderStatusInfo;
        variableData.orderNotes = data?.hide?.orderNotes;
        variableData.showTaxesItems = data?.hide?.showTaxesItems;
        variableData.storeLogo = data?.logoUrl || "https://placehold.co/100x100";
        variableData.storeName = data?.storeInfo?.name || partnerData?.name;
        variableData.storeEmail = email;
        variableData.storeWebsite = data?.storeInfo?.websiteUrl || `https://${partnerData?.myshopify_domain}`;

        const createdAt = variableData?.created_at;
        if (createdAt) {
            const formattedDate = new Intl.DateTimeFormat('en-GB', {
                day: '2-digit',
                month: 'long',
                year: 'numeric',
            }).format(new Date(createdAt));

            // Add formatted date to the order object so it's available in Liquid
            variableData.formattedCreatedAt = formattedDate;
        }

        const updated_at = variableData?.updated_at;
        if (updated_at) {
            const formattedDate = new Intl.DateTimeFormat('en-GB', {
                day: '2-digit',
                month: 'long',
                year: 'numeric',
            }).format(new Date(updated_at));

            // Add formatted date to the order object so it's available in Liquid
            variableData.formattedUpdatedAt = formattedDate;
        }

        const htmlContent = await engine.parseAndRender(template, variableData);
        return { status: true, data: htmlContent };
    } catch (err) {
        console.error("Error catch in invoicePdf:", err);
        return { status: false, message: err?.message || "Error generating invoicePdf" };
    }
};


export const extractShopifyId = async (gid) => {
    try {
        return gid.split("/").pop();
    } catch (err) {
        console.log(err);
        return false
    }
}

export const orderRestDetails = async (orderId, session, admin) => {
    try {
        const result = await admin.rest.resources.Order.find({
            session,
            id: orderId,
        });

        const response = await admin.graphql(
            `
        query orderDetails($id: ID!) {
          order(id: $id) {
           totalOutstandingSet { 
            presentmentMoney {
              amount
              currencyCode
            }
          }
          totalReceivedSet {
            presentmentMoney {
              amount
              currencyCode
            }
          }
            lineItems(first: 250) {
              nodes {
                id
                sku
                image {
                  url
                }
              }
            }
          }
        }
        `,
            {
                variables: {
                    id: `gid://shopify/Order/${orderId}`,
                },
            }
        );

        const data = await response.json();


        if (result && result?.line_items && data?.data?.order?.lineItems?.nodes) {
            const graphqlLineItems = data.data.order.lineItems.nodes;

            result.line_items = result.line_items.map((item) => {
                const matchingGraphqlItem = graphqlLineItems.find(
                    (gItem) => gItem.sku === item.sku
                );

                return {
                    ...item,
                    image_url: matchingGraphqlItem?.image?.url || "https://cdn.shopify.com/s/files/1/0909/9549/1120/files/AAUvwnj0ICORVuxs41ODOvnhvedArLiSV20df7r8XBjEUQ_s900-c-k-c0x00ffffff-no-rj.jpg?v=1739808008",
                };
            });
        }

        result.total_outstanding = data?.data?.order?.totalOutstandingSet?.presentmentMoney?.amount
        result.total_paid_amount = data?.data?.order?.totalReceivedSet?.presentmentMoney?.amount

        return result;
    } catch (err) {
        console.log(err);
    }
};

export const remainingTimeForEdit = async (partnerId, createdAt) => {
    try {
        if (!partnerId || !createdAt) return false
        const timeFrame = await AppSettings.findOne({ partnerId }).select("presetTimeFrame").lean()
        console.log("timeFrame : ", timeFrame, createdAt);
        if (!timeFrame?.presetTimeFrame?.time || timeFrame.presetTimeFrame.time === 'fulfilled') return false

        const timeInMs = await timeStringToMs(timeFrame.presetTimeFrame.time)
        if (!timeInMs) return false
        console.log("timeInMs : ", timeInMs);
        const thresholdDate = new Date(new Date(createdAt).getTime() + timeInMs);
        console.log("thresholdDate : ", thresholdDate);

        const remainingTime = thresholdDate - new Date()
        console.log("remaining time :", remainingTime);

        const MS_IN_MINUTE = 60 * 1000;
        const MS_IN_HOUR = 60 * MS_IN_MINUTE;
        const MS_IN_DAY = 24 * MS_IN_HOUR;


        if (remainingTime > 0) {
            const days = Math.floor(remainingTime / MS_IN_DAY);
            const hours = Math.floor((remainingTime % MS_IN_DAY) / MS_IN_HOUR);
            const minutes = Math.floor((remainingTime % MS_IN_HOUR) / MS_IN_MINUTE);

            console.log("days, hours, minutes : ", days, hours, minutes);

            let result = '';
            if (days > 0) result += `${days} day${days > 1 ? 's' : ''} `;
            if (hours > 0) result += `${hours} hour${hours > 1 ? 's' : ''} `;
            if (minutes > 0 && days === 0) result += `${minutes} minute${minutes > 1 ? 's' : ''}`;
            console.log("days, hours, minutes : ", days, hours, minutes);

            return result.trim();
        } else {
            return false;
        }

    } catch (error) {
        console.log("Error in remainingTimeForEdit ", error);
        return false
    }



}