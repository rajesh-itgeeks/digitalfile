import { EMAIL_HANDLES } from "../constants/constants";
// Generates an email template for contacting support.
export const contactSupportEmail = (details, merchantEmail) => {
  const data = {
    from: process.env.SMTP_USER_EMAIL,
    to: merchantEmail,
    subject: `You have a form submission for ${details.orderNumber}`,
    replyTo: details.customerEmail,
    html: `
<div style="margin: 0; padding: 0; font-family: Arial, sans-serif; color: #333;">
      <table width="800" align="center" cellpadding="0" cellspacing="0" border="0" style="border-collapse: collapse;">
      
        <!-- Support Email Content -->
        <tr>
          <td style="padding: 40px; box-sizing: border-box;color:black;">
            <p style="font-weight: 700; margin: 0; padding:5px;">Support Request Details</p>
            <p style="margin: 0; padding:5px;"><strong>Order Number:</strong> <a href="#">${details.orderNumber}</a></p>
            <p style="margin: 0; padding:5px;"><strong>Phone:</strong> ${details.phone}</p>
            <p style="margin: 0; padding:5px;"><strong>Message:</strong> ${details.message}</p>
            <p style="margin: 0; padding:5px;">Best regards,<br><strong>Account Editor Support Team</strong></p>
          </td>
        </tr>
      
        <!-- Footer -->
      </table>
    </div>
    `
  };

  return data;
};

// Generates an email template for custom plan support requests
export const customPlanSupportEmail = (details) => {
  const data = {
    from: process.env.SMTP_USER_EMAIL,
    to: process.env.SUPPORT_EMAIL,
    subject: `New Custom Plan Request from ${details.firstName} ${details.lastName}`,
    replyTo: details.email,
    html: `
<div style="margin: 0; padding: 0; font-family: Arial, sans-serif; color: #333;">
  <table width="800" align="center" cellpadding="0" cellspacing="0" border="0" style="border-collapse: collapse;">
    
    <!-- Custom Plan Request Email Content -->
    <tr>
      <td style="padding: 40px; box-sizing: border-box; color:black;">
        <p style="font-weight: 700; margin: 0; padding:5px;">Custom Plan Request Details</p>
        <p style="margin: 0; padding:5px;"><strong>First Name:</strong> ${details.firstName}</p>
        <p style="margin: 0; padding:5px;"><strong>Last Name:</strong> ${details.lastName}</p>
        <p style="margin: 0; padding:5px;"><strong>Phone:</strong> ${details.phone}</p>
        <p style="margin: 0; padding:5px;"><strong>Email:</strong> ${details.email}</p>
        <p style="margin: 0; padding:5px;"><strong>Store URL:</strong> <a href="${details.storeUrl}" target="_blank">${details.storeUrl}</a></p>
        <p style="margin: 0; padding:5px;"><strong>Message:</strong> ${details.message}</p>
        <p style="margin: 20px 0 0 5px;">Please review the request and reach out to the merchant to discuss their custom plan needs.</p>
        <p style="margin: 0; padding:5px;">Best regards,<br><strong>Account Editor Support Team</strong></p>
      </td>
    </tr>
    
    <!-- Footer -->
  </table>
</div>
    `
  };

  return data;
};
// Generates an email template for update order
export const updateOrder = async (details, recipients, type) => {
  let productNames = ''
  if (Array.isArray(details?.productNames)) {
    productNames = details?.productNames.join(" , ")
  }
  let changesMade
  let markettingBody
  if (details?.isMarketting) {
    changesMade = "<div>Marketting Email 1</div>"
  }
  switch (type) {
    case EMAIL_HANDLES.ADD_ITEM_EMAIL: {
      changesMade = `<p style="margin: 0;  padding:10px 0px;">  ${details?.order?.customer?.firstName} ${details?.order?.customer.lastName} added ${productNames} to order ${details?.order?.name} .</p>
        <a href=${details?.redirectUrl} style="display: inline-block; background-color: #008060; color: #fff; padding: 10px 20px; text-decoration: none; border-radius: 4px; margin-top: 15px;margin-bottom:20px;">View Order</a>
      `
      break;
    }
    case EMAIL_HANDLES.REMOVE_ITEM_EMAIL: {
      changesMade = `<p style="margin: 0;  padding:10px 0px;"> ${details?.order?.customer?.firstName} ${details?.order?.customer?.lastName} Removed Item ${details?.itemTitle} from order  ${details?.order?.name} .</p>
        <a href=${details?.redirectUrl} style="display: inline-block; background-color: #008060; color: #fff; padding: 10px 20px; text-decoration: none; border-radius: 4px;  margin-top: 15px;margin-bottom:20px;">View Order</a>
      `
      break;
    }
    case EMAIL_HANDLES.UPSELL_DISCOUNT: {
      changesMade = `<p style="margin: 0; padding:5px;">  ${details?.order?.customer?.firstName} ${details?.order?.customer?.lastName} added ${details?.productName} to order ${details?.order?.name} through upsell list.</p>
        <p style="margin: 0;  padding:7px 0px;"><strong>Product name:</strong> ${details?.productName}</p>
        <p style="margin: 0;  padding:7px 0px;"><strong>Upsell revenue:</strong> ${details?.upsellAmount}</p>
        
          <a href=${details?.redirectUrl} style="display: inline-block; background-color: #008060; color: #fff; padding: 10px 20px; text-decoration: none; border-radius: 4px;  margin-top: 15px;margin-bottom:20px;">View Order</a>

        `
      break;

    }
    case EMAIL_HANDLES.CANCEL_ORDER_EMAIL: {
      changesMade = `<p style="margin: 0; padding:5px;"> ${details?.order?.customer?.firstName} ${details?.order?.customer?.lastName} cancelled order ${details?.order?.name} on ${new Date(details?.order?.cancelledAt).toDateString()}</p>
        <p style="margin: 0; padding:7px 0px;"><strong>Refund Amount:</strong>${details?.order?.totalRefundedSet?.presentmentMoney?.currencyCode} ${details?.order?.totalRefundedSet?.presentmentMoney?.amount}</p>
      ${details?.restock ? `<p style="margin: 0; padding:7px 0px;"><strong>Restocking Fee:</strong> ${details?.restokingFee ? details?.restokingFee : "0.0"}</p>` : ""} 
        <p style="margin: 0; padding:7px 0px;"><strong>Cancellation Reason :</strong> ${details?.staffNote ? details?.staffNote : ""}</p>
        
          <a href=${details?.redirectUrl} style="display: inline-block; background-color: #008060; color: #fff; padding: 10px 20px; text-decoration: none; border-radius: 4px; margin-top: 15px;margin-bottom:20px;">View Order</a> `
      break;

    }
    case EMAIL_HANDLES.UPDATE_CONTACT_INFO: {
      changesMade = `<p style="margin: 0; padding:7px 0px"> ${details?.order?.customer?.firstName} ${details?.order?.customer?.lastName} updated contact info in order ${details?.order?.name} on ${new Date(details?.order?.updatedAt).toDateString()}</p>
              <p style="margin: 0; padding:10px 0px;"><strong>Updated Email Address :</strong> ${details?.email}</p>
          <a href=${details?.redirectUrl} style="display: inline-block; background-color: #008060; color: #fff; padding: 10px 20px; text-decoration: none; border-radius: 4px;  margin-top: 15px;margin-bottom:20px;">View Order</a> `
      break;

    }
    case EMAIL_HANDLES.SWAP_ITEM: {
      changesMade = `<p style="margin: 0; padding:7px 0px"> ${details?.order?.customer?.firstName} ${details?.order?.customer?.lastName} changed item in order ${details?.order?.name} on ${new Date(details?.order?.updatedAt).toDateString()}</p>
             <p style="margin: 0;  padding:10px 0px;">  ${details?.order?.customer?.firstName} ${details?.order?.customer?.lastName} Changed ${details?.removedTitle} to variant ${details?.addedTitle} in order ${details?.order?.name} .</p>
          <a href=${details?.redirectUrl} style="display: inline-block; background-color: #008060; color: #fff; padding: 10px 20px; text-decoration: none; border-radius: 4px;  margin-top: 15px;margin-bottom:20px;">View Order</a> `
      break;

    }
    case EMAIL_HANDLES.UPDATE_SHIPPING: {
      changesMade = `<p style="margin: 0; padding:7px 0px"> ${details?.order?.customer?.firstName} ${details?.order?.customer?.lastName} updated Shipping Address in order ${details?.order?.name} on ${new Date(details?.order?.updatedAt).toDateString()}</p>
                    <p style="margin: 0; padding:10px 0px;"><strong>Updated Shipping Address:</strong> </p>

      ${details?.order?.shippingAddress?.name ? ` <p style="font-size: 15px;margin: 0;">${details?.order?.shippingAddress?.name}</p>` : ''}
      ${details?.order?.shippingAddress?.company ? ` <p style="font-size: 15px;margin: 0;">${details?.order?.shippingAddress?.company}</p>` : ''}
      ${details?.order?.shippingAddress?.address1 ? ` <p style="font-size: 15px;margin: 0;">${details?.order?.shippingAddress?.address1}</p>` : ''}
      ${details?.order?.shippingAddress?.city ? ` <p style="font-size: 15px; margin: 0;">${details?.order?.shippingAddress?.city}</p>` : ''}
      ${details?.order?.shippingAddress?.provinceCode ? ` <p style="font-size: 15px;margin: 0;">${details?.order?.shippingAddress?.provinceCode}</p>` : ''}
      ${details?.order?.shippingAddress?.phone ? ` <p style="font-size: 15px;margin: 0;">${details?.order?.shippingAddress?.phone}</p>` : ''}
      ${details?.order?.shippingAddress?.zip ? ` <p style="font-size: 15px; margin: 0;">${details?.order?.shippingAddress?.zip}</p>` : ''}
      ${details?.order?.shippingAddress?.country ? ` <p style="font-size: 15px; margin: 0;">${details?.order?.shippingAddress?.country}</p>` : ''}
     <a href=${details?.redirectUrl} style="display: inline-block; background-color: #008060; color: #fff; padding: 10px 20px; text-decoration: none; border-radius: 4px; margin-top: 15px;margin-bottom:20px;">View Order</a> `
      break;

    }
    case EMAIL_HANDLES.EDIT_ORDER: {

      const editedList = details?.updatedList.map((nodes) => {
        return `<p style="margin: 0; padding:7px 0px"><strong>Title :</strong>  ${nodes?.title} <strong>Quantity : </strong>${nodes?.quantity} </p>
`
      })
      changesMade = `<p style="margin: 0; padding:7px 0px;"> ${details?.order?.customer?.firstName} ${details?.order?.customer?.lastName} edited order in order ${details?.order?.name} on ${new Date(details?.order?.updatedAt).toDateString()}</p>
                    <p style="margin: 0;padding:7px 0px"><strong>Updated Quantity:</strong> </p>
                    <p style="margin: 0; padding:0px 0px">${editedList.join(" ")}</p>
     <a href=${details?.redirectUrl} style="display: inline-block; background-color: #008060; color: #fff; padding: 10px 20px; text-decoration: none; border-radius: 4px;  margin-top: 15px;margin-bottom:20px;">View Order</a> `
      break;
    }

  }
  let orderSummaryBody = ""
  if (!details?.isMarketting) {
    orderSummaryBody = await summary(details, recipients, changesMade)
  }
  const data = {
    from: process.env.SMTP_USER_EMAIL,
    to: recipients,
    subject: `Order Edit in ${details?.shopName} order ${details?.order?.name}`,
    replyTo: details?.order?.customer?.email,
    html: `
<div style="margin: 0; padding: 0; font-family: Arial, sans-serif; color: #333;">
  ${orderSummaryBody}
</div>
    `
  };

  return data;
};
// Generates an HTML email summary .
export const summary = async (details, merchantEmails, changesMade) => {
  const lineItemDivs = details?.order?.lineItems?.nodes.map((items) => {
    const discountAmount = `Discount -${items?.totalDiscountSet?.presentmentMoney?.amount} ${items?.totalDiscountSet?.presentmentMoney?.currencyCode}`;
    return ` <tr>
      <td style="padding: 10px; border-bottom: 1px solid #ddd;">
        <img src=${items?.image?.url} alt="Product Image" style="width: 100px; height: 100px; border-radius: 8px; border: 1px solid gray;"/>
      </td>
      <td style="padding: 10px; border-bottom: 1px solid #ddd;">
        <p style="font-size: 16px; color: #333; margin: 0;">${items?.title}</p>
        <p style="font-size: 15px; color: #333; font-weight: 500; margin: 4px 0px;"> ${items?.originalUnitPriceSet?.presentmentMoney?.amount} × ${items?.quantity}</p>
        <p style="font-size: 15px; color: #666; font-weight: 400; margin: 4px 0px;">SKU: ${items?.sku}</p>
        <p style="font-size: 15px; color: #666; font-weight: 400; margin: 4px 0px;">${items?.currentQuantity == 0 ? "Removed" : ""}</p>
        <p style="font-size: 14px; color: #666; display: flex; gap: 5px">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" >
<path d="M3.41 13.41L10.58 20.58C10.7657 20.766 10.9863 20.9135 11.2291 21.0141C11.4719 21.1148 11.7322 21.1666 11.995 21.1666C12.2578 21.1666 12.5181 21.1148 12.7609 21.0141C13.0037 20.9135 13.2243 20.766 13.41 20.58L22 12V2H12L3.41 10.59C3.0375 10.9647 2.82841 11.4716 2.82841 12C2.82841 12.5284 3.0375 13.0353 3.41 13.41Z" stroke="#949494" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M17 7H16.99" stroke="#949494" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
${discountAmount}</p>
      </td>
      <td style="padding: 10px; border-bottom: 1px solid #ddd; font-size: 14px; color: #666; font-weight: 500;">${items?.discountedTotalSet?.presentmentMoney?.amount} ${items?.discountedTotalSet?.presentmentMoney?.currencyCode}</td>
    </tr>`
  })
  const htmlBody =
    `
    <hr style="border: 0; height: 1px; background: #ddd; margin-top: 20px; margin-bottom: 10px;"/>
      <h2 style="font-size: 20px;">${details?.shopName}</h2>
      <h3 style="font-size: 28px;"> ${details?.order?.customer?.firstName} ${details?.order?.customer?.lastName} edited order ${details?.order?.name} on ${new Date(details?.order?.updatedAt).toDateString()}.</h3>
      <p style="text-align: left; font-size: 21px; margin:0px">Changes Made </p>
      <div style="color: #666; font-size: 21px;">${changesMade}</div>
  <div
    style=" font-family: Arial, sans-serif;  background-color: #f4f4f4; margin: 0; padding: 30px;">
    <div class="container" style="background-color: #fff; padding: 20px; border-radius: 8px; max-width: 600px; margin: auto; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);">
 
  <h2 style="font-size: 20px; color: #333; margin-bottom: 10px">Updated Order Summary</h2>

  <table style="width: 100%; border-collapse: collapse;">
   ${lineItemDivs.join('')}
  </table>

  <h3 style="font-size: 18px; color: #333; margin-top: 20px;">Order Details</h3>
  <table style="width: 100%; border-collapse: collapse;">
    <tr>
      <td style="padding: 8px; font-weight: 700;">Subtotal:</td>
      <td style="padding: 8px; text-align: right;font-weight: 700;">${details?.order?.currentSubtotalPriceSet?.presentmentMoney?.amount} ${details?.order?.currentSubtotalPriceSet?.presentmentMoney?.currencyCode}</td>
    </tr>
    <tr>
      <td style="padding: 8px; font-weight: 700;">Order discount:</td>
      <td style="padding: 8px; text-align: right;font-weight: 700;">-${details?.order?.totalDiscountsSet?.presentmentMoney?.amount} ${details?.order?.totalDiscountsSet?.presentmentMoney?.currencyCode}</td>
    </tr>
    <tr>
      <td style="padding: 8px; font-weight: 700;">Shipping :</td>
      <td style="padding: 8px; text-align: right;font-weight: 700;">${details?.order?.totalShippingPriceSet?.presentmentMoney?.amount} ${details?.order?.totalShippingPriceSet?.presentmentMoney?.currencyCode}</td>
    </tr>
     <tr>
      <td style="padding: 8px; font-weight: 700;">Tax:</td>
      <td style="padding: 8px; text-align: right; font-weight: 700;">${details?.order?.totalTaxSet?.presentmentMoney?.amount} ${details?.order?.totalTaxSet?.presentmentMoney?.currencyCode}</td>
    </tr>
     <tr>
      <td style="padding: 8px; font-weight: 700;">Paid:</td>
      <td style="padding: 8px; text-align: right; font-weight: 700;">${details?.order?.totalReceivedSet?.presentmentMoney?.amount} ${details?.order?.totalReceivedSet?.presentmentMoney?.currencyCode}</td>
    </tr>
     <tr>
      <td style="padding: 8px; font-weight: 700;">Remaining:</td>
      <td style="padding: 8px; text-align: right; font-weight: 700;">${details?.order?.totalOutstandingSet?.presentmentMoney?.amount < 0 ? 0 : details?.order?.totalOutstandingSet?.presentmentMoney?.amount} ${details?.order?.totalOutstandingSet?.presentmentMoney?.currencyCode}</td>
    </tr>
    <tr>
      <td style="padding: 8px; font-weight: 700;">Total:</td>
      <td style="padding: 8px; text-align: right; font-weight: 700;">${details?.order?.currentTotalPriceSet?.presentmentMoney?.amount} ${details?.order?.currentTotalPriceSet?.presentmentMoney?.currencyCode}</td>
    </tr>
  </table>

  <hr style="border: 0; height: 1px; background: #ddd; margin-top: 20px; margin-bottom: 20px;"/>

  <h3 style="font-size: 18px; color: #333;">Payment & Shipping</h3>
  <p style="font-size: 15px; color: #666;"><strong>Payment method:</strong> ${details?.order?.paymentGatewayNames.join(" , ")}</p>
  
  <h3 style="font-size: 16px; color: #333; margin-top: 20px;">Shipping Address</h3>
${details?.order?.shippingAddress?.name ? ` <p style="font-size: 15px; color: #666;margin: 0;">${details?.order?.shippingAddress?.name}</p>` : ''}
${details?.order?.shippingAddress?.company ? ` <p style="font-size: 15px; color: #666;margin: 0;">${details?.order?.shippingAddress?.company}</p>` : ''}
${details?.order?.shippingAddress?.address1 ? ` <p style="font-size: 15px; color: #666;margin: 0;">${details?.order?.shippingAddress?.address1}</p>` : ''}
${details?.order?.shippingAddress?.city ? ` <p style="font-size: 15px; color: #666;margin: 0;">${details?.order?.shippingAddress?.city}</p>` : ''}
${details?.order?.shippingAddress?.provinceCode ? ` <p style="font-size: 15px; color: #666;margin: 0;">${details?.order?.shippingAddress?.provinceCode}</p>` : ''}
${details?.order?.shippingAddress?.phone ? ` <p style="font-size: 15px; color: #666;margin: 0;">${details?.order?.shippingAddress?.phone}</p>` : ''}
${details?.order?.shippingAddress?.zip ? ` <p style="font-size: 15px; color: #666;margin: 0;">${details?.order?.shippingAddress?.zip}</p>` : ''}
${details?.order?.shippingAddress?.country ? ` <p style="font-size: 15px; color: #666;margin: 0;">${details?.order?.shippingAddress?.country}</p>` : ''}
  
  <div style="margin-top: 20px; text-align: center;">
    <img style="width: 100px" src="https://cdn.shopify.com/shopifycloud/brochure/assets/brand-assets/shopify-logo-primary-logo-456baa801ee66a0a435671082365958316831c9960c480451dd0330bcdae304f.svg" alt="Shopify"/>
    <p style="font-size: 14px; color: #666;">AE - Account Editor</p>
  </div>
</div> 
  </div>
`


  return htmlBody;
};
export const orderSummary = async (details) => {
  const lineItemDivs = details?.order?.lineItems?.nodes.map((items) => {
    const discountAmount = `Discount -${items?.totalDiscountSet?.presentmentMoney?.amount} ${items?.totalDiscountSet?.presentmentMoney?.currencyCode}`;
    return `
    <tr>
      <td style="padding: 10px; border-bottom: 1px solid #ddd;">
        <img src=${items?.image?.url} alt="Product Image" style="width: 100px; height: 100px; border-radius: 8px; border: 1px solid gray;"/>
      </td>
      <td style="padding: 10px; border-bottom: 1px solid #ddd;">
        <p style="font-size: 16px; color: #333; margin: 0;">${items?.title}</p>
        <p style="font-size: 15px; color: #333; font-weight: 500; margin: 4px 0px;"> ${items?.originalUnitPriceSet?.presentmentMoney?.amount} × ${items?.quantity}</p>
        <p style="font-size: 15px; color: #666; font-weight: 400; margin: 4px 0px;">SKU: ${items?.sku}</p>
        <p style="font-size: 15px; color: #666; font-weight: 400; margin: 4px 0px;">${items?.currentQuantity == 0 ? "Removed" : ""}</p>
        <p style="font-size: 14px; color: #666; display: flex; gap: 5px">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" >
<path d="M3.41 13.41L10.58 20.58C10.7657 20.766 10.9863 20.9135 11.2291 21.0141C11.4719 21.1148 11.7322 21.1666 11.995 21.1666C12.2578 21.1666 12.5181 21.1148 12.7609 21.0141C13.0037 20.9135 13.2243 20.766 13.41 20.58L22 12V2H12L3.41 10.59C3.0375 10.9647 2.82841 11.4716 2.82841 12C2.82841 12.5284 3.0375 13.0353 3.41 13.41Z" stroke="#949494" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M17 7H16.99" stroke="#949494" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
${discountAmount}</p>
      </td>
      <td style="padding: 10px; border-bottom: 1px solid #ddd; font-size: 14px; color: #666; font-weight: 500;">${items?.discountedTotalSet?.presentmentMoney?.amount} ${items?.discountedTotalSet?.presentmentMoney?.currencyCode}</td>
    </tr>`
  })
  const htmlBody =
    `
    <a href=${details?.redirectUrl} style="display: inline-block; background-color: #008060; color: #fff; padding: 10px 20px; text-decoration: none; border-radius: 4px;  margin-top: 15px;margin-bottom:20px;">View Order</a> 
    <hr style="border: 0; height: 1px; background: #ddd; margin-top: 20px; margin-bottom: 10px;"/>
  <div
    style=" font-family: Arial, sans-serif;  background-color: #f4f4f4; margin: 0; padding: 22px;">
    <div class="container" style="background-color: #fff; padding: 15px; border-radius: 8px; max-width: 750px; margin: auto; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);">
 
  <h2 style="font-size: 20px; color: #333; margin-bottom: 10px">Updated Order Summary</h2>

  <table style="width: 100%; border-collapse: collapse;">
   ${lineItemDivs.join('')}
  </table>

  <h3 style="font-size: 18px; color: #333; margin-top: 20px;">Order Details</h3>
  <table style="width: 100%; border-collapse: collapse;">
    <tr>
      <td style="padding: 8px; font-weight: 700;">Subtotal:</td>
      <td style="padding: 8px; text-align: right;font-weight: 700;">${details?.order?.currentSubtotalPriceSet?.presentmentMoney?.amount} ${details?.order?.currentSubtotalPriceSet?.presentmentMoney?.currencyCode}</td>
    </tr>
    <tr>
      <td style="padding: 8px; font-weight: 700;">Order discount:</td>
      <td style="padding: 8px; text-align: right;font-weight: 700;">-${details?.order?.totalDiscountsSet?.presentmentMoney?.amount} ${details?.order?.totalDiscountsSet?.presentmentMoney?.currencyCode}</td>
    </tr>
    <tr>
      <td style="padding: 8px; font-weight: 700;">Shipping :</td>
      <td style="padding: 8px; text-align: right;font-weight: 700;">${details?.order?.totalShippingPriceSet?.presentmentMoney?.amount} ${details?.order?.totalShippingPriceSet?.presentmentMoney?.currencyCode}</td>
    </tr>
     <tr>
      <td style="padding: 8px; font-weight: 700;">Tax:</td>
      <td style="padding: 8px; text-align: right; font-weight: 700;">${details?.order?.totalTaxSet?.presentmentMoney?.amount} ${details?.order?.totalTaxSet?.presentmentMoney?.currencyCode}</td>
    </tr>
     <tr>
      <td style="padding: 8px; font-weight: 700;">Paid:</td>
      <td style="padding: 8px; text-align: right; font-weight: 700;">${details?.order?.totalReceivedSet?.presentmentMoney?.amount} ${details?.order?.totalReceivedSet?.presentmentMoney?.currencyCode}</td>
    </tr>
     <tr>
      <td style="padding: 8px; font-weight: 700;">Remaining:</td>
      <td style="padding: 8px; text-align: right; font-weight: 700;">${ details?.order?.totalOutstandingSet?.presentmentMoney?.amount} ${details?.order?.totalOutstandingSet?.presentmentMoney?.currencyCode}</td>
    </tr>
    <tr>
      <td style="padding: 8px; font-weight: 700;">Total:</td>
      <td style="padding: 8px; text-align: right; font-weight: 700;">${details?.order?.currentTotalPriceSet?.presentmentMoney?.amount} ${details?.order?.currentTotalPriceSet?.presentmentMoney?.currencyCode}</td>
    </tr>
  </table>

  <hr style="border: 0; height: 1px; background: #ddd; margin-top: 20px; margin-bottom: 20px;"/>

  <h3 style="font-size: 18px; color: #333;">Payment & Shipping</h3>
  <p style="font-size: 15px; color: #666;"><strong>Payment method:</strong> ${details?.order?.paymentGatewayNames.join(" , ")}</p>
  
  <h3 style="font-size: 16px; color: #333; margin-top: 20px;">Shipping Address</h3>
${details?.order?.shippingAddress?.name ? ` <p style="font-size: 15px; color: #666;margin: 0;">${details?.order?.shippingAddress?.name}</p>` : ''}
${details?.order?.shippingAddress?.company ? ` <p style="font-size: 15px; color: #666;margin: 0;">${details?.order?.shippingAddress?.company}</p>` : ''}
${details?.order?.shippingAddress?.address1 ? ` <p style="font-size: 15px; color: #666;margin: 0;">${details?.order?.shippingAddress?.address1}</p>` : ''}
${details?.order?.shippingAddress?.city ? ` <p style="font-size: 15px; color: #666;margin: 0;">${details?.order?.shippingAddress?.city}</p>` : ''}
${details?.order?.shippingAddress?.provinceCode ? ` <p style="font-size: 15px; color: #666;margin: 0;">${details?.order?.shippingAddress?.provinceCode}</p>` : ''}
${details?.order?.shippingAddress?.phone ? ` <p style="font-size: 15px; color: #666;margin: 0;">${details?.order?.shippingAddress?.phone}</p>` : ''}
${details?.order?.shippingAddress?.zip ? ` <p style="font-size: 15px; color: #666;margin: 0;">${details?.order?.shippingAddress?.zip}</p>` : ''}
${details?.order?.shippingAddress?.country ? ` <p style="font-size: 15px; color: #666;margin: 0;">${details?.order?.shippingAddress?.country}</p>` : ''}
  
  <div style="margin-top: 20px; text-align: center;">
    <img style="width: 100px" src="https://cdn.shopify.com/shopifycloud/brochure/assets/brand-assets/shopify-logo-primary-logo-456baa801ee66a0a435671082365958316831c9960c480451dd0330bcdae304f.svg" alt="Shopify"/>
    <p style="font-size: 14px; color: #666;">AE - Account Editor</p>
  </div>
</div> 
  </div>
`


  return htmlBody;
};

// Generates an email template for welcome merchant
export const welcomeMerchantEmail = (details, merchantEmail) => {
  console.log("merchantEmail :", merchantEmail);

  const data = {
    from: process.env.SMTP_USER_EMAIL,
    to: merchantEmail,
    subject: `You now have full access to Account Editor - 100% Free`,
    replyTo: process.env.SUPPORT_EMAIL,
    html: `<div style="font-family: Arial, sans-serif; background-color: #ffffff; margin: 0; padding: 0; color: #000000; line-height: 1.6;"><!-- Logo Section -->
  <div style="text-align: center; padding: 5% 5% 2%; max-width: 370px; margin: auto;">
    <img src="https://cdn.shopify.com/s/files/1/0677/0769/9395/files/Logo.svg?v=1741934599" alt="Account Editor Logo" style="height: 60px;">
  </div>
  <!-- Welcome Section -->
  <div style="width: 90%;  margin: auto; padding: 0; max-width: 554px;">
    <h1 style="font-size: 1.5em; font-weight: bold; text-align: left; padding-bottom: 20px;">Enjoy Full Access to Account Editor <span style="color: #d7e200;">—100% Free!</span></h1>
    <p style="text-align: left;">
      <span style="background-color: #d7e200; padding: 6px 12px; font-weight: bold; border-radius: 4px;">Hello ${details?.storeOwnerName},</span>
    </p>
    <p style="font-size: 1em; text-align: left;">
      Thank you for installing Account Editor! 🎉 You're now equipped with a powerful post-purchase tool that puts your customers in control—while saving you time and increasing revenue.
    </p>
    <p style="font-size: 1em; font-weight: bold; text-align: left;">
      The best part?For a limited time only, all features are completely free—no hidden costs, no commitments!</p></div>
  <hr style="margin: 3% auto; width: 90%; max-width: 554px; border: none; border-top: 1px solid #ddd;">
  <!-- What Can You Do Section -->
  <div style="width: 90%; max-width: 554px;  margin: auto;">
    <h2 style="font-size: 1.5em; font-weight: bold; text-align: left;">WHAT CAN YOU DO WITH <span style="color: #d7e200;">ACCOUNT EDITOR?</span></h2>
    <ul style="font-size: 1em; padding-left: 5%;">
      <li><strong>Order Editing Window:</strong> Let customers edit their shipping address, contact details, product variants, and quantities within a set timeframe after purchase.</li>
      <li><strong>Smart Cancellations:</strong> Allow order cancellations with custom reasons & optional restocking fees (so you don’t lose out!).</li>
      <li><strong>Upsell Module:</strong> Increase revenue by showcasing relevant products on the Thank You and Order Status pages.</li>
    </ul>
  </div>
  <!-- Divider -->
  <hr style="margin: 3% auto; width: 90%; max-width: 554px; border: none; border-top: 1px solid #ddd;">
  <!-- Get Started Section -->
  <div style="width: 90%; max-width: 554px; margin: auto;">
    <h2 style="font-size: 1.5em; font-weight: bold; text-align: left;">GET STARTED IN JUST 3 STEPS:</h2>
    <ol style="font-size: 1em; padding-left: 5%; margin-top: 10px;">
      <li><strong>Go to Account Editor Settings in your Shopify Admin.</strong></li>
      <li><strong>Customize your order editing timeframe, cancellation policies, and upsell rules.</strong></li>
      <li><strong>Watch as customers effortlessly manage their own orders!</strong></li>
    </ol>
    <!-- CTA Button -->
    <div style="text-align: left; margin: 5% 0;" >
      <a href=${details?.adminUrl} target="_blank"  style="display: flex; width: fit-content; gap: 15px; background-color: #000000; color: #ffffff; text-decoration: none; padding: 12px 25px; font-weight: bold; border-radius: 6px; font-size: 1em;">
        Access Account Editor Now <img src="https://cdn.shopify.com/s/files/1/0677/0769/9395/files/Vector.svg?v=1741934878" style ="width: 12px;height: 100%;padding-left: 9px;padding-top: 5px;" alt="Vector">
      </a> 
    </div>
    <!-- Support Note -->
    <p style="font-size: 0.9em; color: #444444; text-align: left;">
      Need help? Our support team is here for you—just reply to this email.
    </p>
    <p style="font-size: 0.9em; color: #444444; text-align: left;">
      Welcome aboard! We’re excited to see how Account Editor transforms your store. 🚀
    </p>
  </div>
  <!-- Footer Divider -->
  <hr style="margin: 3% auto; width: 90%; max-width: 554px; border: none; border-top: 1px solid #ddd;">
  <!-- Footer Section -->
  <div style="width: 90%; max-width: 554px; margin: auto; text-align: left;">
    <h4 style="font-size: 1.3em; font-weight: bold;">
      <span style="background-color: yellow; color: black; padding: 2px 6px;">FOLLOW US</span>
    </h4>
    <!-- Social Icons -->
    <p style="margin: 12px 0;" >
      <a href="https://www.facebook.com/profile.php?id=61571961765625" style="margin: 0 5px;"><img src="https://cdn.shopify.com/s/files/1/0677/0769/9395/files/Frame.svg?v=1741934878" alt="facebook" style="height: 24px;"></a>
      <a href="https://x.com/account_editor" style="margin: 0 5px;"><img src="https://cdn.shopify.com/s/files/1/0677/0769/9395/files/Frame-1.svg?v=1741934878" alt="x.com" style="height: 24px;"></a>
      <a href="https://www.instagram.com/account_editor_app/" style="margin: 0 5px;"><img src="https://cdn.shopify.com/s/files/1/0677/0769/9395/files/Frame-2.svg?v=1741934878" alt="instagram" style="height: 24px;"></a>
      <a href="https://www.linkedin.com/company/account-editor/" style="margin: 0 5px;"><img src="https://cdn.shopify.com/s/files/1/0677/0769/9395/files/Frame-3.svg?v=1741934879" alt="LinkedIn" style="height: 24px;"></a>   
    </p>
    <!-- Team & Website -->
    <p style="font-size: 0.9em; color: #000000;">
      Best Wishes,<br>
      Account Editor Team<br>
      <a href="https://accounteditor.com"  style="color: #000; text-decoration: none; font-weight: bold; text-decoration: underline;">accounteditor.com</a>
    </p>
    <hr>
    <p style="font-size: 0.8em; color: #666; text-align: center;">© 2025 Account Editor. All rights reserved.</p>
  </div>
</div>`
  };

  return data;
};

//after 1 day of installation
export const orderEditingSupportEmail = (details, merchantEmail) => {
  const data = {
    from: process.env.SMTP_USER_EMAIL,
    to: merchantEmail,
    subject: `Order Edits? You Decide When They Happen!`,
    replyTo: process.env.SUPPORT_EMAIL,
    html: ` 
   <div style="background-color: #F8F7F2; padding-bottom: 49px;">
  <!-- Logo Section -->
  <div style="text-align: center; padding:44px 0px; max-width: 554px; margin: 0 auto;">
    <img src="https://cdn.shopify.com/s/files/1/0596/6384/3496/files/Logo.svg?v=1742458502" alt="Account Editor Logo" style="height: 55px;">
  </div>

  <!-- Welcome Section -->
  <div style="width: 90%;  margin: auto; padding: 0; max-width: 554px;">
    <h1 style="font-size: 26px; font-weight: bold; text-align: left; padding-bottom: 20px; line-height: normal; text-transform: uppercase;">Take Control with the <br><span style="color: #d7e200;">Order Editing Timeframe</span>: Flexible, Fast, and Seamless!</h1>

    <p style="text-align: left; margin-bottom: 25px;">
      <span style="background-color: #E6FF2A; padding: 9px 16px; font-weight: bold; border-radius: 4px; font-size: 14px;">Hello ${details?.storeOwnerName},</span>
    </p>

    <p style="font-size: 1em; text-align: left;">
      Welcome aboard the Account Editor family! Now that you’ve had the app for a day, we’re excited to introduce you to an exciting feature: <strong> Order Editing Timeframe.</strong>
    </p>

  </div>
</div>

  <!-- Why use Section -->
  <div style="width: 90%; max-width: 554px;  margin: auto; padding-top: 50px;">
    <h2 style="font-size: 26px; font-weight: bold; text-align: left; margin: 0; line-height: normal; text-transform: uppercase;">Why use <span style="color: #d7e200;">Order Editing Timeframes?</span></h2>
    
    <ul style="font-size: 1em; padding-left: 5%;">
      <li><strong> Set the clock:</strong> Choose the editing window that works for you. (whether 15 mins. or 1hr it's totally up to you!).</li>
      <li><strong>Keep it simple:</strong> Reduce order management headaches and give your customers the power to edit their orders.</li>
    </ul>
  </div>

  <!-- Divider -->
  <hr style="margin: 3% auto; width: 90%; max-width: 554px; border: none; border-top: 1px solid #ddd;">

  <!-- Why Merchants Love Section -->
  <div style="width: 90%; max-width: 554px;  margin: auto;">
    <h2 style="font-size: 26px; font-weight: bold; text-align: left; text-transform: uppercase;">How Does It Work?</h2>

    <p style="font-size: 1em; padding-left: 1%; list-style: auto; margin-bottom: 25px;">
      <strong>1. Go to the Account Editor dashboard and navigate to timeframe settings.</strong>
    </p> 
    <div>
      <img src="https://account-editor.s3.ap-south-1.amazonaws.com/public/1743157614497-912bea2d391b.png" alt="Dashboard" style="max-width: 520px; width: 100%;" />
    </div> 
    <p style="font-size: 1em; padding-left: 1%; list-style: auto; margin-bottom: 25px;">
      <strong>2. Choose the timeframe that works best for you(eg. 30 mins.,1hr or custom)</strong>
    </p> 
    <div>
      <img src="https://cdn.shopify.com/s/files/1/0596/6384/3496/files/Dashboard2.png?v=1742459145" alt="Dashboard" style="max-width: 520px; width: 100%;" />
    </div> 
    <p style="font-size: 1em; padding-left: 1%; list-style: auto; margin-bottom: 25px;">
      <strong>3. Select the fields you want your customers to edit.</strong>
    </p> 
    <div>
      <img src="https://cdn.shopify.com/s/files/1/0596/6384/3496/files/Dashboard3.png?v=1742459145" alt="Dashboard" style="max-width: 520px; width: 100%;" />
    </div> 
    
  </div>


  <!-- Get Started Section -->
  <div style="width: 90%; max-width: 554px; margin: auto;">
    <!-- CTA Button -->
    <div style="text-align: left; margin: 50px 0;" >
      <a href=${details?.adminUrl} target="_blank"  style="display: flex; width: fit-content; gap: 15px; background-color: #000000; color: #ffffff; text-decoration: none; padding: 12px 25px; font-weight: bold; border-radius: 6px; font-size: 1em;">
        Setup Now <img src="https://cdn.shopify.com/s/files/1/0677/0769/9395/files/Vector.svg?v=1741934878" style ="width: 12px;height: 100%;padding-left: 9px;padding-top: 5px;" alt="Vector">
      </a> 
    </div>

    <!-- Support Note --> 
     <h3 style="text-transform: uppercase; font-size: 20px; margin: 0; margin-bottom: 15px; line-height: normal;"> <span style="color: #d7e200;">Need a helping</span> hand?</h3>
    <p style="font-size: 1em; color: #1E1E1E; text-align: left;">
      Our team is ready to assist! Contact us anytime at <br> <strong>support@accounteditor.com. </strong>
    </p>

  </div>

  <!-- Footer Section -->
  <div style="background-color: #F8F7F2; margin-top: 50px; padding: 50px 0px;">
  <div style="width: 90%; max-width: 554px; margin: auto; text-align: left;">
    <h4 style="font-size: 1.3em; font-weight: bold; margin: 0; margin-bottom: 20px;">
      <span style="background-color: yellow; color: black; padding: 2px 6px;">FOLLOW US</span>
    </h4>

    <!-- Social Icons -->
    <p style="margin: 12px 0;" >
      <a href="https://www.facebook.com/profile.php?id=61571961765625" style="margin: 0 5px;"><img src="https://cdn.shopify.com/s/files/1/0677/0769/9395/files/Frame.svg?v=1741934878" alt="facebook" style="height: 24px;"></a>
      <a href="https://x.com/account_editor" style="margin: 0 5px;"><img src="https://cdn.shopify.com/s/files/1/0677/0769/9395/files/Frame-1.svg?v=1741934878" alt="x.com" style="height: 24px;"></a>
      <a href="https://www.instagram.com/account_editor_app/" style="margin: 0 5px;"><img src="https://cdn.shopify.com/s/files/1/0677/0769/9395/files/Frame-2.svg?v=1741934878" alt="instagram" style="height: 24px;"></a>
      <a href="https://www.linkedin.com/company/account-editor/" style="margin: 0 5px;"><img src="https://cdn.shopify.com/s/files/1/0677/0769/9395/files/Frame-3.svg?v=1741934879" alt="LinkedIn" style="height: 24px;"></a>   
    </p>

    <!-- Team & Website -->
    <p style="font-size: 0.9em; color: #000000;">
      Best Wishes,<br>
      Account Editor Team<br>
      <a href="https://accounteditor.com"  style="color: #000; text-decoration: none; font-weight: bold; text-decoration: underline;">accounteditor.com</a>
    </p>
    <hr>
    <p style="font-size: 13px; color: #1E1E1E; text-align: center; margin-bottom: 0px; margin-top: 10px;">© 2025 Account Editor. All rights reserved.</p>
  </div> 
</div>
   `
  };

  return data;
};

//3 days after installation
export const upsellSupportEmail = (details, merchantEmail) => {
  const data = {
    from: process.env.SMTP_USER_EMAIL,
    to: merchantEmail,
    subject: `Ready to Increase Sales? Learn How Account Editor Helps You Upsell!`,
    replyTo: process.env.SUPPORT_EMAIL,
    html: `
    <div style="background-color: #F8F7F2; padding-bottom: 49px;">
  <!-- Logo Section -->
  <div style="text-align: center; padding:44px 0px; max-width: 554px; margin: 0 auto;">
    <img src="https://cdn.shopify.com/s/files/1/0596/6384/3496/files/Logo.svg?v=1742458502" alt="Account Editor Logo" style="height: 55px;">
  </div>

  <!-- Welcome Section -->
  <div style="width: 90%;  margin: auto; padding: 0; max-width: 554px;">
    <h1 style="font-size: 26px; font-weight: bold; text-align: left; padding-bottom: 20px; line-height: normal; text-transform: uppercase;">Take Control of Your Upselling Strategy with <span style="color: #d7e200;">Upsell Rules!</span></h1>

    <p style="text-align: left; margin-bottom: 25px;">
      <span style="background-color: #E6FF2A; padding: 9px 16px; font-weight: bold; border-radius: 4px; font-size: 14px;">Hello ${details?.storeOwnerName},</span>
    </p>

    <p style="font-size: 1em; text-align: left;"> 
      Did you know that Account Editor not only allows your customers to edit orders on the go, but also helps you <strong> boost revenue and sales</strong> with its <strong> upselling feature?</strong>
    </p>

  </div>
</div>

  <!-- Why use Section -->
  <div style="width: 90%; max-width: 554px;  margin: auto; padding-top: 50px;">
    <h2 style="font-size: 26px; font-weight: bold; text-align: left; margin: 0; line-height: normal; text-transform: uppercase;">Why you’ll <span style="color: #d7e200;">love this!</span></h2>
    
    <ul style="font-size: 1em; padding-left: 5%;">
      <li><strong>Custom Upsell Rules:</strong> Create custom upsell rules based on cart value, customer segment, or collections.</li>
      <li><strong>Granular Control:</strong> You have full control over which upsell item is shown to each customer.</li> 
      <li><strong>Dynamic Discounting:</strong> Apply discounts to upsell items, making the deals irresistible for your customers.</li>
    </ul>
  </div>

  <!-- Divider -->
  <hr style="margin: 3% auto; width: 90%; max-width: 554px; border: none; border-top: 1px solid #ddd;">

  <!-- Why Merchants Love Section -->
  <div style="width: 90%; max-width: 554px;  margin: auto;">
    <h2 style="font-size: 26px; font-weight: bold; text-align: left; text-transform: uppercase;">How Does It Work?</h2>

    <p style="font-size: 1em; padding-left: 1%; list-style: auto; margin-bottom: 25px;">
      <strong>1. Go to the Account Editor Dashboard and navigate to upsell settings.</strong>
    </p> 
    <div>
      <img src="https://account-editor.s3.ap-south-1.amazonaws.com/public/1743157614497-912bea2d391b.png" alt="Dashboard" style="max-width: 520px; width: 100%;" />
    </div> 
    <p style="font-size: 1em; padding-left: 1%; list-style: auto; margin-bottom: 25px;">
      <strong>2. Click on the create upsell button to create your first upsell rule.</strong>
    </p> 
    <div>
      <img src="https://cdn.shopify.com/s/files/1/0596/6384/3496/files/Dashboard5.png?v=1742458813" alt="Dashboard" style="max-width: 520px; width: 100%;" />
    </div> 
    <p style="font-size: 1em; padding-left: 1%; list-style: auto; margin-bottom: 25px;">
      <strong>3. Name the upsell rule you  want to create, select the upsell conditions and items you wish to show and setup discounts.</strong>
    </p> 
    <div>
      <img src="https://cdn.shopify.com/s/files/1/0596/6384/3496/files/Dashboard6.png?v=1742458848" alt="Dashboard" style="max-width: 520px; width: 100%;" />
    </div> 
    
  </div>


  <!-- Get Started Section -->
  <div style="width: 90%; max-width: 554px; margin: auto;">
    <!-- CTA Button -->
    <div style="text-align: left; margin: 50px 0;" >
      <a href=${details?.adminUrl} target="_blank"  style="display: flex; width: fit-content; gap: 15px; background-color: #000000; color: #ffffff; text-decoration: none; padding: 12px 25px; font-weight: bold; border-radius: 6px; font-size: 14px;">
        Setup Now <img src="https://cdn.shopify.com/s/files/1/0677/0769/9395/files/Vector.svg?v=1741934878" style ="width: 12px;height: 100%;padding-left: 9px;padding-top: 5px;" alt="Vector"> 
      </a> 
    </div> 

    <!-- Note --> 
     <div style="margin-bottom:50px;"> 
      <p style="margin: 0; font-size: 16px;"><strong>Note - You can have only one active upsell rule at any given time.</strong></p>
     </div>

    <!-- Support Note --> 
     <h3 style="text-transform: uppercase; font-size: 20px; margin: 0; margin-bottom: 15px; line-height: normal;"> Need Assistance?</h3>
    <p style="font-size: 1em; color: #1E1E1E; text-align: left;">
      If you wish to learn more about our upselling feature or have any other queries feel free to contact us at <strong>support@accounteditor.com. </strong>
    </p>

  </div>

  <!-- Footer Section -->
  <div style="background-color: #F8F7F2; margin-top: 50px; padding: 50px 0px;">
  <div style="width: 90%; max-width: 554px; margin: auto; text-align: left;">
    <h4 style="font-size: 1.3em; font-weight: bold; margin: 0; margin-bottom: 20px;">
      <span style="background-color: yellow; color: black; padding: 2px 6px;">FOLLOW US</span>
    </h4>

   <!-- Social Icons -->
    <p style="margin: 12px 0;" >
      <a href="https://www.facebook.com/profile.php?id=61571961765625" style="margin: 0 5px;"><img src="https://cdn.shopify.com/s/files/1/0677/0769/9395/files/Frame.svg?v=1741934878" alt="facebook" style="height: 24px;"></a>
      <a href="https://x.com/account_editor" style="margin: 0 5px;"><img src="https://cdn.shopify.com/s/files/1/0677/0769/9395/files/Frame-1.svg?v=1741934878" alt="x.com" style="height: 24px;"></a>
      <a href="https://www.instagram.com/account_editor_app/" style="margin: 0 5px;"><img src="https://cdn.shopify.com/s/files/1/0677/0769/9395/files/Frame-2.svg?v=1741934878" alt="instagram" style="height: 24px;"></a>
      <a href="https://www.linkedin.com/company/account-editor/" style="margin: 0 5px;"><img src="https://cdn.shopify.com/s/files/1/0677/0769/9395/files/Frame-3.svg?v=1741934879" alt="LinkedIn" style="height: 24px;"></a>   
    </p>

    <!-- Team & Website -->
    <p style="font-size: 0.9em; color: #000000;">
      Best Wishes,<br>
      Account Editor Team<br>
      <a href="https://accounteditor.com"  style="color: #000; text-decoration: none; font-weight: bold; text-decoration: underline;">accounteditor.com</a>
    </p>
    <hr>
    <p style="font-size: 13px; color: #1E1E1E; text-align: center; margin-bottom: 0px; margin-top: 10px;">© 2025 Account Editor. All rights reserved.</p>
  </div> 
</div>`

  };

  return data;
};
// 4th day after installation
export const accountEditorSupportEmail = (details, merchantEmail) => {

  const data = {
    from: process.env.SMTP_USER_EMAIL,
    to: merchantEmail,
    subject: `Checking In: Need Any Help with Account Editor?`,
    replyTo: process.env.SUPPORT_EMAIL,
    html: `
  <div style="background-color: #F8F7F2; padding-bottom: 49px;">
  <!-- Logo Section -->
  <div style="text-align: center; padding:44px 0px; max-width: 554px; margin: 0 auto;">
    <img src="https://cdn.shopify.com/s/files/1/0596/6384/3496/files/Logo.svg?v=1742458502" alt="Account Editor Logo" style="height: 55px;">
  </div>

  <!-- Welcome Section -->
  <div style="width: 90%;  margin: auto; padding: 0; max-width: 554px;">
    <h1 style="font-size: 26px; font-weight: bold; text-align: left; padding-bottom: 20px; line-height: normal; text-transform: uppercase; margin-top: 0px;">Just Checking In—How Can We Assist You with <span style="color: #d7e200;">Account Editor?</span></h1>

    <p style="text-align: left; margin-bottom: 25px;">
      <span style="background-color: #E6FF2A; padding: 9px 16px; font-weight: bold; border-radius: 4px; font-size: 14px;">Hello ${details?.storeOwnerName},</span>
    </p>

    <p style="font-size: 1em; text-align: left;"> 
      We hope you’re having a great experience with <strong> Account Editor!</strong> As you start exploring all the new features, we wanted to check in and see if there’s anything we can do to help you get started.
    </p>

  </div>
</div>

  <!-- Why use Section -->
  <div style="width: 90%; max-width: 554px;  margin: auto; padding-top: 50px;">
    <h2 style="font-size: 26px; font-weight: bold; text-align: left; margin: 0; line-height: normal; text-transform: uppercase;">All the Features You Need In One App! - <span style="color: #d7e200;">All For FREE</span></h2>
    
    <ul style="font-size: 1em; padding-left: 5%; list-style: auto; margin-top: 20px; font-weight: 700;">
      <li style="margin-bottom: 15px; font-size: 16px;"><strong> Advanced Editing Window Timeframe</strong> </li>
      <li style="margin-bottom: 15px; font-size: 16px;"><strong>Smart Cancellation Setting With Restocking Fee</strong> </li> 
      <li style="margin-bottom: 15px; font-size: 16px;"><strong>Upselling Rules</strong></li> 
      <li style="margin-bottom: 15px; font-size: 16px;"><strong>Priority Support</strong></li>
    </ul>
  </div>

  <!-- Divider -->
  <hr style="margin: 3% auto; width: 90%; max-width: 554px; border: none; border-top: 1px solid #ddd;">

  <!-- Get started Section -->
  <div style="width: 90%; max-width: 554px;  margin: auto;">
    <h2 style="font-size: 26px; font-weight: bold; text-align: left; text-transform: uppercase;"><span style="color: #d7e200;">Get Started</span> With These Resources</h2>
    <p>We’ve made it easy for you to hit the ground running. Explore these resources to get the most out of your new features:</p>
    <ul style="font-size: 1em; padding-left: 5%; font-weight: 700; margin-bottom: 50px;">
      <li style="margin-bottom: 10px;"><a href="https://www.accounteditor.com/faqs" style="font-size: 16px; color: #1E1E1E;">FAQs</a></li>
    </ul>
    
  </div>

<!-- Support Note --> 
  <div style="width: 90%; max-width: 554px; margin: auto;">
    <p style="font-size: 16px; margin-bottom: 20px; margin-top: 0px;">We are always ready to help you make the most out of Account Editor, so please feel free to reach out to us, whether it's a question or a challenge, We are Here to Help.</p>
    <p style="font-size: 1em; color: #1E1E1E; text-align: left;">
      Contact us at  <br> <strong>support@accounteditor.com. </strong>
    </p>
  </div> 

  <div style="width: 90%; max-width: 554px; margin: auto; margin-top: 50px; margin-bottom: 50px;">
    <p style="font-size: 16px;"><strong>We’re excited to see how Account Editor will benefit your business!</strong></p>
  </div>

  <!-- Footer Section -->
  <div style="background-color: #F8F7F2; margin-top: 50px; padding: 50px 0px;">
  <div style="width: 90%; max-width: 554px; margin: auto; text-align: left;">
    <h4 style="font-size: 1.3em; font-weight: bold; margin: 0; margin-bottom: 20px;">
      <span style="background-color: yellow; color: black; padding: 2px 6px;">FOLLOW US</span>
    </h4>

    <!-- Social Icons -->
    <p style="margin: 12px 0;" >
      <a href="https://www.facebook.com/profile.php?id=61571961765625" style="margin: 0 5px;"><img src="https://cdn.shopify.com/s/files/1/0677/0769/9395/files/Frame.svg?v=1741934878" alt="facebook" style="height: 24px;"></a>
      <a href="https://x.com/account_editor" style="margin: 0 5px;"><img src="https://cdn.shopify.com/s/files/1/0677/0769/9395/files/Frame-1.svg?v=1741934878" alt="x.com" style="height: 24px;"></a>
      <a href="https://www.instagram.com/account_editor_app/" style="margin: 0 5px;"><img src="https://cdn.shopify.com/s/files/1/0677/0769/9395/files/Frame-2.svg?v=1741934878" alt="instagram" style="height: 24px;"></a>
      <a href="https://www.linkedin.com/company/account-editor/" style="margin: 0 5px;"><img src="https://cdn.shopify.com/s/files/1/0677/0769/9395/files/Frame-3.svg?v=1741934879" alt="LinkedIn" style="height: 24px;"></a>   
    </p>

    <!-- Team & Website -->
    <p style="font-size: 0.9em; color: #000000;">
      Best Wishes,<br>
      Account Editor Team<br>
      <a href="https://accounteditor.com"  style="color: #000; text-decoration: none; font-weight: bold; text-decoration: underline;">accounteditor.com</a>
    </p>
    <hr>
    <p style="font-size: 13px; color: #1E1E1E; text-align: center; margin-bottom: 0px; margin-top: 10px;">© 2025 Account Editor. All rights reserved.</p>
  </div> 
</div>`

  };

  return data;
};
// Generates an email template for community support
export const reInstallRequest = (details, merchantEmail) => {
  const data = {
    from: process.env.SMTP_USER_EMAIL,
    to: merchantEmail,
    subject: `Rediscover The Benefits of Account Editor`,
    replyTo: process.env.SUPPORT_EMAIL,
    html: `<div style="background-color: #F8F7F2; padding-bottom: 49px;">
  <!-- Logo Section -->
  <div style="text-align: center; padding:44px 0px; max-width: 554px; margin: 0 auto;">
    <img src="https://cdn.shopify.com/s/files/1/0596/6384/3496/files/Logo.svg?v=1742458502" alt="Account Editor Logo" style="height: 55px;">
  </div>

  <!-- Welcome Section -->
  <div style="width: 90%;  margin: auto; padding: 0; max-width: 554px;">
    <h1 style="font-size: 26px; font-weight: bold; text-align: left; padding-bottom: 20px; line-height: normal; text-transform: uppercase; margin-top: 0px;">Your  <span style="color: #d7e200;">Account Editor</span> Journey is Waiting – Let’s Pick Up Where You Left Off! </span></h1>

    <p style="text-align: left; margin-bottom: 25px;">
      <span style="background-color: #E6FF2A; padding: 9px 16px; font-weight: bold; border-radius: 4px; font-size: 14px;">Hello ${details?.storeOwnerName},</span>
    </p>

    <p style="font-size: 1em; text-align: left;"> 
      We noticed that you took a step away from Account Editor we understand things change, but we just want to remind you of the benefits it can have for your business.
    </p>
  </div>
</div>

  <!-- Why use Section -->
  <div style="width: 90%; max-width: 554px;  margin: auto; padding-top: 50px;">
    <h2 style="font-size: 26px; font-weight: bold; text-align: left; margin: 0; line-height: normal; text-transform: uppercase;">Here is why a community of merchants <span style="color: #d7e200;">trust Account Editor: </span></h2>
    
    <ul style="font-size: 1em; padding-left: 5%;  margin-top: 20px;">
      <li style="margin-bottom: 15px; font-size: 16px;"><strong>Edits:</strong> Customers can edit their orders post-purchase, giving them control while saving you time. </li>
      <li style="margin-bottom: 15px; font-size: 16px;"><strong>Fewer Support tickets:</strong> Spend less time on support tickets so that you can focus more on growth.</li> 
      <li style="margin-bottom: 15px; font-size: 16px;"><strong>Happier Customers:</strong> With a smoother post-purchase experience customers are more likely to revisit your store.</li> 
      <li style="margin-bottom: 15px; font-size: 16px;"><strong>Increased Average Order Value:</strong> Increase the average order value of your store with conditional upsell rules.</li>
    </ul>
  </div>

  <div style="width: 90%; max-width: 554px;  margin: auto;">
    <!-- CTA Button -->
    <div style="text-align: left; margin: 50px 0;" >
      <a href=${details?.adminUrl} target="_blank"  style="display: flex; width: fit-content; gap: 15px; background-color: #000000; color: #ffffff; text-decoration: none; padding: 12px 25px; font-weight: bold; border-radius: 6px; font-size: 14px;">
        Revisit Account Editor Today <img src="https://cdn.shopify.com/s/files/1/0677/0769/9395/files/Vector.svg?v=1741934878" style ="width: 12px;height: 100%;padding-left: 9px;padding-top: 5px;" alt="Vector">
      </a> 
    </div>
    
  </div>

<!-- Support Note --> 
  <div style="width: 90%; max-width: 554px; margin: auto;">
    <p style="font-size: 16px; margin-bottom: 20px; margin-top: 0px;">Questions about getting started again? Our team is here to help—don’t hesitate to reach out!</p>
    <p style="font-size: 1em; color: #1E1E1E; text-align: left;">
      Contact us at  <br> <strong>support@accounteditor.com. </strong>
    </p>
  </div> 

  <!-- Footer Section -->
  <div style="background-color: #F8F7F2; margin-top: 50px; padding: 50px 0px;">
  <div style="width: 90%; max-width: 554px; margin: auto; text-align: left;">
    <h4 style="font-size: 1.3em; font-weight: bold; margin: 0; margin-bottom: 20px;">
      <span style="background-color: yellow; color: black; padding: 2px 6px;">FOLLOW US</span>
    </h4>

    <!-- Social Icons -->
    <p style="margin: 12px 0;" >
      <a href="https://www.facebook.com/profile.php?id=61571961765625" style="margin: 0 5px;"><img src="https://cdn.shopify.com/s/files/1/0677/0769/9395/files/Frame.svg?v=1741934878" alt="facebook" style="height: 24px;"></a>
      <a href="https://x.com/account_editor" style="margin: 0 5px;"><img src="https://cdn.shopify.com/s/files/1/0677/0769/9395/files/Frame-1.svg?v=1741934878" alt="x.com" style="height: 24px;"></a>
      <a href="https://www.instagram.com/account_editor_app/" style="margin: 0 5px;"><img src="https://cdn.shopify.com/s/files/1/0677/0769/9395/files/Frame-2.svg?v=1741934878" alt="instagram" style="height: 24px;"></a>
      <a href="https://www.linkedin.com/company/account-editor/" style="margin: 0 5px;"><img src="https://cdn.shopify.com/s/files/1/0677/0769/9395/files/Frame-3.svg?v=1741934879" alt="LinkedIn" style="height: 24px;"></a>   
    </p>
    <!-- Team & Website -->
    <p style="font-size: 0.9em; color: #000000;">
      Best Wishes,<br>
      Account Editor Team<br>
      <a href="https://accounteditor.com"  style="color: #000; text-decoration: none; font-weight: bold; text-decoration: underline;">accounteditor.com</a>
    </p>

    <!-- Policy Links -->
    <p style="font-size: 0.8em; color: #444; text-align: center; margin-top: 50px; margin-bottom: 10px;">
      <a href="#" style="text-decoration: none; color: #000; margin: 0 8px;">FAQ's</a> |
      <a href="#" style="text-decoration: none; color: #000; margin: 0 8px;">Blogs</a> |
      <a href="#" style="text-decoration: none; color: #000; margin: 0 8px;">Privacy Policy</a> |
      <a href="#" style="text-decoration: none; color: #000; margin: 0 8px;">Terms of Service</a>
    </p>
    <hr>
    <p style="font-size: 13px; color: #1E1E1E; text-align: center; margin-bottom: 0px; margin-top: 10px;">© 2025 Account Editor. All rights reserved.</p>
  </div> 
</div>`
  };

  return data;
};


//on app uninstall
export const unInstallEmail = (details, merchantEmail) => {

  const data = {
    from: process.env.SMTP_USER_EMAIL,
    to: merchantEmail,
    subject: `Sorry to see you leave Account Editor, let us know what happened `,
    replyTo: process.env.SUPPORT_EMAIL,
    html: ` <div style="background-color: #F8F7F2; padding-bottom: 49px;">
  <!-- Logo Section -->
  <div style="text-align: center; padding:44px 0px; max-width: 554px; margin: 0 auto;">
    <img src="https://cdn.shopify.com/s/files/1/0596/6384/3496/files/Logo.svg?v=1742458502" alt="Account Editor Logo" style="height: 55px;">
  </div>

  <!-- Welcome Section -->
  <div style="width: 90%;  margin: auto; padding: 0; max-width: 554px;">
    <h1 style="font-size: 26px; font-weight: bold; text-align: left; padding-bottom: 20px; line-height: normal; text-transform: uppercase; margin-top: 0px;"><span style="color: #d7e200;">Help Us</span> Make Account Editor <br>Better for You</h1>

    <p style="text-align: left; margin-bottom: 25px;">
      <span style="background-color: #E6FF2A; padding: 9px 16px; font-weight: bold; border-radius: 4px; font-size: 14px;">Hello ${details?.storeOwnerName},</span>
    </p>

    <p style="font-size: 1em; text-align: left;">  
      We noticed you recently uninstalled Account Editor, and we’re sorry to see you go. Your feedback matters to us—was there something we could have done better?
    </p> 
    <p style="font-size: 1em; text-align: left;">Let us know by replying to this email</p>
  </div>
</div>
<!-- Support Note --> 
  <div style="width: 90%; max-width: 554px; margin: auto; margin-top: 10px; margin-bottom: 10px;">
    <p style="font-size: 1em; margin-bottom: 20px; margin-top: 0px;">If you ever decide to return, we’re here to help you set up and make the most of our application</p>
    <p style="font-size: 1em; color: #1E1E1E; text-align: left;">
      <strong> forward to hearing from you!</strong>
    </p>
  </div> 


  <!-- Footer Section -->
  <div style="background-color: #F8F7F2; margin-top: 50px; padding: 50px 0px;">
  <div style="width: 90%; max-width: 554px; margin: auto; text-align: left;">
    <h4 style="font-size: 1.3em; font-weight: bold; margin: 0; margin-bottom: 20px;">
      <span style="background-color: yellow; color: black; padding: 2px 6px;">FOLLOW US</span>
    </h4>

    <!-- Social Icons -->
    <p style="margin: 12px 0;" >
      <a href="https://www.facebook.com/profile.php?id=61571961765625" style="margin: 0 5px;"><img src="https://cdn.shopify.com/s/files/1/0677/0769/9395/files/Frame.svg?v=1741934878" alt="facebook" style="height: 24px;"></a>
      <a href="https://x.com/account_editor" style="margin: 0 5px;"><img src="https://cdn.shopify.com/s/files/1/0677/0769/9395/files/Frame-1.svg?v=1741934878" alt="x.com" style="height: 24px;"></a>
      <a href="https://www.instagram.com/account_editor_app/" style="margin: 0 5px;"><img src="https://cdn.shopify.com/s/files/1/0677/0769/9395/files/Frame-2.svg?v=1741934878" alt="instagram" style="height: 24px;"></a>
      <a href="https://www.linkedin.com/company/account-editor/" style="margin: 0 5px;"><img src="https://cdn.shopify.com/s/files/1/0677/0769/9395/files/Frame-3.svg?v=1741934879" alt="LinkedIn" style="height: 24px;"></a>   
    </p>

    <!-- Team & Website -->
    <p style="font-size: 0.9em; color: #000000;">
      Best Wishes,<br>
      Account Editor Team<br>
      <a href="https://accounteditor.com"  style="color: #000; text-decoration: none; font-weight: bold; text-decoration: underline;">accounteditor.com</a>
    </p>

    <!-- Policy Links -->
    <p style="font-size: 0.8em; color: #444; text-align: center; margin-top: 50px; margin-bottom: 10px;">
      <a href="#" style="text-decoration: none; color: #000; margin: 0 8px;">FAQ's</a> |
      <a href="#" style="text-decoration: none; color: #000; margin: 0 8px;">Blogs</a> |
      <a href="#" style="text-decoration: none; color: #000; margin: 0 8px;">Privacy Policy</a> |
      <a href="#" style="text-decoration: none; color: #000; margin: 0 8px;">Terms of Service</a>
    </p>
    <hr>

    <p style="font-size: 13px; color: #1E1E1E; text-align: center; margin-bottom: 0px; margin-top: 10px;">© 2025 Account Editor. All rights reserved.</p>
  </div> 
</div>`
  };

  return data;
};

//2 days after installation
export const smarterCancellationsSupportEmail = (details, merchantEmail) => {

  const data = {
    from: process.env.SMTP_USER_EMAIL,
    to: merchantEmail,
    subject: `Meet Smart Cancellation Settings: Enable, Disable, and Personalize`,
    replyTo: process.env.SUPPORT_EMAIL,
    html: `
    <div style="background-color: #F8F7F2; padding-bottom: 49px;">
  <!-- Logo Section -->
  <div style="text-align: center; padding:44px 0px; max-width: 554px; margin: 0 auto;">
    <img src="https://cdn.shopify.com/s/files/1/0596/6384/3496/files/Logo.svg?v=1742458502" alt="Account Editor Logo" style="height: 55px;">
  </div>

  <!-- Welcome Section -->
  <div style="width: 90%;  margin: auto; padding: 0; max-width: 554px;">
    <h1 style="font-size: 26px; font-weight: bold; text-align: left; padding-bottom: 20px; line-height: normal; text-transform: uppercase; margin-top: 0px;"><span style="color: #d7e200;">Smarter Cancellations</span> for Seamless Customer Experiences!</span></h1>

    <p style="text-align: left; margin-bottom: 25px;">
      <span style="background-color: #E6FF2A; padding: 9px 16px; font-weight: bold; border-radius: 4px; font-size: 14px;">Hello ${details?.storeOwnerName},</span>
    </p>

    <p style="font-size: 1em; text-align: left;">
      We’re excited to inform you that your Account Editor app has one powerful feature you are looking for i.e. <strong>Smart Cancellation Settings.</strong> A feature designed to give you full control over order cancellations.
    </p>

  </div>
</div>

  <!-- Why use Section -->
  <div style="width: 90%; max-width: 554px;  margin: auto; padding-top: 50px;">
    <h2 style="font-size: 26px; font-weight: bold; text-align: left; margin: 0; line-height: normal; text-transform: uppercase;">Why use <span style="color: #d7e200;">Smart Cancellation Settings?</span></h2>
    
    <ul style="font-size: 1em; padding-left: 5%;">
      <li><strong>Enable/Disable Cancellations:</strong> Decide whether cancellations should be allowed at all or not.</li>
      <li><strong>Restocking Fee:</strong> Enable a fixed or percentage-based restocking fee so you dont pay for canceled orders out of your pocket.</li> 
      <li><strong>Custom Cancellation Reasons:</strong> Personalize the reasons customers can select when requesting a cancellation.</li>
    </ul>
  </div>

  <!-- Divider -->
  <hr style="margin: 3% auto; width: 90%; max-width: 554px; border: none; border-top: 1px solid #ddd;">

  <!-- Why Merchants Love Section -->
  <div style="width: 90%; max-width: 554px;  margin: auto;">
    <h2 style="font-size: 26px; font-weight: bold; text-align: left; text-transform: uppercase;">How Does It Work?</h2>

    <p style="font-size: 1em; padding-left: 1%; list-style: auto; margin-bottom: 25px;">
      <strong>1. Go to the Account Editor dashboard and navigate to Smart Cancellation settings.</strong>
    </p> 
    <div>
      <img src="https://account-editor.s3.ap-south-1.amazonaws.com/public/1743157614497-912bea2d391b.png" alt="Dashboard" style="max-width: 520px; width: 100%;" />
    </div> 
    <p style="font-size: 1em; padding-left: 1%; list-style: auto; margin-bottom: 25px;">
      <strong>2. Enable or disable cancellations with restocking fees.</strong>
    </p> 
    <div>
      <img src="https://cdn.shopify.com/s/files/1/0596/6384/3496/files/Dashboard7.png?v=1742470645" alt="Dashboard" style="max-width: 520px; width: 100%;" />
    </div> 
    <p style="font-size: 1em; padding-left: 1%; list-style: auto; margin-bottom: 25px;">
      <strong>3. Set custom cancellation reasons to show your customers</strong>
    </p> 
    <div>
      <img src="https://cdn.shopify.com/s/files/1/0596/6384/3496/files/Dashboard9.png?v=1742470645" alt="Dashboard" style="max-width: 520px; width: 100%;" />
    </div> 
    
  </div>


  <!-- Get Started Section -->
  <div style="width: 90%; max-width: 554px; margin: auto;">
    <!-- CTA Button -->
    <div style="text-align: left; margin: 50px 0;" >
      <a href=${details?.adminUrl} target="_blank"  style="display: flex; width: fit-content; gap: 15px; background-color: #000000; color: #ffffff; text-decoration: none; padding: 12px 25px; font-weight: bold; border-radius: 6px; font-size: 1em;">
        Setup Now <img src="https://cdn.shopify.com/s/files/1/0677/0769/9395/files/Vector.svg?v=1741934878" style ="width: 12px;height: 100%;padding-left: 9px;padding-top: 5px;" alt="Vector">
      </a> 
    </div>

    <!-- Support Note --> 
     <h3 style="text-transform: uppercase; font-size: 20px; margin: 0; margin-bottom: 15px; line-height: normal;"> Need A Helping Hand?</h3>
    <p style="font-size: 1em; color: #1E1E1E; text-align: left;">
      Our team is ready to assist! Contact us anytime at <br> <strong>support@accounteditor.com. </strong>
    </p>

  </div>

  <!-- Footer Section -->
  <div style="background-color: #F8F7F2; margin-top: 50px; padding: 50px 0px;">
  <div style="width: 90%; max-width: 554px; margin: auto; text-align: left;">
    <h4 style="font-size: 1.3em; font-weight: bold; margin: 0; margin-bottom: 20px;">
      <span style="background-color: yellow; color: black; padding: 2px 6px;">FOLLOW US</span>
    </h4>

    <!-- Social Icons -->
    <p style="margin: 12px 0;" >
      <a href="https://www.facebook.com/profile.php?id=61571961765625" style="margin: 0 5px;"><img src="https://cdn.shopify.com/s/files/1/0677/0769/9395/files/Frame.svg?v=1741934878" alt="facebook" style="height: 24px;"></a>
      <a href="https://x.com/account_editor" style="margin: 0 5px;"><img src="https://cdn.shopify.com/s/files/1/0677/0769/9395/files/Frame-1.svg?v=1741934878" alt="x.com" style="height: 24px;"></a>
      <a href="https://www.instagram.com/account_editor_app/" style="margin: 0 5px;"><img src="https://cdn.shopify.com/s/files/1/0677/0769/9395/files/Frame-2.svg?v=1741934878" alt="instagram" style="height: 24px;"></a>
      <a href="https://www.linkedin.com/company/account-editor/" style="margin: 0 5px;"><img src="https://cdn.shopify.com/s/files/1/0677/0769/9395/files/Frame-3.svg?v=1741934879" alt="LinkedIn" style="height: 24px;"></a>   
    </p>

    <!-- Team & Website -->
    <p style="font-size: 0.9em; color: #000000;">
      Best Wishes,<br>
      Account Editor Team<br>
      <a href="https://accounteditor.com"  style="color: #000; text-decoration: none; font-weight: bold; text-decoration: underline;">accounteditor.com</a>
    </p>
    <hr>
    <p style="font-size: 13px; color: #1E1E1E; text-align: center; margin-bottom: 0px; margin-top: 10px;">© 2025 Account Editor. All rights reserved.</p>
  </div> 
</div>`


  };

  return data;
};
// Generates an email template to thank a user for their review of the service.
export const yourReviewEmail = (details, merchantEmail) => {
  const data = {
    from: process.env.SMTP_USER_EMAIL,
    to: merchantEmail,
    subject: `Thank You For Your Review!`,
    replyTo: process.env.SUPPORT_EMAIL,
    html: `
    <div style="background-color: #F8F7F2; padding-bottom: 49px;">
  <!-- Logo Section -->
  <div style="text-align: center; padding:44px 0px; max-width: 554px; margin: 0 auto;">
    <img src="https://cdn.shopify.com/s/files/1/0596/6384/3496/files/Logo.svg?v=1742458502" alt="Account Editor Logo" style="height: 55px;">
  </div>

  <!-- Welcome Section -->
  <div style="width: 90%;  margin: auto; padding: 0; max-width: 554px;">
    <h1 style="font-size: 26px; font-weight: bold; text-align: left; padding-bottom: 20px; line-height: normal; text-transform: uppercase; margin-top: 0px;"> Thank You For Your Review! </h1>

    <p style="text-align: left; margin-bottom: 25px;">
      <span style="background-color: #E6FF2A; padding: 9px 16px; font-weight: bold; border-radius: 4px; font-size: 14px;">Hello ${details?.storeOwnerName},</span>
    </p>

    <p style="font-size: 1em; text-align: left;"> 
      Thank you for taking the time to leave a review! We truly appreciate your feedback and are delighted to hear about your experience with Account Editor.
    </p>
  </div>
</div>


<!-- Support Note --> 
  <div style="width: 90%; max-width: 554px; margin: auto; margin-top: 50px; margin-bottom: 50px;">
    <p style="font-size: 16px; margin-bottom: 20px; margin-top: 0px;">Your insights help us continue to improve and provide the best service possible. If you have any more suggestions or need further assistance, please don’t hesitate to reach out.</p>
    <p style="font-size: 16px; margin-bottom: 20px; margin-top: 0px;">We’re committed to your success and are here to help anytime!</p>
    <p style="font-size: 1em; color: #1E1E1E; text-align: left; margin-bottom: 0px;">
      Contact us at  <br> <strong>support@accounteditor.com. </strong>
    </p>
    <p style="font-size: 16px; margin-bottom:0px; margin-top: 50px;"><strong>Thanks again for being part of the Account Editor community!</strong></p>
  </div> 

   

  <!-- Footer Section -->
  <div style="background-color: #F8F7F2; margin-top: 50px; padding: 50px 0px;">
  <div style="width: 90%; max-width: 554px; margin: auto; text-align: left;">
    <h4 style="font-size: 1.3em; font-weight: bold; margin: 0; margin-bottom: 20px;">
      <span style="background-color: yellow; color: black; padding: 2px 6px;">FOLLOW US</span>
    </h4>

    <!-- Social Icons -->
    <p style="margin: 12px 0;" >
      <a href="https://www.facebook.com/profile.php?id=61571961765625" style="margin: 0 5px;"><img src="https://cdn.shopify.com/s/files/1/0677/0769/9395/files/Frame.svg?v=1741934878" alt="facebook" style="height: 24px;"></a>
      <a href="https://x.com/account_editor" style="margin: 0 5px;"><img src="https://cdn.shopify.com/s/files/1/0677/0769/9395/files/Frame-1.svg?v=1741934878" alt="x.com" style="height: 24px;"></a>
      <a href="https://www.instagram.com/account_editor_app/" style="margin: 0 5px;"><img src="https://cdn.shopify.com/s/files/1/0677/0769/9395/files/Frame-2.svg?v=1741934878" alt="instagram" style="height: 24px;"></a>
      <a href="https://www.linkedin.com/company/account-editor/" style="margin: 0 5px;"><img src="https://cdn.shopify.com/s/files/1/0677/0769/9395/files/Frame-3.svg?v=1741934879" alt="LinkedIn" style="height: 24px;"></a>   
    </p>

    <!-- Team & Website -->
    <p style="font-size: 0.9em; color: #000000;">
      Best Wishes,<br>
      Account Editor Team<br>
      <a href="https://accounteditor.com"  style="color: #000; text-decoration: none; font-weight: bold; text-decoration: underline;">accounteditor.com</a>
    </p>

    <!-- Policy Links -->
    <p style="font-size: 0.8em; color: #444; text-align: center; margin-top: 50px; margin-bottom: 10px;">
      <a href="#" style="text-decoration: none; color: #000; margin: 0 8px;">FAQ's</a> |
      <a href="#" style="text-decoration: none; color: #000; margin: 0 8px;">Blogs</a> |
      <a href="#" style="text-decoration: none; color: #000; margin: 0 8px;">Privacy Policy</a> |
      <a href="#" style="text-decoration: none; color: #000; margin: 0 8px;">Terms of Service</a>
    </p>
    <hr>
    <p style="font-size: 13px; color: #1E1E1E; text-align: center; margin-bottom: 0px; margin-top: 10px;">© 2025 Account Editor. All rights reserved.</p>
  </div> 
</div>`

  };

  return data;
};


//15 days after installation
export const customerReviewEmail = (details, merchantEmail) => {
  const data = {
    from: process.env.SMTP_USER_EMAIL,
    to: merchantEmail,
    subject: `Enjoying Account Editor? We’d Love to Hear About It!`,
    replyTo: process.env.SUPPORT_EMAIL,
    html: `<div style="font-family: Arial, sans-serif; background-color: #ffffff; margin: 0; padding: 0; color: #000000; line-height: 1.6;">
<div style="background-color: #F8F7F2; padding-bottom: 49px;">
  <!-- Logo Section -->
  <div style="text-align: center; padding:44px 0px; max-width: 554px; margin: 0 auto;">
    <img src="https://cdn.shopify.com/s/files/1/0677/0769/9395/files/Logo.svg?v=1741934599" alt="Account Editor Logo" style="height: 55px;">
  </div>

  <!-- Welcome Section -->
  <div style="width: 90%;  margin: auto; padding: 0; max-width: 554px;">
    <h1 style="font-size: 26px; font-weight: bold; text-align: left; padding-bottom: 20px; line-height: normal; text-transform: uppercase; margin-top: 0px;">Share Your <span style="color: #d7e200;">Experience</span></h1>

    <p style="text-align: left; margin-bottom: 25px;">
      <span style="background-color: #E6FF2A; padding: 9px 16px; font-weight: bold; border-radius: 4px; font-size: 14px;">Hello ${details?.storeOwnerName},</span>
    </p>

    <p style="font-size: 1em; text-align: left; margin: 0;"> 
      We hope Account Editor is helping you enhance your business operations! You are a valuable part of the Account Editor family, and we’d love to hear your thoughts. How has Account Editor helped your business? Are there features you love or areas where we can improve? Your feedback will not only help us grow but also help other businesses understand how Account Editor can make a difference.
    </p>

  </div>
</div>

  <!--  Section -->
  <div style="width: 90%; max-width: 554px;  margin: auto; padding-top: 50px;">
    <h2 style="font-size: 24px; font-weight: bold; text-align: left; margin: 0; line-height: normal; text-transform: uppercase; margin-bottom: 10px;">Click below to leave a quick review—it <br> only takes a few minutes!</h2>
    <a href='https://apps.shopify.com/account-editor' target="_blank"  style="display: flex; width: fit-content; gap: 15px; background-color: #292929; color: #ffffff; text-decoration: none; padding: 12px 25px; font-weight: bold; border-radius: 6px; font-size: 1em;">
      Leave A Review <img src="https://cdn.shopify.com/s/files/1/0677/0769/9395/files/Vector.svg?v=1741934878" style ="width: 12px;height: 100%;padding-left: 9px;padding-top: 5px;" alt="Vector">
    </a>  
  </div>

  <!-- Divider -->
  <hr style="margin: 30px auto; width: 90%; max-width: 554px; border: none; border-top: 1px solid #ddd;"> 

   <!-- Work Section -->
   <div style="width: 90%; max-width: 554px;  margin: auto;">
    <h2 style="font-size: 24px; font-weight: bold; text-align: left; margin: 0; line-height: normal; text-transform: uppercase;"><span style="color: #d7e200;">Get Started</span> With These Resources </span></h2> 
    <p style="font-size: 16px; margin-top: 10px; margin-bottom: 10px;">We’ve made it easy for you to hit the ground running. Explore these resources to get the most out of your new features:</p>
    <ul style="font-size: 1em; padding-left: 5%;">
      <li style="margin-bottom: 10px;"><a href="https://www.accounteditor.com/faqs" style="font-size: 16px; color: #1E1E1E;">FAQs</a></li>
    </ul>
  </div>

  <!-- Divider -->
  <hr style="margin: 30px auto; width: 90%; max-width: 554px; border: none; border-top: 1px solid #ddd;">

  
  <!-- Get Started Section -->
  <div style="width: 90%; max-width: 554px; margin: auto;">
    <!-- Support Note --> 
    <p style="font-size: 1em; color: #1E1E1E; text-align: left; margin: 0; line-height: 24px;">
      Thank you for being a valued part of our community. If you need any assistance or have suggestions, don’t hesitate to reach out to us.
    </p> 
    <p style="font-size: 1em; color: #1E1E1E; text-align: left; margin: 0; line-height: 24px; margin-top: 10px;"><strong>Contact us at support@accounteditor.com</strong> </p>
       <!-- CTA Button -->
       <div style="text-align: left; margin-bottom: 50px; margin-top: 10px;" >
        <p style="font-size: 1em; color: #1E1E1E; text-align: left; margin-top: 10px;"><strong>We truly appreciate your support and look forward to hearing from you!</strong> </p>
      </div>

  </div>

  <!-- Footer Section -->
  <div style="background-color: #F8F7F2; margin-top: 50px; padding: 50px 0px;">
  <div style="width: 90%; max-width: 554px; margin: auto; text-align: left;">
    <h4 style="font-size: 1.3em; font-weight: bold; margin: 0; margin-bottom: 20px;">
      <span style="background-color: yellow; color: black; padding: 2px 6px;">FOLLOW US</span>
    </h4>

    <!-- Social Icons -->
    <p style="margin: 12px 0;" >
      <a href="https://www.facebook.com/profile.php?id=61571961765625" style="margin: 0 5px;"><img src="https://cdn.shopify.com/s/files/1/0677/0769/9395/files/Frame.svg?v=1741934878" alt="facebook" style="height: 24px;"></a>
      <a href="https://x.com/account_editor" style="margin: 0 5px;"><img src="https://cdn.shopify.com/s/files/1/0677/0769/9395/files/Frame-1.svg?v=1741934878" alt="x.com" style="height: 24px;"></a>
      <a href="https://www.instagram.com/account_editor_app/" style="margin: 0 5px;"><img src="https://cdn.shopify.com/s/files/1/0677/0769/9395/files/Frame-2.svg?v=1741934878" alt="instagram" style="height: 24px;"></a>
      <a href="https://www.linkedin.com/company/account-editor/" style="margin: 0 5px;"><img src="https://cdn.shopify.com/s/files/1/0677/0769/9395/files/Frame-3.svg?v=1741934879" alt="LinkedIn" style="height: 24px;"></a>   
    </p>

    <!-- Team & Website -->
    <p style="font-size: 0.9em; color: #000000;">
      Best Wishes,<br>
      Account Editor Team<br>
      <a href="https://accounteditor.com"  style="color: #000; text-decoration: none; font-weight: bold; text-decoration: underline;">accounteditor.com</a>
    </p>
    <hr>
    <p style="font-size: 13px; color: #1E1E1E; text-align: center; margin-bottom: 0px; margin-top: 10px;">© 2025 Account Editor. All rights reserved.</p>
  </div> 
</div>

</div>`

  };

  return data;
};
