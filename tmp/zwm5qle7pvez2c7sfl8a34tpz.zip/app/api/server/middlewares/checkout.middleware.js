import { getShopInfo } from "../services/partner/index.server.js";

import { authenticate, unauthenticated } from "../../../shopify.server.js";
export const authenticateCheckout = async (request) => {
  try {

    let admin, session;
    if (process.env.ENV_SERVER !== 'development') {
      
      let { sessionToken } = await authenticate.public.checkout(request);
      ({ admin, session } = await unauthenticated.admin(sessionToken.dest));
    } else {
      const shop = new URL(request.url).searchParams.get("shop");
      ({ session, admin } = await unauthenticated.admin(shop));
    }
    return { status: true, data: { admin, session } };
  } catch (error) {
    console.error(`Catch Error in authenticateCheckout:`, error);
    return { status: false, message: error?.message };
  }
};