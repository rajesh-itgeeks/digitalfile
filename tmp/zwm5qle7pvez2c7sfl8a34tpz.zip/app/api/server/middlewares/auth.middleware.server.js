import { ErrorMessage } from "../constants/messages.js";
import { getShopInfo } from "../services/partner/index.server.js";
import { authenticate, sessionStorage, unauthenticated } from "../../../shopify.server.js";


export const authenticateUser = async (req) => {
    try {
        const url = new URL(req.url);
        const queryShop = url.searchParams.get("shop");
        console.log(":::----- Query Parameter Shop :", queryShop);

        // Determine session and admin details based on queryShop presence
        const { session, admin } = queryShop
            ? await unauthenticated.admin(queryShop)
            : await authenticate.admin(req);

        if (!session?.shop) {
            return { status: false, message: `Shop ${ErrorMessage.NOT_FOUND}` };
        }

        const shop = session.shop;
        const storeSessions = await sessionStorage.findSessionsByShop(shop);

        if (!storeSessions?.length || shop !== storeSessions[0].shop) {
            return { status: false, message: ErrorMessage.NOT_AUTHORIZED };
        }

        req.currentShop = shop;
        req.currentPartnerInfo = await getShopInfo(shop);
        req.session = session;
        req.admin = admin;

        return { status: true };
    } catch (error) {
        console.error(`Catch Error in authenticateUser:`, error);
        return { status: false, message: `Shop ${ErrorMessage.NOT_FOUND}` };
    }
};
