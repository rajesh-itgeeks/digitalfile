// models
import { AppSettings } from "../models/appSettings.model.js";

// Response handlers
import { sendResponse } from "../utils/sendResponse.js";
import { ErrorMessage } from "../constants/messages.js";
import { statusCode } from "../constants/statusCodes.js";

// Services
import { orderAdmin } from "../services/order/utils.js";


// Common function to validate time frame
export const validateTimeFrame = async (timeString, admin, orderId) => {
    try {
        const now = new Date();

        let thresholdDate = new Date();

        // Define time units and their millisecond equivalents
        const timeUnits = {
            minutes: 60000,
            hours: 3600000,
            days: 86400000,
            week: 7 * 86400000,
            month: -1, // Special case for months
        };

        // Calculate the threshold date based on timeString
        for (const [unit, multiplier] of Object.entries(timeUnits)) {
            if (timeString.includes(unit)) {
                const value = parseInt(timeString.split(unit)[0], 10);
                unit === 'month'
                    ? thresholdDate.setMonth(now.getMonth() - value)
                    : thresholdDate.setUTCMilliseconds(now.getUTCMilliseconds() - (value * multiplier))

                break;
            }
        }
        // Handle invalid or missing threshold date
        if (!thresholdDate) {
            return {
                status: false,
                message: ErrorMessage.INVALID_TIME_FRAME
            };
        }

        const response = await admin.graphql(
            `#graphql 
              query MyMutation {
              order(id: "gid://shopify/Order/${orderId}") {
                id
                createdAt
              }
            }`,
        );
        const data = await response.json()

        // Compare order creation date with the threshold date
        if (!data?.data?.order?.createdAt) {
            console.log("Invalid created date",data?.data?.order?.createdAt);
            return {
                status: false,
                message: ErrorMessage.INVALID_CREATED_DATE
            };
        }
        const createdAt = new Date(data?.data?.order?.createdAt);
        console.log("order createdAt : ", createdAt);

        const createdAtUtc = new Date(createdAt.toISOString());
        console.log("created At--", createdAtUtc, "--", "threshold Date--", thresholdDate)
        if (createdAtUtc.getTime() < thresholdDate.getTime()) {
            return {
                status: false,
                message: ErrorMessage.ORDER_TIME_FRAME_EXCEEDED
            };
        }
        return { status: true };
    } catch (err) {
        console.log(err);
        return {
            status: false,
            message: ErrorMessage.NOT_FOUND
        }
    }
};

// validateOrder function
export const validateOrder = async (orderId, partnerId, admin, session) => {
    try {
        console.log("orderId : ", orderId);
        if (orderId == 1 || orderId == 0) return { status: true };

        const appSettings = await AppSettings.findOne({ partnerId }).select("presetTimeFrame");
        const timeString = appSettings?.presetTimeFrame?.time;
        console.log("TimeString : ", timeString);

        // Skip validation if no time frame or fulfilled status
        if (!timeString || timeString === "fulfilled") return { status: true };

        // Validate the order's time frame
        const isValid = await validateTimeFrame(timeString, admin, orderId);

        console.log("isValid :", isValid);
        if (!isValid.status) {
            return {
                status: false,
                message: isValid?.message
            }
        };

        // Check Shopify order fulfillment status
        const shopifyOrderDetails = await orderAdmin(orderId, admin);
        const orderStatus = shopifyOrderDetails?.displayFulfillmentStatus;
        const orderCancel = shopifyOrderDetails?.cancelledAt;
        console.log("Order Status : ", orderStatus);
        console.log("Order Cancel : ", orderCancel);
        if (orderStatus === "FULFILLED" || orderCancel) {
            return {
                status: false,
                message: ErrorMessage.ORDER_FULFILLED
            }
        }
        return { status: true };
    } catch (error) {
        console.log("Error in validateOrder:", error);
        return {
            status: false,
            message: ErrorMessage.INTERNAL_SERVER_ERROR
        }
    }
};