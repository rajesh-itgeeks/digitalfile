import { SESClient } from "@aws-sdk/client-ses";
// SMTP configuration for sending emails

export const emailConfig = {
    host: process.env.SMTP_HOST,            // The SMTP server's hostname (e.g., smtp.gmail.com)
    port: process.env.SMTP_PORT,            // The port for the SMTP server (e.g., 465 for SSL, 587 for TLS)
    secure: true,                           // Whether the connection should use SSL/TLS (true means use SSL/TLS)
    auth: {
        user: process.env.SMTP_USER,        // SMTP username (e.g. email address)
        pass: process.env.SMTP_PASSWORD,    // SMTP password (e.g., the password or an app-specific password)
    },
}
// Initialize AWS SES client with the specified region
export const ses = new SESClient({ region: process.env.AWS_REGION });
// SES client with explicit AWS credentials
export const sesClient = new SESClient({
    region: process.env.AWS_REGION,
    credentials: {
        accessKeyId: process.env.AWS_ACCESS_KEY_ID,
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
    },
});