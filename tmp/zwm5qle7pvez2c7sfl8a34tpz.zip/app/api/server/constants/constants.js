export const PLAN = {
    FREE_AMOUNT: 0,
    BASIC: 'basic',
    FREE_NAME: 'essential',
    PROFESSIONAL: 'professional',
    ENTERPRISE: 'enterprise',
}

export const INTERVAL = {
    EVERY_30_DAYS: "EVERY_30_DAYS",
    ANNUAL: 'ANNUAL'
}

export const CURRENCY = {
    USD: "USD",
}

export const SHOPIFY_TAGS = {
    ACCOUNT_EDITOR: "ae_account_editor",
    ADD_ITEM: "ae_add_item",
    REMOVE_ITEM:"ae_remove_item",
    EDIT_ITEM:"ae_edit_item",
    SWAP_ITEM:"ae_swap_item",
    CANCEL_ORDER:"ae_cancel_order",
    AE_HOLD_ORDER:"ae_hold_order",
    UPDATE_SHIPPING: "ae_update_shipping",
    UPDATE_CONTACT_INFO: "ae_update_contact_info",
    UPDATE_SHIPPING_METHOD: "ae_update_shipping_method",

}

export const ORDER_ACTION = {
    CANCEL_ORDER: "cancel_order",
    ADD_ITEM: "add_item",
    REMOVE_ITEM: "remove_item",
    SWAP_ITEM: "swap_item",
    UPDATE_ITEM: 'update_item',
    UPDATE_SHIPPING: 'update_shipping_address',
    UPDATE_CONTACT_INFO: 'update_contact_info',
    ORDER_REFUND: 'order_refund',
    STORE_CREDIT: 'store_credit',
    UP_SELL_REVENUE: 'up_sell_revenue'
}

export const UP_SELL_CONDITION_TYPE = {
    SEGMENT: "segment",
    CART_VALUE: "cartValue",
    COLLECTION: "collection"
}

export const UP_SELL_MATCH = {
    ALL: "all",
    ANY: "any",
}
export const TRIGGER_HANDLES = {
    DISABLE_EMAIL_EDITING: "disable-email-editing",
    DISABLE_PHONE_NUMBER_EDITING: "disable-phone-number-editing",
    DISABLE_SHIPPING_ADDRESS_EDITING: "disable-shipping-address",
    DISABLE_ITEM_QUANTITY_CHANGES: "disable-item-quantity-changes",
    DISABLE_PRODUCT_SWAPS: "disable-product-swaps",
    DISABLE_ORDER_CANCELLATIONS: "disable-order-cancellations",
    DISABLE_ADDING_NEW_ITEMS_TO_ORDERS: "disable-adding-new-items",
    DISABLE_REMOVING_ITEMS_FROM_ORDERS: "disable-removing-items",
    DISALLOW_CUSTOMER_EDIT: "customer-disallow-edits",
};

export const EMAIL_HANDLES = {
    ADD_ITEM_EMAIL: "addItem",
    REMOVE_ITEM_EMAIL: "removeItem",
    UPSELL_DISCOUNT: "upsellDiscount",
    CANCEL_ORDER_EMAIL: "cancelOrder",
    EDIT_ORDER: "editOrder",
    UPDATE_SHIPPING: "updateShipping",
    UPDATE_CONTACT_INFO: "updateContactInfo",
    SWAP_ITEM: "swapItem",
    UNINSTALL_EMAIL: "unInstallEmail"
}
export const NOTIFICATION_TYPES = {
    PAYMENT_PENDING: "paymentPending",
    ORDER_CANCELLATION: "orderCancellation",
    ORDER_EDIT: "orderEdit",
    ADD_UPSELL_ITEM: "addUpSellItem",
    ORDER_EDITS_TIME_FRAME: "orderEditsTimeFrame",
}



const isProduction = process.env.ENV_SERVER === "production";
export const MARKETING_EMAILS = [
    {
        templateType: "orderEditingSupportEmail",
        delayTime: isProduction ? 1 * 24 * 60 * 60 * 1000 : 30000,
        isMarketing: true,
    },
    {
        templateType: "smarterCancellationsSupportEmail",
        delayTime: isProduction ? 2 * 24 * 60 * 60 * 1000 : 60000,
        isMarketing: true,
    },
    {
        templateType: "upsellSupportEmail",
        delayTime: isProduction ? 3 * 24 * 60 * 60 * 1000 : 90000,
        isMarketing: true,
    },
    {
        templateType: "accountEditorSupportEmail",
        delayTime: isProduction ? 4 * 24 * 60 * 60 * 1000 : 120000,
        isMarketing: true,
    },
    {
        templateType: "customerReviewEmail",
        delayTime: isProduction ? 15 * 24 * 60 * 60 * 1000 : 150000,
        isMarketing: true,
    },
];

export default {
    PLAN,
    INTERVAL,
    CURRENCY,
    SHOPIFY_TAGS,
    ORDER_ACTION,
    UP_SELL_CONDITION_TYPE,
    UP_SELL_MATCH,
    TRIGGER_HANDLES
};
