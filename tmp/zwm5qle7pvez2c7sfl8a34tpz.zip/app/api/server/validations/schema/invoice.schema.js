import Joi from "joi";

export const updateInvoiceSchema = Joi.object({
    enableCustomerInvoice: Joi.boolean().optional(),
    storeInfo: Joi.object({
        name: Joi.string().allow(null, ""), 
        email: Joi.string().email().allow(null, ""),
        websiteUrl: Joi.string().uri().allow(null, ""),
    }).optional(),
    hide: Joi.object({
        showTaxesItems: Joi.boolean().optional(),
        hideProductSkus: Joi.boolean().optional(),
        orderStatusInfo: Joi.boolean().optional(),
        orderNotes: Joi.boolean().optional(),
    }).optional(),
    logoUrl: Joi.string().uri().allow(null, "").optional(),
    previewTemplate: Joi.string().allow(null, "").optional(),

}).optional();
