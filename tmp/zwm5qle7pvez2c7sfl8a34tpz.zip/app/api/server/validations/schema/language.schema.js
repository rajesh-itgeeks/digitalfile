import Joi from "joi";
export const saveSchema = Joi.object({
   lang:Joi.string().required(),
   status : Joi.boolean().optional(),
   langJson:Joi.object().optional(),
   name:Joi.string().required()

});
export const detailsSchema = Joi.object({
   id:Joi.string().required(),
   lang:Joi.string().required(),
   searchKey:Joi.string().allow(null,"").optional(),
   offset : Joi.number().optional(),
   limit : Joi.number().optional(),
});

