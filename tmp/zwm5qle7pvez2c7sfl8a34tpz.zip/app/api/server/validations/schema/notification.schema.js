import Joi from "joi";
import { NOTIFICATION_TYPES } from "../../constants/constants";

// Schema for validating updating notification details request
export const notificationSchema = Joi.object({
    enableMerchantNotification: Joi.boolean().optional(),
    enableCustomerNotification: Joi.boolean().optional(),
    merchantEmails: Joi.array().items(Joi.string().email()).optional(),
    customerSenderEmail: Joi.string().allow(null, "").optional(),
    orderEdit: Joi.object({
        status: Joi.boolean().optional()
    }).optional(),
    paymentPending: Joi.object({
        status: Joi.boolean().optional(),
        times: Joi.array().items(Joi.string().optional()).optional(),
    }).optional(),
    orderCancellation: Joi.object({
        status: Joi.boolean().optional()
    }).optional(),
    addUpSellItem: Joi.object({
        status: Joi.boolean().optional()
    }).optional(),
    orderEditsTimeFrame: Joi.object({
        status: Joi.boolean().optional(),
        times: Joi.array().items(Joi.string().optional()).optional(),
    }).optional(),
});

export const detailsSchema = Joi.object({
    type: Joi.string()
        .valid(
            NOTIFICATION_TYPES.PAYMENT_PENDING,
            NOTIFICATION_TYPES.ORDER_EDIT,
            NOTIFICATION_TYPES.ADD_UPSELL_ITEM,
            NOTIFICATION_TYPES.ORDER_CANCELLATION,
            NOTIFICATION_TYPES.ORDER_EDITS_TIME_FRAME     
        )
        .required(),
});
export const templateSchema = Joi.object({
    type: Joi.string()
        .valid(
            NOTIFICATION_TYPES.PAYMENT_PENDING,
            NOTIFICATION_TYPES.ORDER_EDIT,
            NOTIFICATION_TYPES.ADD_UPSELL_ITEM,
            NOTIFICATION_TYPES.ORDER_CANCELLATION,
            NOTIFICATION_TYPES.ORDER_EDITS_TIME_FRAME        
        )
        .required(),

    emailTemplate: Joi.string().required(),// Ensures emailTemplate is a required string
    subject: Joi.string().allow(null).optional(),

});
