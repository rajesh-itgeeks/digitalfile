import Joi from "joi";

// Define a Joi schema for validating settings data
export const createSettingSchema = Joi.object({
  // Contact information settings
  contactInformation: Joi.object({
    email: Joi.object({
      isOn: Joi.boolean().optional(), // Whether email is enabled
    }).optional(),
    phone: Joi.object({
      isOn: Joi.boolean().optional(), // Whether phone is enabled
    }).optional(),
  }).optional(),

  // Order items settings
  orderItems: Joi.object({
    addItems: Joi.object({
      isOn: Joi.boolean().optional(), // Whether adding items is allowed
    }).optional(),
    increaseQuantity: Joi.object({
      isOn: Joi.boolean().optional(), // Whether quantity modification is allowed
    }).optional(),
    decreaseQuantity: Joi.object({
      isOn: Joi.boolean().optional(), // Whether quantity modification is allowed
    }).optional(),
    removeItem: Joi.object({
      isOn: Joi.boolean().optional(), // Whether removing an item is allowed
    }).optional(),
    swap: Joi.object({
      isOn: Joi.boolean().optional(), // Whether swapping items is allowed
    }).optional(),
  }).optional(),

  // Preset time frame settings (can be an object or an empty array)
  presetTimeFrame: Joi.alternatives().try(
    Joi.object({
      time: Joi.string().allow("", null).optional(), // Time value as string, allows empty or null
      type: Joi.string().allow("", null).optional(), // Type value as string, allows empty or null
    }).min(0) // Ensures that the object can have zero properties
    // Joi.array().length(0) // Uncomment if an empty array is also allowed
  ).optional(),

  // Shipping details settings
  shippingDetails: Joi.object({
    isOn: Joi.boolean().optional(), // Whether shipping details are enabled
  }).optional(),

  // Support settings
  support: Joi.object({
    isOn: Joi.boolean().optional(), // Whether support options are enabled
  }).optional(),

  // shipping settings
  shipping: Joi.object({
    shippingAddress: Joi.object({
      city: Joi.boolean().optional(),
      state: Joi.boolean().optional(),
      country: Joi.boolean().optional(),
    }).optional(),

    addressLookup: Joi.object({
      isOn: Joi.boolean().optional(),
    }).optional(),

    addressValidation: Joi.object({
      isOn: Joi.boolean().optional(),
    }).optional(),

    enableShippingFee: Joi.object({
      isOn: Joi.boolean().optional(),
    }).optional(),

    enableShippingFeeItem: Joi.object({
      isOn: Joi.boolean().optional(),
    }).optional(),

    splitShippingToggle: Joi.object({
      isOn: Joi.boolean().optional(),
    }).optional(),

  }).optional(),
  orderHold: Joi.object({
    isOn: Joi.boolean().optional(),
  }).optional(),
  orderTags: Joi.array().items(Joi.string()).optional(),
  productTags: Joi.array().items(Joi.string()).optional(),
  // Shipping details settings
  orderHolds: Joi.object({
    isOn: Joi.boolean().optional(), // Whether shipping details are enabled
  }).optional(),
  orderChangesRevert: Joi.object({
    isOn: Joi.boolean().optional(), // Whether shipping details are enabled
  }).optional(),
  // Order cancellation settings
  cancelOrder: Joi.object({
    isOn: Joi.boolean().optional(),
    reason: Joi.array().optional(), // List of reasons for cancellation
    restockingFees: Joi.object().optional(),
    credit: Joi.string().allow("", null).optional()
  }).optional(),
  //Discount Settings
  discount: Joi.object({
    enableRecalculation: Joi.object({
      isOn: Joi.boolean().optional(),
    }).optional(),
    allowPostPurchase: Joi.object({
      isOn: Joi.boolean().optional(),
    }).optional(),
  }).optional(),

});
