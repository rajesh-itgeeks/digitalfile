// Importing Joi for schema validation
import Joi from "joi";
// Schema for validating the request body for listing operations
export const listSchema = Joi.object({
    // limit is an optional field, can be a number, null, or an empty string
    limit: Joi.number().allow(null, "").optional(),
    // offset is an optional field, can be a number, null, or an empty string
    offset: Joi.number().allow(null, "").optional(),
    query: Joi.string().allow(null, "").optional(),
    shortBy: Joi.string().valid('ASE', 'DES').optional(),
});

// Schema for validating the 'id' parameter in the request URL
export const paramIdSchema = Joi.object({
    // id is a required field, must be a number
    id: Joi.number().required(),
});

// Schema for validating the 'id' query in the request URL
export const queryIdSchema = Joi.object({
    // id is a required field, must be a number
    id: Joi.string().required(),
});

export const queryShopSchema = Joi.object({
    shop: Joi.string().required(),
});
