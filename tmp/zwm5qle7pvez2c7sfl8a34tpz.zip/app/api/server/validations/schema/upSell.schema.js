// Importing Joi for schema validation
import Joi from "joi";

// Schema for creating an entity (e.g., discount rules or product conditions)
export const createSchema = Joi.object({
    name: Joi.string().required(), // Name of the entity (required)
    
    condition: Joi.array()
        .items(
            Joi.object({
                type: Joi.string()
                    .valid('segment', 'cartValue', 'collection') // Defines condition type
                    .required(),
                sign: Joi.string()
                    .valid('=', '>=', '<=', '!=') // Comparison operators
                    .required(),
                id: Joi.string().required() // Identifier for the condition
            })
        )
        .required().min(1), // At least one condition is required

    productMustMatch: Joi.string().valid('all', 'any').required(), // Match all or any products
    productLimit: Joi.number().min(0).max(5).required(), // Product limit (0-5)
    selectView: Joi.string().valid('list', 'slide').required(), // UI selection mode
    products: Joi.array()
        .items(Joi.object())
        .required(), // Array of product objects (required)

    variantsIds: Joi.array()
        .items(Joi.object())
        .optional(), // Optional array of variant objects

    productVariants: Joi.array()
        .items(Joi.string().pattern(/^gid:\/\/shopify\/ProductVariant\/\d+$/)) // Shopify Product Variant GID
        .optional(),

    discount: Joi.number().min(0).max(100).required(), // Discount percentage (0-100)
    isActive: Joi.boolean().optional() // Whether the rule is active (optional)
});

// Schema for updating an entity
export const updateSchema = Joi.object({
    name: Joi.string().optional(), // Name (optional for updates)
    isActive : Joi.boolean().optional(), // Active status (optional)

    condition: Joi.array()
        .items(
            Joi.object({
                type: Joi.string()
                    .valid('segment', 'cartValue', 'collection')
                    .required(),
                sign: Joi.string()
                    .valid('=', '>=', '<=', '!=')
                    .required(),
                id: Joi.string().optional() // ID is optional for updates
            })
        )
        .optional().min(1), // At least one condition required if provided

    productMustMatch: Joi.string().valid('all', 'any').optional(),
    productLimit: Joi.number().min(0).max(5).optional(),
    selectView: Joi.string().valid('list', 'slide').optional(),

    products: Joi.array()
        .items(Joi.object())
        .required(), // Products are still required

    variantsIds: Joi.array()
        .items(Joi.object())
        .optional(),

    productVariants: Joi.array()
        .items(Joi.string().pattern(/^gid:\/\/shopify\/ProductVariant\/\d+$/))
        .optional(),

    discount: Joi.number().min(0).max(100).optional() // Discount is optional for updates
});

// Schema for activating or deactivating an entity
export const activeSchema = Joi.object({
    type: Joi.string().valid("active", "deactive").required(), // Activation status (required)
});

// Schema for validating customer-related descriptions
export const descriptionSchema = Joi.object({
    customerId: Joi.string()
        .pattern(/^gid:\/\/shopify\/Customer\/\d+$/) // Shopify Customer GID format
        .required(),

    cartValue: Joi.number().positive().required(), // Cart value must be a positive number

    variants: Joi.array()
        .items(Joi.string().pattern(/^gid:\/\/shopify\/ProductVariant\/\d+$/)) // Valid Product Variant GID
        .min(1)
        .default([]) // At least one variant required
});
