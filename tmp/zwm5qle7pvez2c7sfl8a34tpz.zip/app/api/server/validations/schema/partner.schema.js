// Importing Joi validation library
import Joi from "joi";

// Schema for validating the update request
export const updateSchema = Joi.object({
    chargeId: Joi.number().allow(null).optional()    ,     // Optional number, can be null
    isStarted:Joi.boolean().optional(),
    planName:Joi.string().allow(null, "").optional(),
});

// Schema for validating the updatePagePreviewing request
export const updatePagePreviewingSchema = Joi.object({
    // 'thankyouPage' is an object with the following fields
    thankyouPage: Joi.object().keys({
        name: Joi.string().required(),        // Required string for 'name'
        isAdded: Joi.boolean().required(),    // Required boolean to indicate if it's added
    }),

    // 'orderStatusPage' is similar to 'thankyouPage' object with the following fields
    orderStatusPage: Joi.object().keys({
        name: Joi.string().required(),        // Required string for 'name'
        isAdded: Joi.boolean().required(),    // Required boolean to indicate if it's added
    }),

    // 'upSellOrderStatus' is similar to 'thankyouPage' object with the following fields
    upSellOrderStatus: Joi.object().keys({
        name: Joi.string().required(),        // Required string for 'name'
        isAdded: Joi.boolean().required(),    // Required boolean to indicate if it's added
    }),

    // 'upSellThankyouPage' is similar to 'thankyouPage' object with the following fields
    upSellThankyouPage: Joi.object().keys({
        name: Joi.string().required(),        // Required string for 'name'
        isAdded: Joi.boolean().required(),    // Required boolean to indicate if it's added
    }),
});

export const verificationCodeSchema = Joi.object({
    verificationCode: Joi.string().required()
})

export default {
    updateSchema,
    updatePagePreviewingSchema,
    verificationCodeSchema
};
