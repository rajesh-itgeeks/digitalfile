import Joi from "joi";
import {PLAN,INTERVAL,CURRENCY} from "../../constants/constants.js"

// Schema for validating subscription request
export const subscribeSchema = Joi.object({
    // 'plan' should be one of the valid plan names (either Free or Professional)
    plan: Joi.string().valid(PLAN.ENTERPRISE, PLAN.BASIC, PLAN.PROFESSIONAL).required(),
    // 'amount' should be a number greater than or equal to 0 (for subscription amount)
    amount: Joi.number().min(0).required(),
    // 'currency' must be exactly 3 characters, and it must be USD
    currency: Joi.string().length(3).required().valid(CURRENCY.USD),
    // 'interval' should be either 'EVERY_30_DAYS' or 'ANNUAL'
    interval: Joi.string().valid(INTERVAL.EVERY_30_DAYS, INTERVAL.ANNUAL).required(),
    // 'trial' is an optional boolean indicating whether there is a trial period
    trial: Joi.boolean().optional(),
    // 'trialDays' is an optional number specifying the trial days duration
    trialDays: Joi.number().optional(),
    // 'returnUrl' is required and must be a valid URI
    returnUrl: Joi.string().uri().required(),
});

// Schema for validating unsubscribe request
export const unSubscribeSchema = Joi.object({
    // 'planId' should be a string matching a specific pattern (Shopify AppSubscription ID format)
    planId: Joi.string().regex(/gid:\/\/shopify\/AppSubscription\/\d+/).required(),
    // 'enableFreePlan' is a required boolean, indicating whether the user wants to enable the free plan
    enableFreePlan: Joi.boolean().required(),
    planName: Joi.string().allow(null, "").optional(),
});
