import Joi from "joi";
export const analyticsSchema = Joi.object({
    startDate: Joi.string().required(),
    endDate: Joi.string().required(),
    type: Joi.string().allow("HOURLY", "DAILY").required(),
});
