import Joi from "joi";

// Schema for creating a support request related to an order
export const createSupportSchema = Joi.object({
    customerId: Joi.string().allow(null, "").optional(), // Customer ID (nullable and optional)
    orderNumber: Joi.string().required(), // Order number (must be provided)
    orderId: Joi.number().required(), // Order ID (must be a number and required)
    country: Joi.string().required(), // Country of the customer (required)
    customerEmail: Joi.string().required(), // Customer's email (required)
    phone: Joi.number().allow(null).optional(), // Phone number (optional, can be null)
    message: Joi.string().required(), // Support message from the customer (required)
});

// Schema for custom support requests (e.g., general inquiries)
export const customSupportSchema = Joi.object({
    firstName: Joi.string().min(1).required(), // First name (minimum 1 character, required)
    lastName: Joi.string().min(1).required(), // Last name (minimum 1 character, required)
    phone: Joi.string().required(), // Phone number (must be provided)
    email: Joi.string().email().required(), // Valid email format (required)
    storeUrl: Joi.string().uri().required(), // Store URL (must be a valid URI, required)
    message: Joi.string().min(1).optional() // Support message (optional but min length 1 if provided)
});
