import Joi from "joi";
export const addItemSchema = Joi.array().items(Joi.object({
    productVariantId: Joi.string().required(), // Product variant identifier (required)
    quantity: Joi.number().required(), // Quantity of the product (required)
    customerId: Joi.string().regex(/gid:\/\/shopify\/Customer\/\d+/).required(), // Customer identifier (required, must match a specific pattern)
})).min(1).required();

export const editCommitSchema = Joi.object({
    calculatedOrderId: Joi.string().required(), // Order identifier (required)
    notifyCustomer: Joi.boolean().required(), // Whether to notify the customer (required)
    staffNote: Joi.string().required() // Staff note for the order (required)
});

export const shippingAddressSchema = Joi.object({
    address1: Joi.string().allow(null, "").optional(), // First line of the address (optional)
    address2: Joi.string().allow(null, "").optional(), // Second line of the address (optional)
    city: Joi.string().allow(null, "").optional(), // City of the shipping address (optional)
    firstName: Joi.string().allow(null, "").optional(), // First name of the customer (optional)
    lastName: Joi.string().allow(null, "").optional(), // Last name of the customer (optional)
    country: Joi.string().allow(null, "").optional(), // Country of the shipping address (optional)
    phone: Joi.string().allow(null, "").optional(), // Phone number (optional)
    province: Joi.string().allow(null, "").optional(), // Province (optional)
    provinceCode: Joi.string().allow(null, "").optional(), // Province code (optional)
    zip: Joi.string().allow(null, "").optional(), // Zip code (optional)
    customerId: Joi.string().regex(/gid:\/\/shopify\/Customer\/\d+/).required(), // Customer identifier (required)
    selectedMethod: Joi.object().pattern(Joi.string(), Joi.string().allow(null, '')).allow(null).optional(), // selectedMethod code (optional)
});

export const cancelOrderSchema = Joi.object({
    staffNote: Joi.string().required(), // Note from the staff about the cancellation (required)
    refund: Joi.bool().required(), // Whether to issue a refund (required)
    restock: Joi.bool().required(), // Whether to restock the items (required)
    customerId: Joi.string().regex(/gid:\/\/shopify\/Customer\/\d+/).required(), // Customer identifier (required)
    amount: Joi.number().optional(),
    type: Joi.string().valid('percentage', 'fixed', 'shippingtaxes').optional(),
    value: Joi.number().optional(),
    currencyCode: Joi.string().required(),
    customerRefundedAmount: Joi.number().required(),
    totalAmount: Joi.string().required(),
});

export const removeItemSchema = Joi.object({
    calculatedLineItemId: Joi.string().required(), // Line item identifier (required)
    productVariantId: Joi.string().required(), // Product variant identifier (required)
    customerId: Joi.string().regex(/gid:\/\/shopify\/Customer\/\d+/).required(), // Customer identifier (required)
});

export const swapItemSchema = Joi.object({
    calculatedLineItemId: Joi.string().required(), // Line item identifier (required)
    lineItemId: Joi.string().required(), // Line item identifier (required)
    productVariantId: Joi.string().required(), // Product variant identifier (required)
    quantity: Joi.number().required(), // Quantity of the swapped item (required)
    customerId: Joi.string().regex(/gid:\/\/shopify\/Customer\/\d+/).required(), // Customer identifier (required)
});

export const contactInfoSchema = Joi.object({
    email: Joi.string().required(), // Customer's email address (required)
    customerId: Joi.string().regex(/gid:\/\/shopify\/Customer\/\d+/).required(), // Customer identifier (required)
});

export const storeCreditSchema = Joi.object({
    customerId: Joi.string().regex(/gid:\/\/shopify\/Customer\/\d+/).required(), // Customer identifier (required)
    amount: Joi.object({
        amount: Joi.string().min(0).required(), // Amount to be credited (required)
        currencyCode: Joi.string().length(3).required() // Currency code (required)
    }).required()
});

export const giftCardSchema = Joi.object({
    initialValue: Joi.string().required(), // Initial value of the gift card (required)
    customerId: Joi.string().regex(/gid:\/\/shopify\/Customer\/\d+/).required(), // Customer identifier (required)
    recipientAttributes: Joi.object({
        id: Joi.string().regex(/gid:\/\/shopify\/Customer\/\d+/).required(), // Recipient's customer identifier (required)
        message: Joi.string().required(), // Message for the gift card (required)
        preferredName: Joi.string().required(), // Recipient's preferred name (required)
        sendNotificationAt: Joi.string().isoDate().required() // Time to send the notification (required)
    }).required()
});

export const editItemSchema = Joi.array().items(Joi.object({
    calculatedLineItemId: Joi.string().regex(/gid:\/\/shopify\/CalculatedLineItem\/\d+/).required(), // Line item identifier (required)
    quantity: Joi.number().min(1).required(), // New quantity for the item (required, must be at least 1)
    oldQuantity: Joi.number().min(1).required(), // New quantity for the item (required, must be at least 1)
    customerId: Joi.string().regex(/gid:\/\/shopify\/Customer\/\d+/).required(), // Customer identifier (required)
    productVariantId: Joi.string().required(), // Product variant identifier (required)
})).min(1).required();

export const addDiscountItemSchema = Joi.object({
    customerId: Joi.string().regex(/gid:\/\/shopify\/Customer\/\d+/).required(), // Customer identifier (required)
    productVariantId: Joi.string().required(), // Product variant identifier (required)
    quantity: Joi.number().required(), // Quantity of the product (required)
    discountAmount: Joi.number().required(),
    isUpSell: Joi.bool().required(),
    percentage: Joi.number().min(0).required(),
});
export const addressPredictionSchema = Joi.object({
    query: Joi.string().required(), // query (required)

});
export const addressDetailsSchema = Joi.object({
    placeId: Joi.string().required(), // query (required)

});
