// Importing schema for validation
import {activeSchema,createSchema,descriptionSchema,updateSchema} from "../validations/schema/upSell.schema.js";

export const create = async (body) => {
    const { error } = createSchema.validate(body);
    if (error) {
        // If validation fails, respond with a BAD_REQUEST status and the error message
        return {
            status: false,
            message: error.details[0].message
        } 
        } else {
        // If validation is successful, move to the next middleware or route handler
        return { status:true };
    }
};

export const update = async (body) => {
    const { error } = updateSchema.validate(body);
    if (error) {
        // If validation fails, respond with a BAD_REQUEST status and the error message
        return {
            status: false,
            message: error.details[0].message
        } 
        } else {
        // If validation is successful, move to the next middleware or route handler
        return { status:true };
    }
};

export const active = async (body) => {
    const { error } = activeSchema.validate(body);
    if (error) {
        // If validation fails, respond with a BAD_REQUEST status and the error message
        return {
            status: false,
            message: error.details[0].message
        }
         } else {
        // If validation is successful, move to the next middleware or route handler
        return { status:true };
    }
};

export const description = async (body) => {
    const { error } = descriptionSchema.validate(body);
    if (error) {
        // If validation fails, respond with a BAD_REQUEST status and the error message

        return {
            status: false,
            message: error.details[0].message
        }     } else {
        // If validation is successful, move to the next middleware or route handler
        return { status:true };
    }
};

