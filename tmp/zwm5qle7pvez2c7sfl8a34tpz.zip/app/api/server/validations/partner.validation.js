// Import necessary modules
import schema from "./schema/partner.schema.js";
import { createSettingSchema } from "./schema/store.schema.js";
// Middleware to validate update request body
export const update = async (body) => {
    const { error } = schema.updateSchema.validate(body);  // Validate request body using updateSchema
    if (error) {
        // If validation fails, return a 400 Bad Request with the error message
        return {
            status: false,
            message: error.details[0].message
        }
    } else {
        // If validation succeeds, proceed to the next middleware or route handler
        return { status:true }
    }
};

// Middleware to validate updatePagePreviewing request body
export const updatePagePreviewingValidation = async (req) => {
    const { error } = schema.updatePagePreviewingSchema.validate(req.body);  // Validate request body using updatePagePreviewingSchema
    if (error) {
        // If validation fails, return a 400 Bad Request with the error message
        return {
            status: false,
            message: error.details[0].message
        }
    } else {
        // If validation succeeds, proceed to the next middleware or route handler
        return { status:true }
    }
};

export const verificationCode = async (req, res, next) => {
    const { error } = schema.verificationCodeSchema.validate(req.body);
    if (error) {
        // If validation fails, return a 400 Bad Request with the error message
        return {
            status: false,
            message: error.details[0].message
        }
    } else {
        // If validation succeeds, proceed to the next middleware or route handler
        return { status:true }
    }
};
export const settingsValidation = async (body) => {
    const { error } = createSettingSchema.validate(body);
    if (error) {
        return {status:false,message:error.details[0].message}
    } else {
        return {status:true};
    }
};
