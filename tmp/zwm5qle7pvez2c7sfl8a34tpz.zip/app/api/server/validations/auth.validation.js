// Importing schema for validation
import {listSchema,paramIdSchema,queryIdSchema,queryShopSchema} from "../validations/schema/auth.schema";
// Importing status codes for response handling

// Middleware to validate request body for listing operation
export const list = async (body) => {
    // Validating the request body against the listSchema
    const { error } = listSchema.validate(body);
    if (error) {
        // If validation fails, respond with a BAD_REQUEST status and the error message
        return {
            status: false,
            message: error.details[0].message
        }    } else {
        // If validation is successful, move to the next middleware or route handler
        return {status:true}
    }
};

// Middleware to validate request parameters for ID
export const paramId = async (id) => {
    // Validating the 'id' parameter from the request
    const { error } = paramIdSchema.validate({ id });
    if (error) {
        // If validation fails, respond with a BAD_REQUEST status and the error message
        return {
            status: false,
            message: error.details[0].message
        }    } else {
        // If validation is successful, move to the next middleware or route handler
        return {status:true}
    }
};

// Middleware to validate request query for ID
export const queryId = async (id) => {
    // Validating the 'id' query from the request
    const { error } = queryIdSchema.validate({ id });
    if (error) {
        // If validation fails, respond with a BAD_REQUEST status and the error message
        return {
            status: false,
            message: error.details[0].message
        }    } else {
        // If validation is successful, move to the next middleware or route handler
        return { status:true }
    }
};

// Middleware to validate request query for shop
export const queryShop = async (shop) => {
    const { error } = queryShopSchema.validate({ shop });
    if (error) {
        // If validation fails, respond with a BAD_REQUEST status and the error message
        return {
            status: false,
            message: error.details[0].message
        }    } else {
        // If validation is successful, move to the next middleware or route handler
        return { status:true }
    }
};
