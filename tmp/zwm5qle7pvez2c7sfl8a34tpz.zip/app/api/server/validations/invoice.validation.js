import  {updateInvoiceSchema} from './schema/invoice.schema.js'
export const checkInvoiceValidation = async (body) => {
    const { error } = updateInvoiceSchema.validate(body);
    if (error) {
        return {status:false,message:error.details[0].message}
    } else {
        return {status:true};
    }
};
