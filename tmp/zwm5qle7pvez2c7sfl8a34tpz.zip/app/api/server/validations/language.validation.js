import * as language from './schema/language.schema'

// Middleware for validating subscription requests
export const saveValidation = async (body) => {
    // Validate the request body using the 'notificationSchema'
    const { error } = language.saveSchema.validate(body);
    if (error) {
        return {
            status: false,
            message: error.details[0].message
        }
    } else {
        return { status: true }
    }
};
export const detailsValidation = async (body) => {
    // Validate the request body using the 'notificationSchema'
    const { error } = language.detailsSchema.validate(body);
    if (error) {
        return {
            status: false,
            message: error.details[0].message
        }
    } else {
        return { status: true }
    }
};

