// Validation schema imports
import * as schema from "./schema/order.schema.js"
// Validation middleware for adding an item to an order
export const addItem = async (body) => {
    const { error } = schema.addItemSchema.validate(body);
    if (error) {
        return {status:false,message:error.details[0].message}
    } else {
        return {status:true};
    }
};

// Validation middleware for editing a commitment in an order
export const editCommit = async (body) => {
    const { error } = schema.editCommitSchema.validate(body);
    if (error) {
        return {status:false,message:error.details[0].message}
    } else {
        return {status:true};
    }
};

// Validation middleware for updating shipping address in an order
export const shippingAddress = async (body) => {
    const { error } = schema.shippingAddressSchema.validate(body);
    if (error) {
        return {status:false,message:error.details[0].message}
    } else {
        return {status:true};
    }
};

// Validation middleware for canceling an order
export const cancelOrder = async (body) => {
    const { error } = schema.cancelOrderSchema.validate(body);
    if (error) {
        return {status:false,message:error.details[0].message}
    } else {
        return {status:true};
    }
};

// Validation middleware for removing an item from an order
export const removeItem = async (body) => {
    const { error } = schema.removeItemSchema.validate(body);
    if (error) {
        return {status:false,message:error.details[0].message}
    } else {
        return {status:true};
    }
};

// Validation middleware for swapping an item in an order
export const swapItem = async (body) => {
    const { error } = schema.swapItemSchema.validate(body);
    if (error) {
        return {status:false,message:error.details[0].message}
    } else {
        return {status:true};
    }
};

// Validation middleware for updating contact information in an order
export const contactInfo = async (body) => {
    const { error } = schema.contactInfoSchema.validate(body);
    if (error) {
        return {status:false,message:error.details[0].message}
    } else {
        return {status:true};
    }
};


// Validation middleware for processing store credit in an order
export const storeCreditValidation = async (body) => {
    const { error } = schema.storeCreditSchema.validate(body);
    if (error) {
        return {status:false,message:error.details[0].message}
    } else {
        return {status:true};
    }
};

// Validation middleware for using a gift card in an order
export const giftCardValidation = async (body) => {
    const { error } = schema.giftCardSchema.validate(body);
    if (error) {
        return {status:false,message:error.details[0].message}
    } else {
        return {status:true};
    }
};

// Validation middleware for editing an item in an order
export const editItem = async (body) => {
    const { error } = schema.editItemSchema.validate(body);
    if (error) {
        return {status:false,message:error.details[0].message}
    } else {
        return {status:true};
    }
};

export const addDiscountItemValidation = async (body) => {
    const { error } = schema.addDiscountItemSchema.validate(body);
    if (error) {
        // If validation fails, respond with a BAD_REQUEST status and the error message
        return {status:false,message:error.details[0].message}
    } else {
        // If validation is successful, move to the next middleware or route handler
        return {status:true};
    }
};
export const addressPredictionsValidation = async (body) => {
    const { error } = schema.addressPredictionSchema.validate(body);
    if (error) {
        // If validation fails, respond with a BAD_REQUEST status and the error message
        return {status:false,message:error.details[0].message}
    } else {
        // If validation is successful, move to the next middleware or route handler
        return {status:true};
    }
};
export const addressDetailsValidation = async (body) => {
    const { error } = schema.addressDetailsSchema.validate(body);
    if (error) {
        // If validation fails, respond with a BAD_REQUEST status and the error message
        return {status:false,message:error.details[0].message}
    } else {
        // If validation is successful, move to the next middleware or route handler
        return {status:true};
    }
};