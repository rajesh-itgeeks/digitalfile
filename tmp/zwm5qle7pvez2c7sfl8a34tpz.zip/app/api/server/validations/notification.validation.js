import * as notifications from './schema/notification.schema'

// Middleware for validating subscription requests
export const saveValidation = async (body) => {
    // Validate the request body using the 'notificationSchema'
    const { error } = notifications.notificationSchema.validate(body);
    if (error) {
        return {
            status: false,
            message: error.details[0].message
        }
    } else {
        return { status: true }
    }
};
export const detailsValidation = async (body) => {
    // Validate the request body using the 'notificationSchema'
    const { error } = notifications.detailsSchema.validate(body);
    if (error) {
        return {
            status: false,
            message: error.details[0].message
        }
    } else {
        return { status: true }
    }
};
export const templateValidation = async (body) => {
    // Validate the request body using the 'notificationSchema'
    const { error } = notifications.templateSchema.validate(body);
    if (error) {
        return {
            status: false,
            message: error.details[0].message
        }
    } else {
        return { status: true }
    }
};

