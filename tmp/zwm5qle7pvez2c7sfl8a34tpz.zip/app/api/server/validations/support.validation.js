import * as schema from "./schema/support.schema.js";
// Middleware for validating unsubscribe requests
export const createSupport = async (body) => {
    // Validate the request body using the 'createSupportSchema'
    const { error } = schema.createSupportSchema.validate(body);
    if (error) {
        return {
            status: false,
            message: error.details[0].message
        }
    } else {
         // If validation succeeds, proceed to the next middleware/controller
        return { status: true }
    }
};
// Middleware for validating unsubscribe requests
export const customSupport = async (body) => {
    // Validate the request body using the 'customSupportSchema'
    const { error } = schema.customSupportSchema.validate(body);
    if (error) {
        return {
            status: false,
            message: error.details[0].message
        }
    } else {
         // If validation succeeds, proceed to the next middleware/controller
        return { status: true }
    }
};
