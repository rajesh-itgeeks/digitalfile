import * as analytics from './schema/analytics.schema'

// Middleware for validating subscription requests
export const dashboardValidation = async (body) => {
    // Validate the request body using the 'notificationSchema'
    const { error } = analytics.analyticsSchema.validate(body);
    if (error) {
        return {
            status: false,
            message: error.details[0].message
        }
    } else {
        return { status: true }
    }
};
