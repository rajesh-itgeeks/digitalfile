import {subscribeSchema,unSubscribeSchema} from "./schema/plan.schema.js";


// Middleware for validating subscription requests
export const subscribeValidation = async (body) => {
    // Validate the request body using the 'subscribeSchema'
    const { error } = subscribeSchema.validate(body);
    if (error) {
        return {
            status: false,
            message: error.details[0].message
        }
    } else {
        // If validation succeeds, proceed to the next middleware/controller
return { status:true }
    }
};

// Middleware for validating unsubscribe requests
export const unSubscribeValidation = async (body) => {
    // Validate the request body using the 'unSubscribeSchema'
    const { error } = unSubscribeSchema.validate(body);
    if (error) {
        // If validation fails, return a 400 Bad Request with the error message
        return {
            status: false,
            message: error.details[0].message
        }    } else {
        // If validation succeeds, proceed to the next middleware/controller
return { status:true }    }
};
