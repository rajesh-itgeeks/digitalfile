// Importing response message handlers
import { SuccessMessage } from "../../constants/messages.js";
/** 
 * Fetches a list of segments from Shopify.
 *
 * @param {Object} session - Shopify session object for making authenticated requests.
 * @returns {Object} - Status, message, and the list of segments fetched from Shopify.
 */
export const getSegmentsList = async (admin) => {
  // Fetch segments using Shopify GraphQL
  const response = await admin.graphql(
    `#graphql
    query {
      segments(first: 250) {
        nodes {
          creationDate
          id
          lastEditDate
          name
        }
      }
    }`
  );

  const data = await response.json()

  // check query send error order not found case 
  // const error = data?.data?.orderEditAddLineItemDiscount?.userErrors;
  // if (error?.length) {
  //   return {
  //     status: false,
  //     message: error[0].message
  //   }
  // }

  return {
    status: true,
    message: `Segments ${SuccessMessage.LIST_FETCHED}`,
    data: data,
  };
};


/**
 * Checks if a customer is part of a specific segment.
 *
 * @param {String} segmentId - The ID of the segment to check.
 * @param {String} customerId - The ID of the customer to check against the segment.
 * @param {Object} session - Shopify session object for making authenticated requests.
 * @returns {Boolean} - True if the customer is part of the specified segment; otherwise, false.
 */
export const checkSegmentInUpSell = async (segmentId, customerId, admin) => {
  // Fetch segment members for the specified segment
  const response = await admin.graphql(
    `#graphql
    query {
      customerSegmentMembers(first: 250, segmentId: "${segmentId}") {
        edges {
          node {
            firstName
            id
          }
        }
      }
    }`
  );

  const data = await response.json()

  // Normalize the customer ID to match the format used in the segment
  const normalizedCustomerId = customerId.replace(
    "gid://shopify/Customer/",
    "gid://shopify/CustomerSegmentMember/"
  );

  // Extract the edges from the response
  const edges = data?.data?.customerSegmentMembers?.edges || [];
  // Check if the normalized customer ID matches any of the node IDs in the segment
  return edges.some((edge) => edge.node.id === normalizedCustomerId);
};
