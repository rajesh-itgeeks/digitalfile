import { SuccessMessage } from '../../constants/messages.js';

export const getAllCountryDeliveryProfilesList = async (admin) => {
  /* ───── 1. delivery profiles ───── */
  const profilesQuery = `
    query {
      deliveryProfiles(first: 250) {
        nodes {
          profileLocationGroups {
            countriesInAnyZone {
              country {
                code { countryCode }
                name
                id
                provinces { name code id }
              }
            }
          }
        }
      }
    }
  `;
  const profilesJson = await (await admin.graphql(profilesQuery)).json();
  const profiles = profilesJson?.data?.deliveryProfiles?.nodes ?? [];

  if (!profiles.length) {
    return {
      status: false,
      message: 'No delivery profiles found.',
      data: { enabledCountriesFromDeliveryProfile: [] },
    };
  }

  /* ───── 2. union of all profile countries ───── */
  const allCodes = new Set();
  const codeToCountry = new Map();

  profiles.forEach((profile) => {
    profile.profileLocationGroups?.forEach((group) => {
      group.countriesInAnyZone?.forEach(({ country }) => {
        const code = country.code.countryCode;
        allCodes.add(code);
        if (!codeToCountry.has(code)) codeToCountry.set(code, country);
      });
    });
  });

  /* ───── 3. enabled market codes ───── */
  const marketsQuery = `
    query {
      markets(first: 100) {
        edges {
          node {
            enabled
            regions(first: 250) {
              nodes { ... on MarketRegionCountry { code } }
            }
          }
        }
      }
    }
  `;
  const marketsJson = await (await admin.graphql(marketsQuery)).json();
  const enabledCodes = new Set(
    (marketsJson?.data?.markets?.edges ?? [])
      .map((e) => e.node)
      .filter((m) => m.enabled)
      .flatMap((m) => m.regions.nodes.map((r) => r.code)),
  );

  /* ───── 4. final list: union ∩ enabled markets ───── */
  const filteredCountries = [...allCodes]
    .filter((code) => enabledCodes.has(code))
    .map((code) => codeToCountry.get(code));

  /* ───── 5. respond ───── */
  return {
    status: true,
    message: `Country ${SuccessMessage.LIST_FETCHED}`,
    data: { enabledCountriesFromDeliveryProfile: filteredCountries },
  };
};
