import { unauthenticated } from "../../../../shopify.server";
import { ErrorMessage, SuccessMessage } from "../../constants/messages";
import { flowTrigger } from "../../models/flowTrigger.model";
import { webVitalsMatrics } from "../../models/webVitalsMatrics.model";
import { extractShopifyId } from "../../utils/utils";
import { removeInReversOrders } from "../order/holdOrder";
// Function to create a flow trigger record
export const FlowTrigger = async (payload) => {
    try {
        // Save flow trigger data to the database
        const result = await flowTrigger.create({ payload: payload });
        console.log("Flow Trigger payload created :", result);
        return {
            status: true,
            message: SuccessMessage.CREATED,
            data: result
        }
    } catch (error) {
        console.error("Error in flow-trigger api:", error);
        return {
            status: false,
            message: ErrorMessage.INTERNAL_SERVER_ERROR
        }
    }
}
// Function to store web vitals metrics
export const webVitals = async (details) => {
    try {
        if (!details?.shop) {
            return {
                status: false,
                message: `Shop ${ErrorMessage.NOT_FOUND}`
            }
        }
        // Save web vitals data to the database
        const result = await webVitalsMatrics.create({ data: details });
        console.log("Web Vitals Matrics payload created");
        return {
            status: true,
            message: SuccessMessage.CREATED,
            data: result
        }
    } catch (error) {
        console.error("Error in webVitalsMatrics api:", error);
        return {
            status: false,
            message: ErrorMessage.INTERNAL_SERVER_ERROR
        }
    }
}
export const orderHoldRelease = async (payload) => {
    try {
        const shop = payload?.shopify_domain;
        const orderId= await extractShopifyId(payload?.properties?.order_id)
        const { admin, session } = await unauthenticated.admin(shop);
        removeInReversOrders(orderId, admin)
        return {
            status: true,
            message: SuccessMessage.FETCHED
        }
    } catch (error) {
        console.error("Error in order hold release api:", error);
        return {
            status: false,
            message: ErrorMessage.INTERNAL_SERVER_ERROR
        }
    }
}