// models
import { Notifications } from "../../models/notifications.model.js";
import { DefaultNotifications } from "../../models/defaultNotifications.model.js";
import { VerifyEmailIdentityCommand, GetIdentityVerificationAttributesCommand } from "@aws-sdk/client-ses";

// constants
import { SuccessMessage, ErrorMessage } from "../../constants/messages.js";
import { NOTIFICATION_TYPES } from "../../constants/constants.js";
import { convertLiquidToHtml, extractShopifyId } from "../../utils/utils.js";
import { ses, sesClient } from "../../config/email.js";

// remove current partner all up-sell details 
export const save = async (details) => {
  try {
    const result = await Notifications.findOneAndUpdate(
      { partnerId: details.partnerId },
      details,
      { new: true, upsert: true } // This ensures the latest updated document is returned
    );
    return {
      status: true,
      message: `Notifications ${SuccessMessage.UPDATED}`,
      data: result
    }
  } catch (error) {
    console.log("Error in save notifications:", error);
    return {
      status: false,
      message: error?.message || ErrorMessage.INTERNAL_SERVER_ERROR
    }
  }
}
// Update a specific notification type for a partner
export const updateType = async (typeDetails) => {
  const { partnerId, type, emailTemplate, subject } = typeDetails;
  // const result = await Notifications.findOneAndUpdate({ partnerId }, { $set: { [type]: details } }, { upsert: true, new: true });
  const result = await Notifications.findOneAndUpdate(
    { partnerId },
    { $set: { [`${type}.emailTemplate`]: emailTemplate, [`${type}.subject`]: subject } }, // Updates only the emailTemplate field
    { upsert: true, new: true }
  );
  return {
    status: true,
    data: result
  }
}
// Fetch notification template details for a specific type
export const templateDetails = async (details) => {
  try {
    const { type, partnerId } = details;
    let result = await Notifications.findOne({ partnerId }, { [type]: 1, _id: 1, createdAt: 1, updatedAt: 1 });
    let data = {
      _id: result._id,
      type: type,
      emailTemplate: result[type]?.emailTemplate,
      subject: result[type]?.subject,
      createdAt: result.createdAt,
      updatedAt: result.updatedAt
    }
    if (!result[type]?.emailTemplate) {
      data = await DefaultNotifications.findOne({ type }).lean();
    }
    return {
      status: true,
      message: `Notifications ${SuccessMessage.FETCHED}`,
      data: data
    }
  } catch (error) {
    console.log("Error in templates Details : ", error);
    return {
      status: false,
      message: error?.message || ErrorMessage.INTERNAL_SERVER_ERROR
    }
  }
}
// Fetch notification details excluding email templates & subjects
export const notification = async (partnerId) => {
  try {
// Exclude email template & subject fields from response
    const excludedFields = Object.values(NOTIFICATION_TYPES).reduce((acc, type) => {
      acc[`${type}.emailTemplate`] = 0;
      acc[`${type}.subject`] = 0;
      return acc;
    }, {});

    let result = await Notifications.findOne({ partnerId }, excludedFields);
    return {
      status: true,
      message: `Notifications ${SuccessMessage.FETCHED}`,
      data: result
    }
  } catch (error) {
    console.log("Error in templates Detail : ", error);
    return {
      status: false,
      message: error?.message || ErrorMessage.INTERNAL_SERVER_ERROR
    }
  }
}
// Generate email template preview by converting Liquid to HTML
export const templatePreview = async (details) => {
  // get order id in number
  const { orderId, emailTemplate, emailSubject, admin, session } = details;
  const id = await extractShopifyId(orderId);
  if (!id) {
    return {
      status: false,
      message: `Order id ${ErrorMessage.NOT_FOUND}`
    }
  }
   // Convert Liquid template to HTML
  const result = await convertLiquidToHtml({ emailTemplate, emailSubject, id, admin, session });
  return {
    status: true,
    message: SuccessMessage.FETCHED,
    data: { emailHtml: result?.emailHtml, emailSubject: result?.subject }
  }
}
// Fetch default notification template by type
export const defaultTemplate = async (details) => {
  const { type } = details;
  const result = await DefaultNotifications.findOne({ type });
  if (!result) {
    return {
      status: false,
      message: ErrorMessage.NOT_FOUND,
    }
  }
  return {
    status: true,
    message: SuccessMessage.FETCHED,
    data: result
  }
}
// Fetch notification details by partner ID
export const notificationDetailsById = async (partnerId) => {
  const result = await Notifications.findOne({ partnerId });
  return {
    status: true,
    data: result
  }
}
// Verify an email address using AWS SES
export const sendEmailVerify = async (email) => {
  try {
    const params = { EmailAddress: email };
    // Check if email is already verified
    const result=await checkVerifyEmail([email]);
    const data= result.data;
    if(data[email]){
      return {
        status: true,
        message: 'Email already Verified',
        
      }
    }
    // Send verification request
    const response = await ses.send(new VerifyEmailIdentityCommand(params));
    return {
      status: true,
      message: 'Email send success',
      data: response
    }
  } catch (error) {
    console.error("Error verifying email:", error);
    return {
      status: false,
      message: error?.message || ErrorMessage.NOT_FOUND,
    }
  }
}
// Check verification status of an email in AWS SES
export const checkVerifyEmail = async (emails) => {
  const command = new GetIdentityVerificationAttributesCommand({
    Identities: emails,
  });
  try {
    const response = await sesClient.send(command);
    const verificationResults = {};
    emails.forEach(email => {
      verificationResults[email] = response.VerificationAttributes[email]?.VerificationStatus === 'Success';
    });
    return {
      status: true,
      message: 'Email verified',
      data: verificationResults
    }
  } catch (error) {
    console.error("Error fetching verification status:", error);
    return {
      status: false,
      message: error?.message || ErrorMessage.NOT_FOUND
    }
  }
}