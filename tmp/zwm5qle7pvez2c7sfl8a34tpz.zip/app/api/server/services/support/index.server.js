// models
import {ContactSupports} from "../../models/contactSupports.model.js";
import {CustomPlanSupports} from "../../models/customPlanSupports.model.js";

// file imports
import {emailConfig} from "../../config/email.js";
import * as emailTemplates from "../../utils/emailTemplate.js";

// Response handlers
import { SuccessMessage } from "../../constants/messages.js";

// packages
import nodemailer from "nodemailer";

// create customer contact support
export const support = async (details, merchantEmail) => { 

 try {
  const supportDetails = await ContactSupports.create(details);
  // send support mail
  const transporter = nodemailer.createTransport(emailConfig);
  const mailOptions = emailTemplates.contactSupportEmail(details, merchantEmail);
  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.error(`Error in support email send :`, error);
    } else {
      console.log(`Support email send success :`, info.response);
    }
  });

  return {
    status: true,
    message: `Contact support ${SuccessMessage.CREATED}`,
    data: supportDetails
  };
 } catch (error) {
  console.log("Error in contact support", error);
  return {
    status: false,
    message:error?.message,
  }
 }
};

// create merchant custom plan support
export const customPlanSupport = async (details) => {

  const supportDetails = await CustomPlanSupports.create(details);
  // send support mail
  const transporter = nodemailer.createTransport(emailConfig);
  const mailOptions = emailTemplates.customPlanSupportEmail(details);
  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.error(`Error in support email send :`, error);
    } else {
      console.log(`Custom Plan Support email send success :`, info.response);
    }
  });

  return {
    status: true,
    message: `Contact support ${SuccessMessage.CREATED}`,
    data: supportDetails
  };
};
