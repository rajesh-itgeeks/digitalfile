// Importing response message handlers
import { SuccessMessage } from "../../constants/messages.js";

/**
 * Fetches a paginated list of collections based on the provided parameters.
 *
 * @param {Object} params - Query parameters including cursor positions, search query, and limit.
 * @param {Object} session - Shopify session object for making authenticated requests.
 * @returns {Object} - Status, message, and the list of collections fetched from Shopify.
 */
export const getCollectionList = async (params, session) => {
  // Construct cursor and query string for pagination and search functionality
  const cursorAfter = params.cursorAfter ? `,after:"${params.cursorAfter}"` : "";
  const cursorBefore = params.cursorBefore ? `,before:"${params.cursorBefore}"` : "";
  const queryString = params.searchQuery ? `,query: "${params.searchQuery}"` : "";
  const cursor = cursorAfter ? `first:${params.limit}` : cursorBefore ? `last:${params.limit}` : `first:${params.limit}`;

  // Initialize Shopify GraphQL client
  const client = new shopify.api.clients.Graphql({ session });

  // GraphQL query to fetch collections
  const query = `{
    collections(${cursor}${cursorAfter}${cursorBefore}${queryString}) {
      edges {
        cursor
        node {
          title
          description
          descriptionHtml
          handle
          id
          updatedAt
          image {
            altText
            id
            originalSrc
          }
        }
      }
    }
  }`;

  // Execute the query
  const data = await client.request(query, {
    variables: {},
    headers: { myHeader: '1' }, // Example header, modify as needed
    retries: 2 // Retry configuration
  });

  return {
    status: true,
    message: `Collection ${SuccessMessage.LIST_FETCHED}`,
    data: data
  };
};

/**
 * Checks if a given collection contains any of the specified product variants.
 *
 * @param {String} collectionId - The ID of the collection to check.
 * @param {Array} variantsIds - Array of product variant IDs to check against the collection.
 * @param {Object} session - Shopify session object for making authenticated requests.
 * @returns {Boolean} - True if any of the variants are found in the collection; otherwise, false.
 */
export const checkCollectionsInUpSell = async (collectionId, variantsIds, admin) => {
  // Fetch products and their variants from the specified collection
  const response = await admin.graphql(
    `#graphql
    query {
      collection(id: "${collectionId}") {
        products(first: 250) {
          nodes {
            id
            variants(first: 250) {
              edges {
                node {
                  id
                }
              }
            }
          }
        }
      }
    }`
  );
  const data = await response.json()

  // Extract product variant IDs from the collection
  const productVariants =
    data?.data?.collection?.products?.nodes?.flatMap(product =>
      product.variants.edges.map(edge => edge.node.id)
    ) || [];

  // Check if any of the provided variant IDs match the collection's product variants
  return variantsIds?.some(variant => productVariants.includes(variant));
};

