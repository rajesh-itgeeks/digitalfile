// Model imports
import { AppSettings } from "../../models/appSettings.model.js";
import { Partner } from "../../models/partner.model.js";
import { SetupGuides } from "../../models/setupGuides.model.js";
import { ContactSupports } from "../../models/contactSupports.model.js";
import nodemailer from "nodemailer";
import * as emailTemplates from "../../utils/emailTemplate.js";
import { SuccessMessage, ErrorMessage } from "../../constants/messages.js";
// Constants
import { MARKETING_EMAILS, PLAN } from "../../constants/constants.js";
import { PagePreviewing } from "../../models/pagePreviewing.model.js";
import { OrderEditingHistory } from "../../models/orderEditingHistory.model.js";
import { Orders } from "../../models/orders.model.js";
import { Notifications } from "../../models/notifications.model.js";
import { emailConfig } from "../../config/email.js";
import { EmailNotification } from "../../models/emailNotification.model.js";
import { ReversOrders } from "../../models/reversOrders.model.js";
import { Translate } from '@google-cloud/translate/build/src/v2';
import { Languages } from "../../models/languages.model.js";
import { addLeadToZoho, updateLeadToZoho } from "../../utils/zoho.server.js";
const translate = new Translate();


// fetch shop partner shop details by REST api and store appropriate details in database
export const createShop = async (request) => {

    const { admin, session } = request;

    const shopInfo = await admin.rest.resources.Shop.all({ session: session });
    if (!shopInfo.data?.length) {
        return {
            status: false,
            message: `Shop ${ErrorMessage.NOT_CREATED}`
        };
    }
    const storData = shopInfo.data[0];
    const details = {
        shopJson: storData,
        myshopify_domain: storData.myshopify_domain,
        amount: PLAN.FREE_AMOUNT,
        planName: PLAN.FREE_NAME,
        isStarted: false,
        hidingFeatures: []
    };

    const shopDetails = await Partner.create(details);

    // added default app settings
    await addedDefaultAppSettings(shopDetails._id, admin);
    // added default setup guid
    await addedDefaultSetupGuid(shopDetails._id);
    // added default page previewing data
    await addedDefaultPagePreviewing(shopDetails._id);
    // added default notification data
    await addedDefaultNotification(shopDetails._id);
    //added default Language English for partner
    await addDefaultLanguage(shopDetails._id);

    const responseData = {
        shopJson: {
            shop_owner: shopDetails.shopJson.shop_owner,
        },
        isStarted: shopDetails.isStarted,
        planName: shopDetails.planName,
        amount: shopDetails.amount,
        interval: shopDetails.interval ? shopDetails.interval : "",
        hidingFeatures: shopDetails.hidingFeatures
    }
    // send support mail
    const merchantEmail = storData.email
    const storeOwnerName = storData?.shop_owner
    const name = storData.myshopify_domain.replace(".myshopify.com", "");
    const adminUrl = `https://admin.shopify.com/store/${name}/apps/account-editor/app`
    const emailData = {
        merchantEmail,
        storeOwnerName,
        adminUrl
    }
    const transporter = nodemailer.createTransport(emailConfig);
    const mailOptions = emailTemplates.welcomeMerchantEmail(emailData, merchantEmail);
    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.error(`Error in Welcome email send :`, error);
        } else {
            console.log(`Welcome email send success :`, info.response);
        }
    });

    // MARKETING_EMAILS.map(async (item) => {
    //     const dateToSend = new Date(Date.now() + item.delayTime);
    //     const details = { ...item, storeOwnerName, merchantEmail, adminUrl }
    //     const { subject, html } = emailTemplates[item.templateType](details, merchantEmail)
    //     await EmailNotification.create({
    //         partnerId: shopDetails._id,
    //         isCancelled: false,
    //         isMarketing: true,
    //         merchantData: {
    //             header: '',
    //             summary: html,
    //             receiverEmail: merchantEmail,
    //             senderEmail: process.env.SMTP_USER_EMAIL,
    //             replyToEmail: process.env.SMTP_USER_EMAIL,
    //             subject,
    //             orderActions: [
    //                 {
    //                     actionType: 'Marketing Email',
    //                     editSummary: '',
    //                 },
    //             ],
    //         },
    //         createdAt: dateToSend,
    //     });
    // })

    try {
        const now = new Date();
        const formattedDate = now.toISOString().split('T')[0];
        const payload = {
            Company: storData.name,
            Last_Name: storData.shop_owner || storData.name,
            Email: storData.email,
            Phone: storData.phone || '',
            Current_App_Status: "Installed",
            Store_Url: storData.myshopify_domain || '',
            Customer_Email: storData.customer_email || '',
            Store_Plan: storData.plan_name || '',
            App_Plan: "Essential",
            Install_Date: formattedDate,
            Country: storData.country || '',
            Lead_Source: "Download",
        };
        // check if partner plan is partner_test
        if (storData.plan_name == "partner_test")
            payload.Lead_Status = "Pre-Qualified"
        await addLeadToZoho(payload);

        const webhookPayload = {
            storeName: storData.name,
            email: storData.email,
            customerEmail: storData.customer_email,
            plan: storData.plan_name,
            url: storData.myshopify_domain,
            paidPlan: PLAN.FREE_NAME,
            installed: "Installed",
            country: storData.country_name,
        };

        await fetch('https://script.google.com/macros/s/AKfycbwIpY7F-r5OWGD4GjoRsGay26XHYxwGvAYU0d5z7zvw0B6DERiaJlsZhX-sjE1WWCs2dw/exec', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(webhookPayload)
        });
        console.log("Sheet webhook execute");
    } catch (error) {
        console.error("Failed to send webhook:", error);
        // Optional: log this error somewhere or continue silently
    }

    return {
        status: true,
        message: `Shop ${SuccessMessage.CREATED}`,
        data: responseData
    };
}

export const addedDefaultPagePreviewing = async (shopId) => {
    await PagePreviewing.create({
        partnerId: shopId,
        thankyouPage: {
            name: "Thankyou Page",
            isAdded: false,
        },
        orderStatusPage: {
            name: "Order Status Page",
            isAdded: false,
        },
        upSellThankyouPage: {
            name: "Up-Sell Thankyou Page",
            isAdded: false,
        },
        upSellOrderStatus: {
            name: "Up-Sell Order Status Page",
            isAdded: false,
        }
    })
}

// current partner default app settings update
export const addedDefaultAppSettings = async (shopId, admin) => {
    const details = {
        partnerId: shopId,
        contactInformation: {
            "isOn": false,
            "email": {
                "isOn": false,
                "time": null
            },
            "phone": {
                "isOn": false,
                "time": null
            }
        },
        shippingDetails: {
            "isOn": false
        },
        orderItems: {
            "isOn": false,
            "quantity": {
                "isOn": false,
                "time": null
            },
            "swap": {
                "isOn": false,
                "time": null
            },
            "removeItem": {
                "isOn": false,
                "time": null
            },
            "addItems": {
                "isOn": false,
                "time": null
            }
        },
        orderManage: {
            "updateAddress": 1,
            "contactInformation": 2,
            "orderItems": 3,
            "orderActions": 4,
            "contactSupport": 5,
            "cancelOrder": 6
        },
        presetTimeFrame: {
            "time": "",
            "type": ""
        },
        cancelOrder: {
            "isOn": false,
            "refunds": {
                "storecredit": false,
                "directrefund": false
            },
            "reason": [
                {
                    "desc": "Found a better price",
                    "key": "cr1",
                },
                {
                    "desc": "Changed my mind",
                    "key": "cr2",
                },
                {
                    "desc": "Item no longer needed",
                    "key": "cr3",
                },
                {
                    "desc": "Shipping cost too high",
                    "key": "cr4",
                },
                {
                    "desc": "Order was incorrect",
                    "key": "cr5",
                },
            ],
            "restockingFees": {
                "isOn": false,
                "type": "percentage",
                "fee": 0,
                "message": ""
            },
            "credit": ""
        },
        orderTags: [],
        productTags: [],
        support: {
            "isOn": false
        },
        orderHolds: {
            "isOn": false
        }
    }
    const appSettingsDetails = await AppSettings.create(details);
    await updateStoreMetaField(appSettingsDetails, admin);
    return true
}

// current partner default setup guid
export const addedDefaultSetupGuid = async (shopId) => {

    const details = {
        partnerId: shopId,
        orderEditingFeature: false,
        editingWindow: false,
        smartCollections: false,
        plan: false
    }
    await SetupGuides.create(details);
    return true
}
export const addedDefaultNotification = async (shopId) => {

    const details = {
        partnerId: shopId,
        enableMerchantNotification: false,
        enableCustomerNotification: true,
        merchantEmails: [],
        customerSenderEmail: null,
        orderEdit: {
            "status": false,
            "emailTemplate": null,
            "subject": null,
        },
        paymentPending: {
            "status": false,
            "emailTemplate": null,
            "subject": null,
        },
        orderCancellation: {
            "status": false,
            "emailTemplate": null,
            "subject": null,
        },
        addUpSellItem: {
            "status": false,
            "emailTemplate": null,
            "subject": null,
        }

    }
    await Notifications.create(details);
    return true
}

// get partner info by shop name 
export const getShopInfo = async (shop) => {
    const details = await Partner.findOne({ myshopify_domain: shop });
    return details;
}

// get partner info by shop name 
export const getShopInfoGraphQl = async (admin) => {
    const details = await admin.graphql(
        `
        #graphql
        { 
        shop {
                name
                url
                myshopifyDomain
                email
                plan {
                displayName
                partnerDevelopment
                shopifyPlus
                }
             }
    }
        `
    );
    const data = await details.json()
    return data;
}

// update partner service 
export const updateShop = async (details, partnerId, session, admin) => {
    if (details?.chargeId) {
        const chargeDetails = await validChargeId(details.chargeId, session, admin);

        if (!chargeDetails.status) {
            return {
                status: chargeDetails.status,
                message: chargeDetails.message
            }
        }

        // Update details with subscription info
        details.amount = chargeDetails.price;
        details.planName = chargeDetails.name;
    }

    await Partner.updateOne({ _id: partnerId }, details);
    return {
        status: true,
        message: SuccessMessage.UPDATED
    }
}

// Check charge ID validity
export const validChargeId = async (chargeId, session, admin) => {
    try {
        const data = await admin.rest.resources.RecurringApplicationCharge.find({
            session,
            id: chargeId,
        });

        if (!data) {
            console.error(`Invalid charge ID: ${chargeId}`);
            return false;
        }

        return data;
    } catch (error) {
        console.error("Error in validChargeId:", error);
        return {
            status: false,
            message: `${ErrorMessage.INVALID_SECRET} For Partner Payment.`
        }
    }
};


export const translateJson = async (obj, targetLanguage) => {

    const translated = {};

    for (const key in obj) {
        if (typeof obj[key] === 'object') {
            translated[key] = await translateJson(obj[key], targetLanguage);
        } else if (typeof obj[key] === 'string') {
            const [translation] = await translate.translate(obj[key], targetLanguage);
            translated[key] = translation;
        } else {
            translated[key] = obj[key]; // Leave non-string values untouched
        }
    }

    return translated;
}

// get partner info by id 
export const storeInfo = async (shopId, request) => {
    const details = await Partner.findOne({ _id: shopId });
    if (!details) {
        const result = await createShop(request)

        if (!result.status) {
            return {
                status: false,
                message: `Shop  ${ErrorMessage.NOT_CREATED}`,
            }
        }
        return {
            status: true,
            message: `Shop info ${SuccessMessage.CREATED}`,
            data: result
        }
    }
    else {
        const responseData = {
            "shopJson": {
                "shop_owner": details.shopJson.shop_owner,
            },
            "isStarted": details.isStarted,
            "planName": details.planName,
            "amount": details.amount,
            "interval": details.interval ? details.interval : "",
            "chargeId": details.chargeId ? details.chargeId : "",
            "hidingFeatures": details.hidingFeatures,
            "currency": details.shopJson.currency,
            "domain": details.myshopify_domain
        }
        return {
            status: true,
            message: `Shop info ${SuccessMessage.FETCHED}`,
            data: responseData
        }
    }

}

// get partner settings by id  
export const getPartnerAppSettings = async (partnerId, admin) => {
    const details = await AppSettings.findOne({ partnerId });
    await updateStoreMetaField(details, admin);
    if (!details) {
        return {
            status: false,
            message: `Partner settings ${ErrorMessage.NOT_FOUND}`
        }
    }
    return {
        status: true,
        message: `Partner settings ${SuccessMessage.FETCHED}`,
        data: details
    }
}

// update partner settings by id  
export const updatePartnerAppSettings = async (partnerId, details, admin) => {

    let updatedSettings;
    // Check if cancelOrder.reason is missing, and preserve existing if so
    if (!details?.cancelOrder?.reason) {
        const existing = await AppSettings.findOne({ partnerId });
        const existingReasons = existing?.cancelOrder?.reason;

        // Merge cancelOrder, preserving existing reasons if not provided
        const cancelOrder = {
            ...(details.cancelOrder || {}),
            reason: existingReasons
        };

        updatedSettings = await AppSettings.findOneAndUpdate(
            { partnerId },
            {
                $set: {
                    ...details,
                    cancelOrder
                }
            },
            { new: true, upsert: true }
        );
    } else {
        // Full update with new reasons
        updatedSettings = await AppSettings.findOneAndUpdate(
            { partnerId },
            { $set: details },
            { new: true, upsert: true }
        );
    }

    await updateStoreMetaField(updatedSettings, admin);
    if (details?.cancelOrder?.reason) {
        await cancellationReasons(partnerId, details)
    }
    return {
        status: true,
        message: `Partner settings ${SuccessMessage.UPDATED}`,
        data: updatedSettings
    }
}

export const cancellationReasons = async (partnerId, details) => {
    try {
        const reasonList = details?.cancelOrder?.reason;

        const existingDocs = await Languages.find({ partnerId });
        if (!existingDocs?.length) {
            const reason = {}
            for (const index in reasonList) {
                const count = Number(index) + 1;
                const key = `cr${count}`
                reason[key] = reasonList[index]?.desc;
            }
            await Languages.create({ partnerId, lang: "en", status: true, name: "English", langJson: { ...reason } });
            return true;
        } else {
            for (const doc of existingDocs) {
                const langJson = { ...(doc.langJson || {}) };

                // 1. Remove CR keys
                for (const key of Object.keys(langJson)) {
                    if (/^cr\d+$/.test(key)) {
                        delete langJson[key];
                    }
                }

                // 2. Add new CR keys
                for (const index in reasonList) {
                    const count = Number(index) + 1;
                    langJson[`cr${count}`] = reasonList[index]?.desc;
                }

                // 3. Update each language document
                await Languages.updateOne(
                    { _id: doc._id },
                    { $set: { langJson } }
                );
            }
            return true
        }

    } catch (error) {
        console.log("Error in cancellationReasons", error);
        return false
    }
}
// update store meta fields 
export const updateStoreMetaField = async (details, admin) => {
    const responseData = await admin.graphql(`
        #graphql
            query {
                shop {
                    id
                }
            }
        `)
    const currentAppData = await responseData.json();
    const response = await admin.graphql(`
        #graphql
        mutation CreateAppDataMetafield($metafieldsSetInput: [MetafieldsSetInput!]!) {
            metafieldsSet(metafields: $metafieldsSetInput) {
                metafields {
                    id
                    namespace
                    key
                    jsonValue
                    ownerType
                    value
                }
                userErrors {
                    field
                    message
                }
        }
        }`, {
        variables: {
            "metafieldsSetInput": [
                {
                    "namespace": "account_editor_app",
                    "key": "account_editor_settings",
                    "type": "json",
                    "value": JSON.stringify(details),
                    "ownerId": currentAppData?.data?.shop?.id
                }
            ]
        },
    })
    // Send the request      
    const data = await response.json()
    return data;
}

// get current partner page previewing details   
export const getPagePreviewing = async (shopId, request) => {
    const { admin } = request;

    const pagePreviewingDetails = await PagePreviewing.findOne({ partnerId: shopId });
    // default create details if not exist
    if (!pagePreviewingDetails) {
        const response = await admin.graphql(
            `#graphql
            query checkoutProfiles {
             checkoutProfiles(first:1,query:"is_published:true") {
                 nodes {
                 id
                 isPublished
                 }
             }
             }`,
        );

        const data = await response.json();


        const checkoutProfileId = data?.data?.checkoutProfiles?.nodes[0]?.id;
        const id = checkoutProfileId ? checkoutProfileId.split('/').pop() : null;

        const details = await PagePreviewing.create({
            partnerId: shopId,
            thankyouPage: {
                name: "Thankyou Page",
                isAdded: false,
            },
            orderStatusPage: {
                name: "Order Status Page",
                isAdded: false,
            },
            upSellThankyouPage: {
                name: "Up-Sell Thankyou Page",
                isAdded: false,
            },
            upSellOrderStatus: {
                name: "Up-Sell Order Status Page",
                isAdded: false,
            },
            checkoutPageId: id
        })
        return {
            status: true,
            message: `Partner page previewing ${SuccessMessage.FETCHED}`,
            data: details
        }
    }
    return {
        status: true,
        message: `Partner page previewing ${SuccessMessage.FETCHED}`,
        data: pagePreviewingDetails
    }
}

// page previewing update details 
export const updatePagePreviewing = async (partnerId, details) => {
    await PagePreviewing.updateOne({ partnerId: partnerId }, details);
    await SetupGuides.findOneAndUpdate({ partnerId: partnerId }, { orderEditingFeature: true });
    return {
        status: true,
        message: `Partner page previewing ${SuccessMessage.UPDATED}`
    }
}

// remove partner details
export const removePartnerDetails = async (myshopify_domain) => {
    const partnerDetails = await Partner.findOne({ myshopify_domain });

    if (!partnerDetails) {
        console.log("Partner details not found for:", myshopify_domain);
        return { status: false, message: `Partner details ${ErrorMessage.NOT_FOUND}` }; // No details to remove
    }

    const partnerId = partnerDetails._id;

    // Remove associated records in parallel
    await Promise.all([
        PagePreviewing.deleteOne({ partnerId }),
        OrderEditingHistory.deleteMany({ partnerId }),
        SetupGuides.deleteOne({ partnerId }),
        AppSettings.deleteOne({ partnerId }),
        Orders.deleteMany({ shop: partnerDetails.myshopify_domain }),
        Partner.deleteOne({ _id: partnerDetails._id }),
        EmailNotification.deleteMany({ partnerId }),
        Notifications.deleteOne({ partnerId }),
        ReversOrders.deleteMany({ partnerId })
    ]);

    console.log(`Removed all details for partner with ID: ${partnerId}`);
    return { status: true, message: "Details removed successfully" };
};

// remove customer details 
export const removeCustomer = async (id) => {
    await ContactSupports.deleteMany({ customerId: id });
    console.log("ContactSupports deleted successfully of customerId ", id);
    return true
}

// uninstalled partner un-subscribe partner plan
export const unInstalled = async (id) => {
    const partnerDetails = await Partner.findOne({ 'shopJson.id': id });
    if (partnerDetails) {
        // update partner plan details 
        await Partner.updateOne({ _id: partnerDetails._id }, {
            amount: PLAN.FREE_AMOUNT,
            planName: PLAN.FREE_NAME,
            subscribeId: null,
            chargeId: null,
            interval: null
        });
        await PagePreviewing.updateOne({ partnerId: partnerDetails._id },
            {
                thankyouPage: {
                    name: "Thankyou Page",
                    isAdded: false,
                },
                orderStatusPage: {
                    name: "Order Status Page",
                    isAdded: false,
                },
                upSellThankyouPage: {
                    name: "Up-Sell Thankyou Page",
                    isAdded: false,
                },
                upSellOrderStatus: {
                    name: "Up-Sell Order Status Page",
                    isAdded: false,
                }
            },);
        await EmailNotification.deleteMany({ partnerId: partnerDetails._id });
        await ReversOrders.deleteMany({ partnerId: partnerDetails._id });
    }

    const webhookPayload = {
        storeName: partnerDetails.shopJson?.name,
        type: "uninstall",
    };

    try {
        await fetch('https://script.google.com/macros/s/AKfycbwIpY7F-r5OWGD4GjoRsGay26XHYxwGvAYU0d5z7zvw0B6DERiaJlsZhX-sjE1WWCs2dw/exec', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(webhookPayload)
        });

        // zoho code right here
        const email = partnerDetails.shopJson?.email
        console.log("store email :", email);
        await updateLeadToZoho(email)

        console.log("Sheet webhook execute");
    } catch (error) {
        console.error("Failed to send webhook:", error);
        // Optional: log this error somewhere or continue silentlypp
    }

    return true
}


export const addDefaultLanguage = async (partnerId) => {
    try {
        await Languages.create({ lang: "en", status: true, langJson: {}, partnerId, name: "English" })
        return true;
    } catch (error) {
        console.log("Error in adding default language", error);
        return false;
    }
}