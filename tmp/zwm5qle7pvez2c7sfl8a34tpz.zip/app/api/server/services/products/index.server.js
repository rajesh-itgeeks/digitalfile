
// Importing response message handlers
import { SuccessMessage } from "../../constants/messages.js";

/**
 * Fetches a paginated list of products based on the provided parameters.
 *
 * @param {Object} params - Query parameters including cursor positions, search query, and limit.
 * @param {Object} session - Shopify session object for making authenticated requests.
 * @returns {Object} - Status, message, and the list of products fetched from Shopify.
 */
export const getProductList = async (params, session) => {
  // Construct cursor and query string for pagination and search functionality
  const cursorAfter = params.cursorAfter ? `,after:"${params.cursorAfter}"` : "";
  const cursorBefore = params.cursorBefore ? `,before:"${params.cursorBefore}"` : "";
  const queryString = params.searchQuery ? `,query: "${params.searchQuery}"` : "";
  const cursor = cursorAfter ? `first:${params.limit}` : cursorBefore ? `last:${params.limit}` : `first:${params.limit}`;

  // Initialize Shopify GraphQL client
  const client = new shopify.api.clients.Graphql({ session });

  // GraphQL query to fetch product list
  const query = `
    query {
      products(${cursor}${cursorAfter}${cursorBefore}${queryString}) {
        edges {
          node {
            id
            title
            totalInventory
            featuredMedia {
              preview {
                image {
                  url
                }
              }
            }
            variants(first: 250) {
              edges {
                node {
                  id
                  title
                  price
                  inventoryQuantity
                  availableForSale
                }
              }
            }
          }
          cursor
        }
        pageInfo {
          hasPreviousPage
          hasNextPage
        }
      }
    }
  `;

  // Execute the query
  const data = await client.request(query, {
    variables: {},
    headers: { myHeader: '1' }, // Example header, modify as needed
    retries: 2 // Retry configuration
  });

  return {
    status: true,
    message: `Product ${SuccessMessage.LIST_FETCHED}`,
    data: data
  };
};

/**
 * Fetches detailed information for product variants based on their IDs.
 *
 * @param {Array} variantIds - Array of product variant IDs to fetch details for.
 * @param {Object} session - Shopify session object for making authenticated requests.
 * @returns {Array} - List of product variant details.
 */
export const getProductVariantDetailsForUpSell = async (variantIds, admin) => {
  // Array to store details of variants
  const variantsDetails = [];

  // Fetch details for each variant ID
  for (const id of variantIds) {
    // Fetch product variant details
    const response = await admin.graphql(
      `#graphql
      query {
        productVariant(id: "${id}") {
          availableForSale
          price
          id
          image {
            src
            originalSrc
          }
          displayName
          title
          sku
          product {
            id
            featuredImage {
              src
            }
          }
        }
      }`
    );

    const data = await response.json()

    // Process the response data
    if (data?.data?.productVariant) {
      const variant = response.data.productVariant;

      // Fallback for variant image if not available
      variant.image = variant.image?.src || variant.product?.featuredImage?.src || null;

      variantsDetails.push(variant); // Add processed variant to the details list
    }
  }

  return variantsDetails;
};
