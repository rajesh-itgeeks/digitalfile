import { json, unstable_parseMultipartFormData, unstable_createMemoryUploadHandler } from "@remix-run/node";
import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";
import crypto from "crypto";
import path from "path";
import { ErrorMessage, SuccessMessage } from "../../constants/messages";
// Initialize S3 client
const s3 = new S3Client({
  region: process.env.AWS_REGION, 
  endpoint: process.env.S3_ENDPOINT, 
  forcePathStyle: false, 
  credentials: {
      accessKeyId: process.env.AWS_ACCESS_KEY_ID,
      secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  },
});
const ALLOWED_IMAGE_TYPES = ["image/jpeg", "image/png", "image/gif", "image/webp"];
// function to generate a unique file name
export const generateFileName = (originalName) => {
  const randomString = crypto.randomBytes(6).toString("hex");
  return `${Date.now()}-${randomString}${path.extname(originalName)}`;
};

export const uploadImage=async(request)=>{
  
  // Create an upload handler for multipart form data
const uploadHandler = unstable_createMemoryUploadHandler({
              maxPartSize: 5 * 1024 * 1024, 
          });
            // Parse form data
          const formData = await unstable_parseMultipartFormData(request, uploadHandler);
                  const file = formData.get("image"); 
                    // Check if file exists
                  if (file.size==0) {
                    return {
                      status: false,
                      message: ` ${ErrorMessage.FILE_NOT_FOUND}`,
                  };
                  }
                  // Validate file type
                  if (!ALLOWED_IMAGE_TYPES.includes(file.type)) {
                    return {
                      status: false,
                      message: `${ErrorMessage.INVALID_FILE_TYPE}`,
                  };
                  }
                  // Generate a unique file name
                  const fileName = generateFileName(file.name);
                  const folderName=process.env.S3_BUCKET_STORE;
                    // Convert file to buffer
                  const fileBuffer = Buffer.from(await file.arrayBuffer());
                   // Prepare upload parameters
                  const uploadParams = {
                      Bucket: process.env.S3_BUCKET, 
                      Key: `${folderName}/${fileName}`,
                      Body: fileBuffer,
                      ContentType: file.type,
                      ACL: "public-read", 
                      ContentLength: fileBuffer.length, 
                  };
             
                  const response=await s3.send(new PutObjectCommand(uploadParams));
                  // Construct the image URL
                  const imageUrl = `${process.env.S3_BASEURL}/${folderName}/${fileName}`;
          
           return {
                  status: true,
                  message: `UpSell ${SuccessMessage.UPLOADED}`,
                  data:imageUrl,
              };
                
}