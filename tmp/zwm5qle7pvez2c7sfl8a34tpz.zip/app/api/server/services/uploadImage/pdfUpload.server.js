import puppeteer from "puppeteer";
import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";
import crypto from "crypto";
import path from "path";
import { ErrorMessage, SuccessMessage } from "../../constants/messages";
import { convertLiquidToHtmlInvoice } from "../../utils/utils";
import { getDefaultInvoice } from "../invoice/index.server";

const s3 = new S3Client({
  region: process.env.AWS_REGION,
  endpoint: process.env.S3_ENDPOINT,
  forcePathStyle: false,
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  },
});

const generateFileName = () => {
  const randomString = crypto.randomBytes(6).toString("hex");
  return `${Date.now()}-${randomString}.pdf`;
};

export const generateInvoicePDF = async (admin,session) => {
  try {
    // const {template} =await getDefaultInvoice();
    // const htmlTemplate = await convertLiquidToHtmlInvoice(template, admin, session);
    const htmlContent = `
     <!doctype html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Email Template</title> 
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&display=swap" rel="stylesheet">
</head> 
<div style="width: 100%; max-width: 600px; margin: 0 auto; font-family: 'Inter', sans-serif;">
 <table class="email" width="100%" border="0" cellspacing="0" cellpadding="0" style="border-radius: 8px;">
    <tr>
        <td>
            <table border="0" style="width: 100%; padding: 16px;" cellspacing="0" cellpadding="0">
                <tbody>

                    <tr>
                        <td>
                            <table border="0" cellspacing="0" cellpadding="0" style="width: 100%;">
                                <tbody>
                                    <tr>
                                        <td>
                                           <div> 
                                              <img src="https://via.placeholder.com/133" alt="Company Logo" width="133" />
                                           </div>
                                        </td> 
                                         <td>
                                          <p style="text-align: right; margin: 0; font-size: 14px; line-height: 20px; color: #777777;">Receipt / Tax Invoice ODID12345</p>
                                          <p style="text-align: right; margin: 0; font-size: 14px; line-height: 20px; color: #777777;">Created 2024-03-27</p> 
                                          <p style="text-align: right; margin: 0; font-size: 14px; line-height: 20px; color: #777777;">Last Updated 2024-03-28</p>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </td>
                    </tr>

                    <tr>
                      <td>
                        <table border="0" cellspacing="0" cellpadding="0" style="width: 100%; text-align: left; margin-top: 24px;">
                           <tbody>
                              <tr>
                                 <th style="width: 500px; color: #303030; font-size: 13px;">Shipping Address</th>
                                 <th style="width: 500px; color: #303030; font-size: 13px;">Customer</th>
                                 <th align="right" style="width: 500px; color: #303030; font-size: 13px;">Order</th>
                               </tr> 
                               <tr style="width: 100%;">
                                <td>
                                 <div style="color: #777777; font-size: 13px; line-height: 22px; font-weight: 500; margin-top: 13px;">
                                    <p>John</p> 
                                    <p>Doe</p>
                                    <p>123 Street Name</p>
                                    <p>Los Angeles</p> 
                                    <p>90001</p>
                                    <p>USA</p> 
                                    <p>+1 234 567 890</p>
                                  </div>
                                </td>
                                <td>
                                 <div style="color: #777777; font-size: 13px; line-height: 22px; font-weight: 500; margin-top: 13px;">
                                    <p>Jane</p>
                                    <p>Smith</p>
                                    <p>456 Avenue</p>
                                    <p>New York</p>
                                    <p>10001</p>
                                    <p>USA</p>
                                    <p>+1 987 654 321</p>
                                  </div>   
                                </td>
                                <td align="right" style="vertical-align: top;">
                                 <div style="color: #777777; font-size: 13px; line-height: 22px; font-weight: 500; margin-top: 13px;">
                                    <p>Paid</p>
                                    <p>jane.smith@example.com</p>
                                    </div>
                                </td>
                               </tr>
                           </tbody>
                         </table>   
                      </td>
                    </tr> 

                      <tr>
                        <td>
                           <table border="0" cellspacing="0" cellpadding="0" style="width: 100%; margin-top: 24px; border: 1px solid #EBEBEB;">
                              <tbody>
                                <tr>
                                  <th align="left" style="width: 25%; padding-left: 12px; padding-top: 12px; padding-bottom: 12px; background-color: #F9FAFB;">Items</th>
                                  <th align="left" style="width: 25%; background-color: #F9FAFB;">Price</th> 
                                  <th align="left" style="width: 25%; background-color: #F9FAFB;">Qty</th>
                                  <th align="left" style="width: 25%; background-color: #F9FAFB;">Total</th>
                                </tr> 
                                <tr>
                                  <td style="padding-left: 16px; padding-top: 16px; padding-bottom: 16px;">Product A</td>
                                  <td>$10.00 USD</td>
                                  <td>2</td>
                                  <td>$20.00 USD</td>
                                </tr>
                                <tr>
                                  <td style="padding-left: 16px; padding-top: 16px; padding-bottom: 16px;">Product B</td>
                                  <td>$15.00 USD</td>
                                  <td>1</td>
                                  <td>$15.00 USD</td>
                                </tr> 
                              </tbody>
                            </table>   
                         </td>
                       </tr> 

                       <tr>
                        <td>
                           <table align="right" border="0" cellspacing="0" cellpadding="0" style="width: 46%; margin-top: 20px;">
                              <tbody> 
                                <tr>
                                  <td>Order discount</td>
                                  <td align="right">-$5.00 USD</td>
                                </tr> 
                                <tr>
                                  <td>Subtotal</td> 
                                  <td align="right">$30.00 USD</td>
                                </tr>
                                <tr>
                                   <td>Shipping</td> 
                                   <td align="right">$5.00 USD</td>
                                </tr>
                                <tr>
                                   <td>VAT</td> 
                                   <td align="right">$2.00 USD</td>
                                </tr> 
                                <tr>
                                 <td colspan="2">Los Angeles Tax 6%</td>
                               </tr>
                               <tr>
                                 <td style="border-bottom: 1px solid #303030;">Total</td> 
                                 <td style="border-bottom: 1px solid #303030;" align="right">$32.00 USD</td>
                               </tr>
                              </tbody>
                            </table>   
                         </td>
                       </tr> 

                       <tr>
                        <td>
                           <table border="0" cellspacing="0" cellpadding="0" style="width: 100%; margin-top: 24px; text-align: center;">
                              <tbody>
                                <tr>
                                   <td>  
                                        <p style="color:#8A8A8A;">Thank you for shopping with us!</p>  
                                        <p><a href="mailto:jane.smith@example.com" style="color: #1990C6;">jane.smith@example.com</a></p> 
                                        <p><a href="https://example-shop.com" style="color: #8A8A8A;">https://example-shop.com</a></p>
                                   </td>
                                </tr>
                              </tbody>
                            </table>   
                         </td>
                       </tr>   
                </tbody>
            </table>
        </td>
    </tr> 
</table>
</div>
</html>

    `;

    const browser = await puppeteer.launch();
    const page = await browser.newPage();
    await page.setContent(htmlContent, { waitUntil: "domcontentloaded" });

    const pdfBuffer = await page.pdf({ format: "A4" });
    await browser.close();

    const fileName = generateFileName();
    const folderName = process.env.S3_BUCKET_STORE;

    const uploadParams = {
      Bucket: process.env.S3_BUCKET,
      Key: `${folderName}/${fileName}`,
      Body: pdfBuffer,
      ContentType: "application/pdf",
      ACL: "public-read",
      ContentLength: pdfBuffer.length,
    };

    await s3.send(new PutObjectCommand(uploadParams));

    const fileUrl = `${process.env.S3_BASEURL}/${folderName}/${fileName}`;

    return {
      status: true,
      message: `Invoice ${SuccessMessage.UPLOADED}`,
      data: fileUrl, 
    };
  } catch (error) {
    console.error("Error generating/uploading PDF:", error);
    return {
      status: false,
      message: ErrorMessage.INTERNAL_SERVER_ERROR,
    };
  }
};
