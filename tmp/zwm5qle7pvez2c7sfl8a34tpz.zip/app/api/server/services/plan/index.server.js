// models
import { Partner } from "../../models/partner.model.js";
import { AppSettings } from "../../models/appSettings.model.js";
import { UpSells } from "../../models/upSell.model.js";


// Response handlers
import { SuccessMessage, ErrorMessage } from "../../constants/messages.js";

// constants
import { PLAN } from "../../constants/constants.js";

// subscribe plan  
export const subscribe = async (planDetails, session, admin) => {
  // Create a new Shopify Storefront API client using the obtained session
  const isTrial = planDetails?.trial ? `, trialDays: ${planDetails.trialDays}` : '';
  console.log("--- Plan Redirect Url:", planDetails.returnUrl);
  const isTest = process.env.ENV_SERVER === 'production' ? session.shop === 'productionae.myshopify.com' ? true : false : true;

  // Define the GraphQL mutation
  const query = `
    #graphql
    mutation AppSubscriptionCreate {
      appSubscriptionCreate(
        name: "${planDetails.plan}",
        returnUrl: "${planDetails.returnUrl}",
        test: ${isTest},
        lineItems: [
          {
            plan: {
              appRecurringPricingDetails: {
                price: {
                  amount: ${planDetails.amount},
                  currencyCode: ${planDetails.currency}
                },
                interval: ${planDetails.interval}
              }
            }
          }
        ]
        ${isTrial}
      ) {
        userErrors {
          field
          message
        }
        appSubscription {
          id
          test
        }
        confirmationUrl
      }
    }
  `;

  // Send the request
  const response = await admin.graphql(query);

  const data = await response.json();

  // Extract potential errors
  const error = data?.data?.appSubscriptionCreate?.userErrors;
  if (error?.length) {
    return {
      status: false,
      message: ErrorMessage.SUBSCRIPTION_FAILED,
      data: error
    };
  }

  // Check subscription ID
  const subscribeId = data?.data?.appSubscriptionCreate?.appSubscription?.id;
  if (!subscribeId) {
    console.log('--- Subscription ID is null');
    return {
      status: false,
      message: ErrorMessage.SUBSCRIPTION_FAILED,
      data: `Subscription ID: ${subscribeId}`
    };
  }

  // Update the partner table with the subscribeId
  await Partner.updateOne(
    { myshopify_domain: session.shop },
    { subscribeId: subscribeId, interval: planDetails.interval }
  );

  return {
    status: true,
    message: SuccessMessage.SUBSCRIPTION_SUCCESS,
    data: data
  };
};

// un-subscribe plan
export const unSubscribe = async (planDetails, partnerDetails, admin) => {
  const planName = planDetails?.planName ? planDetails.planName : PLAN.FREE_NAME;
  console.log("Taking Plan :", planName);
  // Create a new Shopify Storefront API client using the obtained session
  // Define the GraphQL mutation
  const response = await admin.graphql(`
          #graphql
          mutation AppSubscriptionCancel($id: ID!) {
                appSubscriptionCancel(id: $id) {
                  userErrors {
                    field
                    message
                  }
                  appSubscription {
                    id
                    status
                  }
                }
              }
              `, {
    variables: {
      "id": planDetails.planId
    },
  });
  // Send the request
  const data = await response.json();

  // Extract potential errors
  const error = data?.data?.appSubscriptionCancel?.userErrors;
  if (error?.length) {
    return {
      status: false,
      message: error[0]?.message,
    };
  }

  // if current plan is professional and go for free plan
  if (partnerDetails.planName === PLAN.PROFESSIONAL && planDetails.enableFreePlan) {
    // update partner plan details
    await Partner.updateOne({ _id: partnerDetails._id }, {
      amount: PLAN.FREE_AMOUNT,
      planName: PLAN.FREE_NAME,
      interval: "EVERY_30_DAYS",
      subscribeId: null,
      chargeId: null
    });
    // remove cancel order extra reason if added 
    await removeExtraCancelOrderReason(partnerDetails._id);
    // update presetTimeFrame if it is on custom
    await updateUniversalPresetTimeFrame(partnerDetails._id);
    // remove up-sell collection details
    await removeUpSellDetails(partnerDetails._id);
    // remove restocking details
    await removeRestockingDetails(partnerDetails._id);
  }
  // // if current plan is enterprise and go for free plan
  // else if (partnerDetails.planName === PLAN.ENTERPRISE && planDetails.enableFreePlan) {
  //     // update partner plan details
  //     await Partner.updateOne({ _id: partnerDetails._id }, {
  //         amount: PLAN.FREE_AMOUNT,
  //         planName: PLAN.FREE_NAME,
  //         subscribeId: null,
  //         chargeId: null
  //     });
  //     // remove cancel order extra reason if added 
  //     await removeExtraCancelOrderReason(partnerDetails._id);
  //     // update presetTimeFrame if it is on custom
  //     await updateUniversalPresetTimeFrame(partnerDetails._id);
  //     // update individual time
  //     await updateIndividualTimeFrame(partnerDetails._id);
  //     // remove up-sell collection details
  //     await removeUpSellDetails(partnerDetails._id);
  //     // remove restocking details
  //     await removeRestockingDetails(partnerDetails._id);
  // }
  // // if current plan is enterprise and got for professional
  // else if (partnerDetails.planName === PLAN.ENTERPRISE && planDetails.planName === PLAN.PROFESSIONAL) {
  //     // update individual time
  //     await updateIndividualTimeFrame(partnerDetails._id);
  //     // remove up-sell collection details
  //     await removeUpSellDetails(partnerDetails._id);
  //     // remove restocking details
  //     await removeRestockingDetails(partnerDetails._id);
  // }

  return {
    status: true,
    message: SuccessMessage.UN_SUBSCRIBE_SUCCESS,
    data: data
  };
};

// remove extra cancel order reason
export const removeExtraCancelOrderReason = async (partnerId) => {
  const appSettingsDetails = await AppSettings.findOne({ partnerId }).select('cancelOrder');

  if (!appSettingsDetails || !appSettingsDetails.cancelOrder || !Array.isArray(appSettingsDetails.cancelOrder.reason)) {
    return true;
  }

  appSettingsDetails.cancelOrder.reason = appSettingsDetails.cancelOrder.reason.slice(0, 5);
  appSettingsDetails.markModified('cancelOrder.reason');

  await appSettingsDetails.save();

  return true;
}

// if current type is custom update time 
export const updateUniversalPresetTimeFrame = async (partnerId) => {
  const appSettingsDetails = await AppSettings.findOne({ partnerId }).select('presetTimeFrame');

  if (!appSettingsDetails || !appSettingsDetails.presetTimeFrame) {
    return true;
  }

  // check time type is custom or not 
  if (appSettingsDetails.presetTimeFrame.type !== 'custom') {
    return true;
  }

  await AppSettings.updateOne({ partnerId }, { 'presetTimeFrame.time': "60minutes", "presetTimeFrame.type": "" });
  return true;
}

// update individual time frame 
export const updateIndividualTimeFrame = async (partnerId) => {
  await AppSettings.updateOne({ partnerId },
    {
      'contactInformation.email.time': "",
      "contactInformation.phone.time": "",
      "orderItems.quantity.time": "",
      "orderItems.swap.time": "",
      "orderItems.removeItem.time": "",
      "orderItems.addItems.time": "",
    }
  );
  return true;
}

// remove current partner all up-sell details 
export const removeUpSellDetails = async (partnerId) => {
  await UpSells.deleteMany({ partnerId });
}

// remove order cancel restocking details 
export const removeRestockingDetails = async (partnerId) => {
  await AppSettings.updateOne({ partnerId },
    {
      'cancelOrder.restocking.type': "percentage",
      'cancelOrder.restocking.value': null,
      'cancelOrder.restocking.message': null,
    }
  );
  return true;
}

// check current plan status by charge id 
export const planStatus = async (chargeId, session, admin) => {
  try {
    if (!chargeId) {
      return {
        status: true,
        message: SuccessMessage.FETCHED,
        data: { status: true }
      };
    }
    const chargeDetails = await admin.rest.resources.RecurringApplicationCharge.find({
      session: session,
      id: chargeId,
    });
    if (chargeDetails.status !== 'active') {
      return {
        status: true,
        message: SuccessMessage.FETCHED,
        data: { status: false }
      };
    }
    return {
      status: true,
      message: SuccessMessage.FETCHED,
      data: { status: true }
    };
  } catch (error) {
    console.log("Error in Check Partner Charge Details : ", error);
    return {
      status: false,
      message: ErrorMessage.NOT_FOUND
    }
  }
}