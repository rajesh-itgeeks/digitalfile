import { SetupGuides } from "../../models/setupGuides.model.js";
// Response handlers
import { SuccessMessage } from "../../constants/messages.js";
import { OrderEditingHistory } from "../../models/orderEditingHistory.model.js";
import { ORDER_ACTION } from "../../constants/constants.js";


// create customer contact support
export const dashboardStatus = async (partnerId, details) => {
  // Set the start and end dates for the dashboard filter (start date at 00:00:00 and end date at 23:59:59)
  let startDateObj = new Date(details.startDate);
  startDateObj.setHours(0, 0, 0, 0);
  let endDateObj = new Date(details.endDate);
  endDateObj.setHours(23, 59, 59, 999);

  // Prepare the date filter based on the provided start and end dates
  const dateFilter = {};
  if (details.startDate) dateFilter.$gte = new Date(startDateObj);
  if (details.endDate) dateFilter.$lte = new Date(endDateObj);

  // Base filter for matching orders based on partnerId
  const baseMatch = { partnerId };
  if (Object.keys(dateFilter).length) {
    baseMatch.createdAt = dateFilter;
  }

  // Get distinct customer edits for the partner
  const uniqueCustomerEdits = await OrderEditingHistory.distinct("customerId", baseMatch);

  // Get the total number of unique order edits
  const uniqueOrderEdits = await OrderEditingHistory.aggregate([
    {
      $match: baseMatch
    },
    {
      $group: {
        _id: { customerId: "$customerId", orderId: "$orderId" }
      }
    },
    {
      $count: "total"
    }
  ]);
  const totalOrderEdits = uniqueOrderEdits[0]?.total || 0;

  // Get the total number of canceled orders
  const canceledOrdersCount = await OrderEditingHistory.aggregate([
    {
      $match: {
        ...baseMatch,
        orderAction: ORDER_ACTION.CANCEL_ORDER
      }
    },
    {
      $group: {
        _id: "$orderId"
      }
    },
    {
      $count: "total"
    }
  ]);

  const totalCanceledOrders = canceledOrdersCount[0]?.total || 0;

  // Calculate the total revenue from adding items to orders
  const totalAddItemAmount = await OrderEditingHistory.aggregate([
    {
      $match: {
        ...baseMatch,
        orderAction: ORDER_ACTION.ADD_ITEM
      }
    },
    {
      $group: {
        _id: null,
        totalAmount: { $sum: { $toDouble: "$amount" } },
        // totalAmount: { $sum: "$amount" }
      }
    }
  ]);

  const addItemRevenue = totalAddItemAmount[0]?.totalAmount || 0;

  // Get the number of customers who added new products
  // const customersAddingProducts = await OrderEditingHistory.distinct("customerId", {
  //   ...baseMatch,
  //   orderAction: ORDER_ACTION.ADD_ITEM
  // });

  // Calculate the final revenue based on the different order actions
  const revenue = (totalOrderEdits - totalCanceledOrders) * 4 + totalCanceledOrders * 10 + addItemRevenue;

  const totalDiscountAmount = await OrderEditingHistory.aggregate([
    {
      $match: {
        ...baseMatch,
        orderAction: ORDER_ACTION.UP_SELL_REVENUE,
        isRemoved: false
      },
    },
    {
      $group: {
        _id: null,
        totalDiscountAmount: { $sum: { $toDouble: "$discountAmount" } },
      },
    },
  ]);

  const totalUpsellAmount = totalDiscountAmount[0]?.totalDiscountAmount || 0

  // Return the dashboard data
  return {
    status: true,
    message: `Dashboard status ${SuccessMessage.FETCHED}`,
    data: {
      orderEdits: totalOrderEdits, //order edited
      revenue: Number(revenue?.toFixed(2)),  //app attributed revenue
      cancelledOrders: totalCanceledOrders,    //cancelled orders
      discountAmount: totalUpsellAmount,  //upsell revenue
      customerEdits: uniqueCustomerEdits?.length,  //customer edits
      // customersAddingProducts: customersAddingProducts.length,
    }
  };
}
export const dashboardPageData = async (partnerId, details) => {
  if (details.type === 'HOURLY') {
    const startTodayDate = new Date(details.startDate);
    startTodayDate.setUTCHours(0, 0, 0, 0); // Start of the day

    const endTodayDate = new Date(details.startDate);
    endTodayDate.setUTCHours(23, 59, 59, 999); // End of the day at 23:59:59

    const startPreviousDayDate = new Date(startTodayDate.getTime() - 1 * 24 * 60 * 60 * 1000);
    startPreviousDayDate.setUTCHours(0, 0, 0, 0); // Start of the previous day

    const endPreviousDayDate = new Date(endTodayDate.getTime() - 1 * 24 * 60 * 60 * 1000);
    endPreviousDayDate.setUTCHours(23, 59, 59, 999); // End of the previous day at 23:59:59

    // Create the base filter
    const baseMatch = {
      partnerId,
    };

    // Initialize an array to store the hourly data
    const ORDER_EDIT_DATA = [];
    const ORDER_CANCELLED_DATA = [];
    const UP_SELL_REVENUE_DATA = [];
    const REVENUE_DATA = [];
    //get data of last 24 hours
    for (let hour = 0; hour < 24; hour++) {
      const startTodayHour = new Date(startTodayDate);
      startTodayHour.setUTCHours(hour, 0, 0, 0);

      const endTodayHour = new Date(startTodayDate);
      endTodayHour.setUTCHours(hour + 1, 0, 0, 0);

      const startPreviousDayHour = new Date(startPreviousDayDate);
      startPreviousDayHour.setUTCHours(hour, 0, 0, 0);

      const endPreviousDayHour = new Date(endPreviousDayDate);
      endPreviousDayHour.setUTCHours(hour + 1, 0, 0, 0);

      // Filter for the current hour
      const hourFilterToday = {
        ...baseMatch,
        createdAt: {
          $gte: startTodayHour,
          $lt: endTodayHour,
        },
      };

      const hourPreviousDayFilter = {
        ...baseMatch,
        createdAt: {
          $gte: startPreviousDayHour,
          $lt: endPreviousDayHour,
        },
      };
      if (true) {
        const uniqueOrderEditsToday = await OrderEditingHistory.aggregate([
          {
            $match: hourFilterToday
          },
          {
            $group: {
              _id: { customerId: "$customerId", orderId: "$orderId" }
            }
          },
          {
            $count: "total"
          }
        ]);

        const totalOrderEditsToday = uniqueOrderEditsToday[0]?.total || 0;

        const uniqueOrderEditsPreviousDay = await OrderEditingHistory.aggregate([
          {
            $match: hourPreviousDayFilter
          },
          {
            $group: {
              _id: { customerId: "$customerId", orderId: "$orderId" }
            }
          },
          {
            $count: "total"
          }
        ]);
        const totalOrderEditsPreviousday = uniqueOrderEditsPreviousDay[0]?.total || 0;
        // Add the data to the hourlyData array
        ORDER_EDIT_DATA.push({
          name: `${hour % 12 === 0 ? 12 : hour % 12}${hour < 12 ? "am" : "pm"}`, // Generate time label
          date: startTodayHour,
          count: totalOrderEditsToday,
          previousIndex: hour - 1, // Placeholder for any further logic
          pvcount: totalOrderEditsPreviousday,
          previous: {
            name: `${hour % 12 === 0 ? 12 : hour % 12}${hour < 12 ? "am" : "pm"}`,
            date: startPreviousDayHour,
            count: totalOrderEditsPreviousday
          }
        });
      }

      if (true) {
        const orderCancelledToday = await OrderEditingHistory.distinct("orderId", {
          ...hourFilterToday,
          orderAction: ORDER_ACTION.CANCEL_ORDER
        });
        const orderCancelledPreviousDay = await OrderEditingHistory.distinct("orderId", {
          ...hourPreviousDayFilter,
          orderAction: ORDER_ACTION.CANCEL_ORDER
        });
        ORDER_CANCELLED_DATA.push({
          name: `${hour % 12 === 0 ? 12 : hour % 12}${hour < 12 ? "am" : "pm"}`, // Generate time label
          date: startTodayHour,
          count: orderCancelledToday?.length || 0,
          previousIndex: hour - 1, // Placeholder for any further logic
          pvcount: orderCancelledPreviousDay?.length,
          previous: {
            name: `${hour % 12 === 0 ? 12 : hour % 12}${hour < 12 ? "am" : "pm"}`,
            date: startPreviousDayHour,
            count: orderCancelledPreviousDay?.length || 0
          }
        });
      }
      if (true) {



        const totalDiscountAmountToday = await OrderEditingHistory.aggregate([
          {
            $match: {
              ...hourFilterToday,
              orderAction: ORDER_ACTION.UP_SELL_REVENUE,
              isRemoved: false
            },
          },
          {
            $group: {
              _id: null,
              totalDiscountAmount: { $sum: { $toDouble: "$discountAmount" } },
            },
          },
        ]);

        const totalUpsellAmountToday = totalDiscountAmountToday[0]?.totalDiscountAmount || 0
        const totalDiscountAmountPreviousDay = await OrderEditingHistory.aggregate([
          {
            $match: {
              ...hourFilterToday,
              orderAction: ORDER_ACTION.UP_SELL_REVENUE,
              isRemoved: false
            },
          },
          {
            $group: {
              _id: null,
              totalDiscountAmount: { $sum: { $toDouble: "$discountAmount" } },
            },
          },
        ]);

        const totalUpsellAmountPreviousDay = totalDiscountAmountPreviousDay[0]?.totalDiscountAmount || 0

        UP_SELL_REVENUE_DATA.push({
          name: `${hour % 12 === 0 ? 12 : hour % 12}${hour < 12 ? "am" : "pm"}`,
          date: startTodayHour,
          count: totalUpsellAmountToday,
          previousIndex: hour - 1,
          pvcount: totalUpsellAmountPreviousDay,
          previous: {
            name: `${hour % 12 === 0 ? 12 : hour % 12}${hour < 12 ? "am" : "pm"}`,
            date: startPreviousDayHour,
            count: totalUpsellAmountPreviousDay
          }
        });


      }
      if (true) {
        // Get the total number of unique order edits
        const uniqueOrderEditsToday = await OrderEditingHistory.aggregate([
          {
            $match: hourFilterToday
          },
          {
            $group: {
              _id: { customerId: "$customerId", orderId: "$orderId" }
            }
          },
          {
            $count: "total"
          }
        ]);
        const totalOrderEditsToday = uniqueOrderEditsToday[0]?.total || 0;

        // Get the total number of canceled orders
        const canceledOrdersCountToday = await OrderEditingHistory.aggregate([
          {
            $match: {
              ...hourFilterToday,
              orderAction: ORDER_ACTION.CANCEL_ORDER
            }
          },
          {
            $group: {
              _id: "$orderId"
            }
          },
          {
            $count: "total"
          }
        ]);

        const totalCanceledOrdersToday = canceledOrdersCountToday[0]?.total || 0;

        // Calculate the total revenue from adding items to orders
        const totalAddItemAmountToday = await OrderEditingHistory.aggregate([
          {
            $match: {
              ...hourFilterToday,
              orderAction: ORDER_ACTION.ADD_ITEM
            }
          },
          {
            $addFields: {
              amountNum: { $toDouble: "$amount" }
            }
          },
          {
            $group: {
              _id: null,
              totalAmount: { $sum: "$amountNum" }
            }
          }
        ]);


        const addItemRevenueToday = totalAddItemAmountToday[0]?.totalAmount || 0;

        // Calculate the final revenue of current day hour based on the different order actions
        const revenueToday = (totalOrderEditsToday - totalCanceledOrdersToday) * 4 + totalCanceledOrdersToday * 10 + addItemRevenueToday;

        const uniqueOrderEditsPreviousday = await OrderEditingHistory.aggregate([
          {
            $match: hourPreviousDayFilter
          },
          {
            $group: {
              _id: { customerId: "$customerId", orderId: "$orderId" }
            }
          },
          {
            $count: "total"
          }
        ]);
        const totalOrderEditsPreviousDay = uniqueOrderEditsPreviousday[0]?.total || 0;

        // Get the total number of canceled orders
        const canceledOrdersCountPreviousDay = await OrderEditingHistory.aggregate([
          {
            $match: {
              ...hourPreviousDayFilter,
              orderAction: ORDER_ACTION.CANCEL_ORDER
            }
          },
          {
            $group: {
              _id: "$orderId"
            }
          },
          {
            $count: "total"
          }
        ]);

        const totalCanceledOrdersPreviousDay = canceledOrdersCountPreviousDay[0]?.total || 0;

        // Calculate the total revenue from adding items to orders
        const totalAddItemAmountPreviousDay = await OrderEditingHistory.aggregate([
          {
            $match: {
              ...hourPreviousDayFilter,
              orderAction: ORDER_ACTION.ADD_ITEM
            }
          },
          {
            $addFields: {
              amountNum: { $toDouble: "$amount" }
            }
          },
          {
            $group: {
              _id: null,
              totalAmount: { $sum: "$amountNum" }
            }
          }
        ]);


        const addItemRevenuePreviousDay = totalAddItemAmountPreviousDay[0]?.totalAmount || 0;

        // Calculate the final revenue of previous day hour based on the different order actions
        const revenuePreviousDay = (totalOrderEditsPreviousDay - totalCanceledOrdersPreviousDay) * 4 + totalCanceledOrdersPreviousDay * 10 + addItemRevenuePreviousDay;

        REVENUE_DATA.push({
          name: `${hour % 12 === 0 ? 12 : hour % 12}${hour < 12 ? "am" : "pm"}`,
          date: startTodayHour,
          count: revenueToday?.toFixed(2),
          previousIndex: hour - 1,
          pvcount: revenuePreviousDay?.toFixed(2),
          previous: {
            name: `${hour % 12 === 0 ? 12 : hour % 12}${hour < 12 ? "am" : "pm"}`,
            date: startPreviousDayHour,
            count: revenuePreviousDay?.toFixed(2)
          }
        });

      }
    }

    return {
      status: true,
      message: "Hourly data fetched successfully",
      data: { ORDER_EDIT_DATA, ORDER_CANCELLED_DATA, REVENUE_DATA, UP_SELL_REVENUE_DATA },
    };
  }

  else if (details.type === 'DAILY') {
    //in case of daily we'll calculate the difference of days and return diffInDays number of objects
    const start = new Date(details.startDate);
    const end = new Date(details.endDate);
    const diffInMilliseconds = Math.abs(end - start);
    const diffInDays = Math.ceil(diffInMilliseconds / (1000 * 60 * 60 * 24));

    const baseMatch = {
      partnerId,
    };
    //initialize empty array for objects
    const ORDER_EDIT_DATA = [];
    const ORDER_CANCELLED_DATA = [];
    const UP_SELL_REVENUE_DATA = [];
    const REVENUE_DATA = [];
    for (let i = 0; i <= diffInDays; i++) {
      const currentDate = new Date(new Date(details.startDate).getTime() - (i) * 24 * 60 * 60 * 1000);
      const lastWeekDate = new Date(currentDate.getTime() - (diffInDays + 1) * 24 * 60 * 60 * 1000);

      const currentDateStartingHours = new Date(currentDate);
      currentDateStartingHours.setUTCHours(0, 0, 0, 0); // Start of the day

      const currentDateEndingHours = new Date(currentDate);
      currentDateEndingHours.setUTCHours(23, 59, 59, 999); // End of the day at 23:59:59:999

      const lastWeekDateDateStartingHours = new Date(lastWeekDate);
      lastWeekDateDateStartingHours.setUTCHours(0, 0, 0, 0); // Start of the last week day

      const lastWeekDateDateEndingHours = new Date(lastWeekDate);
      lastWeekDateDateEndingHours.setUTCHours(23, 59, 59, 999); // End of the last week day at 23:59:59:999

      const hourFilterCurrentDate = {
        ...baseMatch,
        createdAt: {
          $gte: currentDateStartingHours,
          $lt: currentDateEndingHours, // Use $lt for exclusive upper bound
        },
      }
      const hourFilterPreviousDate = {
        ...baseMatch,
        createdAt: {
          $gte: lastWeekDateDateStartingHours,
          $lt: lastWeekDateDateEndingHours, // Use $lt for exclusive upper bound
        },
      }
      //order edit
      if (true) {
        const uniqueOrderEditsToday = await OrderEditingHistory.aggregate([
          {
            $match: hourFilterCurrentDate
          },
          {
            $group: {
              _id: { customerId: "$customerId", orderId: "$orderId" }
            }
          },
          {
            $count: "total"
          }
        ]);
        const totalOrderEditsToday = uniqueOrderEditsToday[0]?.total || 0;

        const uniqueOrderEditsPreviousDay = await OrderEditingHistory.aggregate([
          {
            $match: hourFilterPreviousDate
          },
          {
            $group: {
              _id: { customerId: "$customerId", orderId: "$orderId" }
            }
          },
          {
            $count: "total"
          }
        ]);
        const totalOrderEditsPreviousday = uniqueOrderEditsPreviousDay[0]?.total || 0;
        // Add the data to the dailyData array
        ORDER_EDIT_DATA.push({
          name: new Date(currentDate).toDateString().split(' ').slice(1, 3).join(' ') || "Date", // Generate time label
          date: currentDate,
          count: totalOrderEditsToday,
          previousIndex: i - 1, // Placeholder for any further logic
          pvcount: totalOrderEditsPreviousday,
          previous: {
            name: new Date(lastWeekDate).toDateString().split(' ').slice(1, 3).join(' ') || "Date",
            date: lastWeekDate,
            count: totalOrderEditsPreviousday
          }
        });
      }
      //cancelled
      if (true) {

        // Get the number of customers who added new products
        const orderCancelledToday = await OrderEditingHistory.distinct("orderId", {
          ...hourFilterCurrentDate,
          orderAction: ORDER_ACTION.CANCEL_ORDER
        });
        const orderCancelledPreviousDay = await OrderEditingHistory.distinct("orderId", {
          ...hourFilterPreviousDate,
          orderAction: ORDER_ACTION.CANCEL_ORDER
        });
        ORDER_CANCELLED_DATA.push({
          name: new Date(currentDate).toDateString().split(' ').slice(1, 3).join(' ') || "Date", // Generate time label
          date: currentDate,
          count: orderCancelledToday?.length || 0,
          previousIndex: i - 1, // Placeholder for any further logic
          pvcount: orderCancelledPreviousDay?.length,
          previous: {
            name: new Date(lastWeekDate).toDateString().split(' ').slice(1, 3).join(' ') || "Date",
            date: lastWeekDate,
            count: orderCancelledPreviousDay?.length || 0
          }
        });

      }

      if (true) {
        const totalDiscountAmountToday = await OrderEditingHistory.aggregate([
          {
            $match: {
              ...hourFilterCurrentDate,
              orderAction: ORDER_ACTION.UP_SELL_REVENUE,
              isRemoved: false
            },
          },
          {
            $group: {
              _id: null,
              totalDiscountAmount: { $sum: { $toDouble: "$discountAmount" } },
            },
          },
        ]);

        const totalUpsellAmountToday = totalDiscountAmountToday[0]?.totalDiscountAmount || 0
        const totalDiscountAmountPreviousDay = await OrderEditingHistory.aggregate([
          {
            $match: {
              ...hourFilterPreviousDate,
              orderAction: ORDER_ACTION.UP_SELL_REVENUE,
              isRemoved: false
            },
          },
          {
            $group: {
              _id: null,
              totalDiscountAmount: { $sum: { $toDouble: "$discountAmount" } },
            },
          },
        ]);

        const totalUpsellAmountPreviousDay = totalDiscountAmountPreviousDay[0]?.totalDiscountAmount || 0
        UP_SELL_REVENUE_DATA.push({
          name: new Date(currentDate).toDateString().split(' ').slice(1, 3).join(' ') || "Date", // Generate time label
          date: currentDate,
          count: totalUpsellAmountToday,
          previousIndex: i - 1, // Placeholder for any further logic
          pvcount: totalUpsellAmountPreviousDay,
          previous: {
            name: new Date(lastWeekDate).toDateString().split(' ').slice(1, 3).join(' ') || "Date",
            date: lastWeekDate,
            count: totalUpsellAmountPreviousDay
          }
        });


      }
      if (true) {


        // Get the total number of unique order edits
        const uniqueOrderEditsToday = await OrderEditingHistory.aggregate([
          {
            $match: hourFilterCurrentDate
          },
          {
            $group: {
              _id: { customerId: "$customerId", orderId: "$orderId" }
            }
          },
          {
            $count: "total"
          }
        ]);
        const totalOrderEditsToday = uniqueOrderEditsToday[0]?.total || 0;

        // Get the total number of canceled orders
        const canceledOrdersCountToday = await OrderEditingHistory.aggregate([
          {
            $match: {
              ...hourFilterCurrentDate,
              orderAction: ORDER_ACTION.CANCEL_ORDER
            }
          },
          {
            $group: {
              _id: "$orderId"
            }
          },
          {
            $count: "total"
          }
        ]);

        const totalCanceledOrdersToday = canceledOrdersCountToday[0]?.total || 0;

        // Calculate the total revenue from adding items to orders
        const totalAddItemAmountToday = await OrderEditingHistory.aggregate([
          {
            $match: {
              ...hourFilterCurrentDate,
              orderAction: ORDER_ACTION.ADD_ITEM
            }
          },
          {
            $addFields: {
              amountNum: { $toDouble: "$amount" }
            }
          },
          {
            $group: {
              _id: null,
              totalAmount: { $sum: "$amountNum" }
            }
          }
        ]);


        const addItemRevenueToday = totalAddItemAmountToday[0]?.totalAmount || 0;

        // Calculate the final revenue based on the different order actions
        const revenueToday = (totalOrderEditsToday - totalCanceledOrdersToday) * 4 + totalCanceledOrdersToday * 10 + addItemRevenueToday;

        const uniqueOrderEditsPreviousday = await OrderEditingHistory.aggregate([
          {
            $match: hourFilterPreviousDate
          },
          {
            $group: {
              _id: { customerId: "$customerId", orderId: "$orderId" }
            }
          },
          {
            $count: "total"
          }
        ]);
        const totalOrderEditsPreviousDay = uniqueOrderEditsPreviousday[0]?.total || 0;

        // Get the total number of canceled orders
        const canceledOrdersCountPreviousDay = await OrderEditingHistory.aggregate([
          {
            $match: {
              ...hourFilterPreviousDate,
              orderAction: ORDER_ACTION.CANCEL_ORDER
            }
          },
          {
            $group: {
              _id: "$orderId"
            }
          },
          {
            $count: "total"
          }
        ]);

        const totalCanceledOrdersPreviousDay = canceledOrdersCountPreviousDay[0]?.total || 0;

        const totalAddItemAmountPreviousDay = await OrderEditingHistory.aggregate([
          {
            $match: {
              ...hourFilterPreviousDate,
              orderAction: ORDER_ACTION.ADD_ITEM
            }
          },
          {
            $addFields: {
              amountNum: { $toDouble: "$amount" }
            }
          },
          {
            $group: {
              _id: null,
              totalAmount: { $sum: "$amountNum" }
            }
          }
        ]);


        const addItemRevenuePreviousDay = totalAddItemAmountPreviousDay[0]?.totalAmount || 0;

        const revenuePreviousDay = (totalOrderEditsPreviousDay - totalCanceledOrdersPreviousDay) * 4 + totalCanceledOrdersPreviousDay * 10 + addItemRevenuePreviousDay;

        REVENUE_DATA.push({
          name: new Date(currentDate).toDateString().split(' ').slice(1, 3).join(' ') || "Date",
          date: currentDate,
          count: revenueToday?.toFixed(2),
          previousIndex: i - 1,
          pvcount: revenuePreviousDay?.toFixed(2),
          previous: {
            name: new Date(lastWeekDate).toDateString().split(' ').slice(1, 3).join(' ') || "Date",
            date: lastWeekDate,
            count: revenuePreviousDay?.toFixed(2)
          }
        });

      }
    }
    return {
      status: true,
      message: "Daily data fetched successfully",
      data: { ORDER_EDIT_DATA, ORDER_CANCELLED_DATA, UP_SELL_REVENUE_DATA, REVENUE_DATA },
    };
  }
}

// return setup guide details 
export const setupGuide = async (partnerId, details) => {
  const data = await SetupGuides.findOneAndUpdate({ partnerId: partnerId }, details, { upsert: true, new: true });
  // Return the setup guide details
  return { status: true, message: `Setup Guide Details ${SuccessMessage.FETCHED}`, data: data };
}

