import { unauthenticated } from "../../../../shopify.server";
import { removeItem } from "../order/edit";
import { getCalculatedLineItemsIds } from "../order/holdOrder";
import { addDiscountFixed } from "../order/up-sell";
import { addOrderItemSingle, getOrderCalculateId, orderEditCommit } from "../order/utils";

export const discountAdd = async (admin, orderrId, varianttID, session) => {

  const orderId = `gid://shopify/Order/${orderrId}`;
  const merchandiseId = `gid://shopify/ProductVariant/${varianttID}`;
  try {
    const { storefront } = await unauthenticated.storefront(
      session?.shop
    );
    const orderRes = await admin.graphql(
      `query($id: ID!) {
        order(id: $id) {
          lineItems(first: 50) {
            nodes {
              id
              quantity
              variant { id }
              currentQuantity
            }
          }
        }
      }`,
      { variables: { id: orderId } }
    );

    const orderData = await orderRes.json();
    const targetLineItem = orderData?.data?.order?.lineItems?.nodes.find(
      item => item.variant?.id === merchandiseId
    );
    const quantity = targetLineItem ? targetLineItem.currentQuantity : 0;



    const response = await storefront.graphql(
      `#graphql
       mutation cartCreate($input: CartInput!) {
                          cartCreate(input: $input) {
                            cart {
                              id
                              checkoutUrl
                              createdAt
                              updatedAt
                              lines(first: 10) {
                                edges {
                                  node {
                                    id
                                  }
                                }
                              }
                            }
                            userErrors {
                              field
                              message
                            }
                          }
                        }`, {
      variables: {
        "input": {
          lines: [
            {
              quantity,
              merchandiseId,
            },
          ],
        }

      },
    }
    );

    const cartCreateData = await response.json();
    const cart = cartCreateData?.data?.cartCreate?.cart;
    console.log("====cart", cart)

    // Fetch cart data to extract discounts
    const getCartQuery = await storefront.graphql(`
      #graphql
      query getCart($cartId: ID!) {
        cart(id: $cartId) {
          id
          discountAllocations {
            discountedAmount {
              amount
              currencyCode
            }
            discountApplication {
              allocationMethod
              targetSelection
              targetType
              value {
                ... on MoneyV2 {
                  __typename
                  amount
                  currencyCode }
                ... on PricingPercentageValue {
                  __typename
                  
                  percentage  }
              }
            }
            ... on CartAutomaticDiscountAllocation { title }
            ... on CartCustomDiscountAllocation { title }
          }
          lines(first: 10) {
            edges {
              node {
                quantity
                merchandise {
                  ... on ProductVariant {
                    id
                  }
                }
                discountAllocations {
                  discountedAmount { amount currencyCode }
                  discountApplication {
                    value {
                      ... on PricingPercentageValue {
                        __typename
                        percentage }
                      ... on MoneyV2 {
                        __typename
                        amount
                        currencyCode }
                    }
                  }
                  ... on CartAutomaticDiscountAllocation { title }
                  ... on CartCustomDiscountAllocation { title }
                }
              }
            }
          }
        }
      }
      
    `, {
      variables: { cartId: cart?.id }
    });

    const orderEditBeginRes = await admin.graphql(
      `mutation orderEditBegin($id: ID!) {
        orderEditBegin(id: $id) {
          calculatedOrder {
            id
            lineItems(first: 50) {
              nodes {
                id
                quantity
                variant {
                  id
                }
                calculatedDiscountAllocations {
                  discountApplication {
                    id
                    __typename
                    ... on CalculatedManualDiscountApplication {
                      id
                      description
                      appliedTo
                      allocationMethod
                      targetSelection
                      targetType
                      value {
                        ... on MoneyV2 {
                          __typename
                          amount
                          currencyCode
                        }
                        ... on PricingPercentageValue {
                          __typename
                          percentage
                        }
                      }
                    }
                  }
                }
                discountAllocations {
                  allocatedAmount {
                    amount
                    currencyCode
                  }
                }
              }
            }
          }
          userErrors {
            field
            message
          }
        }
      }`,
      { variables: { id: orderId } }
    );

    const beginData = await orderEditBeginRes.json();



    const cartData = await getCartQuery.json();
    console.log("-------cartData", cartData)
    const cartt = cartData?.data?.cart;
    let discounts = [];

    let discountTitle = "";
    if (cartt?.discountAllocations?.length > 0) {
      cartt.discountAllocations.forEach((alloc) => {
        const value = alloc.discountApplication?.value;
        const isPercentage = value?.__typename === "PricingPercentageValue";

        // Get title depending on the type
        if (alloc.__typename === "CartAutomaticDiscountAllocation" || alloc.__typename === "CartCustomDiscountAllocation") {
          discountTitle = alloc.title;
        } else if (alloc.__typename === "CartCodeDiscountAllocation") {
          discountTitle = alloc.code;
        }

        discounts.push({
          scope: "cart",
          type: isPercentage ? "percentage" : "fixed",
          value: isPercentage ? value?.percentage : value?.amount,
          currency: alloc.discountedAmount.currencyCode,
          discountedAmount: alloc.discountedAmount.amount,
          title: discountTitle || "Unnamed Discount"
        });
      });
    }

    // Line-level discounts
    else {
      cartt?.lines?.edges?.forEach((line) => {
        const lineItem = line.node;
        if (lineItem.discountAllocations?.length > 0) {
          lineItem.discountAllocations.forEach((alloc) => {
            const value = alloc.discountApplication?.value;
            const isPercentage = value?.__typename === "PricingPercentageValue";

            discountTitle = alloc.title;
            discounts.push({
              scope: "line",
              type: isPercentage ? "percentage" : "fixed",
              value: isPercentage ? value?.percentage : value?.amount,
              currency: value?.currencyCode ?? alloc.discountedAmount?.currencyCode,
              discountedAmount: alloc.discountedAmount?.amount,
              title: discountTitle || "Unnamed Discount"
            });
          });
        }
      });
    }
    console.log("----------discounts", discounts);



    // Get the calculated order ID
    const calculatedOrderId = beginData.data?.orderEditBegin?.calculatedOrder?.id;

    // Get the line items from the calculated order
    const lineItems = beginData.data?.orderEditBegin?.calculatedOrder?.lineItems?.nodes;

    // Find the calculated line item that matches the merchandise ID
    const calculatedLineItem = lineItems?.find(item => item.variant?.id === merchandiseId);

    const calculatedLineItemId = calculatedLineItem?.id;
    const discountAmount = calculatedLineItem?.discountAllocations?.reduce((total, alloc) => {
      return total + parseFloat(alloc.allocatedAmount?.amount || 0);
    }, 0);
    const appliedDiscountTitle = calculatedLineItem?.calculatedDiscountAllocations?.[0]?.discountApplication?.description
    const discountApplicationId = calculatedLineItem?.calculatedDiscountAllocations?.[0]?.discountApplication?.id;
    console.log(calculatedLineItem, '-------------discountApplicationId');

    // Check if the line item was found, and proceed with applying discounts
    if (!calculatedLineItemId) {
      return new Response(JSON.stringify({ error: "No matching calculated line item found" }), {
        status: 404,
        headers: { "Content-Type": "application/json" },
      });
    }
    if (discounts.length === 0) {
      if (discountApplicationId) {
        const removeItemMutationn = await admin.graphql(`
    mutation orderEditRemoveLineItemDiscount(
      $id: ID!
      $discountApplicationId: ID!
    ) {
      orderEditRemoveLineItemDiscount(
        id: $id
        discountApplicationId: $discountApplicationId
      ) {
        calculatedOrder {
          id
        }
        userErrors {
          field
          message
        }
      }
    }`, {
          variables: {
            id: calculatedOrderId,
            discountApplicationId,
          },
        });
        const removeItemDetailss = await removeItemMutationn.json();
        console.log(removeItemDetailss.data, '------------removeItemDetails.data');
        const commitRes = await admin.graphql(
          `mutation orderEditCommit(
                  $id: ID!
                  $notifyCustomer: Boolean!
                  $staffNote: String
                ) {
                  orderEditCommit(
                    id: $id
                    notifyCustomer: $notifyCustomer
                    staffNote: $staffNote
                  ) {
                    order {
                      id
                    }
                    userErrors {
                      field
                      message
                    }
                  }
                }`,
          {
            variables: {
              id: calculatedOrderId,
              notifyCustomer: false,
              staffNote: "Discount applied via app",
            },
          }
        );

        const commitData = await commitRes.json();
        return new Response(JSON.stringify({ message: "discount removed." }), {
          headers: { "Content-Type": "application/json" },
        });
      }
      else {
        return new Response(JSON.stringify({ message: "No applicable discounts found." }), {
          headers: { "Content-Type": "application/json" },
        });
      }

    }
    const cartDiscount = parseFloat(discounts[0]?.discountedAmount || 0);

    // Apply discount to calculated line item
    for (const discount of discounts) {
      const discountInput =
        discount.type === "percentage"
          ? {
            percentValue: parseFloat(discount.value),
            description: discount.title || `${discount.value}% off`,
          }
          : {
            fixedValue: {
              amount: discount?.discountedAmount && !isNaN(discount.value) ? parseFloat(discount.value) : 0,
              currencyCode: discount?.currency || "USD",
            },
            description: discount?.title || `Save $${discount.value}`,
          };
      console.log(cartDiscount, '---------------cartDiscount');
      console.log(discountAmount, '---------------discountAmount');
      console.log(discountTitle, '---------------discountTitle');
      console.log(appliedDiscountTitle, '---------------appliedDiscountTitle');

      if (cartDiscount == discountAmount || discountTitle == appliedDiscountTitle) {
        return new Response(JSON.stringify({ msg: "Discount Apply" }), {
          status: 200,
          headers: { "Content-Type": "application/json" },
        });
      }

      if (discountApplicationId) {
        const removeItemMutation = await admin.graphql(`
                      mutation orderEditRemoveLineItemDiscount(
                        $id: ID!
                        $discountApplicationId: ID!
                      ) {
                        orderEditRemoveLineItemDiscount(
                          id: $id
                          discountApplicationId: $discountApplicationId
                        ) {
                          calculatedOrder {
                            id
                          }
                          userErrors {
                            field
                            message
                          }
                        }
                      }`, {
          variables: {
            id: calculatedOrderId,
            discountApplicationId,
          },
        });
        const removeItemDetails = await removeItemMutation.json();
        console.log(removeItemDetails.data, '------------removeItemDetails.data');

        const userErrors = removeItemDetails.data?.orderEditRemoveLineItemDiscount?.userErrors;
        if (userErrors?.length > 0) {
          console.warn("Remove Item application error:", userErrors);
          return userErrors;
        }
      }

      const discountMutation = `
                            mutation orderEditAddLineItemDiscount(
                              $id: ID!
                              $lineItemId: ID!
                              $discount: OrderEditAppliedDiscountInput!
                            ) {
                              orderEditAddLineItemDiscount(
                                id: $id
                                lineItemId: $lineItemId
                                discount: $discount
                              ) {
                                calculatedOrder {
                                  id
                                }
                                userErrors {
                                  field
                                  message
                                }
                              }
                            }`;

      const discountRes = await admin.graphql(discountMutation, {
        variables: {
          id: calculatedOrderId,
          lineItemId: calculatedLineItemId,
          discount: discountInput,
        },
      });

      const discountData = await discountRes.json();
      const userErrors = discountData.data?.orderEditAddLineItemDiscount?.userErrors;
      if (userErrors?.length > 0) {
        console.warn("Discount application error:", userErrors);
        return userErrors;
      }
    }

    // Commit the order edit
    const commitRes = await admin.graphql(
      `mutation orderEditCommit(
                      $id: ID!
                      $notifyCustomer: Boolean!
                      $staffNote: String
                    ) {
                      orderEditCommit(
                        id: $id
                        notifyCustomer: $notifyCustomer
                        staffNote: $staffNote
                      ) {
                        order {
                          id
                        }
                        userErrors {
                          field
                          message
                        }
                      }
                    }`,
      {
        variables: {
          id: calculatedOrderId,
          notifyCustomer: false,
          staffNote: "Discount applied via app",
        },
      }
    );

    const commitData = await commitRes.json();
    const commitErrors = commitData.data?.orderEditCommit?.userErrors;

    if (commitErrors?.length > 0) {
      return new Response(JSON.stringify({ error: "Commit failed", commitErrors }), {
        status: 400,
        headers: { "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({
      discounts,
      message: "Discounts successfully applied",
    }), {
      headers: { "Content-Type": "application/json" },
    });

  } catch (err) {
    console.error("Unhandled error:", err);
    return new Response("Server error", { status: 500 });
  }
}

export const checkDiscountType = async (orderId, lineItemId, admin) => {
  const orderGraphResponse = await admin.graphql(
    `query($id: ID!) {
      order(id: $id) {
        discountApplications(first: 250) {
          nodes {
            __typename
            allocationMethod
            targetSelection
            targetType
            ... on DiscountCodeApplication { code }
            ... on AutomaticDiscountApplication { title }
            ... on ManualDiscountApplication { title }
            ... on ScriptDiscountApplication { title }
            value {
              ... on MoneyV2 { amount }
              ... on PricingPercentageValue { percentage }
            }
          }
        }
        lineItems(first: 250) {
          edges {
            node {
              id
              currentQuantity
              discountAllocations {
                allocatedAmount { amount }
                discountApplication {
                  __typename
                  targetSelection
                  targetType
                  ... on DiscountCodeApplication { code }
                  ... on AutomaticDiscountApplication { title }
                }
              }
            }
          }
        }
      }
    }`,
    { variables: { id: `gid://shopify/Order/${orderId}` } }
  );

  const orderDetails = await orderGraphResponse.json();
  const order = orderDetails?.data?.order;
  if (!order) return { status: false, discounts: [] };

  const discountApplications = order.discountApplications?.nodes || [];
  const lineItems = order.lineItems?.edges || [];
  const allDiscounts = [];

  const foundDiscounts = [];
  const isZeroAmount = (amount) => {
    const parsed = parseFloat(amount || "0");
    return parsed === 0;
  };

  //check Shipping or Order wide discounts first
  for (const discount of discountApplications) {
    const typeName = discount?.__typename;
    if (!typeName) continue;

    if (discount.targetType === "SHIPPING_LINE") {
      foundDiscounts.push({
        discount: "shippingDiscount",
        type: typeName === "DiscountCodeApplication" ? "code" : "automatic",
        code: discount.code,
        title: discount.title
      });
    }

    if (discount.targetType === "LINE_ITEM" && discount.targetSelection === "ALL") {
      foundDiscounts.push({
        discount: "orderDiscount",
        type: typeName === "DiscountCodeApplication" ? "code" : "automatic",
        code: discount.code,
        title: discount.title
      });
    }

    if (discount.targetType === "LINE_ITEM" && discount.targetSelection === "ENTITLED") {
      foundDiscounts.push({
        discount: "amountOfProduct",
        type: typeName === "DiscountCodeApplication" ? "code" : "automatic",
        code: discount.code,
        title: discount.title
      });
    }
  }
  // check if orderDiscount exist return 
  if (foundDiscounts.some(d => d.discount === "orderDiscount")) {
    return { status: true, discounts: foundDiscounts };
  }
  // Line Item Discounts
  for (const item of lineItems) {
    const currentQuantity = item.node?.currentQuantity;
    if (!currentQuantity || currentQuantity <= 0) continue;

    const discounts = item.node.discountAllocations || [];
    for (const alloc of discounts) {
      const allocAmount = alloc.allocatedAmount?.amount || "0.0";
      const discountApp = alloc.discountApplication || {};
      allDiscounts.push({
        allocatedAmount: allocAmount,
        type: discountApp.__typename,
        code: discountApp.code,
        title: discountApp.title
      });
    }
  }

  const codeDiscounts = allDiscounts.filter(d => d.type === "DiscountCodeApplication");
  const autoDiscounts = allDiscounts.filter(d => d.type === "AutomaticDiscountApplication");



  if (codeDiscounts.length) {
    const hasZeroAmount = codeDiscounts.some(d => isZeroAmount(d.allocatedAmount));
    codeDiscounts.map((item) => {
      foundDiscounts.push({
        discount: hasZeroAmount ? "buyXGetY" : "amountOfProduct",
        type: "code",
        code: item.code,
        title: item.title
      });
    })

  }

  if (autoDiscounts.length) {
    const hasZeroAmount = autoDiscounts.some(d => isZeroAmount(d.allocatedAmount));
    autoDiscounts.map((item) => {
      foundDiscounts.push({
        discount: hasZeroAmount ? "buyXGetY" : "amountOfProduct",
        type: "automatic",
        code: item.code,
        title: item.title
      });
    })
  }

  const uniqueDiscounts = [];
  const seenCodes = new Set();
  if (foundDiscounts?.length) {
    for (const discount of foundDiscounts) {
      const code = discount.code || discount.title;
      if (!seenCodes.has(code)) {
        seenCodes.add(code);
        uniqueDiscounts.push(discount);
      }
    }
  }

  return { status: true, discounts: uniqueDiscounts };
};

export const alreadyAddedDiscountsInOrder = async (orderDetails) => {
  const codesSet = new Set();

  const lineItems = orderDetails?.orderJson?.lineItems?.nodes || [];

  for (const item of lineItems) {
    const allocations = item?.discountAllocations || [];

    for (const allocation of allocations) {
      const application = allocation?.discountApplication;
      if (application?.__typename === "DiscountCodeApplication" && application?.code) {
        if (codesSet.has(application.code)) continue;

        codesSet.add(application.code);
      }
    }
  }
  return Array.from(codesSet);
}

export const discountValidate = async (details, admin) => {
  // check discount added or not if added which type 
  const discountType = await checkDiscountType(details.orderId, details.lineItemId, admin);

  return {
    status: true,
    data: discountType
  }
}

// check if given order any discount added using cart if exist extract all with line item , order or shipping
export const checkOrderDiscount = async (orderDetails, discountCodes, orderId, admin) => {
  const { storefront } = await unauthenticated.storefront(
    orderDetails.shop
  );
  const cartItems = orderDetails.itemDetails.map(item => ({
    quantity: item.quantity,
    merchandiseId: item.productVariantId
  }));
  // create cart id by storefront mutation 
  const createCartResponse = await createCart(storefront, cartItems);

  // check if any issue in create cart process
  if (!createCartResponse.status) {
    return {
      status: false,
      message: createCartResponse.message
    }
  }
  // if create created success apply discounts on create cart 
  const applyDiscountCodeResponse = await applyDiscountInCart(storefront, createCartResponse.data, discountCodes);
  return applyDiscountCodeResponse;

}

// create new cart
export const createCart = async (storefront, cartItems) => {
  const response = await storefront.graphql(
    `#graphql
          mutation cartCreate($input: CartInput) {
            cartCreate(input: $input) {
              cart {
                id
                checkoutUrl
              }
              userErrors {
                field
                message
              }
            }
          }`, {
    variables: {
      "input": {
        lines: cartItems,
      }

    },
  }
  );

  const cartDetails = await response.json();
  // check if any error in create cart 
  const cartData = cartDetails.data.cartCreate;
  if (cartData.userErrors?.length) {
    console.log("Error in cart create :", cartData.userErrors);
    return {
      status: false,
      message: cartData.userErrors[0].message
    }
  }
  const cartId = cartData.cart.id;
  return {
    status: true,
    data: cartId
  }
}

export const applyDiscountInCart = async (storefront, cartId, discountCodes) => {
  const response = await storefront.graphql(
    `#graphql
        mutation cartDiscountCodesUpdate($cartId: ID!, $discountCodes: [String!]) {
        cartDiscountCodesUpdate(cartId: $cartId, discountCodes: $discountCodes) {
          cart {
              id
              checkoutUrl
              discountAllocations {
              discountedAmount {
                amount
                currencyCode
              }
              discountApplication {
                allocationMethod
                targetSelection
                targetType
                value {
                  ... on MoneyV2 {
                    __typename
                    amount
                    currencyCode
                  }
                  ... on PricingPercentageValue {
                    __typename

                    percentage
                  }
                }
              }
              ... on CartAutomaticDiscountAllocation {
                title
              }
              ... on CartCustomDiscountAllocation {
                title
              }
            }
            createdAt
            updatedAt
            lines(first: 10) {
              edges {
                node {
                  id
                  quantity
                  merchandise {
                    ... on ProductVariant {
                      id
                    }
                  }
                  discountAllocations {
                  __typename
                    discountedAmount {
                      amount
                      currencyCode
                    }
                    discountApplication {
                      __typename
                      value {
                        ... on PricingPercentageValue {
                          __typename
                          percentage
                        }
                        ... on MoneyV2 {
                          __typename
                          amount
                          currencyCode
                        }
                      }
                    }
                    ... on CartAutomaticDiscountAllocation {
                      title
                    }
                    ... on CartCustomDiscountAllocation {
                      title
                    }
                  }
                }
              }
            }
          }
          userErrors {
            field
            message
          }
        }
      }         
    `, {
    variables: {
      cartId: `${cartId}`,
      discountCodes: discountCodes
    },
  }
  );

  const cartDetails = await response.json();
  return cartDetails;
}

// checkDiscount
export const checkLineItemDiscount = async (orderDetails, lineItemId) => {
  const lineItem = orderDetails?.lineItems?.nodes?.find(item => item.id === lineItemId);
  // return false if give line item not exist in order
  if (!lineItem) {
    return { status: false };
  }
  // check code discount added or not
  const discountCodes = (lineItem.discountAllocations || [])
    .filter(alloc => alloc.discountApplication?.__typename === "DiscountCodeApplication" || alloc.discountApplication?.__typename === "ManualDiscountApplication")
  // return false if discount not exist
  if (!discountCodes.length) {
    return {
      status: false
    };
  }
  // map codes with their corresponding amounts
  const discounts = discountCodes.map(alloc => ({
    code: alloc.discountApplication.code || alloc.discountApplication.description,
    amount: parseFloat(alloc.allocatedAmount?.amount || 0)
  }));
  // return all discount codes
  return {
    status: true,
    discounts
  };
}

// discountEligible
export const discountEligible = async (details, admin) => {
  const inputDetails = {
    // customerId: details.customerId,
    lineItems: details.lineItems,
    presentmentCurrencyCode: details.currencyCode,
    acceptAutomaticDiscounts: true
  }
  if (details.codes?.length) {
    inputDetails.discountCodes = details.codes
  }
  if (details.shippingAddress) {
    inputDetails.shippingAddress = details.shippingAddress
  }
  console.log(inputDetails, '-------inputDetails');

  const response = await admin.graphql(
    `#graphql
      mutation CalculateDraftOrder($input: DraftOrderInput!) {
        draftOrderCalculate(input: $input) {
          calculatedDraftOrder {
            customer {
              id
            }
            discountCodes
            appliedDiscount{
              description
              title
              value
              valueType
              amount
            }
            platformDiscounts {
              title
              code
              automaticDiscount
              presentationLevel
              totalAmountPriceSet {
                presentmentMoney {
                  amount
                  currencyCode
                }
              }
            }
            lineItems {
              appliedDiscount {
                amountSet {
                  presentmentMoney {
                    amount
                    currencyCode
                  }
                  shopMoney {
                    amount
                    currencyCode
                  }
                }
                value
                valueType
                description
              }
              discountedTotalSet {
                presentmentMoney {
                  amount
                  currencyCode
                }
                shopMoney {
                  amount
                  currencyCode
                }
              }
              product {
                id
                title
              }
              quantity
              requiresShipping
              sku
              taxable
              title
              variantTitle
              variant {
                id
              }
              weight {
                value
                unit
              }
            }
            totalDiscountsSet {
              presentmentMoney {
                amount
                currencyCode
              }
              shopMoney {
                amount
                currencyCode
              }
            }
          }
          userErrors {
            field
            message
          }
        }
      }       
    `, {
    variables: {
      input: inputDetails
    }
  }
  );

  const draftOrderCreate = await response.json();
  const appliedCodes = draftOrderCreate?.data?.draftOrderCalculate?.calculatedDraftOrder?.platformDiscounts || [];
  // const matchedCodes = appliedCodes.filter(code => appliedCodes.includes(code));
  return appliedCodes;

}

export const matchUpdatedOrderDiscounts = async (orderDetails, calculatedOrderId, orderId, items, admin, actionType) => {

  const lineItems = orderDetails?.lineItems?.nodes || [];
  let oldDiscounts = new Set();
  for (const item of lineItems) {
    if (item.currentQuantity <= 0) continue;
    const allocations = item.discountAllocations || [];
    for (const alloc of allocations) {
      const discount = alloc.discountApplication;
      if (!discount) continue;

      const raw = discount.code || discount.title;
      const parts = raw.split('+');
      for (const part of parts) {
        if (part?.trim()) oldDiscounts.add(part.trim());
      }
    }
  }
  oldDiscounts = Array.from(oldDiscounts);
  console.log("oldDiscounts :", oldDiscounts);
  
  let draftOrderLineItems = [];
  const oldItems = orderDetails?.lineItems?.nodes || [];
  if (actionType == 'edit' || actionType == 'add') {
    const mappedOldItems = oldItems.map(({ currentQuantity, variant }) => ({
      quantity: currentQuantity,
      variantId: variant.id,
    })).filter(({ quantity }) => quantity > 0);

    const mappedNewItems = (items || []).map(({ quantity, productVariantId }) => ({
      quantity,
      variantId: productVariantId,
    })).filter(({ quantity }) => quantity > 0);

    const lineItemMap = new Map();
    for (const item of mappedOldItems) {
      if (!lineItemMap.has(item.variantId)) lineItemMap.set(item.variantId, item)
    }
    for (const item of mappedNewItems) {
      lineItemMap.set(item.variantId, item);
    }

    draftOrderLineItems = Array.from(lineItemMap.values());
  } else if (actionType == 'remove') {
    const variantIdToRemove = items?.[0]?.productVariantId;
    draftOrderLineItems = oldItems
      .filter(({ variant, currentQuantity }) => (
        variant.id !== variantIdToRemove && currentQuantity > 0
      ))
      .map(({ currentQuantity, variant }) => ({
        quantity: currentQuantity,
        variantId: variant.id,
      }));
  } else if (actionType == 'swap') {
    const lineItemIdToSwap = items?.[0]?.lineItemId;
    draftOrderLineItems = oldItems
      .filter(({ id, currentQuantity }) => (
        id !== lineItemIdToSwap && currentQuantity > 0
      ))
      .map(({ currentQuantity, variant }) => ({
        quantity: currentQuantity,
        variantId: variant.id,
      }));
    draftOrderLineItems.push({
      variantId: items?.[0]?.productVariantId,
      quantity: items?.[0]?.quantity
    })
  }

  const { coordinatesValidated, countryCodeV2, name, ...shippingAddress } = orderDetails.shippingAddress || {};

  const applyDiscountData = {
    lineItems: draftOrderLineItems,
    codes: oldDiscounts,
    currencyCode: orderDetails.currentTotalPriceSet?.presentmentMoney?.currencyCode,
    customerId: orderDetails.customer?.id,
    shippingAddress
  }

  const discountEligibleDetails = await discountEligible(applyDiscountData, admin);

  const newDiscounts = (discountEligibleDetails || [])
    .map(({ title, totalAmountPriceSet, presentationLevel }) => ({
      code: title,
      amount: totalAmountPriceSet?.presentmentMoney?.amount,
      shipping: presentationLevel === "shipping_level",
    })).filter(Boolean);

  // return if both discounts empty
  console.log("newDiscounts :", newDiscounts);

  if (!oldDiscounts?.length && !newDiscounts.length) {
    return { status: false };
  }

  const newCodes = new Set(newDiscounts.map(d => d.code));
  console.log("items.isWarning :", items.isWarning);

  if (items.isWarning == "false" || undefined) {
    const removedDiscounts = oldDiscounts.filter(code => !newCodes.has(code));
    const countBasedDiscountResult = await countBasedDiscount(removedDiscounts, admin);
    if (countBasedDiscountResult) {
      return {
        status: true,
        discountsUpdated: false,
        messages: "sendNotification"
      }
    }
  }

  const discountsAreEqual = oldDiscounts.length === newCodes.size && oldDiscounts.every(code => newCodes.has(code));
  console.log("discountsAreEqual :", discountsAreEqual);

  if (discountsAreEqual) {
    return {
      status: false
    };
  }

  // Remove old line items
  const removeLineItems = await getCalculatedLineItemsIds(orderId, orderDetails, admin);
  console.log("Removing all old line items...");
  await Promise.all(removeLineItems.map(({ id }) => removeItem(calculatedOrderId, id, admin)));

  await orderEditCommit({
    calculatedOrderId,
    notifyCustomer: true,
    staffNote: "Removing old line items for discount update"
  }, admin);;

  const newCalc = await getOrderCalculateId(orderId, admin);
  const newCalculatedOrderId = newCalc?.data?.data?.orderEditBegin?.calculatedOrder?.id;

  // get discount tags and all discounts 
  const discountTag = newDiscounts.map(({ code }) => code).join("+");
  const totalDiscountAmount = newDiscounts.reduce(
    (acc, { amount }) => acc + parseFloat(amount || 0),
    0
  );
  console.log("discountTag :", discountTag);
  console.log("totalDiscountAmount :", totalDiscountAmount);

  const updatedList = [];
  const productNames = [];
  // add all new line items with discount
  console.log("Adding all new line items...");
  for (const item of draftOrderLineItems) {
    const result = await addOrderItemSingle(orderId, {
      productVariantId: item.variantId,
      quantity: item.quantity
    }, newCalculatedOrderId, admin);
    if (totalDiscountAmount) {
      // add discount
      const discountData = {
        amount: (totalDiscountAmount / draftOrderLineItems.length) / item.quantity,
        currencyCode: orderDetails.currentTotalPriceSet?.presentmentMoney?.currencyCode,
        calculatedLineItemId: result?.data?.calculatedLineItemId,
        calculatedOrderId: newCalculatedOrderId,
        quantity: item.quantity,
        discountTag
      };
      await addDiscountFixed(discountData, admin);
    }
    const matched = items.find(i => i.productVariantId === item.variantId);
    if (matched) {
      if (actionType == 'add') {
        updatedList.push({ status: true, message: `${result?.data?.productTitle} ${result?.data?.productVariant}` });
      } else {
        updatedList.push({ quantity: item.quantity, title: `${result?.data?.productTitle} ${result?.data?.productVariant}` });
      }

      productNames.push(` ${result?.data?.productTitle} ${result?.data?.productVariant} `)
    }
  }

  return {
    status: true,
    discountsUpdated: true,
    data: {
      calculatedOrderId: newCalculatedOrderId,
      updatedList,
      productNames
    }
  };
}

export const addDiscountInAllOrderLineItems = async (orderId, details, admin) => {
  console.log(orderId);
  let discountTag = '';
  const totalDiscountAmount = details.codes.reduce((acc, discount) => {
    const amount = parseFloat(discount.amount || 0);
    discountTag += discount.code;
    return acc + amount;
  }, 0);
  console.log(totalDiscountAmount, '----------------totalDiscountAmount');
  // get calculated order details
  const calculateOrderDetails = await getOrderCalculateId(orderId, admin);
  const calculatedOrderData = calculateOrderDetails?.data?.data?.orderEditBegin?.calculatedOrder;
  const calculatedOrderId = calculatedOrderData?.id;
  const calculatedLineItems = calculatedOrderData.lineItems.edges;
  const filteredLineItems = calculatedLineItems
    .filter(item => item.node.quantity > 0)
    .map(item => ({
      id: item.node.id,
      quantity: item.node.quantity,
      variantId: item.node.variant.id
    }));
  for (const item of filteredLineItems) {
    const discountData = {
      amount: (totalDiscountAmount / filteredLineItems.length) / item.quantity,
      currencyCode: details.currencyCode,
      calculatedLineItemId: item.id,
      calculatedOrderId: calculatedOrderId,
      quantity: item.quantity,
      discountTag: discountTag
    };
    console.log(discountData, '-----------------------------discountData');
    await addDiscountFixed(discountData, admin);
  }

  // commit all changes in order 
  const commitDetails = {
    calculatedOrderId: calculatedOrderId,
    notifyCustomer: true,
    staffNote: "Add new discount in line items"
  }
  const commitResult = await orderEditCommit(commitDetails, admin);
  return commitResult;
}


export const addDiscountInAllOrderLineItemsNew = async (itemDetails, details, admin) => {
  const discountData = {
    amount: (details.totalDiscountAmount / itemDetails.itemsLength) / itemDetails.quantity,
    currencyCode: details.currencyCode,
    calculatedLineItemId: itemDetails.id,
    calculatedOrderId: itemDetails.calculatedOrderId,
    quantity: itemDetails.quantity,
    discountTag: details.discountTag
  };
  console.log(discountData, '-----------------------------discountData');
  await addDiscountFixed(discountData, admin);
  // check auto shipping code 
  const hasShippingDiscount = details.codes.some(code => code.shipping === true);
  if (hasShippingDiscount) {
    console.log('-----------------------------logic for 0 shipping');
  }

  return true;
}

export const countBasedDiscount = async (discounts, admin) => {
  for (const discount of discounts) {
    const response = await admin.graphql(
      `#graphql
        query {
        discountNodes(query: "${discount} ", first: 250) {
          edges {
            node {
              id
              discount {
                ... on DiscountCodeBasic {
                  endsAt
                  recurringCycleLimit
                  summary
                  title
                  createdAt
                  discountClass
                  hasTimelineComment
                  shortSummary
                  startsAt
                  endsAt
                  status
                  appliesOncePerCustomer
                  asyncUsageCount
                  usageLimit
                }
              }
            }
          }
        }
      }       
    `);

    const data = await response.json();
    const edges = data?.data?.discountNodes?.edges ?? [];
    const hasUsageLimit = edges.some(edge => edge.node.discount?.usageLimit);
    if (hasUsageLimit) {
      return true;
    }
  }

  return false;
}

