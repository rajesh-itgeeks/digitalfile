

import { SuccessMessage, ErrorMessage } from "../../constants/messages.js";
import { Invoice } from "../../models/invoice.model.js";
import { DefaultInvoices } from "../../models/defaultInvoices.js";
import { convertLiquidToHtmlInvoice, getInvoicePdfContent } from "../../utils/utils.js";
import { PutObjectCommand } from "@aws-sdk/client-s3";
import { s3 } from '../../config/s3Config.js'
import { v4 as uuidv4 } from "uuid";
import puppeteer from "puppeteer";
import fs from "fs";
import pdf from 'html-pdf-node';
import { Partner } from "../../models/partner.model.js";

// get default Invoice helper function
const getDefaultInvoice = async () => {
  const defaultData = await DefaultInvoices.findOne().select("-_id -__v -partnerId").lean();
  return { template: defaultData?.template };
};


//  Get Invoice
export const getInvoice = async (partnerId, admin, session) => {
  console.log("--partnerIdddd", partnerId)
  let data;
  data = await Invoice.findOne({ partnerId }).select("-_id -__v -partnerId").lean();
  const partnerData = await Partner.findById(partnerId).select("shopJson").lean();
  if (!data) {
    const defaultInvoice = await getDefaultInvoice();

    const htmlTemplate = await convertLiquidToHtmlInvoice(defaultInvoice.template, admin, session, false, partnerId, partnerData);
    // defaultInvoice.previewTemplate = defaultInvoice.template;
    // defaultInvoice.htmlTemplate=htmlTemplate?.emailHtml;

    data = {
      htmlTemplate: htmlTemplate?.emailHtml
    };

    //  data.htmlTemplate=htmlTemplate?.emailHtml
    return { status: true, message: `Invoice ${SuccessMessage.FETCHED}`, data: data };
  }
  if (!data.previewTemplate || data.previewTemplate.trim() === '') {
    data.previewTemplate = (await DefaultInvoices.findOne().select("template").lean())?.template;
  }
  // data.previewTemplate=(await DefaultInvoices.findOne().select("template").lean())?.template
  const template = data.previewTemplate || (await DefaultInvoices.findOne().select("template").lean())?.template;
  const htmlTemplate = await convertLiquidToHtmlInvoice(template, admin, session, data, partnerId, partnerData);
  data.htmlTemplate = htmlTemplate.emailHtml;

  return { status: true, message: `Invoice ${SuccessMessage.FETCHED}`, data: data };
};


export const getDefaultInvoiceDetails = async () => {
  const defaultInvoice = await getDefaultInvoice();
  return { status: true, message: `Invoice ${SuccessMessage.FETCHED}`, data: { previewTemplate: defaultInvoice.template } };
};


//  Create or Update Invoice
export const InvoiceCreate = async (details, partnerId, admin, session) => {

  const template = details.previewTemplate || (await DefaultInvoices.findOne().select("template").lean())?.template;
  const result = await Invoice.findOneAndUpdate({ partnerId }, details, { new: true, upsert: true })
    .select("-_id -__v -partnerId")
    .lean();

  if (!result) {
    return { status: false, message: ErrorMessage.SAVE_FAILED };
  }

  const htmlTemplate = await convertLiquidToHtmlInvoice(template, admin, session);

  return { status: true, message: `Invoices ${SuccessMessage.SAVED}`, data: { result, htmlTemplate } };
};

// Invoice Preview
export const InvoicePreview = async (templateDetails, admin, session) => {

  const emailHtml = await convertLiquidToHtmlInvoice(templateDetails, admin, session);

  return { status: true, message: `Invoice ${SuccessMessage.FETCHED}`, data: emailHtml };
};



// Invoice pdf download
export const generateInvoicePDF = async (admin, session, orderId, partnerDetail) => {
  const partnerId = partnerDetail._id;
  try {
    let data = await Invoice.findOne({ partnerId }).select("-_id -__v -partnerId").lean();
    const partnerData = partnerDetail?.shopJson;
    if (!data) {
      const defaultInvoice = await getDefaultInvoice();
      data = { previewTemplate: defaultInvoice.template };
    }
    if (!data.previewTemplate || data.previewTemplate.trim() === '') {
      data.previewTemplate = (await DefaultInvoices.findOne().select("template").lean())?.template;
    }
    const result = await getInvoicePdfContent(data, data.previewTemplate, admin, session, orderId, partnerData)
    if (!result.status) {
      return { status: false, message: result?.message }
    }
    const htmlContent = result?.data;
    const logoUrl = data?.logoUrl ? data.logoUrl : "https://placehold.co/100x100";
    return {
      status: true,
      message: `${SuccessMessage.INVOICE_CREATED}`,
      data: { htmlContent, logoUrl },
    };
  } catch (error) {
    console.error("Error generating CONTENT OF INVOICE:", error);
    return { status: false, message: error?.message || ErrorMessage.INTERNAL_SERVER_ERROR };
  }
};