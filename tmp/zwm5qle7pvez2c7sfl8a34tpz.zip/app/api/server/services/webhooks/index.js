import { unauthenticated } from "../../../../shopify.server";
import { NOTIFICATION_TYPES } from "../../constants/constants";
import { SuccessMessage } from "../../constants/messages";
import { Orders } from "../../models/orders.model";
import { PagePreviewing } from "../../models/pagePreviewing.model";
import { Partner } from "../../models/partner.model";
import { ReversOrders } from "../../models/reversOrders.model";
import { UpSells } from "../../models/upSell.model";
import { convertLiquidToHtmlForEmail, getShopInfoGraphQl } from "../../utils/utils";
import { removeInReversOrders } from "../order/holdOrder";
import { setNotifyCustomerEmail, setPaymentPendingEmail, flowTriggers } from "../order/utils";


export const orderCreate = async (payload) => {

  const match = payload?.order_status_url.match(/https?:\/\/([^/]+)/);
  const shopName = match ? match[1] : null;

  const orderId = payload.id, shop = shopName, orderDetails = payload;
  const partnerDetails = await Partner.findOne({
    $or: [
      { myshopify_domain: shop },
      { "shopJson.domain": shop }
    ]
  });
  if (!partnerDetails) {
    console.log("Partner details not found for shop :", shopName);
    return {
      status: true,
      message: `Order create ${SuccessMessage.WEBHOOK_EXECUTE}`
    };
  }
  const partnerId = partnerDetails?._id;

  const { admin } = await unauthenticated.admin(partnerDetails.myshopify_domain);
  const shopInfo = await getShopInfoGraphQl(admin)

  orderDetails.shop = {
    ...shopInfo?.data?.shop
  }

  const isUpsellActive = await checkIsUpsellActive(shop)
  console.log("checkIsUpsellActive :", isUpsellActive);


  if (isUpsellActive) {
    await convertLiquidToHtmlForEmail({ ...orderDetails, partnerId }, NOTIFICATION_TYPES.ADD_UPSELL_ITEM, 'customer')
  }

  await setPaymentPendingEmail(partnerId, orderDetails, orderId);

  await setNotifyCustomerEmail(partnerId, orderDetails, orderId)

  // check extension enable in app or not 
  const enable = await extensionEnable(shop);
  if (!enable) {
    return {
      status: true,
      message: `Order payment ${SuccessMessage.WEBHOOK_EXECUTE}`
    };
  }

  const orderExist = await Orders.findOne({ orderId });
  if (orderExist) {
    return {
      status: true,
      message: `Order payment ${SuccessMessage.WEBHOOK_EXECUTE}`
    };
  }

  const orderData = {
    current_subtotal_price: orderDetails.current_subtotal_price,
    financial_status: orderDetails.financial_status,
    created_at: orderDetails.created_at
  }

  // create not exist
  await Orders.create({
    orderId, shop, orderDetails: orderData, partnerId
  })

  return {
    status: true,
    message: `Order payment ${SuccessMessage.WEBHOOK_EXECUTE}`,
    data: payload
  };
}

// check extension is enable on app or not 
export const extensionEnable = async (shop) => {
  if (!shop) return false;

  // Retrieve partner details by shop name
  const partnerDetails = await Partner.findOne({ myshopify_domain: shop }).select('_id');
  if (!partnerDetails) return false;

  // Retrieve partner page preview details
  const pagePreview = await PagePreviewing.findOne({ partnerId: partnerDetails._id });
  if (!pagePreview) return false;

  // Check if either thankyouPage or orderStatusPage is added
  const isThankYouPageAdded = pagePreview.thankyouPage?.isAdded || false;
  const isOrderStatusPageAdded = pagePreview.orderStatusPage?.isAdded || false;

  console.info('isThankYouPageAdded : ', isThankYouPageAdded);
  console.info('isOrderStatusPageAdded : ', isOrderStatusPageAdded);

  return isThankYouPageAdded || isOrderStatusPageAdded;
};

export const orderTransactions = async (payload) => {
  const orderId = payload.order_id
  const webhookOrder = await Orders.findOne({ orderId: orderId });
  const reversOrder = await ReversOrders.findOne({ orderId: orderId });

  // check first order exist or not if not create new entry
  if (webhookOrder || reversOrder) {
    const shop = webhookOrder?.shop ? webhookOrder.shop : reversOrder?.shopName;
    if (!shop) {
      return {
        status: true,
        message: `Order transactions ${SuccessMessage.WEBHOOK_EXECUTE}`,
      };
    }
    const { admin } = await unauthenticated.admin(shop);
    await removeInReversOrders(orderId, admin);
  }
  // remove entry form database and release order
  return {
    status: true,
    message: `Order transactions ${SuccessMessage.WEBHOOK_EXECUTE}`,
  };
}

export const orderCancellation = async (payload) => {
  const orderId = payload?.id;
  if (orderId) {
    return true;
  }
  await ReversOrders.deleteOne({ orderId })
  return true;
}


export const checkIsUpsellActive = async (shop) => {
  if (!shop) return false;

  // Retrieve partner details by shop name
  const partnerDetails = await Partner.findOne({ myshopify_domain: shop }).select('_id');
  if (!partnerDetails) return false;

  // Retrieve partner page preview details
  const pagePreview = await PagePreviewing.findOne({ partnerId: partnerDetails._id });
  if (!pagePreview) return false;

  // Check if either thankyouPage or orderStatusPage is added
  const isUpsellAddedOrderStatus = pagePreview?.upSellOrderStatus?.isAdded || false;
  console.log("isUpsellAddedOrderStatus : ", isUpsellAddedOrderStatus);

  if (!isUpsellAddedOrderStatus) return false

  const activeUpsell = await UpSells.findOne({ partnerId: partnerDetails._id, isActive: true });

  if (!activeUpsell) return false
  console.log("Found Active Up_sell : true");

  return true

}


export const orderUpdate = async (payload) => {

  const match = payload?.order_status_url.match(/https?:\/\/([^/]+)/);
  const shopName = match ? match[1] : null;
  const partnerDetails = await Partner.findOne({
    $or: [
      { "myshopify_domain": shopName },
      { "shopJson.domain": shopName }
    ]
  });
  if(partnerDetails?._id){
    const { admin } = await unauthenticated.admin(partnerDetails.myshopify_domain);
    console.log(partnerDetails.myshopify_domain, "===========shop domain==================");
    flowTriggers(payload.id, 'order-edited', admin);    
  }
  return true;
};