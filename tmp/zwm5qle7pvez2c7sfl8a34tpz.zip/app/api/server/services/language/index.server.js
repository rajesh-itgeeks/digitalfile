import { ErrorMessage, SuccessMessage } from "../../constants/messages"
import { Languages } from "../../models/languages.model"
import { getLanguage } from "../order/utils";

export const saveLanguage = async (partnerId, details) => {
    try {
        const { lang = "en", status, langJson, name = "English" } = details
        let oldJson = await Languages.findOne({ partnerId, lang });
        if (!oldJson) {
            oldJson = await Languages.findOne({ partnerId, lang: "en" });
        }
        const languageData = await Languages.findOneAndUpdate(
            { lang, partnerId },
            {
                $set: {
                    lang,
                    status: status,
                    name: name,
                    langJson: { ...oldJson?.langJson, ...langJson }
                }
            },
            {
                new: true,
                upsert: true
            }
        );

        return {
            status: true,
            message: `Language ${SuccessMessage.FETCHED}`,
            data: languageData
        };

    } catch (error) {
        console.log("Error in createPartnerLanguage", error);
        return {
            status: false,
            message: error?.message || "Error in createPartnerLanguage",
        };
    }

}

export const languageDetails = async (partnerId, lang) => {
    try {
        const languageDetails = await getLanguage(partnerId, lang)
        if (!languageDetails) {
            return {
                status: false,
                message: `languageDetails ${ErrorMessage.NOT_FOUND}`,
            };
        }
        return {
            status: true,
            message: `Language Json ${SuccessMessage.UPDATED}`,
            data: languageDetails?.data
        }
    } catch (error) {
        console.log("Error in store language", error);
        return {
            status: false,
            message: error?.message || "Error in store language",
        };
    }
}
export const languageList = async (partnerId) => {
    try {

        const storeLanguages = await Languages.find({ partnerId })
        if (!storeLanguages?.length) {
            await Languages.create({ partnerId, lang: "en", status: true, langJson: {}, name: "English" })
        }
        const languages = await Languages.find({
            $or: [
                { isDefault: true },
                { partnerId: partnerId }
            ]
        }).select('-langJson')
        const langMap = new Map();

        for (const lang of languages) {
            if (lang.partnerId?.toString() === partnerId.toString()) {
                // If language is created by partner, always prefer it
                langMap.set(lang.lang, lang);
            } else if (!langMap.has(lang.lang)) {
                // If no partner-specific version yet, use default
                langMap.set(lang.lang, lang);
            }
        }

        // 3. Get the unique list
        const languageListUnique = Array.from(langMap.values());
        return {
            status: true,
            message: `Language List ${SuccessMessage.FETCHED}`,
            data: languageListUnique
        }
    } catch (error) {
        console.log("Error in store language", error);
        return {
            status: false,
            message: error?.message || "Error in store language",
        };
    }
}
export const details = async (details) => {
    try {
        const { id, lang, searchKey = "" } = details
        const offset = details?.offset || 0
        const limit = details?.limit || 10
        const defaultData = await Languages.findOne({ lang, isDefault: true })
        const languageData = await Languages.findById(id)
        languageData.langJson = {
            ...defaultData?.langJson,
            ...languageData?.langJson
        };

        let entries = Object.entries(languageData?.langJson || []);
        // Step 1: Apply search if searchKey is given
        const totalKeysCount = entries?.length
        let searchKeysCount = 0
        if (searchKey) {
            const lowerSearch = searchKey.toLowerCase();
            entries = entries.filter(([key, value]) => {
                return key.toLowerCase().includes(lowerSearch) ||
                    String(value).toLowerCase().includes(lowerSearch);
            });

            searchKeysCount = entries?.length
        }
        const paginatedLangJson = Object.fromEntries(entries.slice(offset, offset + limit)
        );
        languageData.langJson = paginatedLangJson
        return {
            status: true,
            message: `Language data ${SuccessMessage.FETCHED}`,
            data: { languageData, totalKeysCount, searchKeysCount }
        }
    } catch (error) {
        console.log("Error in language details", error);
        return {
            status: false,
            message: error?.message || "Error in language details",
        };
    }
}