import { SHOPIFY_TAGS } from "../../../constants/constants";
import { ReversOrders } from "../../../models/reversOrders.model";
import { alreadyAddedDiscountsInOrder, checkOrderDiscount } from "../../discounts/index.server";
import { removeItem } from "../edit";
import { changeOrderShippingAddress, updateShippingMethod } from "../shipping";
import { addDiscountFixed, addDiscountPercentage } from "../up-sell";
import { addedNewTag, addOrderItemSingle, getOrderCalculateId, orderAdmin, orderEditCommit, removedTag } from "../utils";


export const addInReversOrders = async (orderId, admin, orderDetails, partnerId, shopName, isHoldOn) => {
    try {
        // check first order in hold or not if not added on hold
        console.log("Order display fulfillment status :", orderDetails.displayFulfillmentStatus);

        // check if not hold add on hold
        if (isHoldOn && orderDetails.displayFulfillmentStatus != 'ON_HOLD') {
            const holdOrderDetails = await holdOrder(orderId, admin);
            if (!holdOrderDetails.status) {
                return {
                    status: false,
                    message: holdOrderDetails.message
                }
            }
            await addedNewTag(SHOPIFY_TAGS.AE_HOLD_ORDER, orderId, admin)
        }
        // check order details already exist 
        const orderExist = await ReversOrders.findOne({ orderId });
        if (orderExist) {
            console.log('Order Details Already Added in Revers Orders');
            return {
                status: true,
                message: "Add in revers orders success"
            }
        }

        await ReversOrders.create({ orderId, orderJson: orderDetails, partnerId, shopName });
        return {
            status: true,
            message: "Add in revers orders success"
        }
    } catch (error) {
        console.log("Catch error in addInReversOrders :", error);
        return {
            status: false,
            message: "Error in add in revers orders"
        }
    }
}

export const removeInReversOrders = async (orderId, admin) => {
    const releaseOrderResponse = await releaseOrder(orderId, admin);
    if (!releaseOrderResponse.status) {
        return {
            status: false,
            message: releaseOrderResponse.message
        }
    }
    await removedTag(SHOPIFY_TAGS.AE_HOLD_ORDER, orderId, admin)

    await ReversOrders.deleteOne({ orderId });
    return {
        status: true,
        messages: "Remove in revers orders success"
    }
}

export const deleteDetailsFromReverse = async (orderId) => {
    await ReversOrders.deleteOne({ orderId });
    return {
        status: true,
        messages: "Remove in revers orders success"
    }
}

export const releaseOrder = async (orderId, admin) => {
    const orderFulfillmentDetails = await getOrderFulfillmentId(orderId, admin, true);
    if (!orderFulfillmentDetails.status) {
        return {
            status: false,
            message: orderFulfillmentDetails.message
        }
    }
    const fulfillmentOrders = orderFulfillmentDetails.data;
    if (!fulfillmentOrders?.length) {
        return {
            status: true,
            message: "No open fulfillment orders found"
        }
    }
    const holdResults = await Promise.all(
        fulfillmentOrders.map(async (fulfillmentOrder) => {
            const response = await admin.graphql(
                `#graphql
    mutation FulfillmentOrderReleaseHold($id: ID!) {
    fulfillmentOrderReleaseHold(id: $id) {
    fulfillmentOrder {
    id
    }
    userErrors {
    code
    field
    message
    }
    }
    }`,
                {
                    variables: {
                        "id": fulfillmentOrder.id,
                    },
                });
            const details = await response.json();
            const error = details?.data?.fulfillmentOrderReleaseHold?.userErrors;
            if (error.length) {
                return {
                    status: false,
                    message: error[0]?.message
                }
            }
            return { status: true };
        })
    );
    const failed = holdResults.find(result => !result.status);
    if (failed) {
        return {
            status: false,
            message: failed.message || "Failed to hold one or more fulfillment orders"
        };
    }
    return {
        status: true,
        message: "All fulfillment orders release successfully"
    };
}

export const holdOrder = async (orderId, admin) => {
    const orderFulfillmentDetails = await getOrderFulfillmentId(orderId, admin);
    if (!orderFulfillmentDetails.status) {
        return {
            status: false,
            message: orderFulfillmentDetails.message
        }
    }
    const fulfillmentOrders = orderFulfillmentDetails.data;
    if (!fulfillmentOrders?.length) {
        return {
            status: true,
            message: "No open fulfillment orders found"
        }
    }
    const holdResults = await Promise.all(
        fulfillmentOrders.map(async (fulfillmentOrder) => {
            const response = await admin.graphql(
                `#graphql
    mutation HoldMutation($id: ID!, $fulfillmentHold: FulfillmentOrderHoldInput!) {
    fulfillmentOrderHold(id: $id, fulfillmentHold: $fulfillmentHold) {
    fulfillmentOrder {
    id
    fulfillmentHolds {
    id
    reason
    reasonNotes
    }
    }
    userErrors {
    code
    field
    message
    }
    }
    }
    `,
                {
                    variables: {
                        "id": fulfillmentOrder.id,
                        "fulfillmentHold": {
                            "reason": "AWAITING_PAYMENT",
                            "reasonNotes": "Account-Editor holds orders automatically when the customer updates their order with new products. It'll be auto-released after the payment."
                        },
                    },
                });
            const details = await response.json();
            const error = details?.data?.fulfillmentOrderHold?.userErrors;
            if (error.length) {
                return {
                    status: false,
                    message: error[0]?.message
                }
            }
            return { status: true };
        })
    );
    const failed = holdResults.find(result => !result.status);
    if (failed) {
        return {
            status: false,
            message: failed.message || "Failed to hold one or more fulfillment orders"
        };
    }
    return {
        status: true,
        message: "All fulfillment orders held successfully"
    };
}

export const getOrderFulfillmentId = async (orderId, admin, isRelease = false) => {
    const response = await admin.graphql(
        `#graphql
        {
        order(id: "gid://shopify/Order/${orderId}") {
        fulfillmentOrders(first: 250) {
        edges {
        node {
        id
        status
        lineItems (first: 250){
        edges {
        node {
        id
        lineItem{
        id
        quantity
        }
        }
        }
        }
        }
        }
        }
        }
        }
        `,
    );
    const details = await response.json();
    const orderDetails = details?.data?.order;
    if (!orderDetails) {
        return {
            status: false,
            message: `Order ${ErrorMessage.NOT_FOUND}`
        }
    }
    const fulfillmentOrders = orderDetails.fulfillmentOrders?.edges
        ?.map(edge => edge.node)
        ?.filter(order => order.status === (isRelease ? "ON_HOLD" : "OPEN"));
    return {
        status: true,
        data: fulfillmentOrders
    }
}

// reverse order 
export const reverseOrderFromShopify = async (orderId, admin, session) => {
    const orderLatestDetails = await orderAdmin(orderId, admin);
    const removeLineItems = await getCalculatedLineItemsIds(orderId, orderLatestDetails, admin);
    console.log("Remove Items :", removeLineItems);

    const oldOrderDetails = await ReversOrders.findOne({ orderId });

    let lineItemCount = 1;
    const itemDetails = oldOrderDetails.orderJson.lineItems.nodes.map(lineItem => {
        lineItemCount += 1;
        const allocations = lineItem.discountAllocations || [];
        const discountAmount = allocations.reduce((sum, alloc) => {
            return sum + parseFloat(alloc.allocatedAmount?.amount || 0);
        }, 0);
        const tags = allocations.map(a =>
            a.discountApplication?.code
                ? a.discountApplication.code
                : a.discountApplication?.title
        ).filter(Boolean);
        return {
            productVariantId: lineItem.variant.id,
            quantity: lineItem.quantity,
            customerId: oldOrderDetails.orderJson.customerId,
            partnerId: oldOrderDetails.partnerId,
            discountAmount: discountAmount,
            discountTags: `${[...new Set(tags)].join(', ')}`,
            currencyCode: oldOrderDetails.orderJson?.currentTotalPriceSet?.presentmentMoney?.currencyCode,
        }
    });


    console.log("Add Items :", itemDetails);

    const calculateOrderDetails = await getOrderCalculateId(orderId, admin);
    const calculatedOrderId = calculateOrderDetails?.data?.data?.orderEditBegin?.calculatedOrder?.id;

    if (!calculateOrderDetails.status || !calculatedOrderId) {
        return {
            status: false,
            message: calculateOrderDetails.message
        };
    }

    await Promise.all(
        removeLineItems.map(({ id }) => removeItem(calculatedOrderId, id, admin))
    );

    await orderEditCommit({
        calculatedOrderId,
        notifyCustomer: true,
        staffNote: "Remove item"
    }, admin);



    await Promise.all(
        itemDetails.flatMap(async (item) => {
            const { quantity, discountAmount, } = item;
            // if no discount or only 1 quantity
            if (!discountAmount || quantity === 1) {
                return [
                    (async () => {
                        const calculateOrderDetails = await getOrderCalculateId(orderId, admin);
                        const calculatedOrderId = calculateOrderDetails?.data?.data?.orderEditBegin?.calculatedOrder?.id;
                        const result = await addOrderItemSingle(orderId, item, calculatedOrderId, admin);
                        if (discountAmount > 0 && result?.data?.calculatedLineItemId) {
                            const discountDetails = {
                                amount: discountAmount,
                                currencyCode: item.currencyCode,
                                calculatedLineItemId: result?.data?.calculatedLineItemId,
                                calculatedOrderId: calculatedOrderId,
                                quantity: 1,
                                discountTag: item.discountTags
                            };
                            await addDiscountFixed(discountDetails, admin);
                        }
                        // add commit 
                        await orderEditCommit({
                            calculatedOrderId: calculatedOrderId,
                            notifyCustomer: true,
                            staffNote: "Add items back"
                        }, admin);
                        return true;
                    })(),
                ];
            }

            // for quantity > 1 with discount
            const base = Math.floor((discountAmount / quantity) * 100) / 100;
            const remainder = +(discountAmount - base * quantity).toFixed(2);

            // case with no remainder, treat as single item
            if (remainder === 0) {
                return [
                    (async () => {
                        const calculateOrderDetails = await getOrderCalculateId(orderId, admin);
                        const calculatedOrderId = calculateOrderDetails?.data?.data?.orderEditBegin?.calculatedOrder?.id;
                        const result = await addOrderItemSingle(orderId, item, calculatedOrderId, admin);
                        if (result?.data?.calculatedLineItemId) {
                            const discountDetails = {
                                amount: discountAmount / quantity,
                                currencyCode: item.currencyCode,
                                calculatedLineItemId: result?.data?.calculatedLineItemId,
                                calculatedOrderId: calculatedOrderId,
                                quantity: quantity,
                                discountTag: item.discountTags
                            };
                            await addDiscountFixed(discountDetails, admin);
                        }
                        // add commit 
                        await orderEditCommit({
                            calculatedOrderId: calculatedOrderId,
                            notifyCustomer: true,
                            staffNote: "Add items back"
                        }, admin);
                        return true;
                    })(),
                ];
            }

            // split into two calls when remainder exists
            const itemPart1 = { ...item, quantity: quantity - 1, discountAmount: base };
            const itemPart2 = { ...item, quantity: 1, discountAmount: +(base + remainder).toFixed(2) };

            return [
                (async () => {
                    const calculateOrderDetails = await getOrderCalculateId(orderId, admin);
                    const calculatedOrderId = calculateOrderDetails?.data?.data?.orderEditBegin?.calculatedOrder?.id;

                    const result = await addOrderItemSingle(orderId, itemPart1, calculatedOrderId, admin);
                    if (result?.data?.calculatedLineItemId) {
                        const discountDetails = {
                            amount: itemPart1.discountAmount,
                            currencyCode: itemPart1.currencyCode,
                            calculatedLineItemId: result?.data?.calculatedLineItemId,
                            calculatedOrderId: calculatedOrderId,
                            quantity: itemPart1.quantity,
                            discountTag: itemPart1.discountTags
                        };
                        await addDiscountFixed(discountDetails, admin);
                    }
                    // add commit 
                    await orderEditCommit({
                        calculatedOrderId: calculatedOrderId,
                        notifyCustomer: true,
                        staffNote: "Add items back"
                    }, admin);

                    return true;
                })(),
                (async () => {
                    const calculateOrderDetails = await getOrderCalculateId(orderId, admin);
                    const calculatedOrderId = calculateOrderDetails?.data?.data?.orderEditBegin?.calculatedOrder?.id;

                    const result = await addOrderItemSingle(orderId, itemPart2, calculatedOrderId, admin);
                    if (result?.data?.calculatedLineItemId) {
                        const discountDetails = {
                            amount: itemPart2.discountAmount,
                            currencyCode: itemPart2.currencyCode,
                            calculatedLineItemId: result?.data?.calculatedLineItemId,
                            calculatedOrderId: calculatedOrderId,
                            quantity: 1,
                            discountTag: itemPart2.discountTags
                        };
                        await addDiscountFixed(discountDetails, admin);
                    }
                    await orderEditCommit({
                        calculatedOrderId: calculatedOrderId,
                        notifyCustomer: true,
                        staffNote: "Add items back"
                    }, admin);

                    return true;
                })(),
            ];
        })
    )

    console.log("Items remove and added success!!!", lineItemCount);

    const releaseDetails = await removeInReversOrders(orderId, admin);
    if (!releaseDetails.status) {
        return {
            status: false,
            message: releaseDetails.message
        };
    }

    const shippingLines = oldOrderDetails?.orderJson?.shippingLines;
    const selectedMethod = Array.isArray(shippingLines?.edges) && shippingLines?.edges.length > 0
        ? Object.fromEntries(
            shippingLines.edges.map((edge, index) => {
                const title = edge.node?.title ?? 'unknown';
                const amount = edge.node?.originalPriceSet?.presentmentMoney?.amount ?? 0;
                return [index.toString(), `${index}__${index}_<end>_${title}/${amount}`];
            })
        )
        : {}

    const shippingChange = {
        ...oldOrderDetails.orderJson.shippingAddress,
        customerId: oldOrderDetails.orderJson.customerId,
        selectedMethod: selectedMethod
    };

    setTimeout(async () => {

        await updateShippingMethod(orderId, shippingChange, admin);

        await changeOrderShippingAddress(orderId, shippingChange, admin, session);



    }, 200 * lineItemCount);

    return {
        status: true,
        message: "Line items successfully reversed"
    };
};


// remove all existing line items from order
export const getCalculatedLineItemsIds = async (orderId, orderDetails, admin) => {
    // Get variantId and quantity from provided orderDetails (could be old or current)
    const lineItems = orderDetails?.lineItems?.nodes || [];
    const originalLineItems = lineItems.map((node) => ({
        variantId: node.variant.id,
        quantity: node.quantity
    }));

    // Get calculated order edit ID and line items from Shopify
    const details = await getOrderCalculateId(orderId, admin);
    const calculatedEdges =
        details?.data?.data?.orderEditBegin?.calculatedOrder?.lineItems?.edges || [];

    // Match calculated line items by variantId and return calculated ID with quantity from original
    const matchedCalculatedLineItems = calculatedEdges
        .map((item) => {
            const { id, variant } = item.node;

            // Find corresponding original line item by variantId
            const match = originalLineItems.find((orig) => orig.variantId === variant.id);
            if (match) {
                return {
                    id, // Calculated Shopify Line Item ID
                    quantity: match.quantity // Quantity from original (old) order
                };
            }
            return null;
        })
        .filter(Boolean); // Remove nulls

    return matchedCalculatedLineItems;
};
