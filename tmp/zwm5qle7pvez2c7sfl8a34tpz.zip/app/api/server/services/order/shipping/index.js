import {
  EMAIL_HANDLES,
  NOTIFICATION_TYPES,
  ORDER_ACTION,
  SHOPIFY_TAGS,
} from "../../../constants/constants";
import { ErrorMessage, SuccessMessage } from "../../../constants/messages";
import { AppSettings } from "../../../models/appSettings.model";
import { OrderEditingHistory } from "../../../models/orderEditingHistory.model";
import { emailSender } from "../../../utils/utils";
import { creditCardRefund } from "../cancellation";
import { existingItemsAvailability } from "../edit";
import { addInReversOrders, removeInReversOrders } from "../holdOrder";
import { addedNewTag, getMessage, getOrderCalculateId, isHoldEnable, orderAdmin, orderEditCommit } from "../utils";

export const changeOrderShippingAddress = async (
  orderId,
  details,
  admin,
  session,
  extensionName,
  lang
) => {
  const response = await admin.graphql(
    `
    #graphql
    mutation updateOrderMetafields($input: OrderInput!) {
        orderUpdate(input: $input) {
          order {
            id
            email
            shippingAddress {
              address1
              address2
              city
              firstName
              lastName
              country
              phone
              province
              provinceCode
              zip
            }
          }
          userErrors {
            message
            field
          }
        }
      }
      `,
    {
      variables: {
        input: {
          shippingAddress: {
            address1: details.address1,
            address2: details.address2,
            city: details.city,
            firstName: details.firstName,
            lastName: details.lastName,
            country: details.country,
            phone: details.phone,
            province: details.province,
            provinceCode: details.provinceCode,
            zip: details.zip,
          },
          id: `gid://shopify/Order/${orderId}`,
          email: details.email,
        },
      },
    },
  );
  // Send the request
  const data = await response.json();
  // check query send error
  const error = data?.data?.orderUpdate?.userErrors;
  if (error.length) {
    return {
      status: false,
      message: error[0]?.message || ErrorMessage.MUTATION_BADE_REQ,
    };
  }

  // order editing history
  await OrderEditingHistory.create({
    partnerId: details.partnerId,
    orderAction: ORDER_ACTION.UPDATE_SHIPPING,
    customerId: details.customerId,
    orderId: orderId,
  });




  const editSummary = `Shipping address was updated in the order`;
  const emailData = {
    id: orderId,
    admin,
    session,
    partnerId: details.partnerId,
    type: NOTIFICATION_TYPES.ORDER_EDIT,
    shippingAddress: data?.data?.orderUpdate?.order?.shippingAddress,
    editSummary,
  };

  emailSender(emailData, EMAIL_HANDLES.UPDATE_SHIPPING, "merchant");
  emailSender(emailData, EMAIL_HANDLES.UPDATE_SHIPPING, "customer");
  if (extensionName == "ChangeShippingMethod") {

    return {
      status: true,
      message: await getMessage(lang, details.partnerId, "shippingMethodChanged"),
      data: { data, address: true },
    };
  } else {
    await addedNewTag(SHOPIFY_TAGS.UPDATE_SHIPPING, orderId, admin);
  }

  return {
    status: true,
    message: await getMessage(lang, details.partnerId, "shippingAddressChanged"),
    data: { data, address: true },
  };
};

export const fetchShippingAddressOld = async (orderId, admin,lang) => {
  const response = await admin.graphql(
    `
      query getOrderShippingAddress($id: ID!) {
        order(id: $id) {
          id
          email
          shippingAddress {
            address1
            address2
            city
            zip
            firstName
            lastName
            country
            phone
            province
            provinceCode
          }
        }
      }
    `,
    {
      variables: {
        id: `gid://shopify/Order/${orderId}`,
      },
    },
  );

  // Parse response
  const data = await response.json();

  if (data.errors) {
    return {
      status: false,
      message: data.errors[0]?.message || await getMessage(lang, details.partnerId, "failedFetchAddress"),
    };
  }

  return {
    status: true,
    data: data?.data?.order?.shippingAddress || null,
  };
};

export const updateShippingMethod = async (
  orderId,
  details,
  admin,
  session,
  orderDetails,
  lang
) => {
  try {

    // 1. Retrieve Calculated Order ID for editing
    const calculateOrderDetails = await getOrderCalculateId(orderId, admin);
    const calculatedOrderId =
      calculateOrderDetails?.data?.data?.orderEditBegin?.calculatedOrder?.id;

    if (!calculatedOrderId) {
      return {
        status: false,
        message: await getMessage(lang, details.partnerId, "calculatedIdError")
      };
    }

    // 2. Check shipping methods
    const selectedMethods = details?.selectedMethod;
    if (!selectedMethods || typeof selectedMethods !== "object") {
      return {
        status: false,
        message: getMessage(lang, details.partnerId, "invalidShippingMethod"),
      };
    }


    // 3. Fetch current shipping info, including all shipping lines
    const orderResponse = await admin.graphql(`
      {
        order(id: "gid://shopify/Order/${orderId}") {
          currentSubtotalPriceSet {
            presentmentMoney {
              currencyCode
            }
          }
          shippingLines(first: 250) {
            edges {
              node {
                id
                title
                originalPriceSet {
                  presentmentMoney {
                    amount
                    currencyCode
                  }
                }  
              }
            }
          }
        }
      }
    `);

    const orderData = (await orderResponse.json())?.data?.order;
    if (!orderData) {
      return {
        status: false,
        message: await getMessage(lang, details.partnerId, "orderNotFoundError"),
      };
    }

    const currencyCode =
      orderData.currentSubtotalPriceSet?.presentmentMoney?.currencyCode ||
      "USD";
    const existingShippingLines = orderData?.shippingLines?.edges || [];

    // 4. Check for duplicates and remove only unmatched shipping lines
    const alreadyAddedMethods = new Set();
    let allMatched = true; // Assume all shipping is already set

    for (const shippingEdge of existingShippingLines) {
      const shippingId = shippingEdge.node.id;
      const title = shippingEdge.node.title;
      const amount = parseFloat(
        shippingEdge.node.originalPriceSet.presentmentMoney.amount,
      );

      const isAlreadySelected = Object.values(selectedMethods).some((rawValue) => {
        const parts = rawValue.split("<end>_");
        if (parts.length < 2) return false;

        const rawTitlePrice = parts[1];
        const lastSlashIndex = rawTitlePrice.lastIndexOf("/");

        if (lastSlashIndex === -1) return false;  // No slash found, invalid format

        const selectedTitle = rawTitlePrice.substring(0, lastSlashIndex).trim();
        const selectedPriceStr = rawTitlePrice.substring(lastSlashIndex + 1).trim();
        const selectedPrice = parseFloat(selectedPriceStr);

        if (isNaN(selectedPrice)) return false;

        const matched = title.trim() === selectedTitle && amount === selectedPrice;

        if (matched) {
          alreadyAddedMethods.add(rawValue);  // Track to avoid re-adding
        }

        return matched;
      });
      if (isAlreadySelected) continue;

      allMatched = false; // something was removed, so not fully matched

      const shippingLineOrderId = shippingId.split("/").pop();
      const removeResp = await admin.graphql(
        `
      mutation removeShippingLine($calculatedOrderId: ID!, $shippingLineId: ID!) {
        orderEditRemoveShippingLine(id: $calculatedOrderId, shippingLineId: $shippingLineId) {
          calculatedOrder {
            id
            shippingLines {
              id
              title
            }
          }
          userErrors {
            field
            message
            code
          }
        }
      }
    `,
        {
          variables: {
            calculatedOrderId,
            shippingLineId: `gid://shopify/CalculatedShippingLine/${shippingLineOrderId}`,
          },
        },
      );

      const removeJson = await removeResp.json();
      const removeData = removeJson?.data?.orderEditRemoveShippingLine;

      if (removeData?.userErrors?.length) {
        return {
          status: false,
          message:
            removeData.userErrors[0]?.message ||
            await getMessage(lang, details.partnerId, "failedRemoveShippingLine")
        };
      }
    }

    // Add new ones
    for (const [profileId, rawValue] of Object.entries(selectedMethods)) {
      if (alreadyAddedMethods.has(rawValue)) continue;

      allMatched = false; // new one being added

      const parts = rawValue.split("<end>_");
      if (parts.length < 2) {
        const message = await getMessage(lang, details.partnerId, "invalidShippingFormat")
        return {
          status: false,
          message: `${message} ${profileId}`,
        };
      }
      const rawString = parts[1];
      const lastSlashIndex = rawString.lastIndexOf('/');
      const name = rawString.substring(0, lastSlashIndex).trim();
      const priceStr = rawString.substring(lastSlashIndex + 1).trim();
      const price = parseFloat(priceStr);

      if (!name || isNaN(price)) {
        const message = await getMessage(lang, details.partnerId, "invalidShippingPrice")
        return {
          status: false,
          message: `${message} ${profileId}`,
        };
      }

      const addInput = {
        calculatedOrderId,
        title: name.trim(),
        price,
        currencyCode,
      };

      const result = await addShippingLineOrder(addInput, admin, lang);
      if (!result?.status) {
        const message = await getMessage(lang, details.partnerId, "failedAddShipping")
        return {
          status: false,
          message: result.message || `${message}${name}`,
        };
      }
    }

    // 5. Check if all methods are already added
    if (allMatched) {
      return {
        status: true,
        message: await getMessage(lang, details.partnerId, "shippingAlreadyAdd"),
      };
    }

    // 6. Commit order
    const commitResult = await orderEditCommit(
      {
        calculatedOrderId,
        notifyCustomer: false,
        staffNote: "Shipping method updated by customer",
      },
      admin,
    );

    if (!commitResult?.status) {
      return {
        status: false,
        message: commitResult.message || await getMessage(lang, details.partnerId, "failedShippingUpdate"),
      };
    }
    await addedNewTag(SHOPIFY_TAGS.UPDATE_SHIPPING_METHOD, orderId, admin);
    // 7. Refund if needed
    let refundAmount =
      commitResult?.data?.data?.orderEditCommit?.order?.totalOutstandingSet
        ?.shopMoney?.amount;
    refundAmount = refundAmount ? parseFloat(refundAmount) : 0;

    if (refundAmount <= 0) {
      const refundDetails = {
        reason: "Edit order item",
      };
      await creditCardRefund(refundDetails, orderId, false, admin);

      const removeResponse = await removeInReversOrders(orderId, admin);

      if (!removeResponse.status) {
        return {
          status: false,
          message: removeResponse.message
        }
      }

    } else {

      if (orderDetails) {

        const displayFulfillmentStatus = commitResult?.data?.data?.orderEditCommit?.order?.displayFulfillmentStatus;
        const orderData = {
          lineItems: { nodes: orderDetails.lineItems.nodes.filter(item => item.currentQuantity > 0) },
          displayFulfillmentStatus: displayFulfillmentStatus,
          shippingAddress: orderDetails.shippingAddress,
          shippingLines: orderDetails.shippingLines,
          customerId: orderDetails.customer?.id
        }
        const isHoldOn = await isHoldEnable(details.partnerId);
        const addInReversOrdersResponse = await addInReversOrders(orderId, admin, orderData, details.partnerId, session.shop, isHoldOn);
        if (!addInReversOrdersResponse.status) {
          return {
            status: false,
            message: addInReversOrdersResponse.message
          }
        }
      }
    }

    // 8. Done
    return {
      status: true,
      message: await getMessage(lang, details.partnerId, "shippingUpdateSuccess"),
      data: commitResult,
    };
  } catch (error) {
    console.error("Error in updateShippingMethod:", error);
    return {
      status: false,
      message:
        error?.message || await getMessage(lang, details.partnerId, "errorShippingUpdate"),
    };
  }
};


export const addShippingLineOrder = async (details, admin, lang) => {
  try {
    const mutation = `
        mutation addShipping(
          $id: ID!,
          $title: String!,
          $amount: Decimal!,
          $currencyCode: CurrencyCode!
        ) {
          orderEditAddShippingLine(
            id: $id
            shippingLine: {
              title: $title
              price: {
                amount: $amount
                currencyCode: $currencyCode
              }
            }
          ) {
            calculatedOrder {
              id
              shippingLines {
                id
                stagedStatus
                title
                price {
                  shopMoney {
                    currencyCode
                    amount
                  }
                }
              }
            }
            userErrors {
              field
              message
              code
            }
          }
        }
      `;

    const variables = {
      id: details.calculatedOrderId,
      title: details.title,
      amount: details.price,
      currencyCode: details.currencyCode,
    };

    const rawResponse = await admin.graphql(mutation, { variables });
    const response = await rawResponse.json();

    const data = response.data?.orderEditAddShippingLine;
    const userErrors = data?.userErrors || [];

    if (userErrors.length > 0) {
      return {
        status: false,
        message: userErrors[0].message || "Unknown error",
      };
    }

    return {
      status: true,
      message: await getMessage(lang, details.partnerId, "orderShippingLineUpdate"),
      data: data,
    };
  } catch (error) {
    return {
      status: false,
      message: error?.message || "Something went wrong",
    };
  }
};

// Helper function to fetch converted price if currency differs
const getConvertedRatePrice = async (rateId, admin, presentmentCurrency) => {
  try {
    const response = await admin.graphql(`
      query {
        node(id: "gid://shopify/DeliveryMethodDefinition/${rateId}") {
          ... on DeliveryMethodDefinition {
            rateProvider {
              ... on DeliveryRateDefinition {
                price {
                  amount
                  currencyCode
                }
              }
            }
          }
        }
      }
    `);

    const data = await response.json();
    const amount = data?.data?.node?.rateProvider?.price?.amount;
    const currency = data?.data?.node?.rateProvider?.price?.currencyCode;
    if (currency !== presentmentCurrency) {
      return null;
    }
    return amount ? parseFloat(amount) : null;
  } catch (error) {
    return null;
  }
};
const getVariantQntityLocation = async (
  locationId,
  inventoryItemId,
  admin,
  mainQnt,
) => {
  try {
    const response = await admin.graphql(`
      query {

        location(id: "${locationId}") {
          inventoryLevel(inventoryItemId: "${inventoryItemId}") {
            quantities(names: "available") {
              quantity
            }
          }
        }
      }
    `);
    const data = await response.json();

    const quantities = data?.data?.location?.inventoryLevel?.quantities;
    if (!quantities || !Array.isArray(quantities) || quantities.length === 0) {
      return 0;
    }

    const availableQty = parseInt(quantities[0].quantity, 10);

    const neededQty = parseInt(mainQnt, 10);

    if (isNaN(availableQty) || isNaN(neededQty)) {
      return 0;
    }


    if (neededQty <= availableQty) {
      return true;
    } else {

      return availableQty;
    }

  } catch (error) {
    console.error("Error in getVariantQntityLocation:", error);
    return false;
  }
};

const priceConverter = async (admin, input) => {
  try {
    const response = await admin.graphql(
      `
      mutation draftOrderCalculate($input: DraftOrderInput!) {
        draftOrderCalculate(input: $input) {
          userErrors {
            field
            message
          }
          calculatedDraftOrder {
            availableShippingRates {
              handle
              title
              price {
                amount
                currencyCode
              }
            }
            presentmentCurrencyCode
            currencyCode
            shippingLine {
              discountedPriceSet {
                presentmentMoney {
                  amount
                  currencyCode
                }
              }
            }
          }
        }
      }
    `,
      { variables: { input } },
    );

    const data = await response.json();
    const conversion =
      data?.data?.draftOrderCalculate?.calculatedDraftOrder?.shippingLine
        ?.discountedPriceSet?.presentmentMoney;

    if (!conversion) return null;

    return {
      amount: parseFloat(conversion.amount),
      currencyCode: conversion.currencyCode,
    };
  } catch (error) {
    console.error("Error converting price:", error);
    return null;
  }
};

export const isSplitShippingOn = async (partnerId) => {
  const details = await AppSettings.findOne({ partnerId });
  return details?.shipping?.splitShippingToggle?.isOn
}

export const checkOrderShippingAddress = async (
  orderId,
  details,
  admin,
  session,
  extensionName,
  lang
) => {
  try {
    const orderGID = `gid://shopify/Order/${orderId}`;

    // Fetch Order Data
    const orderResponse = await admin.graphql(`{
      order(id: "${orderGID}") {
        
        currentShippingPriceSet { presentmentMoney { amount currencyCode }, shopMoney { amount currencyCode } }
        shippingAddress {firstName lastName city provinceCode province zip country countryCode }
        shippingLines(first: 50) {
          edges { node { id title originalPriceSet { presentmentMoney { amount currencyCode }}}}
        }
        lineItems(first: 50) {
          nodes {
            id quantity name requiresShipping variantTitle refundableQuantity
            image { url }
            variant {
              id inventoryPolicy
              deliveryProfile {
                id
                profileLocationGroups {
                  locationGroup { id locations(first: 250 ,includeLegacy: true) { nodes { id }}}
                }
              }
              inventoryItem {
                id tracked
                measurement { weight { unit value }}
                inventoryLevels(first: 50) { nodes { location { id }}}
              }
            }
            originalTotalSet { presentmentMoney { amount currencyCode }, shopMoney { amount currencyCode }}
            discountAllocations {  allocatedAmountSet { presentmentMoney { amount currencyCode }} }
          }
        }
      }
    }`);
    const orderData = (await orderResponse.json())?.data?.order;
    if (!orderData) return { status: false, message: "Order not found or invalid order ID." };
    const lineItems = orderData.lineItems.nodes;
    const orderShippingAddress = orderData.shippingAddress;



    if (lineItems.every(item => !item.requiresShipping)) {
      return { status: true, message: await getMessage(lang, details.partnerId, "noShippingAvailable"), address: true, data: [] };
    }

    const fulfillmentResponse = await admin.graphql(`{
      order(id: "${orderGID}") {
        fulfillmentOrders(first: 250) {
          edges {
            node {
              lineItems(first: 250) { nodes { variant { id }}}
              assignedLocation { location { id }}
            }
          }
        }
      }
    }`);
    const fulfillmentData = (await fulfillmentResponse.json())?.data?.order;

    const locationAssignCheckData = {};
    fulfillmentData?.fulfillmentOrders?.edges.forEach(({ node }) => {
      const locId = node?.assignedLocation?.location?.id;
      if (!locationAssignCheckData[locId]) locationAssignCheckData[locId] = {};
      node.lineItems.nodes.forEach(li => locationAssignCheckData[locId][li.variant?.id] = true);
    });

    const shippingZones = await admin.rest.resources.ShippingZone.all({ session });
    if (!shippingZones?.data?.length) return { status: false, message: await getMessage(lang, details.partnerId, "noFoundZones") };
    const presentmentCurrency = orderData.currentShippingPriceSet?.presentmentMoney?.currencyCode;
    const shopCurrency = orderData.currentShippingPriceSet?.shopMoney?.currencyCode;
    const currenciesMatch = presentmentCurrency === shopCurrency;
    const profileGroups = {};
    const customPrices = {};
    const requiresShippingVariantIds = [];
    let discountAllocations = 0;
    if (extensionName === 'edit-item') {
      const results = await Promise.all(details.map(async (items) => {
        try {
          const isAvailable = await existingItemsAvailability(orderId, items, admin);

          if (!isAvailable.status) {
            return {
              status: false,
              message: isAvailable.message || 'Not available',
              item: items,
            };
          }

          // Return null or false when item is OK (so we can filter later)
          return null;

        } catch (error) {
          console.log("Error in editOrderItem:", error);
          return {
            status: false,
            message: error?.message || 'Unknown error',
            item: items,
          };
        }
      }));

      // Filter out only failed items
      const failedItems = results.filter(item => item !== null);

      if (failedItems.length > 0) {
        return {
          status: false,
          data: failedItems,
        };
      }

    }

    if (extensionName === 'add-discount-item') {
      discountAllocations += parseFloat(details?.discountAmount ?? 0);
    }

    if ((extensionName === 'add-item' || extensionName === 'swap-item' || extensionName === 'add-discount-item')) {

      // If the caller sent a single object instead of an array, normalise it
      const itemsToAdd = Array.isArray(details) ? details : [details];

      for (const { productVariantId, quantity = 1 } of itemsToAdd) {
        if (!productVariantId) continue;

        const variantRes = await admin.graphql(`
          {
            productVariant(id: "${productVariantId}") {
              id
              title
              image { url }
              inventoryPolicy
              product { 
                title
                featuredMedia {
                    ... on MediaImage {
                      id
                      image {
                        url
                      }
                    }
                  }
                 }
              deliveryProfile {
                id
                profileLocationGroups {
                  locationGroup {
                    id
                    locations(first: 250,includeLegacy: true) { nodes { id } }
                  }
                }
              }
              inventoryItem {
                id
                tracked
                requiresShipping
                measurement { weight { unit value } }
                inventoryLevels(first: 50) { nodes { location { id } } }
              }
            }
          }`);
        const variantData = (await variantRes.json())?.data?.productVariant;
        if (!variantData) continue;

        lineItems.push({
          variantId: variantData.id,                 // keep the ID handy
          requiresShipping: variantData.inventoryItem?.requiresShipping,
          refundableQuantity: quantity,
          name: variantData.product?.title ?? "Product",
          variantTitle: variantData.title,
          image: variantData.image ?? variantData?.product?.featuredMedia?.image,
          originalTotalSet: {
            shopMoney: { amount: "0.00", currencyCode: "USD" },
          },
          variant: variantData,
        });
      }

    }

    for (const item of lineItems) {
      if (item.refundableQuantity === 0) continue;




      if (extensionName === 'swap-item' || extensionName === 'remove-item') {
        const lineItemId = item?.id?.split('/')?.pop();
        const calculatedLineItemIdCheck = details?.calculatedLineItemId?.split('/')?.pop();
        if (lineItemId && calculatedLineItemIdCheck && lineItemId === calculatedLineItemIdCheck) {
          continue;
        }

      }


      if (extensionName === 'edit-item') {
        const matchedItem = details?.find(
          itemCheck => itemCheck?.productVariantId === item.variant?.id
        );

        if (matchedItem) {
          item.refundableQuantity = matchedItem.quantity;

        }
      }
      // all dicount add
      const allocations = item.discountAllocations || [];
      const discountAmount = allocations.reduce((sum, alloc) => {
        const amount = parseFloat(alloc.allocatedAmountSet?.presentmentMoney?.amount || 0);
        return sum + amount;
      }, 0);
      discountAllocations += discountAmount;

      if (!item.requiresShipping && item.refundableQuantity !== 0) {
        requiresShippingVariantIds.push({
          variantId: item.variant?.id,
          quantity: item.refundableQuantity
        });
        continue;
      }


      const { variant, refundableQuantity, name, variantTitle, image, originalTotalSet } = item;
      const variantId = variant.id;
      const deliveryProfileId = variant?.deliveryProfile?.id || "no_profile";
      const profileLocationGroups = variant?.deliveryProfile?.profileLocationGroups || [];

      let matchedGroupId = "no_group";
      const variantLocationIds = variant?.inventoryItem?.inventoryLevels?.nodes?.map(n => n.location?.id) || [];

      let checkVariantQntityAll = {};
      checkVariantQntityAll[variantId] = 0;

      let profileLocationGroupsCheck = profileLocationGroups.length;

      for (const pGroup of profileLocationGroups) {

        const groupId = pGroup.locationGroup?.id || "no_group";
        const groupLocIds = pGroup.locationGroup?.locations?.nodes?.map(loc => loc.id) || [];

        let locationChekc = false;
        if (variant.inventoryPolicy !== "CONTINUE" && variant.inventoryItem?.tracked) {
          let hasStock = false;

          for (const locId of groupLocIds) {

            if (!locationAssignCheckData?.[groupLocIds]?.[variantId] && locationAssignCheckData?.[locId]?.[variantId] === undefined && profileLocationGroupsCheck > 1) {

              hasStock = await getVariantQntityLocation(locId, variant.inventoryItem.id, admin, refundableQuantity);


            } else {
              if (profileLocationGroupsCheck == 1 || variantLocationIds.length == 1) {

                hasStock = true;
              } else {
                hasStock = await getVariantQntityLocation(locId, variant.inventoryItem.id, admin, refundableQuantity);
              }
            }
            if (hasStock) {
              if (typeof hasStock === 'number' && !isNaN(hasStock)) {
                checkVariantQntityAll[variantId] = checkVariantQntityAll[variantId] + hasStock
                const neededQty = parseInt(refundableQuantity, 10);
                if (neededQty <= checkVariantQntityAll[variantId]) {
                  hasStock = true;
                  locationChekc = true
                  break;
                }
                hasStock = false;
              } else {
                locationChekc = true
              } break;
            }
          }
          if (hasStock) {
            locationChekc = true
          }
          if (!hasStock) continue;
        } else {
          locationChekc = true
        }

        if (!locationChekc) continue;
        if (variantLocationIds.some(locId => groupLocIds.includes(locId))) {
          matchedGroupId = groupId;

          break;
        }
      }

      if (matchedGroupId == "no_group") {
        return { status: false, message: await getMessage(lang, details.partnerId, "shippingUnavailable") };
      };
      const isSplitOn = await isSplitShippingOn(details.partnerId)
      let groupKey
      if (isSplitOn) {
        groupKey = `${deliveryProfileId}-${matchedGroupId}`;
        // groupKey = `split`;
      } else {
        groupKey = `split`;
      }
      profileGroups[groupKey] ??= { deliveryProfileId, locationGroupId: matchedGroupId, variants: [] };

      profileGroups[groupKey].variants.push({ variantId, quantity: refundableQuantity, title: name, variantTitle, image: image?.url || null });

      const itemSubtotal = parseFloat(originalTotalSet?.shopMoney?.amount || 0);

      customPrices[groupKey] = (customPrices[groupKey] || 0) + itemSubtotal;
    }

    if (!Object.keys(profileGroups).length) {
      return { status: true, message: await getMessage(lang, details.partnerId, "noShippingAvailable"), address: true, data: [] };
    }

    const shippingOptionsPerProfile = [];
    // Constant draft input parts
    const baseShippingAddress = {
      "address1": details.address1 ?? orderShippingAddress.address1 ?? "",
      "address2": details.address2 ?? orderShippingAddress.address2 ?? "",
      "city": details.city ?? orderShippingAddress.city ?? "",
      "company": null,
      "countryCode": details.country ?? orderShippingAddress.countryCode ?? "",
      "firstName": details.firstName ?? orderShippingAddress.firstName ?? "John",
      "lastName": details.lastName ?? orderShippingAddress.lastName ?? "",
      "phone": details?.phone ?? orderShippingAddress.phone ?? null,
      "provinceCode": details.province ?? orderShippingAddress.province ?? "",
      "zip": details.zip ?? orderShippingAddress.zip ?? "",
    };

    for (const [key, group] of Object.entries(profileGroups)) {
      const { deliveryProfileId, locationGroupId, variants } = group;

      const otherGroupsTotal = Object.entries(customPrices).reduce((sum, [k, v]) => k !== key ? sum + v : sum, 0);

      const draftLineItems = variants.map(v => ({ variantId: v.variantId, quantity: v.quantity }));

      if (otherGroupsTotal > 0) {
        draftLineItems.push({ title: "Custom Product", quantity: 1, originalUnitPrice: otherGroupsTotal, requiresShipping: false });
      }

      if (requiresShippingVariantIds.length > 0) {
        draftLineItems.push(...requiresShippingVariantIds);
      }
      // const totalDiscountSetValue = parseFloat(orderData?.totalDiscountsSet?.presentmentMoney?.amount || 0);


      const draftInput = {
        lineItems: draftLineItems,
        "appliedDiscount": {
          "title": "Discount",
          "description": "Special discount",
          "value": discountAllocations,
          "valueType": "FIXED_AMOUNT"
        },
        shippingAddress: baseShippingAddress
      };

      const draftResponse = await admin.graphql(`
    mutation draftOrderCalculate($input: DraftOrderInput!) {
      draftOrderCalculate(input: $input) {
        calculatedDraftOrder {
          availableShippingRates {
            handle title price { amount currencyCode }
          }
        }
      }
  }`, { variables: { input: draftInput } });
      const draftData = await draftResponse.json();

      const rates = draftData?.data?.draftOrderCalculate?.calculatedDraftOrder?.availableShippingRates || [];
      if (!rates.length) {
        // const variantTitles = variants.map(v => v.title).join(", ");
        return { status: false, message: await getMessage(lang, details.partnerId, "shippingUnavailableForAddress") };
      }

      const shippingOptions = [];
      for (const rate of rates) {
        let price = parseFloat(rate.price.amount);
        let currency = rate.price.currencyCode;

        if (!currenciesMatch) {
          const conversionInput = {
            lineItems: draftLineItems,
            shippingAddress: baseShippingAddress,
            presentmentCurrencyCode: presentmentCurrency,
            shippingLine: { shippingRateHandle: rate.handle }
          };

          const converted = await priceConverter(admin, conversionInput);

          if (!converted) {
            return { status: false, message: await getMessage(lang, details.partnerId, "currencyConversionFailed") };
          }

          price = converted.amount;
          currency = converted.currencyCode;

          if (currency !== presentmentCurrency) {
            return {
              status: false,
              message: await getMessage(lang, details.partnerId, "internationalShipError")
            };
          }
        }

        shippingOptions.push({
          name: rate.title,
          price,
          currency,
          type: "shopify_live_rate"
        });
      }

      shippingOptionsPerProfile.push({
        deliveryProfileId: `${deliveryProfileId}_${locationGroupId}`,
        variants,
        subtotal: group.totalSubtotal,
        shippingOptions: shippingOptions.sort((a, b) => a.price - b.price)
      });
    }

    if (extensionName !== "ChangeShippingMethod") {
      const shippingLines = orderData.shippingLines.edges.map(e => e.node);
      const orgShippingLength = shippingLines.length;
      // Create array instead of Set for index-based operations
      const shippingLineArray = shippingLines.map(line =>
        `${line.title?.toLowerCase().trim()}-${parseFloat(line.originalPriceSet.presentmentMoney.amount).toFixed(2)}`
      );

      let hasPriceChanged = 0;
      for (const profile of shippingOptionsPerProfile) {
        for (const option of profile.shippingOptions) {
          const key = `${option.name?.toLowerCase().trim()}-${parseFloat(option.price).toFixed(2)}`;

          const index = shippingLineArray.indexOf(key);
          if (index !== -1) {
            hasPriceChanged++;
            shippingLineArray.splice(index, 1);  // Delete by index
            break;  // No need to check more options in this profile
          }
        }
      }

      if (hasPriceChanged == orgShippingLength && hasPriceChanged == shippingOptionsPerProfile.length) {
        return {
          status: true,
          message: await getMessage(lang, details.partnerId, "reselectShippingMessage"),
          address: true,
          data: shippingOptionsPerProfile,
        };
      }
    }


    return { status: true, message: await getMessage(lang, details.partnerId, "shippingMethodMatched"), data: shippingOptionsPerProfile };

  } catch (error) {
    console.error("Error in checkOrderShippingAddress:", error);
    return { status: false, message: error.message || await getMessage(lang, details.partnerId, "shippingAddressError") };
  }
};
export const itemLineCheckShipping = async (
  orderId,
  details,
  admin,
  session,
  extensionName,
  lang
) => {
  // Determine correct details to send based on structure
  const detailsToSend = details?.selectedMethod ? details : (details[0]?.selectedMethod ? details[0] : null);


  if (detailsToSend) {
    const orderDetails = await orderAdmin(orderId, admin);

    const changeResponse = await updateShippingMethod(orderId, detailsToSend, admin, session, orderDetails);
    if (!changeResponse?.status) {
      return { status: false, message: changeResponse?.message };
    }
    return { status: true, message: changeResponse?.message, data: [] };
  }

  // If no selected method, fallback to checking the shipping address
  const responShippingChck = await checkOrderShippingAddress(orderId, details, admin, session, extensionName, lang);
  if (!responShippingChck?.status) {
    return { status: false, message: responShippingChck?.message, data: [] };
  }

  if (responShippingChck?.address === true) {
    return { status: true, message: responShippingChck?.message, data: responShippingChck?.data };
  }

  return { status: true, message: responShippingChck?.message, data: responShippingChck?.data };
};