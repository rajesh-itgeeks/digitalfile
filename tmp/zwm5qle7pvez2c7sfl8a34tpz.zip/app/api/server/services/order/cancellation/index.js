import { EMAIL_HANDLES, NOTIFICATION_TYPES, ORDER_ACTION, SHOPIFY_TAGS } from "../../../constants/constants";
import { ErrorMessage, SuccessMessage } from "../../../constants/messages";
import { flowTrigger } from "../../../models/flowTrigger.model";
import { OrderEditingHistory } from "../../../models/orderEditingHistory.model";
import { ReversOrders } from "../../../models/reversOrders.model";
import { emailSender } from "../../../utils/utils";
import { changeOrderShippingAddress, updateShippingMethod } from "../shipping";
import { holdOrder, removeInReversOrders } from "../holdOrder";
import { addedNewTag, getOrderCalculateId, orderEditCommit, flowTriggers, getMessage } from "../utils";

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

export const orderCancel = async (orderId, details, admin, session, lang) => {
  // check refund false send customer restocking amount refund
  if (details.restock) {
    const data = await orderRestocking(orderId, details, admin, session);
    if (!data.status) {
      return {
        status: false,
        message: data.message,
      };
    }
    // Delay to allow restocking process completion
    await delay(2000);
  }
  console.log("step4 going for cancel order");
  // GraphQL mutation to cancel the order
  const response = await admin.graphql(`
    #graphql
  mutation orderCancel(
                    $orderId: ID!
                    $reason: OrderCancelReason!
                    $refund: Boolean!
                    $restock: Boolean!
                    $staffNote: String

                  ) {
                    orderCancel(
                      orderId: $orderId
                      reason: $reason
                      refund: $refund
                      restock: $restock
                      staffNote: $staffNote
                    ) {
                      job {
                        done
                        id
                      }
                      orderCancelUserErrors {
                        code
                        field
                        message
                      }
                      userErrors {
                        field
                        message
                      }
                    }
                  }`, {
    variables: {
      "orderId": `gid://shopify/Order/${orderId}`,
      "reason": "CUSTOMER",
      "staffNote": details.staffNote,
      "refund": details.refund,
      "restock": details.restock
    },
  })

  // Send the request
  const cancelOrderData = await response.json()
  // check query send error
  const error = cancelOrderData?.data?.orderCancel?.userErrors;
  if (error?.length) {
    return {
      status: false,
      message: error[0]?.message || ErrorMessage.MUTATION_BADE_REQ
    }
  }

  // add tag in order
  await addedNewTag(SHOPIFY_TAGS.CANCEL_ORDER, orderId, admin);

  // order editing history
  await OrderEditingHistory.create({
    partnerId: details.partnerId,
    orderAction: ORDER_ACTION.CANCEL_ORDER,
    customerId: details.customerId,
    orderId: orderId
  })
  await OrderEditingHistory.updateMany({
    partnerId: details.partnerId,
    customerId: details.customerId,
    orderId: orderId
  }, { isRemoved: true })
  // Prepare email notification data
  const restokingFee = `${details.amount + " " + details.currencyCode}`
  const emailData = {
    restokingFee,
    staffNote: details?.staffNote,
    restock: details.restock,
    customerRefundedAmount: Number(details?.customerRefundedAmount).toFixed(2),
    totalAmount: details?.totalAmount

  }
  const editSummary = "Order Cancelled"
  const emailDataToSend = {
    id: orderId, admin, session, ...emailData, partnerId: details.partnerId, type: NOTIFICATION_TYPES.ORDER_CANCELLATION, editSummary
  }
  // Send email notifications to merchant and customer
  setTimeout(() => {
    emailSender(emailDataToSend, EMAIL_HANDLES.CANCEL_ORDER_EMAIL, 'merchant')
    emailSender(emailDataToSend, NOTIFICATION_TYPES.ORDER_CANCELLATION, 'customer')
  }, 10000)

  // remove order details form revers order id exist 
  const removeResponse = await removeInReversOrders(orderId, admin);
  if (!removeResponse.status) {
    return {
      status: false,
      message: removeResponse.message
    }
  }

  await flowTriggers(orderId, 'order-cancelled', admin);
  //SuccessMessage.CANCEL => orderCancel
  const message = await getMessage(lang, details.partnerId, "orderCancel")
  return {
    status: true,
    message: `${message}`,
    data: cancelOrderData
  };
}
export const orderRestocking = async (orderId, details, admin, session) => {
  // get order calculate details 
  const orderCalculatedDetailsResponse = await getOrderCalculateId(orderId, admin);
  const orderCalculatedDetails = orderCalculatedDetailsResponse?.data?.data?.orderEditBegin?.calculatedOrder
  if (!orderCalculatedDetails?.id) {
    console.log('Error in get order calculate details');
    return {
      status: false,
      message: `Order Details ${ErrorMessage.NOT_FOUND}`
    }
  }
  var lineItems = [];
  // remove all order items
  for (const calculateLineItem of orderCalculatedDetails.lineItems?.edges) {

    await removeCalculateOrderItem(calculateLineItem.node.id, orderCalculatedDetails.id, admin);
  }

  if (details.type == "shippingtaxes") {
    // find order details form reversOrder collection
    const reversOrderDetails = await ReversOrders.findOne({ orderId });
    if (reversOrderDetails) {
      // reverse Order if details exist 
      const shippingLines = reversOrderDetails?.orderJson?.shippingLines;
      const selectedMethod = Array.isArray(shippingLines?.edges) && shippingLines?.edges.length > 0
        ? Object.fromEntries(
          shippingLines.edges.map((edge, index) => {
            const title = edge.node?.title ?? 'unknown';
            const amount = edge.node?.originalPriceSet?.presentmentMoney?.amount ?? 0;
            return [index.toString(), `${index}__${index}_<end>_${title}/${amount}`];
          })
        )
        : {}

      const shippingChange = {
        ...reversOrderDetails.orderJson.shippingAddress,
        customerId: reversOrderDetails.orderJson.customerId,
        selectedMethod: selectedMethod
      };
      await updateShippingMethod(orderId, shippingChange, admin);
      await changeOrderShippingAddress(orderId, shippingChange, admin, session);
    }

  } else {
    // add order custom item
    const addCustomItemResponse = await addCustomItemInOrder(orderCalculatedDetails.id, details, admin);
    if (!addCustomItemResponse.status) {
      console.log('Error in add custom item in order');
      return {
        status: false,
        message: `Order Details ${ErrorMessage.NOT_FOUND}`
      }
    }

    // remove shipping form order 
    const removeShippingResponse = await removeShippingFromOrder(admin, orderId, orderCalculatedDetails.id);
    if (!removeShippingResponse.status) {
      console.log('Error in order remove shipping');
      return {
        status: false,
        message: removeShippingResponse?.message
      }
    }
  }

  // return addCustomItemResponse;
  // commit order now 
  const commitDetails = {
    calculatedOrderId: orderCalculatedDetails.id,
    notifyCustomer: false,
    staffNote: "Restocking-Fee"
  }
  const orderCommitResponse = await orderEditCommit(commitDetails, admin);
  if (!orderCommitResponse.status) {
    return {
      status: false,
      message: orderCommitResponse.message
    }
  }
  // refund given amount by order commit response to customer
  let customerRefundAmount = orderCommitResponse.data.data.orderEditCommit.order.totalOutstandingSet.presentmentMoney.amount
  customerRefundAmount = Math.abs(customerRefundAmount)
  console.log("Amount refund to customer :", customerRefundAmount);
  const refundDetails = {
    reason: "Customer downsized their order with a self-service edit.",
    amount: customerRefundAmount,
    partnerId: details.partnerId,
    customerId: details.customerId,
    currencyCode: details.currencyCode,
    lineItems: lineItems
  }

  const customerRefundResponse = await creditCardRefund(refundDetails, orderId, true, admin);
  return customerRefundResponse;
}
export const removeCalculateOrderItem = async (calculatedLineItemId, calculatedOrderId, admin) => {
  const response = await admin.graphql(`
  #graphql
  mutation increaseLineItemQuantity {
                orderEditSetQuantity(
                  id: "${calculatedOrderId}"
                  lineItemId: "${calculatedLineItemId}"
                  quantity: 0
                ) {
                  calculatedOrder {
                    id
                    addedLineItems(first: 5) {
                      edges {
                        node {
                          id
                          quantity
                        }
                      }
                    }
                  }
                  userErrors {
                    field
                    message
                  }
                }
              }
              `)


  await response.json()
  return true
}

// remove shipping from order 
export const removeShippingFromOrder = async (admin, orderId, calculatedOrderId) => {
  // get order shipping line
  const response = await admin.graphql(
    `
        {
          order(id: "gid://shopify/Order/${orderId}") {
            shippingLine {
              id
            }
          }
        }
      `
  );

  // If your admin.graphql() returns raw fetch-like response, do this:
  const jsonData = await response.json();


  const orderData = jsonData?.data?.order;
  if (!orderData) {
    return {
      status: false,
      message: "Order not found or invalid order ID.",
    };
  }

  const existingShippingLineId = orderData?.shippingLine?.id;
  if (!existingShippingLineId) {
    console.log("existingShippingLineId not found :", existingShippingLineId)
    return {
      status: true,
      message: "Shipping Remove Success"
    }
  }
  const shippingLineOrderId = existingShippingLineId.split("/").pop();
  // remove shipping mutation
  const removeResp = await admin.graphql(
    `
          mutation removeShippingLine($calculatedOrderId: ID!, $shippingLineId: ID!) {
            orderEditRemoveShippingLine(id: $calculatedOrderId, shippingLineId: $shippingLineId) {
              calculatedOrder {
                id
                shippingLines {
                  id
                  title
                  stagedStatus
                }
              }
              userErrors {
                field
                message
                code
              }
            }
          }
        `,
    {
      variables: {
        calculatedOrderId,
        shippingLineId: `gid://shopify/CalculatedShippingLine/${shippingLineOrderId}`,
      },
    }
  );

  const removeJson = await removeResp.json();
  const removeData = removeJson?.data?.orderEditRemoveShippingLine;
  if (removeData?.userErrors?.length) {
    console.error("Remove Shipping Line Errors:", removeData.userErrors);
    return {
      status: false,
      message: removeData.userErrors[0].message || "Failed to remove shipping line",
    };
  }
  return {
    status: true,
    message: "Shipping Remove Success"
  }
}

export const addCustomItemInOrder = async (calculateOrderId, details, admin) => {
  try {
    const itemTitle = details.type === 'percentage' ? `Restocking-Fee ${details.value}%` : details.type === 'fixed' ? `Restocking-Fee ${details.value}(Fixed-Amount)` : `Restocking-Fee ${details.value}(Shipping & Taxes)`;
    console.log({ details });
    const response = await admin.graphql(`
      #graphql
      mutation MyMutation {
                    orderEditAddCustomItem( 
                      id: "${calculateOrderId}"
                      price: { amount: "${details.amount}", currencyCode: ${details.currencyCode} }
                      quantity: 1
                      title: "${itemTitle}"
                      requiresShipping: false,
                      taxable: false
                    ) {
                      calculatedOrder {
                        id
                      }
                      calculatedLineItem {
                        id
                        quantity 
                        title
                        sku
                        variantTitle
                      }
                    }
                  }
                `)

    // Send the request
    const data = await response.json()
    console.log('Add custom order response :', data.data?.orderEditAddCustomItem);

    if (!data?.data?.orderEditAddCustomItem?.calculatedOrder) {
      return {
        status: false,
      }
    }
    return {
      status: true
    }
  } catch (err) {
    console.log("Catch error in addCustomItemInOrder :", err);
  }
}
export const getOrderCaptureTransactionId = async (orderId, admin) => {
  const query = `
                #graphql
                {
                  order(id: "gid://shopify/Order/${orderId}") {
                    totalOutstandingSet{
                        presentmentMoney{
                            amount
                            currencyCode
                        }
                        shopMoney{
                            amount
                            currencyCode
                        }
                    }
                    suggestedRefund(
                      suggestFullRefund:true
                    ) {
                      suggestedTransactions {
  
                        maximumRefundableSet{
                          shopMoney{
                            amount
                            currencyCode
                          }
                          presentmentMoney {
                            amount
                            currencyCode
                          }
                        }
                        amountSet {
                          shopMoney {
                            amount
                            currencyCode
                          }
                          presentmentMoney {
                            amount
                            currencyCode
                          }
                          
                        }
                          gateway
                        parentTransaction {
                          id
                        }
                      }
                      maximumRefundableSet {
                        presentmentMoney {
                          amount
                          currencyCode
                        }
                        shopMoney {
                          amount
                          currencyCode
                        }
                      }
                      
                    }
                  }
                }`;

  try {
    const response = await admin.graphql(query)
    // Send the request
    const data = await response.json()

    // check query send error order not found case 
    const refundedAmount = data?.data?.order?.totalOutstandingSet?.presentmentMoney?.amount;
    if (!refundedAmount) {
      return {
        status: false,
        message: `Refund amount ${ErrorMessage.NOT_FOUND}`
      }
    }
    const suggestedRefund = data?.data?.order?.suggestedRefund;
    if (!suggestedRefund) {
      return {
        status: false,
        message: `Suggested Refund ${ErrorMessage.NOT_FOUND}`
      }
    }

    // Extract values for calculations
    let totalOutstanding = parseFloat(refundedAmount);
    totalOutstanding = Math.abs(totalOutstanding);

    const suggestedTransactions = suggestedRefund.suggestedTransactions.map(txn => ({
      amount: parseFloat(txn.maximumRefundableSet.presentmentMoney.amount),
      parentTransaction: txn.parentTransaction.id,
      gateway: txn.gateway
    }));

    let remainingAmount = totalOutstanding;
    const finalTransactions = [];

    for (const txn of suggestedTransactions) {
      if (remainingAmount <= 0) break;
      const amountToRefund = Math.min(remainingAmount, txn.amount);
      finalTransactions.push({
        amount: amountToRefund,
        parentTransaction: txn.parentTransaction,
        gateway: txn.gateway
      });
      remainingAmount -= amountToRefund;
    }

    return {
      status: true,
      message: SuccessMessage.FETCHED,
      data: finalTransactions
    }
  } catch (error) {
    console.log(error);
    return {
      status: false,
      message: 'Something went wrong in suggestedRefund'
    }
  }

}
export const creditCardRefund = async (details, orderId, isCancel, admin) => {
  // get order CAPTURE transaction id
  var transactionDetails = await getOrderCaptureTransactionId(orderId, admin);
  if (!transactionDetails.status) {
    return {
      status: false,
      message: transactionDetails.message,
    }
  }

  if (!transactionDetails.data?.length) {
    return {
      status: false,
      message: 'No Refund Allocated',
    }
  }

  const refund = async (transactionDetails, isCancel, details, admin) => {
    const formattedTransactionDetails = [];
    transactionDetails.forEach(async element => {
      formattedTransactionDetails.push({
        "orderId": `gid://shopify/Order/${orderId}`,
        "gateway": element.gateway,
        "kind": "REFUND",
        "amount": isCancel ? element.amount : element.amount
        ,
        "parentId": element.parentTransaction
      });
    });

    const response = await admin.graphql(`
      #graphql
      mutation M($input: RefundInput!) {
                    refundCreate(input: $input) {
                      userErrors {
                        field
                        message
                      }
                      refund {
                        id
                        note
                        totalRefundedSet {
                          presentmentMoney {
                            amount
                          }
                        }
                      }
                    }
                  }`, {
      variables: {
        "input": {
          "orderId": `gid://shopify/Order/${orderId}`,
          "note": details.reason,
          "currency": details.currencyCode,
          "transactions": formattedTransactionDetails
        }

      },
    })
    // Send the request      
    const data = await response.json()

    if (data?.data?.refundCreate?.userErrors?.length) {
      return {
        status: false,
        message: data?.data.refundCreate.userErrors[0].message,
      }
    }

    return {
      status: true,
      data: data,
    }
  }

  // refund given amount to customer
  const refundData = await refund(transactionDetails.data, isCancel, details, admin);

  if (!refundData?.status) {
    return {
      status: false,
      message: refundData?.message,
    }
  }

  // order editing history
  await OrderEditingHistory.create({
    partnerId: details.partnerId,
    orderAction: ORDER_ACTION.ORDER_REFUND,
    customerId: details.customerId,
    orderId: orderId,
    amount: details.amount
  })

  return {
    status: true,
    message: 'Credit card refund successfully',
    data: refundData.data
  }

}

export const cancelFlow = async (details, orderId, admin, partnerId, lang) => {
  // hold order 
  const holdOrderDetails = await holdOrder(orderId, admin);
  if (!holdOrderDetails.status) {
    return {
      status: false,
      message: holdOrderDetails.message
    }
  }
  // update order trigger table 
  const payload = {
    shopify_domain: details.shopName,
    properties: {
      order_id: `gid://shopify/Order/${orderId}`
    },
    handle: "customer-disallow-edits"
  }
  await flowTrigger.create({ payload });
  await flowTriggers(orderId, 'order-cancellation-request', admin);
  //Order cancellation request received  => flowCancellationRequest
  const message = await getMessage(lang, partnerId, "flowCancellationRequest")
  return {
    status: true,
    message: message
  }
}