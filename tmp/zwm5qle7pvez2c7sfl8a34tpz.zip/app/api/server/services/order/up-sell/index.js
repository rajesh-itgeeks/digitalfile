import { EMAIL_HANDLES, NOTIFICATION_TYPES, ORDER_ACTION } from "../../../constants/constants";
import { ErrorMessage, SuccessMessage } from "../../../constants/messages";
import { OrderEditingHistory } from "../../../models/orderEditingHistory.model";
import { emailSender } from "../../../utils/utils";
import { addInReversOrders } from "../holdOrder";
import { addOrderItemSingle, getMessage, getOrderCalculateId, isHoldEnable, orderAdminRevers, orderEditCommit } from "../utils";

export const addDiscountItem = async (orderId, details, admin, session, lang) => {
  try {
    // get order calculate id 
    const calculateOrderDetails = await getOrderCalculateId(orderId, admin);
    const calculatedOrderId = calculateOrderDetails?.data?.data?.orderEditBegin?.calculatedOrder?.id;
    console.log('Order Calculated Id :', calculatedOrderId);

    if (!calculateOrderDetails.status && !calculatedOrderId) {
      return {
        status: false,
        message: calculateOrderDetails.message
      }
    }

    // get order details before edit  
    const orderDetails = await orderAdminRevers(orderId, admin);

    // add item in order first 
    const itemDetails = {
      productVariantId: details.productVariantId,
      quantity: details.quantity,
      customerId: details.customerId,
      partnerId: details.parentId,
    }
    const addResult = await addOrderItemSingle(orderId, itemDetails, calculatedOrderId, admin);
    if (!addResult.status) {
      return {
        status: false,
        message: addResult.message
      }
    }

    // create discount for new item 
    const discountDetails = {
      percentage: details.percentage,
      partnerId: details.partnerId,
      customerId: details.customerId,
      discountAmount: details.discountAmount,
      productVariantId: details.productVariantId,
      calculatedLineItemId: addResult.data?.calculatedLineItemId,
      calculatedOrderId: calculatedOrderId,
      isUpSell: details.isUpSell,
    }
    const discountResult = await addDiscount(orderId, discountDetails, admin, session, lang);
    if (!discountResult.status) {
      return {
        status: false,
        data: discountResult.message
      }
    }
    // commit all changes in order 
    const commitDetails = {
      calculatedOrderId: calculatedOrderId,
      notifyCustomer: true,
      staffNote: "Add new item in order"
    }
    const commitResult = await orderEditCommit(commitDetails, admin);

    if (!commitResult.status) {
      return {
        status: false,
        message: commitResult.message
      }
    }
    if (orderDetails) {
      const displayFulfillmentStatus = commitResult?.data?.data?.orderEditCommit?.order?.displayFulfillmentStatus;
      const orderData = {
        lineItems: { nodes: orderDetails.lineItems.nodes.filter(item => item.currentQuantity > 0) },
        discountApplications: orderDetails.discountApplications,
        displayFulfillmentStatus: displayFulfillmentStatus,
        shippingAddress: orderDetails.shippingAddress,
        shippingLines: orderDetails.shippingLines,
        customerId: orderDetails.customer?.id,
        currentTotalPriceSet: orderDetails.currentTotalPriceSet,
      }
      const isHoldOn = await isHoldEnable(details.partnerId);
      const addInReversOrdersResponse = await addInReversOrders(orderId, admin, orderData, details.partnerId, session.shop, isHoldOn);
      if (!addInReversOrdersResponse.status) {
        return {
          status: false,
          message: addInReversOrdersResponse.message
        }
      }
    }
    return {
      status: true,
      data: discountResult.message
    }
  } catch (error) {
    console.log("Error in addDiscountItem:", error);
    return {
      status: false,
      message: error?.message || ErrorMessage.INTERNAL_SERVER_ERROR
    }
  }
}

export const addDiscount = async (orderId, details, admin, session, lang) => {
  const response = await admin.graphql(`
    #graphql 
    mutation orderEditAddLineItemDiscount(
                $discount: OrderEditAppliedDiscountInput!
                $id: ID!
                $lineItemId: ID!
              ) {
                orderEditAddLineItemDiscount(
                  discount: $discount
                  id: $id
                  lineItemId: $lineItemId
                ) {
                  addedDiscountStagedChange {
                    id
                    description
                  }
                  calculatedLineItem {
                    id
                    quantity
                    title
                    variantTitle
                    discountedUnitPriceSet {
                      presentmentMoney {
                        amount
                        currencyCode
                      }
                      shopMoney {
                        currencyCode
                      }
                    }
                    calculatedDiscountAllocations {
                      allocatedAmountSet {
                        presentmentMoney {
                          amount
                          currencyCode
                        }
                        shopMoney {
                          amount
                          currencyCode
                        }
                      }
                    }
                  }
                  calculatedOrder {
                    id
                    notificationPreviewHtml
                    originalOrder {
                      id
                    }
                  }
                  userErrors {
                    field
                    message
                  }
                }
              }
              `, {
    variables: {
      "discount": {
        "description": `AE Upsell Discount`,
        "percentValue": details.percentage
      },
      "id": details.calculatedOrderId,
      "lineItemId": details.calculatedLineItemId
    },
  })
  // Send the request
  const data = await response.json()

  // check query send error order not found case 
  const error = data?.data?.orderEditAddLineItemDiscount?.userErrors;
  if (error?.length) {
    return {
      status: false,
      message: error[0].message
    }
  }
  let productName = ''
  if (details.isUpSell) {
    // order editing history
    await OrderEditingHistory.create({
      partnerId: details.partnerId,
      orderAction: ORDER_ACTION.UP_SELL_REVENUE,
      customerId: details.customerId,
      orderId: orderId,
      discountAmount: details.discountAmount,
      productVariantId: details.productVariantId

    })
    // Prepare email data
    const emailData = {
      upsellAmount: details?.discountAmount,
      productName: data?.data?.orderEditAddLineItemDiscount?.calculatedLineItem?.title
    }
    productName = emailData?.productName
    const editSummary = `${emailData?.productName} was added through Upsell List`
    const emailDataSend = {
      id: orderId, admin, session, ...emailData, partnerId: details.partnerId, type: NOTIFICATION_TYPES.ADD_UPSELL_ITEM, editSummary
    }
    // Send email notifications to merchant and customer
    setTimeout(() => {
      emailSender(emailDataSend, EMAIL_HANDLES.UPSELL_DISCOUNT, 'merchant')
      emailSender(emailDataSend, NOTIFICATION_TYPES.ORDER_EDIT, 'customer')
    }, 5000)


  }
  //SuccessMessage.ADDED => itemAdded
  const message = await getMessage(lang, details.partnerId, "itemsAdded");
  return {
    status: true,
    message: `${productName} ${message}`,
  }
}

export const addDiscountFixed = async (details, admin) => {
  const response = await admin.graphql(`
    #graphql 
    mutation orderEditAddLineItemDiscount(
                $discount: OrderEditAppliedDiscountInput!
                $id: ID!
                $lineItemId: ID!
              ) {
                orderEditAddLineItemDiscount(
                  discount: $discount
                  id: $id
                  lineItemId: $lineItemId
                ) {
                  addedDiscountStagedChange {
                    id
                    description
                  }
                  calculatedLineItem {
                    id
                    quantity
                    title
                    variantTitle
                    discountedUnitPriceSet {
                      presentmentMoney {
                        amount
                        currencyCode
                      }
                      shopMoney {
                        currencyCode
                      }
                    }
                    calculatedDiscountAllocations {
                      allocatedAmountSet {
                        presentmentMoney {
                          amount
                          currencyCode
                        }
                        shopMoney {
                          amount
                          currencyCode
                        }
                      }
                    }
                  }
                  calculatedOrder {
                    id
                    notificationPreviewHtml
                    originalOrder {
                      id
                    }
                  }
                  userErrors {
                    field
                    message
                  }
                }
              }
              `, {
    variables: {
      "discount": {
        "description": details.discountTag,
        "fixedValue": {
          "amount": details.amount,
          "currencyCode": details.currencyCode
        }
      },
      "id": details.calculatedOrderId,
      "lineItemId": details.calculatedLineItemId
    },
  })
  // Send the request
  const data = await response.json()

  // check query send error order not found case 
  const error = data?.data?.orderEditAddLineItemDiscount?.userErrors;
  if (error?.length) {
    return {
      status: false,
      message: error[0].message
    }
  }
  return {
    status: true,
    message: data,
  }
}

export const addDiscountPercentage = async (details, admin) => {
  const response = await admin.graphql(`
    #graphql 
    mutation orderEditAddLineItemDiscount(
                $discount: OrderEditAppliedDiscountInput!
                $id: ID!
                $lineItemId: ID!
              ) {
                orderEditAddLineItemDiscount(
                  discount: $discount
                  id: $id
                  lineItemId: $lineItemId
                ) {
                  addedDiscountStagedChange {
                    id
                    description
                  }
                  calculatedLineItem {
                    id
                    quantity
                    title
                    variantTitle
                    discountedUnitPriceSet {
                      presentmentMoney {
                        amount
                        currencyCode
                      }
                      shopMoney {
                        currencyCode
                      }
                    }
                    calculatedDiscountAllocations {
                      allocatedAmountSet {
                        presentmentMoney {
                          amount
                          currencyCode
                        }
                        shopMoney {
                          amount
                          currencyCode
                        }
                      }
                    }
                  }
                  calculatedOrder {
                    id
                    notificationPreviewHtml
                    originalOrder {
                      id
                    }
                  }
                  userErrors {
                    field
                    message
                  }
                }
              }
              `, {
    variables: {
      "discount": {
        "description": details.discountTag,
        "percentValue": details.percentValue
      },
      "id": details.calculatedOrderId,
      "lineItemId": details.calculatedLineItemId
    },
  })
  // Send the request
  const data = await response.json()

  // check query send error order not found case 
  const error = data?.data?.orderEditAddLineItemDiscount?.userErrors;
  if (error?.length) {
    return {
      status: false,
      message: error[0].message
    }
  }
  return {
    status: true,
    message: data,
  }
}