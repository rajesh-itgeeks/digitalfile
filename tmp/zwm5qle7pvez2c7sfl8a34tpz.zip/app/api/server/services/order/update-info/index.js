import {
  EMAIL_HANDLES,
  NOTIFICATION_TYPES,
  ORDER_ACTION,
  SHOPIFY_TAGS,
} from "../../../constants/constants";
import { ErrorMessage, SuccessMessage } from "../../../constants/messages";
import { AppSettings } from "../../../models/appSettings.model";
import { OrderEditingHistory } from "../../../models/orderEditingHistory.model";
import { Partner } from "../../../models/partner.model";
import { emailSender, saveOrderAction } from "../../../utils/utils";
import { updateStoreMetaField } from "../../partner/index.server";
import { flowTriggers, addedNewTag, getMessage } from "../utils";

export const changeOrderShippingAddress = async (
  orderId,
  details,
  admin,
  session,
  lang
) => {
  const response = await admin.graphql(
    `
    #graphql
    mutation updateOrderMetafields($input: OrderInput!) {
        orderUpdate(input: $input) {
          order {
            id
            email
            shippingAddress {
              address1
              address2
              city
              firstName
              lastName
              country
              phone
              province
              provinceCode
              zip
            }
          }
          userErrors {
            message
            field
          }
        }
      }
      `,
    {
      variables: {
        input: {
          shippingAddress: {
            address1: details.address1,
            address2: details.address2,
            city: details.city,
            firstName: details.firstName,
            lastName: details.lastName,
            country: details.country,
            phone: details.phone,
            province: details.province,
            provinceCode: details.provinceCode,
            zip: details.zip,
          },
          id: `gid://shopify/Order/${orderId}`,
          email: details.email,
        },
      },
    },
  );
  // Send the request
  const data = await response.json();
  // check query send error
  const error = data?.data?.orderUpdate?.userErrors;
  if (error.length) {
    return {
      status: false,
      message: error[0]?.message || ErrorMessage.MUTATION_BADE_REQ,
    };
  }

  // order editing history
  await OrderEditingHistory.create({
    partnerId: details.partnerId,
    orderAction: ORDER_ACTION.UPDATE_SHIPPING,
    customerId: details.customerId,
    orderId: orderId,
  });
  const editSummary = `Shipping address was updated in the order`;
  // Prepare email data
  const emailData = {
    id: orderId,
    admin,
    session,
    partnerId: details.partnerId,
    type: NOTIFICATION_TYPES.ORDER_EDIT,
    shippingAddress: data?.data?.orderUpdate?.order?.shippingAddress,
    editSummary,
  };
  // Send email notifications to merchant and customer
  emailSender(emailData, EMAIL_HANDLES.UPDATE_SHIPPING, "merchant");
  emailSender(emailData, EMAIL_HANDLES.UPDATE_SHIPPING, "customer");

  await addedNewTag(SHOPIFY_TAGS.UPDATE_SHIPPING, orderId, admin);
  await flowTriggers(orderId, "address-updated", admin);
  // SuccessMessage.CHANGE => shippingAddressChanged
  const message = await getMessage(lang, details.partnerId, "shippingAddressChanged");
  return {
    status: true,
    message: `${message}`,
    data: data,
  };
};

export const updateContactInfo = async (orderId, details, admin, session, lang) => {
  const response = await admin.graphql(
    `
    #graphql
    mutation updateOrderMetafields($input: OrderInput!) {
        orderUpdate(input: $input) {
          order {
            id
            email
            shippingAddress {
              address1
              address2
              city
              firstName
              lastName
            }
          }
          userErrors {
            message
            field
          }
        }
      }`,
    {
      variables: {
        input: {
          id: `gid://shopify/Order/${orderId}`,
          email: details.email,
        },
      },
    },
  );

  // Send the request
  const data = await response.json();
  // check query send error
  const error = data?.data?.orderUpdate?.userErrors;
  if (error?.length) {
    return {
      status: false,
      message: error[0]?.message,
    };
  }

  // order editing history
  await OrderEditingHistory.create({
    partnerId: details.partnerId,
    orderAction: ORDER_ACTION.UPDATE_CONTACT_INFO,
    customerId: details.customerId,
    orderId: orderId,
  });
  const editSummary = `Contact info was updated to ${details?.email} the order `;
  const customerEmailData = {
    id: orderId,
    admin,
    session,
    partnerId: details.partnerId,
    type: NOTIFICATION_TYPES.ORDER_EDIT,
    email: details.email,
    editSummary,
  };
  // Send email notifications to merchant and customer
  emailSender(customerEmailData, EMAIL_HANDLES.UPDATE_CONTACT_INFO, "merchant");
  emailSender(customerEmailData, EMAIL_HANDLES.UPDATE_CONTACT_INFO, "customer");
  await addedNewTag(SHOPIFY_TAGS.UPDATE_CONTACT_INFO, orderId, admin);

  await addedNewTag(SHOPIFY_TAGS.UPDATE_CONTACT_INFO, orderId, admin);


  await flowTriggers(orderId, "email-updated", admin);
  //SuccessMessage.CONTACT_INFO_UPDATED => contact info
  const message = await getMessage(lang, details?.partnerId, "contactInfoUpdated");
  return {
    status: true,
    message: `${message}`,
    data: data,
  };
};

export const addressPredictions = async (details) => {
  try {

    console.log('-------------------------------------------address predictions');


    const { query } = details;
    const response = await fetch(
      `https://maps.googleapis.com/maps/api/place/autocomplete/json?${query}&key=${process.env.GOOGLE_API_KEY}`,
      {
        headers: { "Cache-Control": "max-age=3600" },
      },
    );
    const data = await response.json();
    return {
      status: true,
      message: SuccessMessage.FETCHED,
      data,
    };
  } catch (error) {
    return {
      status: false,
      message: error?.message || ErrorMessage.INTERNAL_SERVER_ERROR,
    };
  }
};
export const addressDetails = async (details) => {
  try {
    const { placeId } = details;
    const response = await fetch(
      `https://maps.googleapis.com/maps/api/place/details/json?place_id=${placeId}&key=${process.env.GOOGLE_API_KEY}`,
      {
        headers: { "Cache-Control": "max-age=3600" },
      },
    );
    const data = await response.json();
    console.log(data, '---------------------------------------address details');

    return {
      status: true,
      message: SuccessMessage.FETCHED,
      data,
    };
  } catch (error) {
    return {
      status: false,
      message: error?.message || ErrorMessage.INTERNAL_SERVER_ERROR,
    };
  }
};

export const updateMetaField = async (session, admin) => {
  const partnerDetails = await Partner.findOne({
    myshopify_domain: session.shop,
  });
  if (!partnerDetails) {
    console.log("Partner details not found");
    return {
      status: true,
      message: "Metafield update",
    };
  }
  const appSettings = await AppSettings.findOne({
    partnerId: partnerDetails._id,
  });
  if (!appSettings) {
    console.log("App Settings not found");
    return {
      status: true,
      message: "Metafield update",
    };
  }
  await updateStoreMetaField(appSettings, admin);
  return {
    status: true,
    message: "Metafield update",
  };
};

export const validateAddress = async (details) => {
  try {
    const requestBody = {
      address: {
        regionCode: details.country,
        locality: details.city,
        administrativeArea: details.province,
        postalCode: details.zip,
        addressLines: [details.address1, details.address2].filter(Boolean),
      },
    };

    const response = await fetch(
      `https://addressvalidation.googleapis.com/v1:validateAddress?key=${process.env.GOOGLE_API_KEY}`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Cache-Control": "max-age=3600",
        },
        body: JSON.stringify(requestBody),
      },
    );

    const responseData = await response.json();
    console.log(responseData, '------------------------------responseData');

    if (!response.ok) {
      throw new Error(
        responseData?.error?.message || "Address validation failed",
      );
    }

    const result = responseData.result;

    const verdict = result?.verdict;
    const address = result?.address?.postalAddress;
    const components = result?.address?.addressComponents || [];
    const missingTypes = result?.address?.missingComponentTypes || [];
    const unconfirmedTypes = result?.address?.unconfirmedComponentTypes || [];

    const validationGranularity = verdict?.validationGranularity || "";
    const inputGranularity = verdict?.inputGranularity || "";
    const geocodeGranularity = verdict?.geocodeGranularity || "";
    const hasInferredComponents = verdict?.hasInferredComponents || "";

    const hasInferred = components.some((c) => c.inferred === true);
    const hasReplaced = components.some((c) => c.replaced === true);
    const isInputGranularityValid =
      verdict.inputGranularity === "PREMISE" ||
      verdict.inputGranularity === "ROUTE";
    const isValidationGranularityValid =
      verdict.validationGranularity === "PREMISE" ||
      verdict.validationGranularity === "ROUTE";

    const isAddressComplete = verdict?.addressComplete === true;

    const getConfirmationLevel = (components, type) => {
      const comp = components.find((c) => c.componentType === type);
      return comp?.confirmationLevel === "CONFIRMED";
    };

    const isRouteConfirmed = getConfirmationLevel(components, "route");
    const isLocalityConfirmed = getConfirmationLevel(components, "locality");
    const isSubLoaclityConfirmed = getConfirmationLevel(
      components,
      "sublocality_level_1",
    );
    const isValid =
      isRouteConfirmed &&
      isLocalityConfirmed &&
      isInputGranularityValid &&
      isValidationGranularityValid &&
      isSubLoaclityConfirmed;

    let suggestion = null;
    if (!isValid) {
      const response = await addressPredictions({
        query: `input='${details.address1} ${details.city} ${details.zip} ${details.province}'&types=address&language=en&components=country:${details.country}`,
      });

      const predictions = response?.data?.predictions || [];
      if (predictions.length > 0) {
        const firstPrediction = predictions[0];
        const firstDescription = firstPrediction.description;
        const firstPlaceId = firstPrediction.place_id;

        if (firstPlaceId) {
          const response = await addressDetails({ placeId: firstPlaceId });

          const getAddressComponent = (
            components,
            type,
            useShortName = false,
          ) => {
            const comp = components.find((c) => c.types.includes(type));
            if (!comp) return "";
            return useShortName ? comp.short_name : comp.long_name;
          };

          if (response?.status && response?.data?.result) {
            const result = response.data.result;
            const components = result.address_components || [];
            const adrHTML = result.adr_address || "";
            const streetMatch = adrHTML.match(
              /<span class="street-address">(.*?)<\/span>/,
            );
            const extendedMatch = adrHTML.match(
              /<span class="extended-address">(.*?)<\/span>/,
            );

            const street = streetMatch ? streetMatch[1] : "";
            const extended = extendedMatch ? extendedMatch[1] : "";
            let address1 = [street, extended].filter(Boolean).join(", ");
            if (details.country == 'US') {
              address1 = [
                getAddressComponent(components, "street_number"),
                getAddressComponent(components, "route")
              ].filter(Boolean).join(" ");
            }
            const city =
              getAddressComponent(components, "locality") ||
              getAddressComponent(components, "postal_town") ||
              getAddressComponent(components, "sublocality");
            const state = getAddressComponent(
              components,
              "administrative_area_level_1",
              true,
            );
            const zip = getAddressComponent(components, "postal_code");
            const country = getAddressComponent(components, "country", true);
            suggestion = {
              address1: address1 || "",
              city: city || details.city,
              province: state || "",
              zip: zip || "",
              country: country || details.country,
            };
          }
        }
      }
    }

    let isSameCity = false;
    let isSameStreet = false;

    if (!isValid && suggestion) {
      isSameStreet =
        details.address1?.toLowerCase().trim() !==
        (suggestion?.address1 || "").toLowerCase().trim();
      isSameCity =
        details.city?.toLowerCase().trim() !==
        (suggestion?.city || "").toLowerCase().trim();
    }
    const isComplete = !isSameCity && !isSameStreet;
    return {
      status: true,
      message: SuccessMessage.FETCHED,
      data: {
        isValid,
        isComplete,
        isSameCity,
        isSameStreet,
        hasInferred,
        hasReplaced,
        isAddressComplete,
        isLocalityConfirmed,
        isRouteConfirmed,
        isValidationGranularityValid,
        isSubLoaclityConfirmed,
        isInputGranularityValid,
        granularity: {
          inputGranularity,
          validationGranularity,
          geocodeGranularity,
          hasInferredComponents,
        },
        missingComponentTypes: missingTypes,
        unconfirmedComponentTypes: unconfirmedTypes,
        formattedAddress: result?.address?.formattedAddress,
        original: details,
        suggestion,
        validatedAddress: address,
      },
    };
  } catch (error) {
    return {
      status: false,
      message: error?.message || ErrorMessage.INTERNAL_SERVER_ERROR,
    };
  }
};
