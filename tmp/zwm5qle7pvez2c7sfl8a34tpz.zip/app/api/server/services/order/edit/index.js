import { EMAIL_HANDLES, NOTIFICATION_TYPES, ORDER_ACTION, SHOPIFY_TAGS } from "../../../constants/constants";
import messages, { ErrorMessage, SuccessMessage } from "../../../constants/messages";
import { OrderEditingHistory } from "../../../models/orderEditingHistory.model";
import { emailSender } from "../../../utils/utils";
import { addDiscountInAllOrderLineItemsNew, checkLineItemDiscount, discountEligible, matchUpdatedOrderDiscounts } from "../../discounts/index.server";
import { creditCardRefund } from "../cancellation";
import { addInReversOrders, removeInReversOrders } from "../holdOrder";
import { addDiscountFixed } from "../up-sell";

import { addedNewTag, addOrderItemSingle, getOrderCalculateId, isHoldEnable, newAndSwapItemsAvailability, orderAdmin, orderEditCommit, flowTriggers, getMessage, orderAdminRevers } from "../utils";

export const addOrderItem = async (items, orderId, admin, isSwap = false, session, lang) => {
  try {
    // get order calculate id 
    let productNames = [];
    const calculateOrderDetails = await getOrderCalculateId(orderId, admin);
    let calculatedOrderId = calculateOrderDetails?.data?.data?.orderEditBegin?.calculatedOrder?.id;

    if (!calculateOrderDetails.status && !calculatedOrderId) {
      return {
        status: false,
        message: calculateOrderDetails.message
      }
    }
    // get order details before edit  
    const orderDetails = await orderAdminRevers(orderId, admin);

    let isCommit = false;
    let addedList = [];

    // check existing order discounts match in update order discounts or not 
    const matchDiscountDetails = await matchUpdatedOrderDiscounts(orderDetails, calculatedOrderId, orderId, items, admin, 'add');

    if (matchDiscountDetails.status && !matchDiscountDetails.discountsUpdated) {
      return {
        status: true,
        data: [matchDiscountDetails.messages]
      }
    }
    if (matchDiscountDetails.status && matchDiscountDetails.discountsUpdated) {
      isCommit = true;
      addedList = matchDiscountDetails.data.updatedList;
      calculatedOrderId = matchDiscountDetails.data.calculatedOrderId;
      productNames = matchDiscountDetails.productNames
    }

    // Process each item
    if (!isCommit) {
      await Promise.all(items.map(async (details) => {
        // Check item availability
        const isAvailable = await newAndSwapItemsAvailability(details.productVariantId, details.quantity, admin);
        if (!isAvailable.status) {
          addedList.push({ status: false, message: isAvailable?.message });
          return { status: false, message: isAvailable?.message }
        }
        // Add variant to order
        const response = await admin.graphql(
          `#graphql
            mutation orderEditAddVariant($id: ID!, $quantity: Int!, $variantId: ID!) {
                  orderEditAddVariant(id: $id, quantity: $quantity, variantId: $variantId) {
                    calculatedLineItem {
                      id
                      quantity
                      title
                      variantTitle
                      editableSubtotalSet{
                        presentmentMoney{
                          amount
                          currencyCode
                        }
                        shopMoney{
                          amount
                          currencyCode
                        }
                      }
                    }
                    calculatedOrder {
                      id
                    }
                    userErrors {
                      field
                      message
                    }
                  }
                }
              `, {
          variables: {
            "allowDuplicates": true,
            "id": calculatedOrderId,
            "quantity": details.quantity,
            "variantId": details.productVariantId
          },
        })

        // Send the request
        const data = await response.json()

        // check query send error
        const error = data?.data?.orderEditAddVariant?.userErrors;
        if (error?.length) {
          addedList.push({ status: false, message: error[0]?.message || ErrorMessage.MUTATION_BADE_REQ })
          return { status: false, message: error[0]?.message || ErrorMessage.MUTATION_BADE_REQ }
        }
        const result = data?.data?.orderEditAddVariant?.calculatedLineItem;

        const productTitle = result.title ? result.title : "";
        const productVariant = result.variantTitle ? result.variantTitle : "";


        if (!isSwap) {
          // add tag in order
          await addedNewTag(SHOPIFY_TAGS.ADD_ITEM, orderId, admin);
          // order editing history
          await OrderEditingHistory.create({
            partnerId: items.partnerId,
            orderAction: ORDER_ACTION.ADD_ITEM,
            customerId: details.customerId,
            orderId: orderId,
            amount: data?.data?.orderEditAddVariant?.calculatedLineItem?.editableSubtotalSet?.presentmentMoney?.amount || 0
          })
        }
        isCommit = true;
        productNames.push(` ${productTitle} ${productVariant} `)
        //SuccessMessage.ADDED => itemAdded
        const message = await getMessage(lang, items?.partnerId, "itemsAdded");
        addedList.push({ status: true, message: `${productTitle} ${productVariant} ${message}` });
        return { status: true, message: `${productTitle} ${productVariant} ${message}`, };
      }));
    }


    let commitResult;
    if (isCommit) {
      commitResult = await orderEditCommit({
        calculatedOrderId,
        notifyCustomer: true,
        staffNote: "Add new item in order"
      }, admin);
    }

    if (productNames?.length) {
      const editSummary = `${productNames} was added in the order `;
      // Send email notifications
      const emailData = {
        id: orderId, admin, session, productNames, partnerId: items.partnerId, type: NOTIFICATION_TYPES.ORDER_EDIT, editSummary
      }
      emailSender(emailData, EMAIL_HANDLES.ADD_ITEM_EMAIL, 'merchant')
      emailSender(emailData, NOTIFICATION_TYPES.ORDER_EDIT, 'customer')
      await flowTriggers(orderId, 'product-added', admin);
    }


    const hasSuccess = addedList.some(item => item.status === true);
    if (hasSuccess) {
      const displayFulfillmentStatus = commitResult?.data?.data?.orderEditCommit?.order?.displayFulfillmentStatus;
      if (orderDetails) {
        const orderData = {
          lineItems: { nodes: orderDetails.lineItems.nodes.filter(item => item.currentQuantity > 0) },
          discountApplications: orderDetails.discountApplications,
          displayFulfillmentStatus: displayFulfillmentStatus,
          shippingAddress: orderDetails.shippingAddress,
          shippingLines: orderDetails.shippingLines,
          customerId: orderDetails.customer?.id,
          currentTotalPriceSet: orderDetails.currentTotalPriceSet,
        }

        // add order in reversOrders collection 
        const isHoldOn = await isHoldEnable(items.partnerId);
        const addInReversOrdersResponse = await addInReversOrders(orderId, admin, orderData, items.partnerId, session.shop, isHoldOn);
        if (!addInReversOrdersResponse.status) {
          return {
            status: false,
            message: addInReversOrdersResponse.message
          }
        }
      }
    }
    return { status: true, data: addedList };
  } catch (error) {
    console.log("Error in addOrderItem:", error);
    return {
      status: false,
      message: error?.message,
    };
  }
}

export const editOrderItem = async (orderId, items, admin, session, lang) => {
  try {
    const calculateOrderDetails = await getOrderCalculateId(orderId, admin);
    let calculatedOrderId = calculateOrderDetails?.data?.data?.orderEditBegin?.calculatedOrder?.id;

    if (!calculateOrderDetails.status && !calculatedOrderId) {
      return { status: false, message: calculateOrderDetails.message }
    }

    // get order details before edit  
    const orderDetails = await orderAdminRevers(orderId, admin);
    let isCommit = false;
    let updatedList = [];


    const matchDiscountDetails = await matchUpdatedOrderDiscounts(orderDetails, calculatedOrderId, orderId, items, admin, 'edit');

    if (matchDiscountDetails.status && !matchDiscountDetails.discountsUpdated) {
      return {
        status: true,
        data: [matchDiscountDetails.messages]
      }
    }
    if (matchDiscountDetails.status && matchDiscountDetails.discountsUpdated) {
      isCommit = true;
      updatedList = matchDiscountDetails.data.updatedList;
      calculatedOrderId = matchDiscountDetails.data.calculatedOrderId;
    }

    if (!isCommit) {

      await Promise.all(items.map(async (details) => {
        const isAvailable = await existingItemsAvailability(orderId, details, admin);
        if (!isAvailable.status) {
          updatedList.push({
            status: false,
            message: isAvailable.message
          })
          return { status: false, message: isAvailable.message };
        }

        // GraphQL mutation to update the item quantity in the order
        const response = await admin.graphql(`
                #graphql
                mutation increaseLineItemQuantity {
                  orderEditSetQuantity(
                    id: "${calculatedOrderId}"
                    lineItemId: "${details.calculatedLineItemId}"
                    quantity: ${details.quantity}
                    restock:true
                  ) {
                    calculatedLineItem{
                          id
                          quantity
                          title
                          variantTitle
                    }
                    userErrors {
                      field
                      message
                    }
                  }
                }`, {})

        const data = await response.json()
        // check query send error
        const error = data?.data?.orderEditSetQuantity?.userErrors;
        if (error?.length) {
          updatedList.push({
            status: false,
            message: error[0]?.message
          })
          return {
            status: false, message: error[0]?.message
          };
        }
        // Retrieve updated item details
        const result = data?.data?.orderEditSetQuantity?.calculatedLineItem;
        const productTitle = result.title ? result.title : "";
        const productVariant = result.variantTitle ? result.variantTitle : "";
        // add tag in order
        await addedNewTag(SHOPIFY_TAGS.EDIT_ITEM, orderId, admin);
        // order editing history
        await OrderEditingHistory.create({
          partnerId: items.partnerId,
          orderAction: ORDER_ACTION.UPDATE_ITEM,
          customerId: details.customerId,
          orderId: orderId
        })
        isCommit = true;
        updatedList.push({ quantity: result.quantity, title: `${productTitle} ${productVariant}` });
        const flowTriggerType = isAvailable.quantity < isAvailable.newQuantity
          ? 'product-quantity-increased'
          : 'product-quantity-decreased';
        await flowTriggers(orderId, flowTriggerType, admin);
        //successMessage.UPDATED => itemsUpdated
        const message = await getMessage(lang, items?.partnerId, "itemsUpdated");
        updatedList.push({
          status: false,
          message: ` ${productTitle} ${productVariant} ${message}`,
        })
        return {
          status: true,
          message: ` ${productTitle} ${productVariant} ${message}`,
        };
      }));
    }

    if (isCommit) {
      const commitResult = await orderEditCommit({
        calculatedOrderId,
        notifyCustomer: true,
        staffNote: "Edit item in order"
      }, admin);
      // Send email notifications to merchant and customer if any item was updated
      if (updatedList?.length) {
        const editedList = updatedList.map((nodes) => {
          return `<p style="margin: 0; padding:2px 0px"><strong>Title :</strong>  ${nodes?.title} <strong> Quantity : </strong>${nodes?.quantity} </p>`
        })
        const editSummary = `${editedList.join(" ")}`;
        const emailData = {
          id: orderId, admin, session, updatedList, partnerId: items.partnerId, type: NOTIFICATION_TYPES.ORDER_EDIT, editSummary
        }
        // Send email notifications to merchant and customer
        emailSender(emailData, EMAIL_HANDLES.EDIT_ORDER, 'merchant')
        emailSender(emailData, NOTIFICATION_TYPES.ORDER_EDIT, 'customer')
      }
      // check if refund owned
      let refundAmount = commitResult?.data?.data?.orderEditCommit?.order?.totalOutstandingSet?.shopMoney?.amount;
      console.log("refundAmount :", refundAmount);
      refundAmount = refundAmount ? parseFloat(refundAmount) : 0;
      if (refundAmount <= 0) {
        updatedList.push({ status: true, messages: `Order Item ${SuccessMessage.REFUND}` })
        await creditCardRefund({ reason: "Edit order item" }, orderId, false, admin);
        const removeResponse = await removeInReversOrders(orderId, admin);
        if (!removeResponse.status) {
          return { status: false, message: removeResponse.message };
        }
      } else {
        const displayFulfillmentStatus = commitResult?.data?.data?.orderEditCommit?.order?.displayFulfillmentStatus;
        const orderData = {
          lineItems: { nodes: orderDetails.lineItems.nodes.filter(item => item.currentQuantity > 0) },
          discountApplications: orderDetails.discountApplications,
          displayFulfillmentStatus,
          shippingAddress: orderDetails.shippingAddress,
          shippingLines: orderDetails.shippingLines,
          customerId: orderDetails.customer?.id,
          currentTotalPriceSet: orderDetails.currentTotalPriceSet,
        }
        // add order in reversOrders collection 
        const isHoldOn = await isHoldEnable(items.partnerId);
        const addInReversOrdersResponse = await addInReversOrders(orderId, admin, orderData, items.partnerId, session.shop, isHoldOn);
        if (!addInReversOrdersResponse.status) {
          return { status: false, message: addInReversOrdersResponse.message };
        }
      }
    }

    return { status: true, data: updatedList };
  } catch (error) {
    console.log("Error in editOrderItem:", error);
    return {
      status: false,
      message: error?.message,
    };
  }
}

export const removeOrderItem = async (details, orderId, admin, isSwap = false, session, lang) => {
  try {
    // get order calculate id 
    const calculateOrderDetails = await getOrderCalculateId(orderId, admin);
    let calculatedOrderId = calculateOrderDetails?.data?.data?.orderEditBegin?.calculatedOrder?.id;
    console.log('Order Calculated Id :', calculatedOrderId);

    if (!calculateOrderDetails.status && !calculatedOrderId) {
      return { status: false, message: calculateOrderDetails.message }
    }
    const orderDetails = await orderAdminRevers(orderId, admin);
    let isCommit = false;
    const matchDiscountDetails = await matchUpdatedOrderDiscounts(orderDetails, calculatedOrderId, orderId, [details], admin, 'remove');
    if (matchDiscountDetails.status && !matchDiscountDetails.discountsUpdated) {
      return {
        status: true,
        data: [matchDiscountDetails.messages]
      }
    }
    if (matchDiscountDetails.status && matchDiscountDetails.discountsUpdated) {
      isCommit = true;
      calculatedOrderId = matchDiscountDetails.data.calculatedOrderId;
    }
    let removeResult
    if (!isCommit) {
      // Remove the specified item from the order
      removeResult = await removeItem(calculatedOrderId, details.calculatedLineItemId, admin);
      if (!removeResult.status) {
        return {
          status: false,
          message: removeResult.message
        }
      }
    }
    // If this is not a swap operation, update order history
    if (!isSwap) {
      // add tag in order
      await addedNewTag(SHOPIFY_TAGS.REMOVE_ITEM, orderId, admin);
      // Store order editing history
      await OrderEditingHistory.create({
        partnerId: details.partnerId,
        orderAction: ORDER_ACTION.REMOVE_ITEM,
        customerId: details.customerId,
        orderId: orderId
      })
    }
    await OrderEditingHistory.updateOne({
      partnerId: details.partnerId,
      orderId: orderId,
      customerId: details.customerId,
      orderAction: ORDER_ACTION.UP_SELL_REVENUE,
      productVariantId: removeResult?.data?.data?.orderEditSetQuantity?.calculatedLineItem?.variant?.id,
    }, { isRemoved: true });


    // commit all changes in order 
    const commitDetails = {
      calculatedOrderId: calculatedOrderId,
      notifyCustomer: true,
      staffNote: "Remove item in order"
    }
    const commitResult = await orderEditCommit(commitDetails, admin);
    if (!commitResult.status) {
      return {
        status: false,
        message: commitResult.message
      }
    }
    // Get removed item's title and variant for notification
    const productTitle = removeResult?.data?.data?.orderEditSetQuantity?.calculatedLineItem?.title || ""
    const variantTitle = removeResult?.data?.data?.orderEditSetQuantity?.calculatedLineItem?.variantTitle || ""
    const itemTitle = productTitle + " " + variantTitle
    // Prepare email data
    const editSummary = `${itemTitle} was removed from the order `
    const emailData = {
      id: orderId, admin, session, itemTitle, partnerId: details.partnerId, type: NOTIFICATION_TYPES.ORDER_EDIT, editSummary
    }
    // Send email notifications to merchant and customer
    emailSender(emailData, EMAIL_HANDLES.REMOVE_ITEM_EMAIL, 'merchant')
    emailSender(emailData, NOTIFICATION_TYPES.ORDER_EDIT, 'customer')

    await flowTriggers(orderId, 'product-removed', admin);

    // check if refund owned
    let refundAmount = commitResult?.data?.data?.orderEditCommit?.order?.totalOutstandingSet?.shopMoney?.amount;
    console.log("refundAmount :", refundAmount);
    // Check if a refund is required
    refundAmount = refundAmount ? parseFloat(refundAmount) : 0;
    if (refundAmount <= 0) {
      // Process refund
      const refundDetails = {
        reason: "Edit order item"
      }
      await creditCardRefund(refundDetails, orderId, false, admin);
      const removeResponse = await removeInReversOrders(orderId, admin);
      if (!removeResponse.status) {
        return {
          status: false,
          message: removeResponse.message
        }
      }
    }

    //SuccessMessage.ITEM_REMOVED => itemRemoved
    const message = await getMessage(lang, details?.partnerId, "itemRemoved")
    return {
      status: true,
      message: message,
    }

  } catch (error) {
    console.log("Error in removeOrderItem :", error);
    return {
      status: false,
      message: error?.message,
    };
  }
}

export const removeItem = async (calculatedOrderId, calculatedLineItemId, admin) => {
  try {
    const response = await admin.graphql(`
    #graphql
    mutation increaseLineItemQuantity {
                orderEditSetQuantity(
                  id: "${calculatedOrderId}"
                  lineItemId: "${calculatedLineItemId}"
                  quantity: 0
                  restock: true
                ) {
                  calculatedLineItem {
                  id
                  quantity
                  title
                  variant {
                      id
                    }
                  variantTitle
                      }
                  calculatedOrder {
                    id
                    addedLineItems(first: 5) {
                      edges {
                        node {
                          id
                          quantity
                        }
                      }
                    }
                  }
                  userErrors {
                    field
                    message
                  }
                }
              }
              `)

    // Send the request
    const data = await response.json()

    // check query send error
    const error = data?.data?.orderEditSetQuantity?.userErrors;
    if (error?.length) {
      return {
        status: false,
        message: error[0]?.message || ErrorMessage.MUTATION_BADE_REQ
      }
    }

    return {
      status: true,
      message: SuccessMessage.ITEM_REMOVED,
      data: data
    }

  } catch (error) {
    console.log("Error in removeOrderItem :", error);
    return {
      status: false,
      message: error?.message,
    };
  }
}

export const swapOrderItem = async (details, orderId, admin, session, lang) => {
  try {
    // check item is available or not
    const isAvailable = await newAndSwapItemsAvailability(details.productVariantId, details.quantity, admin);
    if (!isAvailable.status) {
      return {
        status: false,
        message: isAvailable?.message
      }
    }

    // get order calculate id 
    const calculateOrderDetails = await getOrderCalculateId(orderId, admin);
    let calculatedOrderId = calculateOrderDetails?.data?.data?.orderEditBegin?.calculatedOrder?.id;

    if (!calculateOrderDetails.status && !calculatedOrderId) {
      return {
        status: false,
        message: calculateOrderDetails.message
      }
    }

    // get order details before edit  
    const orderDetails = await orderAdminRevers(orderId, admin);
    let isCommit = false
    let variantTitle, productTitle, removedTitleMessage
    const matchDiscountDetails = await matchUpdatedOrderDiscounts(orderDetails, calculatedOrderId, orderId, [details], admin, 'swap');
    if (matchDiscountDetails.status && !matchDiscountDetails.discountsUpdated) {
      return {
        status: true,
        data: [matchDiscountDetails.messages]
      }
    }
    if (matchDiscountDetails.status && matchDiscountDetails.discountsUpdated) {
      isCommit = true;
      calculatedOrderId = matchDiscountDetails.data.calculatedOrderId;
      removedTitleMessage = matchDiscountDetails.data.productNames[0];
    }

    if (!isCommit) {
      // remove existing order item 
      const removeResult = await removeItem(calculatedOrderId, details.calculatedLineItemId, admin);
      if (!removeResult.status) {
        return {
          status: false,
          message: removeResult.message
        };
      }
      productTitle = removeResult?.data?.data?.orderEditSetQuantity?.calculatedLineItem?.title || ""
      variantTitle = removeResult?.data?.data?.orderEditSetQuantity?.calculatedLineItem?.variantTitle || ""
      // add new order item 
      const addDetails = {
        calculatedOrderId: details.calculatedOrderId,
        productVariantId: details.productVariantId,
        quantity: details.quantity,
        customerId: details.customerId,
        partnerId: details.partnerId
      }

      const addResult = await addOrderItemSingle(orderId, addDetails, calculatedOrderId, admin);
      if (!addResult.status) {
        return {
          status: false,
          message: addResult.message
        };
      }
    }
    // add tag in order
    await addedNewTag(SHOPIFY_TAGS.SWAP_ITEM, orderId, admin);

    // order editing history
    await OrderEditingHistory.create({
      partnerId: details.partnerId,
      orderAction: ORDER_ACTION.SWAP_ITEM,
      customerId: details.customerId,
      orderId: orderId
    })

    // commit all changes in order 
    const commitDetails = {
      calculatedOrderId: calculatedOrderId,
      notifyCustomer: true,
      staffNote: "swap item in order"
    }
    const commitResult = await orderEditCommit(commitDetails, admin);
    if (!commitResult.status) {
      return {
        status: false,
        message: commitResult.message
      }
    }
    const emailData = {
      removedTitle: productTitle ? productTitle + " " + variantTitle : removedTitleMessage,
      addedTitle: productTitle ? productTitle + " " + variantTitle : removedTitleMessage
    }

    // check if refund owned
    let refundAmount = commitResult?.data?.data?.orderEditCommit?.order?.totalOutstandingSet?.shopMoney?.amount;
    console.log("refundAmount :", refundAmount);
    refundAmount = refundAmount ? parseFloat(refundAmount) : 0;
    if (refundAmount <= 0) {
      const refundDetails = {
        reason: "Swap order item"
      }
      await creditCardRefund(refundDetails, orderId, false, admin);
      const removeResponse = await removeInReversOrders(orderId, admin);
      if (!removeResponse.status) {
        return {
          status: false,
          message: removeResponse.message
        }
      }
    } else {
      if (orderDetails) {
        const displayFulfillmentStatus = commitResult?.data?.data?.orderEditCommit?.order?.displayFulfillmentStatus;
        const orderData = {
          lineItems: { nodes: orderDetails.lineItems.nodes.filter(item => item.currentQuantity > 0) },
          discountApplications: orderDetails.discountApplications,
          displayFulfillmentStatus: displayFulfillmentStatus,
          shippingAddress: orderDetails.shippingAddress,
          shippingLines: orderDetails.shippingLines,
          customerId: orderDetails.customer?.id,
          currentTotalPriceSet: orderDetails.currentTotalPriceSet,
        }
        const isHoldOn = await isHoldEnable(details.partnerId);
        const addInReversOrdersResponse = await addInReversOrders(orderId, admin, orderData, details.partnerId, session.shop, isHoldOn);
        if (!addInReversOrdersResponse.status) {
          return {
            status: false,
            message: addInReversOrdersResponse.message
          }
        }
      }
    }

    const editSummary = `${emailData?.removedTitle} was swapped with variant ${emailData?.addedTitle} in the order `
    const emailDataSend = {
      id: orderId, admin, session, ...emailData, partnerId: details.partnerId, type: NOTIFICATION_TYPES.ORDER_EDIT, editSummary
    }

    emailSender(emailDataSend, EMAIL_HANDLES.SWAP_ITEM, 'merchant')
    emailSender(emailDataSend, NOTIFICATION_TYPES.ORDER_EDIT, 'customer')

    await flowTriggers(orderId, 'product-variant-swapped', admin);
    //SuccessMessage.SWAP => swap
    const message = await getMessage(lang, details?.partnerId, "swap")
    return {
      status: true,
      message: message,
    }

  } catch (error) {
    console.log("Error in swapOrderItem :", error);
    return {
      status: false,
      message: error?.message,
    };
  }
}

export const existingItemsAvailability = async (orderId, details, admin) => {
  const lineItemId = `gid://shopify/LineItem/${details.calculatedLineItemId.split("/").pop()}`;

  try {
    const response = await admin.graphql(`
        #graphql  
        {
          order(id: "gid://shopify/Order/${orderId}") { 
            lineItems(first: 100) { 
              edges {
                node {
                  id
                  currentQuantity
                  variant {
                    product{
                        id
                        title
                    }
                    id
                    title
                    availableForSale
                    inventoryQuantity
                    inventoryPolicy
                    inventoryItem {
                      tracked
                    }
                  }
                }
              }
            }
          }
        }
      `);

    const data = await response.json();
    const lineItems = data?.data?.order?.lineItems?.edges || [];

    if (!lineItems.length) {
      return { status: false, message: "Data not available" };
    }

    const targetItem = lineItems.find(edge => edge.node.id === lineItemId);

    if (!targetItem) {
      return { status: false, message: "Item not found in order" };
    }

    const { variant, currentQuantity } = targetItem.node;

    if (!variant.inventoryItem.tracked) {
      return { status: true, message: "The Item is not tracked" };
    }

    if (variant.inventoryPolicy == 'CONTINUE') {
      return { status: true, message: "Continue for Sale", quantity: currentQuantity, newQuantity: details.quantity };
    }

    if (!variant.availableForSale && (details.quantity <= currentQuantity)) {
      return { status: true, message: "Decreasing Quantity", quantity: currentQuantity, newQuantity: details.quantity };
    }

    if (variant.availableForSale && (variant.inventoryQuantity + currentQuantity) >= details.quantity) {
      return { status: true, message: "Available for Sale", quantity: currentQuantity, newQuantity: details.quantity };
    }

    return { status: false, message: `Only ${variant.inventoryQuantity + currentQuantity} of ${variant.product.title} can be added to your order.` };

  } catch (error) {
    console.error("Error fetching item availability:", error);
    return { status: false, message: "Error checking item availability" };
  }
};

