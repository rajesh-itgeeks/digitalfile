import { NOTIFICATION_TYPES, ORDER_ACTION, SHOPIFY_TAGS, TRIGGER_HANDLES } from "../../constants/constants";
import { ErrorMessage, SuccessMessage } from "../../constants/messages";
import { validateOrder } from "../../middlewares/orderEditing.middleware";
import { AppSettings } from "../../models/appSettings.model";
import { flowTrigger } from "../../models/flowTrigger.model";
import { OrderEditingHistory } from "../../models/orderEditingHistory.model";
import { PagePreviewing } from "../../models/pagePreviewing.model";
import { Analytics } from "../../models/analytics.model";
import { removeItem } from "./edit";
import { EmailNotification } from "../../models/emailNotification.model";
import { convertLiquidToHtmlForEmail } from "../../utils/utils";
import { Notifications } from "../../models/notifications.model";
import { reverseOrderFromShopify } from "./holdOrder";
import { notificationDetailsById } from "../notifications";
import { Languages } from "../../models/languages.model";

export const addedNewTag = async (tagName, orderId, admin) => {
  const response = await admin.graphql(`mutation addTags($id: ID!, $tags: [String!]!) {
                    tagsAdd(id: $id, tags: $tags) {
                      node {
                        id
                      }
                      userErrors {
                        message
                      }
                    }
                  }`, {
    variables: {
      "id": `gid://shopify/Order/${orderId}`,
      "tags": tagName
    },
  })

  // Send the request
  const data = await response.json()

  // check query send error
  const error = data?.data?.tagsAdd?.userErrors;
  if (error.length) {
    console.log(`catch from addNewTag Error : ${error[0]?.message}`);
  }

  return true;
}

export const removedTag = async (tagName, orderId, admin) => {
  const response = await admin.graphql(`
    mutation removeTags($id: ID!, $tags: [String!]!) {
      tagsRemove(id: $id, tags: $tags) {
        node {
          id
        }
        userErrors {
          message
        }
      }
    }
  `, {
    variables: {
      id: `gid://shopify/Order/${orderId}`,
      tags: tagName
    },
  });

  const data = await response.json();

  const error = data?.data?.tagsRemove?.userErrors;
  if (error.length) {
    console.log(`catch from removeTag Error : ${error[0]?.message}`);
  }

  return true;
};

// get order calculate id  
export const getOrderCalculateId = async (orderId, admin) => {
  try {
    const response = await admin.graphql(`
      #graphql
      mutation orderEditBegin($id: ID!){
                  orderEditBegin(id: $id){
                      calculatedOrder{
                        id
                        lineItems(
                          first: 250
                        ){
                          edges{
                              node{
                                  id
                                  quantity
                                  variant{
                                    id
                                  }
                              }
                          }
                        }
                      }
                      userErrors {
                        field
                        message
                      }
                    }
                  }`, {
      variables: {
        "id": `gid://shopify/Order/${orderId}`
      },
    })


    const data = await response.json()

    // check query send error
    const error = data?.data?.orderEditBegin?.userErrors;
    if (error?.length) {
      return {
        status: false,
        message: error[0]?.message
      }
    }

    return {
      status: true,
      message: `Order calculate id ${SuccessMessage.FETCHED}`,
      data: data
    };
  } catch (error) {
    console.log("Error in getOrderCalculateId", error);
    return {
      status: false,
      message: error?.message
    }
  }
}

//order edit commit 
export const orderEditCommit = async (details, admin) => { // -updated
  try {

    const response = await admin.graphql(`
    #graphql
    mutation orderEditCommit($id: ID!) {
                    orderEditCommit(id: $id) {
                      order {
                        id
                        displayFulfillmentStatus
                        updatedAt
                        paymentCollectionDetails {
                          additionalPaymentCollectionUrl
                        }
                        totalOutstandingSet {
                          shopMoney {
                            amount
                            currencyCode
                          }
                          presentmentMoney {
                            amount
                            currencyCode
                          }
                        }
                      }
                      userErrors {
                        field
                        message
                      }
                    }
                  }
                `, {
      variables: {
        "id": details.calculatedOrderId,
        "notifyCustomer": details.notifyCustomer,
        "staffNote": details.staffNote
      },
    })
    // Send the request
    const data = await response.json()

    // check query send error
    const error = data?.data?.orderEditCommit?.userErrors;
    if (error?.length) {
      return {
        status: false,
        message: error[0]?.message || ErrorMessage.MUTATION_BADE_REQ
      }
    }

    return {
      status: true,
      message: `Order edit commit success`,
      data: data
    };

  } catch (error) {
    return {
      status: false,
      message: error?.message
    }
  }
}
export const newAndSwapItemsAvailability = async (variantId, quantity, admin) => {
  const response = await admin.graphql(`
    #graphql  
    {
      productVariant(id: "${variantId}") {
      product {
        id
        title
      }
      title
      availableForSale
      inventoryQuantity
      inventoryPolicy
      inventoryItem {
        tracked
      }
  }
}
  `)

  const data = await response.json();
  const variant = data?.data?.productVariant;

  if (!variant?.inventoryItem.tracked) {
    return { status: true, message: "The Item is not tracked" };
  }

  if (variant.inventoryPolicy == 'CONTINUE') {
    return { status: true, message: "Continue for Sale" };
  }

  if (variant.availableForSale && variant.inventoryQuantity >= quantity) {
    return { status: true, message: "Available for Sale" };
  }

  return { status: false, message: `Only ${variant.inventoryQuantity} of ${variant.product.title} can be added to your order.` };
}

export const addOrderItemSingle = async (orderId, details, calculatedOrderId, admin) => {
  try {
    const isAvailable = await newAndSwapItemsAvailability(details.productVariantId, details.quantity, admin);
    if (!isAvailable.status) {
      return {
        status: false,
        message: isAvailable?.message
      }
    }

    const variables = {
      allowDuplicates: true,
      id: calculatedOrderId,
      quantity: details.quantity,
      variantId: details.productVariantId,
    };

    const response = await admin.graphql(
      `#graphql
       mutation orderEditAddVariant($id: ID!, $quantity: Int!, $variantId: ID!) {
                  orderEditAddVariant(id: $id, quantity: $quantity, variantId: $variantId) {
                    calculatedLineItem {
                      id
                      quantity
                      title
                      variant {
                        id
                        price
                      }
                      variantTitle
                      editableSubtotalSet{
                        presentmentMoney{
                          amount
                          currencyCode
                        }
                        shopMoney{
                          amount
                          currencyCode
                        }
                      }
                    }
                    calculatedOrder {
                      id
                    }
                    userErrors {
                      field
                      message
                    }
                  }
                }
              `, {
      variables,
    })

    // Send the request
    const data = await response.json()

    // check query send error
    const error = data?.data?.orderEditAddVariant?.userErrors;
    if (error?.length) {
      return {
        status: false,
        message: error[0]?.message || ErrorMessage.MUTATION_BADE_REQ
      }
    }
    const result = data?.data?.orderEditAddVariant?.calculatedLineItem;
    const productTitle = result.title ? result.title : "";
    const productVariant = result.variantTitle ? result.variantTitle : "";
    const calculatedLineItemId = result?.id;

    // order editing history
    await OrderEditingHistory.create({
      partnerId: details.partnerId,
      orderAction: ORDER_ACTION.ADD_ITEM,
      customerId: details.customerId,
      orderId: orderId,
      amount: data?.data?.orderEditAddVariant?.calculatedLineItem?.editableSubtotalSet?.presentmentMoney?.amount || 0
    })

    return {
      status: true,
      message: `Order item ${productTitle} ${productVariant} ${SuccessMessage.ADDED}`,
      data: { calculatedLineItemId, productVariant, productTitle }
    };
  } catch (error) {
    console.log("Error in addOrderItem:", error);
    return {
      status: false,
      message: error?.message,
    };
  }
}



export const orderDetailsById = async (orderId, admin, session, partnerId, extensionName = null, lang) => {
  try {
    // check time frame details
    const languageDetails = await getLanguage(partnerId, lang)
    const timeExceedDetails = await timeExceed(orderId, partnerId, admin, session)
    if (!timeExceedDetails.status || timeExceedDetails?.data?.customerDisallowEdits) {
      return {
        status: true,
        data: {
          timeExceedDetails: timeExceedDetails.data,
          languageDetails: languageDetails?.data
        }
      }
    }

    const response = await admin.graphql(
      `#graphql
        query MyMutation {
        order(id: "gid://shopify/Order/${orderId}") {
          id
          createdAt
          netPaymentSet {
            presentmentMoney {
              amount
              currencyCode
            }
            shopMoney {
              amount
              currencyCode
            }
          }
          lineItems(first: 100) {
            nodes {
              id
              fulfillmentStatus
              quantity
              currentQuantity
              product {
                tags
              }
            }
          }
          customer {
            id
          }
          paymentCollectionDetails {
            additionalPaymentCollectionUrl
          }
          shippingAddress {
            country
          }
          displayFulfillmentStatus
          statusPageUrl  
          email
          name
          cancelledAt
          presentmentCurrencyCode
          createdAt
          shippingLines(first: 250) {
            nodes {
              id
              title
              originalPriceSet {
                presentmentMoney {
                  amount
                  currencyCode
                }
              }  
            }
          }
          currentShippingPriceSet {
            presentmentMoney {
              amount
              currencyCode
            }
          }
          currentTotalTaxSet {
            presentmentMoney {
              amount
              currencyCode
            }
          },
          totalOutstandingSet {
            presentmentMoney {
              amount
              currencyCode
            }
          }
        }
      }`,
    );
    const data = await response.json()
    const paymentUrl = data?.data?.order?.paymentCollectionDetails?.additionalPaymentCollectionUrl;
    const totalPaidAmount = data?.data?.order?.netPaymentSet?.presentmentMoney?.amount;
    const lineItems = data?.data?.order?.lineItems?.nodes;
    const fulfillmentStatus = data?.data?.order?.displayFulfillmentStatus;
    const statusPageUrl = data?.data?.order?.statusPageUrl;
    const customerEmail = data?.data?.order?.email;
    const customer = data?.data?.order?.customer;
    const orderNumber = data?.data?.order?.name;
    const cancelledAt = data?.data?.order?.cancelledAt;
    const shippingAddress = data?.data?.order?.shippingAddress;
    const currencyCode = data?.data?.order?.presentmentCurrencyCode;
    const shippingLines = data?.data?.order?.shippingLines?.nodes;
    const createdAt = data?.data?.order?.createdAt;
    const shippingPriceSet = data?.data?.order?.currentShippingPriceSet?.presentmentMoney;
    const totalTaxSet = data?.data?.order?.currentTotalTaxSet?.presentmentMoney;
    const totalOutstanding = data?.data?.order?.totalOutstandingSet?.presentmentMoney;

    await PagePreviewing.updateOne({ partnerId },
      {
        thankyouPage: {
          name: "Thankyou Page",
          isAdded: true,
        },
        orderStatusPage: {
          name: "Order Status Page",
          isAdded: true,
        },
      });
    if (extensionName) {
      addExtensionNames(partnerId, extensionName);
    }

    return {
      status: true,
      data: { shippingLines, createdAt, shippingPriceSet, totalTaxSet, paymentUrl, totalPaidAmount, lineItems, fulfillmentStatus, cancelledAt, statusPageUrl, shippingAddress, orderNumber, customerEmail, customer, currencyCode, totalOutstanding, timeExceedDetails: timeExceedDetails.data, languageDetails: languageDetails?.data }
    }
  } catch (error) {
    console.log("Error in orderDetailsById:", error);
    return {
      status: false,
      message: `Order details ${ErrorMessage.NOT_FOUND}`
    }
  }
}

export const timeExceed = async (orderId, partnerId, admin, session) => {
  try {
    // check time exceed
    const timeExist = await includeTags(orderId, partnerId, admin);
    if (!timeExist?.status) {
      return {
        status: false,
        message: timeExist?.message || 'Order cannot be edited',
        data: {
          "disableEmailEditing": true,
          "disablePhoneNumberEditing": true,
          "disableShippingAddress": true,
          "disableItemQuantityChanges": true,
          "disableProductSwaps": true,
          "disableOrderCancellations": true,
          "disableAddingNewItems": true,
          "disableRemovingItems": true,
          "customerDisallowEdits": true
        }
      };
    }

    const orderTriggers = await flowTrigger.find({
      "payload.properties.order_id": `gid://shopify/Order/${orderId}`,
    });

    // Creates an object with trigger handle keys with default values false
    let enableKeys = Object.keys(TRIGGER_HANDLES).reduce((acc, key) => {
      acc[toCamelCase(TRIGGER_HANDLES[key])] = false;
      return acc;
    }, {});

    if (orderTriggers?.length) {
      const isDisallowEdit = orderTriggers.find(
        (order) => order.payload.handle === TRIGGER_HANDLES.DISALLOW_CUSTOMER_EDIT
      );
      if (isDisallowEdit) {
        enableKeys = {
          ...enableKeys,
          [toCamelCase(TRIGGER_HANDLES.DISALLOW_CUSTOMER_EDIT)]: true,
        };
      } else {
        for (let order of orderTriggers) {
          enableKeys[toCamelCase(order.payload.handle)] = true;
        }
      }

      return {
        status: true,
        message: SuccessMessage.FETCHED,
        data: enableKeys,
      };
    } else {
      const validatingOrder = await validateOrder(orderId, partnerId, admin, session);
      if (!validatingOrder.status) {
        enableKeys = {
          ...enableKeys,
          [toCamelCase(TRIGGER_HANDLES.DISALLOW_CUSTOMER_EDIT)]: true,
        };
      }
      return {
        status: true,
        message: SuccessMessage.FETCHED,
        data: enableKeys,
      };
    }
  } catch (error) {
    console.log("Error in checkTimeExist:", error);
    return {
      status: false,
      message: error?.message || ErrorMessage.INTERNAL_SERVER_ERROR,
    };
  }

}

const includeTags = async (orderId, partnerId, admin) => {
  let orderDetails = await admin.graphql(
    `#graphql
      query {
        order(id: "gid://shopify/Order/${orderId}") {
        id
        tags
        name
      }
    }`,
  );
  orderDetails = await orderDetails.json()

  const orderTags = orderDetails?.data?.order?.tags?.map(tag => tag.toLowerCase()) || [];
  const partnerDetails = await AppSettings.findOne({ partnerId })
  const tagsToCheck = partnerDetails?.orderTags?.map(tag => tag.toLowerCase()) || [];

  const hasMatchingTag = tagsToCheck.some(tag => orderTags.includes(tag));

  if (!hasMatchingTag) {
    return {
      status: true,
      message: 'Order can be edited',
    };
  }
  return {
    status: false,
    message: 'Order cannot be edited',
  };
}



const toCamelCase = (str) =>
  str.replace(/-([a-z])/g, (match, char) => char.toUpperCase());



export const orderAdmin = async (orderId, admin) => {
  try {
    const response = await admin.graphql(`
          #graphql
          query orderDetails($id: ID!) {
          order(id: $id) {
            id
            displayFulfillmentStatus
            confirmationNumber
            createdAt
            updatedAt
            cancelledAt
            discountApplications(first: 250) {
              nodes {
                __typename
                allocationMethod
                targetSelection
                targetType
                ... on DiscountCodeApplication {
                  code
                }
                ... on AutomaticDiscountApplication {
                  title
                }
                ... on ManualDiscountApplication {
                  title
                }
                ... on ScriptDiscountApplication {
                  title
                }
                value {
                  ... on MoneyV2 {
                    amount
                  }
                  ... on PricingPercentageValue {
                    percentage
                  }
                }
              }
            }
            totalOutstandingSet {
              presentmentMoney {
                amount
                currencyCode
              }
            }
            currentTotalPriceSet {
              presentmentMoney {
                amount
                currencyCode
              }
            }
            currentSubtotalPriceSet {
              presentmentMoney {
                amount
                currencyCode
              }
            }
            totalTaxSet {
              presentmentMoney {
                amount
                currencyCode
              }
            }
            totalReceivedSet {
              presentmentMoney {
                amount
                currencyCode
              }
            }
            totalRefundedSet {
              presentmentMoney {
                amount
                currencyCode
              }
            }
            customer {
              id
              firstName
              lastName
              email
            }
            lineItems(first: 250) {
              nodes {
                id
                name
                quantity
                image {
                  url
                }
                totalDiscountSet {
                  presentmentMoney {
                    amount
                    currencyCode
                  }
                }
                name
                quantity
                sku
                title
                currentQuantity
                discountAllocations {
                  allocatedAmount {
                    amount
                  }
                  discountApplication {
                    __typename
                    targetSelection
                          value {
                      ... on MoneyV2 {
                        __typename
                        amount
                        currencyCode
                      }
                      ... on PricingPercentageValue {
                        __typename
                        percentage
                      }
                    }
                    targetType
                    ... on DiscountCodeApplication {
                      code
                    }
                    ... on AutomaticDiscountApplication {
                      title
                    }
                  }
                }
                originalUnitPriceSet {
                  presentmentMoney {
                    amount
                    currencyCode
                  }
                }
                discountedUnitPriceSet {
                  presentmentMoney {
                    amount
                    currencyCode
                  }
                }
                discountedTotalSet(withCodeDiscounts: true) {
                  presentmentMoney {
                    amount
                    currencyCode
                  }
                }
                variant {
                  image {
                    url
                  }
                  id
                  sku
                  price
                  title
                }
              }
            }
            shippingLines(first: 250) {
              edges {
                node {
                  id
                  title
                  originalPriceSet {
                    presentmentMoney {
                      amount
                      currencyCode
                    }
                  }
                }
              }
            }
            paymentGatewayNames
            shippingAddress {
              address1
              address2
              city
              company
              coordinatesValidated
              country
              countryCodeV2
              firstName
              lastName
              name
              phone
              province
              provinceCode
              zip
            }
            totalDiscountsSet {
              presentmentMoney {
                amount
                currencyCode
              }
            }
            totalPriceSet {
              presentmentMoney {
                amount
                currencyCode
              }
            }
            name
            totalShippingPriceSet {
              presentmentMoney {
                amount
                currencyCode
              }
              shopMoney {
                amount
                currencyCode
              }
            }
          }
        }`, {
      variables: {
        "id": `gid://shopify/Order/${orderId}`,
      },
    })

    const data = await response.json();
    return data?.data?.order;
  } catch (error) {
    console.log('Catch error in orderAdmin :', error);
    return null
  }
}

export const orderAdminRevers = async (orderId, admin) => {
  try {
    const response = await admin.graphql(`
          #graphql
          query orderDetails($id: ID!) {
          order(id: $id) {
            id
            displayFulfillmentStatus
            discountCodes
            discountApplications(first: 250) {
              nodes {
                __typename
                allocationMethod
                targetSelection
                targetType
                ... on DiscountCodeApplication {
                  code
                }
                ... on AutomaticDiscountApplication {
                  title
                }
                ... on ManualDiscountApplication {
                  title
                }
                ... on ScriptDiscountApplication {
                  title
                }
                value {
                  ... on MoneyV2 {
                    amount
                  }
                  ... on PricingPercentageValue {
                    percentage
                  }
                }
              }
            }
            currentTotalPriceSet {
              presentmentMoney {
                amount
                currencyCode
              }
            }
            customer {
              id
            }
            lineItems(first: 250) {
              nodes {
                id
                name
                quantity
                image {
                  url
                }
                totalDiscountSet {
                  presentmentMoney {
                    amount
                    currencyCode
                  }
                }
                name
                quantity
                sku
                title
                variant{
                    id
                }
                currentQuantity
                discountAllocations {
                  allocatedAmount {
                    amount
                  }
                  discountApplication {
                    __typename
                    targetSelection
                          value {
                      ... on MoneyV2 {
                        __typename
                        amount
                        currencyCode
                      }
                      ... on PricingPercentageValue {
                        __typename
                        percentage
                      }
                    }
                    targetType
                    ... on DiscountCodeApplication {
                      code
                    }
                    ... on AutomaticDiscountApplication {
                      title
                    }
                    ... on ManualDiscountApplication {
                      title
                      description
                    }
                  }
                }
                originalUnitPriceSet {
                  presentmentMoney {
                    amount
                    currencyCode
                  }
                }
                discountedUnitPriceSet {
                  presentmentMoney {
                    amount
                    currencyCode
                  }
                }
                discountedTotalSet(withCodeDiscounts: true) {
                  presentmentMoney {
                    amount
                    currencyCode
                  }
                }
                variant {
                  image {
                    url
                  }
                  id
                  sku
                  price
                  title
                }
              }
            }
            shippingLines(first: 250) {
              edges {
                node {
                  id
                  title
                  originalPriceSet {
                    presentmentMoney {
                      amount
                      currencyCode
                    }
                  }
                }
              }
            }
            shippingAddress {
              address1
              address2
              city
              company
              coordinatesValidated
              country
              countryCodeV2
              firstName
              lastName
              name
              phone
              province
              provinceCode
              zip
            }
          }
        }`, {
      variables: {
        "id": `gid://shopify/Order/${orderId}`,
      },
    })

    const data = await response.json();
    return data?.data?.order;
  } catch (error) {
    console.log('Catch error in orderAdminRevers :', error);
    return null
  }
}

export const addExtensionNames = async (partnerId, newExtension) => {
  try {
    await Analytics.findOneAndUpdate(
      { partnerId },
      { $addToSet: { extensions: newExtension } },
      { upsert: true, new: true }
    );

    return {
      status: true,
      message: "Extension added successfully",
    };
  } catch (error) {
    console.error("Error in addExtensionNames:", error);
    return {
      status: false,
      message: "Error adding extension",
    };
  }
};


export const getLatestOrderId = async (admin) => {
  const response = await admin.graphql(`
                              #graphql
                                query {
                                  orders(reverse: true, first:1) {
                                    
                                    pageInfo {
                                      hasNextPage
                                    }
                                    edges {
                                    node{
                                      id
                                    }
                                      cursor
                                    }
                                  }
                                }
                              `,
  )

  const data = await response.json();
  const orderId = data?.data?.orders?.edges[0]?.node?.id;
  return {
    status: true,
    data: orderId
  };
}

export const setPaymentPendingEmail = async (partnerId, orderDetails, orderId) => {
  try {
    //get partner settings for intervals
    let paymentPendingSettings = await Notifications.findOne({ partnerId }).lean();
    const isPaymentPendingOn = paymentPendingSettings?.paymentPending?.status
    const intervalList = paymentPendingSettings?.paymentPending?.times
    console.log("isPaymentPendingOn : ", isPaymentPendingOn)
    if (!isPaymentPendingOn) return
    if (!intervalList?.length) return
    console.log("intervalLists : ", intervalList)
    const senderEmail = paymentPendingSettings?.customerSenderEmail || process.env.SMTP_USER_EMAIL;
    for (let index in intervalList) {
      let timeInMs
      if (index == 0) {
        timeInMs = await timeStringToMs(intervalList[index])
        console.log("In Index 0 timeInMs", timeInMs);

      }
      else if (index == 1) {
        const timeInMs1 = await timeStringToMs(intervalList[index - 1])
        const timeInMs2 = await timeStringToMs(intervalList[index])
        timeInMs = timeInMs1 + timeInMs2
        console.log("In Index 1 timeInMs", timeInMs);
      }
      else if (index == 2) {
        const timeInMs1 = await timeStringToMs(intervalList[index - 2])
        const timeInMs2 = await timeStringToMs(intervalList[index - 1])
        const timeInMs3 = await timeStringToMs(intervalList[index])
        timeInMs = timeInMs1 + timeInMs2 + timeInMs3
        console.log("In Index 2 timeInMs", timeInMs);

      }
      console.log("timeInMs : ", timeInMs)
      if (!timeInMs) continue
      console.log("creating a document");
      await EmailNotification.create({
        partnerId: partnerId,
        orderId: orderId,
        isPaymentPending: true,
        customerData: {
          receiverEmail: orderDetails?.customer?.email,
          senderEmail: senderEmail,
          replyToEmail: senderEmail,
        },
        dueDate: new Date(Date.now() + timeInMs)
      });
    }

  } catch (error) {
    console.log("Error in setPaymentPendingEmail : ", error);
    return;
  }
}
export const setNotifyCustomerEmail = async (partnerId, orderDetails, orderId) => {

  try {
    //get partner settings for intervals
    let notifyCustomerSettings = await Notifications.findOne({ partnerId }).lean();
    const isTimeFrameEmailOn = notifyCustomerSettings?.orderEditsTimeFrame?.status
    const intervalList = notifyCustomerSettings?.orderEditsTimeFrame?.times
    console.log("isNotifyCustomerOn : ", isTimeFrameEmailOn)
    if (!isTimeFrameEmailOn) return
    if (!intervalList?.length) return
    console.log("intervalLists : ", intervalList)
    const senderEmail = notifyCustomerSettings?.customerSenderEmail || process.env.SMTP_USER_EMAIL;
    for (let index in intervalList) {
      let timeInMs
      if (index == 0) {
        timeInMs = await timeStringToMs(intervalList[index])
        console.log("In Index 0 timeInMs", timeInMs);
      }
      else if (index == 1) {
        const timeInMs1 = await timeStringToMs(intervalList[index - 1])
        const timeInMs2 = await timeStringToMs(intervalList[index])
        timeInMs = timeInMs1 + timeInMs2
        console.log("In Index 1 timeInMs", timeInMs);
      }
      else if (index == 2) {
        const timeInMs1 = await timeStringToMs(intervalList[index - 2])
        const timeInMs2 = await timeStringToMs(intervalList[index - 1])
        const timeInMs3 = await timeStringToMs(intervalList[index])
        timeInMs = timeInMs1 + timeInMs2 + timeInMs3
        console.log("In Index 2 timeInMs", timeInMs);

      }
      console.log("timeInMs : ", timeInMs)
      if (!timeInMs) continue
      console.log("creating a document");
      await EmailNotification.create({
        partnerId: partnerId,
        orderId: orderId,
        isOrderEditsTimeFrame: true,
        customerData: {
          receiverEmail: orderDetails?.customer?.email,
          senderEmail: senderEmail,
          replyToEmail: senderEmail,
        },
        dueDate: new Date(Date.now() + timeInMs)
      });
    }
  } catch (error) {
    console.log("Error in setNotifyCustomerEmail : ", error);
    return;
  }

}

export const timeStringToMs = async (timeString) => {
  try {
    console.log("time string is ", timeString)
    let totalMilliseconds
    // Define time units and their millisecond equivalents
    const timeUnits = {
      minutes: 60000,
      hours: 3600000,
      days: 86400000,
      week: 7 * 86400000,
      month: 30 * 86400000, // Special case for months
    };

    // Calculate the threshold date based on timeString
    for (const [unit, multiplier] of Object.entries(timeUnits)) {
      if (timeString.includes(unit)) {
        const value = parseInt(timeString.split(unit)[0], 10);
        totalMilliseconds = value * multiplier;
        console.log("time string to ms is ", totalMilliseconds);
        break;
      }
    }
    return totalMilliseconds;
    // Handle invalid or missing threshold date
  } catch (err) {
    console.log(err);
    return false
  }
};


export const isHoldEnable = async (partnerId) => {
  const appSettings = await AppSettings.findOne({ partnerId }).lean();
  return appSettings?.orderHolds?.isOn
}

export const isOrderChangesRevertEnable = async (partnerId) => {
  const appSettings = await AppSettings.findOne({ partnerId }).lean();
  return appSettings?.orderChangesRevert?.isOn
}

//Flow trigger
export const flowTriggers = async (orderId, trigger, admin) => {
  try {
    const query = `
        mutation FlowTriggerReceive($payload: JSON!) {
          flowTriggerReceive(
            handle: "${trigger}",
            payload: $payload
          ) {
            userErrors {
              field
              message
            }
          }
        }
      `;
    const variables = {
      payload: {
        order_id: Number(orderId)
      },
    };

    const flowResponse = await admin.graphql(query, { variables });
    const datas = await flowResponse.json();
    console.log("Flow Trigger Response:", datas.data.flowTriggerReceive);

  } catch (error) {
    console.log(error);
  }
}


export const getLanguage = async (partnerId, lang) => {
  try {
    const languageData = await Languages.find({
      lang: lang,
      $or: [
        { isDefault: true },
        { partnerId: partnerId }
      ]
    });

    let defaultLangJson = {};
    let partnerLangJson = null;

    for (const lang of languageData) {
      if (lang.isDefault) {
        defaultLangJson = lang.langJson || {};
      } else if (lang.partnerId?.toString() === partnerId.toString()) {
        partnerLangJson = lang.langJson || {};
      }
    }

    let languageDetails = {};
    if (partnerLangJson) {
      languageDetails = { ...defaultLangJson, ...partnerLangJson };
    } else {
      languageDetails = { ...defaultLangJson };
    }
    return {
      status: true,
      message: `Language Json ${SuccessMessage.FETCHED}`,
      data: languageDetails
    }
  } catch (error) {
    return {
      status: false,
      message: error?.message || "Error in getLanguage",

    }
  }
}

export const getMessage = async (lang, partnerId, key) => {
  console.log("lang : ", lang, "key : ", key, "partnerId : ", partnerId);
  const languageData = await getLanguage(partnerId, lang);
  const json = languageData?.data;
  return json?.[key];
}