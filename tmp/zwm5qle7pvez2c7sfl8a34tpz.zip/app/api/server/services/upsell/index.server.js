// models
import { UpSells } from "../../models/upSell.model.js";

// Response handlers
import { SuccessMessage, ErrorMessage } from "../../constants/messages.js";
import { checkSegmentInUpSell } from "../segments1/index.server.js"
import { checkCollectionsInUpSell } from "../collections/index.server.js";
import { UP_SELL_CONDITION_TYPE, UP_SELL_MATCH } from "../../constants/constants.js";
import { PagePreviewing } from "../../models/pagePreviewing.model.js";
export const upSellCreate = async (details) => {
    // check current partner have same up-sell already exist
    const upSellExist = await getUpSellByName(details.name, details.partnerId);
    if (upSellExist) {
        return {
            status: false,
            message: `Upsell name already exists.`
        };
    }

    const data = await UpSells.create(details);
    return {
        status: true,
        message: `UpSell ${SuccessMessage.CREATED}`,
        data: data
    };
};

// get up-sell details by name 
export const getUpSellByName = async (name, partnerId) => {
    const data = await UpSells.findOne({ name, partnerId });
    return data;
}

// get list of up-sell current partner
export const upSellList = async (params, partnerId) => {
    const { offset, limit, query, shortBy } = params;
    const currentPage = offset;
    const skip = currentPage * limit;

    // Build filter object
    let filter = { partnerId };
    if (query) {
        filter.name = { $regex: query, $options: 'i' }; // Case-insensitive search on 'name' field
    }

    // Determine sorting order
    let sortOrder = shortBy === 'ASE' ? 1 : -1;

    // Fetch data with filters and sorting
    const data = await UpSells.find(filter)
        .skip(skip)
        .limit(limit)
        .sort({ isActive: -1, createdAt: sortOrder });

    const totalCountItems = await UpSells.countDocuments({ partnerId });
    const totalCount = await UpSells.countDocuments(filter);
    const active = await UpSells.findOne({ partnerId, isActive: true }).select('_id');
    const numberOfPages = Math.ceil(totalCount / limit) - 1;

    return {
        status: true,
        message: `UpSell ${SuccessMessage.LIST_FETCHED}`,
        data: { data, totalCountItems, totalCount, currentPage, numberOfPages, activeId: active?._id }
    };
}

// get up-sell by id
export const upSellById = async (id) => {
    const data = await UpSells.findById(id);
    if (!data) {
        return {
            status: false,
            message: `UpSell ${ErrorMessage.NOT_FOUND}`
        };
    }
    return {
        status: true,
        message: `UpSell ${SuccessMessage.FETCHED}`,
        data: data
    };
}

// delete up-sell by id
export const upSellDeleteById = async (_id, partnerId) => {
    const data = await UpSells.findOneAndDelete({ _id, partnerId });
    if (!data) {
        return {
            status: false,
            message: `UpSell ${ErrorMessage.NOT_FOUND}`
        };
    }
    return {
        status: true,
        message: `UpSell ${SuccessMessage.DELETED}`,
        data: data
    };
}

// update up-sell by id
export const upSellUpdate = async (_id, details) => {
    const data = await UpSells.findOneAndUpdate({ _id }, details, { upsert: true, new: true });
    if (!data) {
        return {
            status: false,
            message: `UpSell ${ErrorMessage.NOT_FOUND}`
        };
    }
    return {
        status: true,
        message: `UpSell ${SuccessMessage.UPDATED}`,
        data: data
    };
}

// update up-sell by id
export const upSellActive = async (upSellId, type) => {
    if (type === 'active') {
        //if type is active then update all other up-sells to active=false
        await UpSells.updateOne(
            { _id: upSellId },
            { isActive: true }
        );
        await UpSells.updateMany(
            { _id: { $ne: upSellId } },
            { isActive: false }
        );
    }
    if (type === 'deactive') {
        //if type is deactive then update current up-sell to active=false
        await UpSells.updateOne(
            { _id: upSellId },
            { isActive: false }
        );
    }

    return {
        status: true,
        message: `UpSell ${SuccessMessage.UPDATED}`,
        data: true
    };
}


export const upSellDescription = async (partnerId, details, admin) => {

    console.log('upSellDescription-----------------------------------api');
    

    // get current partner active up-sells rules 
    const upSellDetails = await getActiveUpSellDetails(partnerId);
    if (!upSellDetails) {
        return {
            status: false,
            message: `Active up-sell ${ErrorMessage.NOT_FOUND}`
        }
    }

    const conditionStatus = [];
    for (const condition of upSellDetails.condition) {
        // check if in condition type segment
        if (condition.type === UP_SELL_CONDITION_TYPE.SEGMENT) {
            const status = await checkSegmentInUpSell(condition.id, details.customerId, admin);
            conditionStatus.push(status)
        }
        // check if in condition type cart value
        if (condition.type === UP_SELL_CONDITION_TYPE.CART_VALUE) {
            const sign = condition.sign;
            const cartValue = Number(details.cartValue);
            const conditionValue = Number(condition.id);
            const operators = {
                '<=': (a, b) => a <= b,
                '<': (a, b) => a < b,
                '>=': (a, b) => a >= b,
                '>': (a, b) => a > b,
                '!=': (a, b) => a !== b,
                '=': (a, b) => a === b,
            };

            const status = operators[sign] ? operators[sign](conditionValue, cartValue) : false;
            conditionStatus.push(status)
        }
        // check if in condition type collection
        if (condition.type === UP_SELL_CONDITION_TYPE.COLLECTION) {
            const status = await checkCollectionsInUpSell(condition.id, details.variants, admin);
            conditionStatus.push(status)
        }
    }

    console.log("Up-Sell conditions status :", conditionStatus);

    let isProductVariant = false;
    // check up-sell have all or any 
    if (upSellDetails.productMustMatch == UP_SELL_MATCH.ALL) {
        isProductVariant = conditionStatus.every(value => value === true);
    } else {
        isProductVariant = conditionStatus.some(value => value === true);
    }

    console.log("Up-Sell products variants status :", isProductVariant)

    if (!isProductVariant) {
        return {
            status: false,
            message: `${ErrorMessage.ORDER_NOT_ABLE_UP_SELL}`
        }
    }

    await PagePreviewing.updateOne({ partnerId: partnerId }, { 'upSellOrderStatus.isAdded': true });

    return {
        status: true,
        message: `Up-Sell variants ${SuccessMessage.FETCHED}`,
        data: {
            discount: upSellDetails.discount,
            selectView: upSellDetails.selectView,
            productIds: upSellDetails,
        }
    }
}
// get active upsell details from db
export const getActiveUpSellDetails = async (partnerId) => {
    const data = await UpSells.findOne({ partnerId: partnerId, isActive: true });
    return data;
}