import { sendResponse } from "../server/utils/sendResponse";
import { ErrorMessage, SuccessMessage } from "../server/constants/messages";
import { statusCode } from "../server/constants/statusCodes";
import * as upSellService from "../server/services/upsell/index.server";
import { authenticateUser } from "../server/middlewares/auth.middleware.server";
import * as authValidation from "../server/validations/auth.validation";
import * as upSellValidation from "../server/validations/upSell.validation";

// Loader function for GET requests.
export const loader = async ({ request, params }) => {
    const path = params["*"];
    // Switch cases according to the path
    switch (path) {
        case "details":
            {
                try {
                     console.log(`::--- ${new URL(request.url).pathname}?shop=${new URL(request.url).searchParams.get("shop")} ---::`);
                    const url = new URL(request.url);
                    const id = url.searchParams.get("id");  // Get ID from query params

                    if (!id) {
                        return sendResponse(statusCode.BAD_REQUEST, false, "ID is required");
                    }
                    // Call service to get up-sell by id
                    const result = await upSellService.upSellById(id)

                    // Handle service response 
                    if (!result.status) {
                        return sendResponse(statusCode.BAD_REQUEST, false, result?.message);
                    }
                    return sendResponse(statusCode.OK, true, result?.message, result.data);
                } catch (error) {
                    console.error("Error in upSellById:", error);
                    return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
                }
            }
        default:
            return new Response(JSON.stringify({ error: ErrorMessage.INVALID_API_PATH }), {
                status: statusCode.NOT_FOUND,
            });
    }
};

// Action function for handling POST , PUT and DELETE requests.
export const action = async ({ request, params }) => {
    const method = request.method;
    const path = params["*"];
    // Handle PUT requests
    if (method === "PUT") {
        // Switch cases according to the path
        switch (path) {
            case "active":
                {
                    try {
                        // Middleware to authenticate user 
                        const isAuthenticated = await authenticateUser(request);
                        console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
                        // Return if request is not authenticated
                        if (!isAuthenticated.status) {
                            return sendResponse(statusCode.BAD_REQUEST, false, isAuthenticated.message);
                        }
                        const url = new URL(request.url);
                        const id = url.searchParams.get("id");  // Get ID from query params

                        if (!id) {
                            return sendResponse(statusCode.BAD_REQUEST, false, "ID is required");
                        }
                        const details = await request.json()
                        // Validation
                        const isValidated = await upSellValidation.active(details)
                        if (isValidated.status === false) {
                            return sendResponse(statusCode.BAD_REQUEST, false, isValidated.message);
                        }
                        // Call service to update upsell active status
                        const result = await upSellService.upSellActive(id, details.type)

                        // Handle service response
                        if (!result.status) {
                            return sendResponse(statusCode.BAD_REQUEST, false, result?.message);
                        }
                        return sendResponse(statusCode.OK, true, result?.message, result.data);
                    } catch (error) {
                        console.error("Error in upSellActive:", error);
                        return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
                    }
                }

            case "update": {
                try {
                    // Middleware to authenticate user 
                    const isAuthenticated = await authenticateUser(request);
                    console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
                    // Return if request is not authenticated
                    if (!isAuthenticated.status) {
                        return sendResponse(statusCode.BAD_REQUEST, false, isAuthenticated.message);
                    }
                    const url = new URL(request.url);
                    const id = url.searchParams.get("id");  // Get ID from query params

                    if (!id) {
                        return sendResponse(statusCode.BAD_REQUEST, false, "ID is required");
                    }
                    const details = await request.json()
                    // Validation
                    const isValidated = await upSellValidation.update(details)
                    if (isValidated.status === false) {
                        return sendResponse(statusCode.BAD_REQUEST, false, isValidated.message);
                    }
                    // Call service to update upsell
                    const result = await upSellService.upSellUpdate(id, details)
                    // Handle service response
                    if (!result.status) {
                        return sendResponse(statusCode.BAD_REQUEST, false, result?.message);
                    }
                    return sendResponse(statusCode.OK, true, result?.message, result.data);
                } catch (error) {
                    console.error("Error in upSellUpdate:", error);
                    return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
                }
            }
            default:
                return new Response(JSON.stringify({ error: ErrorMessage.INVALID_API_PATH }), {
                    status: statusCode.NOT_FOUND,
                });
        }

    }
    // Handle POST requests
    if (method === "POST") {
        switch (path) {
            case "create": {
                try {
                    // Middleware to authenticate user 
                    const isAuthenticated = await authenticateUser(request);
                    console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
                    if (!isAuthenticated.status) {
                        return sendResponse(statusCode.BAD_REQUEST, false, isAuthenticated.message);
                    }
                    const details = await request.json();
                    // Validation
                    const isValidated = await upSellValidation.create(details)
                    if (isValidated.status === false) {
                        return sendResponse(statusCode.BAD_REQUEST, false, isValidated.message);
                    }
                    details.partnerId = request.currentPartnerInfo?._id;
                    // Call service to create upsell
                    const result = await upSellService.upSellCreate(details)

                    // Handle service response
                    if (!result.status) {
                        return sendResponse(statusCode.BAD_REQUEST, false, result?.message);
                    }
                    return sendResponse(statusCode.OK, true, result?.message, result.data);
                } catch (error) {
                    console.error("Error in upSellCreate:", error);
                    return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
                }
            }
            case "list": {
                try {
                    // Middleware to authenticate user 
                    const isAuthenticated = await authenticateUser(request);
                    console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
                    // Return if request is not authenticated
                    if (!isAuthenticated.status) {
                        return sendResponse(statusCode.BAD_REQUEST, false, isAuthenticated.message);
                    }
                    // Call service to create partner
                    const params = await request.json();
                    // Validation
                    const isValidated = await authValidation.list(params)
                    if (isValidated.status === false) {
                        return sendResponse(statusCode.BAD_REQUEST, false, isValidated.message);
                    }
                    const partnerId = request.currentPartnerInfo?._id;
                    // Call service to get upsell list
                    const result = await upSellService.upSellList(params, partnerId)

                    // Handle service response
                    if (!result.status) {
                        return sendResponse(statusCode.BAD_REQUEST, false, result?.message);
                    }
                    return sendResponse(statusCode.OK, true, result?.message, result.data);
                } catch (error) {
                    console.error("Error in upSellList:", error);
                    return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
                }
            }
            default:
                return new Response(JSON.stringify({ error: ErrorMessage.INVALID_API_PATH }), {
                    status: statusCode.NOT_FOUND,
                });
        }
    }
    // Handle DELETE requests
    if (method === "DELETE") {
        switch (path) {
            case "delete": {
                try {
                    // Middleware to authenticate user 
                    const isAuthenticated = await authenticateUser(request);
                    console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
                    // Return if request is not authenticated
                    if (!isAuthenticated.status) {
                        return sendResponse(statusCode.BAD_REQUEST, false, isAuthenticated.message);
                    }
                    const url = new URL(request.url);
                    const id = url.searchParams.get("id");  // Get ID from query params

                    if (!id) {
                        return sendResponse(statusCode.BAD_REQUEST, false, "ID is required");
                    }
                    const partnerId = request.currentPartnerInfo._id;
                    // Call service to delete upsell bu id
                    const result = await upSellService.upSellDeleteById(id, partnerId)

                    // Handle service response
                    if (!result.status) {
                        return sendResponse(statusCode.BAD_REQUEST, false, result?.message);
                    }
                    return sendResponse(statusCode.OK, true, result?.message, result.data);
                } catch (error) {
                    console.error("Error in upSellDeleteById:", error);
                    return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
                }
            }
            default:
                return new Response(JSON.stringify({ error: ErrorMessage.INVALID_API_PATH }), {
                    status: statusCode.NOT_FOUND,
                });
        }
    }
    return sendResponse(statusCode.NOT_FOUND, false, ErrorMessage.NOT_FOUND);
};
