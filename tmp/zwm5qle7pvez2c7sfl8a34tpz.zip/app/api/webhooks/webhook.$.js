import { sendResponse } from "../server/utils/sendResponse";
import { ErrorMessage, SuccessMessage } from "../server/constants/messages";
import { statusCode } from "../server/constants/statusCodes";
import * as externalService from "../server/services/externalWebhooks/index.server";

// Loader function for GET requests.
export const loader = async ({ request, params }) => {
    return sendResponse(statusCode.OK, true, "success")
};
// Action function for handling POST , PUT and DELETE requests.
export const action = async ({ request, params }) => {
    const method = request.method;
    const path = params["*"];
    // Handle POST requests
    if (method === "POST") {
        // Switch cases according to the path
        switch (path) {
            case "flow":
                {
                    console.log(`::--- ${new URL(request.url).pathname}?shop=${new URL(request.url).searchParams.get("shop")} ---::`);
                    try {
                        const payload = await request.json();
                        // Call service to create flow trigger payload 
                        const result = await externalService.FlowTrigger(payload);
                        // Handle service response
                        if (!result.status) {
                            return sendResponse(statusCode.BAD_REQUEST, false, result?.message);
                        }
                        return sendResponse(statusCode.OK, true, SuccessMessage.CREATED, result?.data);
                    } catch (error) {
                        console.error("Error in flow-trigger api:", error);
                        return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
                    }
                }

            case "web-vitals-matrics":
                {
                    console.log(`::--- ${new URL(request.url).pathname}?shop=${new URL(request.url).searchParams.get("shop")} ---::`);
                    try {
                        const payload = await request.json();
                        // Call service to create web vitals payload 
                        const result = await externalService.webVitals(payload);
                        // Handle service response
                        if (!result.status) {
                            return sendResponse(statusCode.BAD_REQUEST, false, result?.message);
                        }
                        return sendResponse(statusCode.CREATED, true, SuccessMessage.CREATED, result?.data);
                    } catch (error) {
                        console.error("Error in webVitalsMatrics api:", error);
                        return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
                    }
                }
            case "order-hold-release":
                {
                    console.log(`::--- ${new URL(request.url).pathname}?shop=${new URL(request.url).searchParams.get("shop")} ---::`);
                    try {
                        const payload = await request.json();
                        // call service
                        const result=await externalService.orderHoldRelease(payload)

                        // Handle service response
                        if (!result.status) {
                            return sendResponse(statusCode.BAD_REQUEST, false, result?.message);
                        }
                        return sendResponse(statusCode.OK, true, SuccessMessage.REMOVE, result?.data);
                    } catch (error) {
                        console.error("Error in orderHoldRelease api:", error);
                        return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
                    }
                }
            default:
                return new Response(JSON.stringify({ error: ErrorMessage.INVALID_API_PATH }), {
                    status: statusCode.NOT_FOUND,
                });
        }

    }

    return sendResponse(statusCode.NOT_FOUND, false, ErrorMessage.NOT_FOUND);
};
