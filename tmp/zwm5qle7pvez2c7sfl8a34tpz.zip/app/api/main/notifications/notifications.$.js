import { sendResponse } from "../../server/utils/sendResponse";
import { ErrorMessage, SuccessMessage } from "../../server/constants/messages";
import { statusCode } from "../../server/constants/statusCodes";
import { authenticateUser } from "../../server/middlewares/auth.middleware.server";
import * as notificationsService from "../../server/services/notifications";
import * as notificationsValidation from "../../server/validations/notification.validation";
import { getLatestOrderId } from "../../server/services/order/utils";

//Loader function for GET requests.
export const loader = async ({ request, params }) => {
    // Get path from params object 
    const path = params["*"];
    // Switch cases according to the path
    switch (path) {
        case "details":
            {
                try {
                    // Middleware to authenticate user 
                    const isAuthenticated = await authenticateUser(request);
                    console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
                    // Return if request is not authenticated
                    if (!isAuthenticated.status) {
                        return sendResponse(statusCode.BAD_REQUEST, false, isAuthenticated.message);
                    }

                    const partnerId = request.currentPartnerInfo?._id;
                    // Call service to get result from partneId
                    const result = await notificationsService.notification(partnerId);
                    // Handle service response
                    return sendResponse(statusCode.OK, result.status, result?.message, result.data);
                } catch (error) {
                    console.error("Error in notification details:", error);
                    return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
                }
            }
        default:
            return new Response(JSON.stringify({ error: ErrorMessage.INVALID_API_PATH }), {
                status: statusCode.NOT_FOUND,
            });
    }
};

//Action function for handling POST , PUT and DELETE requests.
export const action = async ({ request, params }) => {

    const method = request.method;
    // Get path from params object 
    const path = params["*"];
    // Switch cases according to the path
    if (method === "POST") {
        switch (path) {
            case "template-details":
                {
                    try {

                        // Middleware to authenticate user 
                        const isAuthenticated = await authenticateUser(request);
                        console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
                        // Return if request is not authenticated
                        if (!isAuthenticated.status) {
                            return sendResponse(statusCode.BAD_REQUEST, false, isAuthenticated.message);
                        }
                        // Parse request body
                        const notificationDetails = await request.json();
                        // Validation
                        const isValidated = await notificationsValidation.detailsValidation(notificationDetails);
                        if (!isValidated?.status) {
                            return sendResponse(statusCode.BAD_REQUEST, false, isValidated?.message);
                        }
                        const partnerId = request.currentPartnerInfo?._id;
                        notificationDetails.partnerId = partnerId;
                        // Call service to get teamplateDetails
                        const result = await notificationsService.templateDetails(notificationDetails);
                        // Handle service response
                        return sendResponse(statusCode.OK, result.status, result?.message, result.data);
                    } catch (error) {
                        console.error("Error in template details:", error);
                        return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
                    }
                }
            case "template-preview":
                {
                    try {
                        const isAuthenticated = await authenticateUser(request);
                        // Middleware to authenticate user
                        console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
                        // Return if request is not authenticated
                        if (!isAuthenticated.status) {
                            return sendResponse(statusCode.BAD_REQUEST, false, isAuthenticated.message);
                        }
                        // Parse request body
                        const notificationDetails = await request.json();
                        const partnerId = request.currentPartnerInfo?._id;

                        const orderId = await getLatestOrderId(request.admin);
                        if (!orderId.status) {
                            return sendResponse(statusCode.BAD_REQUEST, orderId.status, orderId?.message);
                        }
                        notificationDetails.partnerId = partnerId;
                        notificationDetails.orderId = orderId.data;
                        notificationDetails.admin = request.admin;
                        notificationDetails.session = request.session;
                        // Call service to get templatePreview
                        const result = await notificationsService.templatePreview(notificationDetails);
                        // Handle service response
                        if (!result) {
                            return sendResponse(statusCode.BAD_REQUEST, result.status, result?.message);
                        }
                        return sendResponse(statusCode.OK, result.status, result?.message, result.data);
                    } catch (error) {
                        console.error("Error in template details:", error);
                        return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
                    }
                }
            case "default":
                {
                    try {
                        // Middleware to authenticate user
                        const isAuthenticated = await authenticateUser(request);
                        console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
                        // Return if request is not authenticated
                        if (!isAuthenticated.status) {
                            return sendResponse(statusCode.BAD_REQUEST, false, isAuthenticated.message);
                        }
                        // Parse request body
                        const notificationDetails = await request.json();
                        if (!notificationDetails.type) {
                            return sendResponse(statusCode.BAD_REQUEST, false, "Type is required");
                        }
                        const partnerId = request.currentPartnerInfo?._id;
                        notificationDetails.partnerId = partnerId;
                        // Call service to get defaultTemplate
                        const result = await notificationsService.defaultTemplate(notificationDetails);
                        // Handle service response
                        if (!result.status) {
                            return sendResponse(statusCode.BAD_REQUEST, result.status, result?.message);
                        }
                        return sendResponse(statusCode.OK, result.status, result?.message, result.data);
                    } catch (error) {
                        console.error("Error in default template details:", error);
                        return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
                    }
                }
            case "send-email-verify":
                {
                    try {
                        const isAuthenticated = await authenticateUser(request);
                        // Middleware to authenticate user 
                        console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
                        // Return if request is not authenticated
                        if (!isAuthenticated.status) {
                            return sendResponse(statusCode.BAD_REQUEST, false, isAuthenticated.message);
                        }
                        // Parse request body
                        const notificationDetails = await request.json();
                        // Call service to verify email
                        const result = await notificationsService.sendEmailVerify(notificationDetails.email);
                        // Handle service response
                        if (!result.status) {
                            return sendResponse(statusCode.BAD_REQUEST, result.status, result?.message);
                        }
                        return sendResponse(statusCode.OK, result.status, result?.message, result.data);
                    } catch (error) {
                        console.error("Error in send email verify:", error);
                        return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
                    }
                }
            case "check-verify-email":
                {
                    try {
                        const isAuthenticated = await authenticateUser(request);
                        // Middleware to authenticate user
                        console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
                        // Return if request is not authenticated
                        if (!isAuthenticated.status) {
                            return sendResponse(statusCode.BAD_REQUEST, false, isAuthenticated.message);
                        }
                        // Parse request body
                        const notificationDetails = await request.json();
                        const partnerId = request.currentPartnerInfo?._id;
                        notificationDetails.partnerId = partnerId;
                        // Call service to check email verification
                        const result = await notificationsService.checkVerifyEmail(notificationDetails.emails);
                        // Handle service response
                        if (!result.status) {
                            return sendResponse(statusCode.BAD_REQUEST, result.status, result?.message);
                        }
                        return sendResponse(statusCode.OK, result.status, result?.message, result?.data);
                    } catch (error) {
                        console.error("Error in default send email verify:", error);
                        return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
                    }
                }
            default:
                return new Response(JSON.stringify({ error: ErrorMessage.INVALID_API_PATH }), {
                    status: statusCode.NOT_FOUND,
                });
        }
    }
    if (method === "PUT") {
        switch (path) {
            case "type":
                {
                    try {
                        // Middleware to authenticate user 
                        const isAuthenticated = await authenticateUser(request);
                        console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
                        // Return if request is not authenticated
                        if (!isAuthenticated.status) {
                            return sendResponse(statusCode.BAD_REQUEST, false, isAuthenticated.message);
                        }
                        // Parse request body
                        const notificationDetails = await request.json();
                        // Validation
                        const isValidated = await notificationsValidation.templateValidation(notificationDetails);
                        if (!isValidated?.status) {
                            return sendResponse(statusCode.BAD_REQUEST, false, isValidated?.message);
                        }
                        const partnerId = request.currentPartnerInfo?._id;
                        notificationDetails.partnerId = partnerId;
                        // Call service to get update type
                        const result = await notificationsService.updateType(notificationDetails)
                        // Handle service response
                        return sendResponse(statusCode.OK, true, result.data);
                    } catch (error) {
                        console.error("Error in email type:", error);
                        return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
                    }
                }
            case "save":
                {
                    try {
                        const isAuthenticated = await authenticateUser(request);
                        console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);                        // Middleware to authenticate user 
                        // Return if request is not authenticated
                        if (!isAuthenticated.status) {
                            return sendResponse(statusCode.BAD_REQUEST, false, isAuthenticated.message);
                        }
                        // Parse request body
                        const notificationDetails = await request.json();
                        // Validation
                        const isValidated = await notificationsValidation.saveValidation(notificationDetails);
                        if (!isValidated?.status) {
                            return sendResponse(statusCode.BAD_REQUEST, false, isValidated?.message);
                        }
                        const partnerId = request.currentPartnerInfo?._id;
                        notificationDetails.partnerId = partnerId;
                        // Call service to save notificationDetails
                        const result = await notificationsService.save(notificationDetails)
                        // Handle service response
                        if (!result.status) {
                            return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR)
                        }
                        return sendResponse(statusCode.OK, true, result?.message, result?.data);
                    } catch (error) {
                        console.error("Error in email save:", error);
                        return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
                    }
                }
            default:
                return new Response(JSON.stringify({ error: ErrorMessage.INVALID_API_PATH }), {
                    status: statusCode.NOT_FOUND,
                });
        }
    }
    return sendResponse(statusCode.NOT_FOUND, false, ErrorMessage.NOT_FOUND);

};
