import { sendResponse } from "../../server/utils/sendResponse";
import { ErrorMessage, SuccessMessage } from "../../server/constants/messages";
import { statusCode } from "../../server/constants/statusCodes";
import { authenticateUser } from "../../server/middlewares/auth.middleware.server";
import * as planValidation from "../../server/validations/plan.validation";
import * as planService from "../../server/services/plan/index.server";

//Loader function for GET requests.
export const loader = async ({ request }) => {
    const result = "result"
    return sendResponse(statusCode.OK, true, SuccessMessage.FETCHED, result);
};

//Action function for handling POST , PUT and DELETE requests.
export const action = async ({ request, params }) => {
    const method = request.method;
    // Get path from params  
    const path = params["*"];
    if (method === "POST") {
        // Switch cases according to the path
        switch (path) {
            case "subscribe": {
                try {
                    //Middleware to authenticate user 
                    const isAuthenticated = await authenticateUser(request);
                    console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
                    // Return if request is not authenticated
                    if (!isAuthenticated.status) {
                        return sendResponse(statusCode.BAD_REQUEST, false, isAuthenticated.message);
                    }
                    // parse request body
                    const planDetails = await request.json();
                    // validation
                    const isValidated = await planValidation.subscribeValidation(planDetails)

                    if (isValidated?.status === false) {
                        return sendResponse(statusCode.BAD_REQUEST, false, isValidated.message);
                    }
                    // Call service to get subscription
                    const result = await planService.subscribe(planDetails, request.session, request.admin)
                    if (!result.status) {
                        return sendResponse(statusCode.BAD_REQUEST, false, result?.message);
                    }
                    return sendResponse(statusCode.OK, true, result?.message, result?.data);
                } catch (error) {
                    console.error("Error in subscribe:", error);
                    return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
                }
            }
            case "un-subscribe": {
                try {
                    //Middleware to authenticate user && add admin , session and currentPartnerInfo to request
                    const isAuthenticated = await authenticateUser(request);
                    console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
                    // Return if request is not authenticated
                    if (!isAuthenticated.status) {
                        return sendResponse(statusCode.BAD_REQUEST, false, isAuthenticated.message);
                    }
                    const partnerDetails = request?.currentPartnerInfo;
                    // parse request body
                    const planDetails = await request.json();
                    //validating request body
                    const isValidated = await planValidation.unSubscribeValidation(planDetails)

                    if (isValidated.status === false) {
                        return sendResponse(statusCode.BAD_REQUEST, false, isValidated?.message);
                    }
                    // Call service to cancel subscription
                    const result = await planService.unSubscribe(planDetails, partnerDetails, request.admin);

                    // Handle service response
                    if (!result.status) {
                        return sendResponse(statusCode.BAD_REQUEST, false, result?.message);
                    }
                    return sendResponse(statusCode.OK, true, result?.message, result.data);
                } catch (error) {
                    console.error("Error in unSubscribe:", error);
                    return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
                }
            }
            case "status": {
                try {
                    //Middleware to authenticate user && add admin , session and currentPartnerInfo to request
                    const isAuthenticated = await authenticateUser(request);
                    console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
                    // Return if request is not authenticated
                    if (!isAuthenticated.status) {
                        return sendResponse(statusCode.BAD_REQUEST, false, isAuthenticated.message);
                    }
                    const partnerDetails = request?.currentPartnerInfo;
                    // Call service to cancel subscription
                    const result = await planService.planStatus(partnerDetails.chargeId, request.session, request.admin);
                    // Handle service response
                    if (!result.status) {
                        return sendResponse(statusCode.BAD_REQUEST, false, result?.message);
                    }
                    return sendResponse(statusCode.OK, true, result?.message, result.data);
                } catch (error) {
                    console.error("Error in unSubscribe:", error);
                    return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
                }
            }
            default:
                return new Response(JSON.stringify({ error: ErrorMessage.INVALID_API_PATH }), {
                    status: statusCode.NOT_FOUND,
                });
        }
    }

    return sendResponse(statusCode.NOT_FOUND, false, ErrorMessage.NOT_FOUND);
};
