import { sendResponse } from "../../server/utils/sendResponse";
import { ErrorMessage } from "../../server/constants/messages";
import { statusCode } from "../../server/constants/statusCodes";
import { authenticateUser } from "../../server/middlewares/auth.middleware.server";
import * as languageService from "../../server/services/language/index.server";
import * as languageValidation from "../../server/validations/language.validation"

// Loader function for GET requests.
export const loader = async ({ request, params }) => {
    // Get path from params object 
    const path = params["*"];
    // Switch cases according to the path
    switch (path) {
        case "list": {
            try {
                // Middleware to authenticate user 
                const isAuthenticated = await authenticateUser(request);
                console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
                // Return if request is not authenticated
                if (!isAuthenticated.status) {
                    return sendResponse(statusCode.BAD_REQUEST, false, isAuthenticated.message);
                }
                const partnerId = request.currentPartnerInfo?._id;
                // Call service to get page preview
                const result = await languageService.languageList(partnerId);
                if (!result?.status) {
                    return sendResponse(statusCode.BAD_REQUEST, false, result?.message);
                }
                return sendResponse(statusCode.OK, true, result?.message, result?.data);
            } catch (error) {
                console.error("Error in language list:", error);
                return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
            }
        }

        default:
            return new Response(JSON.stringify({ error: ErrorMessage.INVALID_API_PATH }), {
                status: statusCode.NOT_FOUND,
            });
    }
};

// Action function for handling POST , PUT and DELETE requests.
export const action = async ({ request, params }) => {
    const method = request.method;
    // Get path from params
    const path = params["*"];
    // Handle POST requests 
    if (method === "POST") {
        switch (path) {
            case "details": {
                try {
                    // Middleware to authenticate user 
                    const isAuthenticated = await authenticateUser(request);
                    console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
                    // Return if request is not authenticated
                    if (!isAuthenticated.status) {
                        return sendResponse(statusCode.BAD_REQUEST, false, isAuthenticated.message);
                    }
                    const details = await request.json();
                    const isValidated = await languageValidation.detailsValidation(details);
                    if (!isValidated?.status) {
                        return sendResponse(statusCode.BAD_REQUEST, false, isValidated?.message);
                    }
                    const result = await languageService.details(details);
                    if (!result?.status) {
                        return sendResponse(statusCode.BAD_REQUEST, false, result?.message);
                    }
                    return sendResponse(statusCode.OK, true, result?.message, result?.data);
                } catch (error) {
                    console.error("Error in language list:", error);
                    return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
                }
            }
            case "save":
                {
                    try {
                        // Middleware to authenticate user 
                        const isAuthenticated = await authenticateUser(request);
                        console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
                        // Return if request is not authenticated
                        if (!isAuthenticated.status) {
                            return sendResponse(statusCode.BAD_REQUEST, false, isAuthenticated.message);
                        }
                        const details = await request.json();
                        const isValidated = await languageValidation.saveValidation(details);
                        if (!isValidated?.status) {
                            return sendResponse(statusCode.BAD_REQUEST, false, isValidated?.message);
                        }
                        const partnerId = request.currentPartnerInfo?._id;
                        // Call service to get page preview
                        const result = await languageService.saveLanguage(partnerId, details);
                        if (!result?.status) {
                            return sendResponse(statusCode.BAD_REQUEST, false, result?.message);
                        }
                        return sendResponse(statusCode.OK, true, result?.message, result?.data);
                    } catch (error) {
                        console.error("Error in save language:", error);
                        return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
                    }
                }

            default:
                return new Response(JSON.stringify({ error: ErrorMessage.INVALID_API_PATH }), {
                    status: statusCode.NOT_FOUND,
                });
        }
    }

    return sendResponse(statusCode.NOT_FOUND, false, ErrorMessage.NOT_FOUND);
};
