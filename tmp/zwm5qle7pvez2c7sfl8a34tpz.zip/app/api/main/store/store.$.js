import { sendResponse } from "../../server/utils/sendResponse";
import messages, { ErrorMessage } from "../../server/constants/messages";
import { statusCode } from "../../server/constants/statusCodes";
import { authenticateUser } from "../../server/middlewares/auth.middleware.server";
import * as partnerService from "../../server/services/partner/index.server";
import * as partnerValidation from "../../server/validations/partner.validation";

// Loader function for GET requests.
export const loader = async ({ request, params }) => {
    // Get path from params object 
    const path = params["*"];
    // Switch cases according to the path
    switch (path) {
        case "page-previewing":
            {
                try {
                    // Middleware to authenticate user 
                    const isAuthenticated = await authenticateUser(request);
                    console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
                    // Return if request is not authenticated
                    if (!isAuthenticated.status) {
                        return sendResponse(statusCode.BAD_REQUEST, false, isAuthenticated.message);
                    }
                    const partnerId = request.currentPartnerInfo?._id;
                    // Call service to get page preview
                    const result = await partnerService.getPagePreviewing(partnerId, request);
                    return sendResponse(statusCode.OK, true, result?.message, result.data);
                } catch (error) {
                    console.error("Error in getPagePreviewing:", error);
                    return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
                }
            }
        default:
            return new Response(JSON.stringify({ error: ErrorMessage.INVALID_API_PATH }), {
                status: statusCode.NOT_FOUND,
            });
    }
};

// Action function for handling POST , PUT and DELETE requests.
export const action = async ({ request, params }) => {
    const method = request.method;
    // Get path from params
    const path = params["*"];
    // Handle PUT requests
    if (method === "PUT") {
        // Switch cases according to the path
        switch (path) {
            case "page-previewing":
                {
                    try {
                        // Middleware to authenticate user 
                        const isAuthenticated = await authenticateUser(request);
                        console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
                        // Return if request is not authenticated
                        if (!isAuthenticated.status) {
                            return sendResponse(statusCode.BAD_REQUEST, false, isAuthenticated.message);
                        }
                        const partnerId = request.currentPartnerInfo?._id;
                        // Parse request body
                        const details = await request.json();
                        // Call service to update page preview
                        const result = await partnerService.updatePagePreviewing(partnerId, details);
                        return sendResponse(statusCode.OK, true, result?.message);
                    } catch (error) {
                        console.error("Error in updatePagePreviewing:", error);
                        return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
                    }
                }

            case "update": {
                try {
                    const url = new URL(request.url);
                    const details = await request.json();

                    // Middleware to authenticate user 
                    const validUser = await authenticateUser(request);
                    console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
                    // Return if request is not authenticated
                    if (validUser.status === false) {
                        return sendResponse(statusCode.BAD_REQUEST, false, validUser.message);
                    }
                    // Validation
                    const isValidated = await partnerValidation.update(details)

                    if (isValidated.status === false) {
                        return sendResponse(statusCode.BAD_REQUEST, false, isValidated.message);
                    }

                    const partnerId = request.currentPartnerInfo?._id;
                    const admin = request.admin;
                    const session = request.session;
                    // Call service to update shop
                    const result = await partnerService.updateShop(details, partnerId, session, admin);

                    // Handle service response
                    if (!result.status) {
                        return sendResponse(statusCode.BAD_REQUEST, false, result?.message);
                    }
                    return sendResponse(statusCode.CREATED, true, result?.message, result.data);
                } catch (error) {
                    console.error("Error in partnerInfo:", error);
                    return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
                }
            }
            case "settings": {
                try {
                    // Middleware to authenticate user 
                    const isAuthenticated = await authenticateUser(request);
                    console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
                    // Return if request is not authenticated
                    if (!isAuthenticated.status) {
                        return sendResponse(statusCode.BAD_REQUEST, false, isAuthenticated.message);
                    }
                    const partnerId = request.currentPartnerInfo?._id;
                    // Parse request body
                    const details = await request.json()
                    //Validation
                    const isValidated = await partnerValidation.settingsValidation(details)
                    if (isValidated.status === false) {
                        return sendResponse(statusCode.BAD_REQUEST, false, isValidated.message);
                    }
                    const admin = request.admin;
                    // Call service to update partner app settings
                    const result = await partnerService.updatePartnerAppSettings(partnerId, details, admin);

                    // Handle service response
                    if (!result.status) {
                        return sendResponse(statusCode.BAD_REQUEST, false, result?.message);
                    }
                    return sendResponse(statusCode.CREATED, true, result?.message, result.data);
                } catch (error) {
                    console.error("Error in updatePartnerAppSettings:", error);
                    return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
                }
            }
            default:
                return new Response(JSON.stringify({ error: ErrorMessage.INVALID_API_PATH }), {
                    status: statusCode.NOT_FOUND,
                });
        }

    }
    // Handle POST requests 
    if (method === "POST") {
        switch (path) {
            case "info": {
                try {

                    // Middleware to authenticate user 
                    const validUser = await authenticateUser(request);
                    console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
                    // Return if request is not authenticated
                    if (!validUser.status) {
                        return sendResponse(statusCode.BAD_REQUEST, false, validUser.message);
                    }
                    const shopId = request.currentPartnerInfo?._id;
                    // Call service to get shop info or create if not exist
                    const result = await partnerService.storeInfo(shopId, request);

                    // Handle service response
                    if (!result.status) {
                        return sendResponse(statusCode.BAD_REQUEST, false, result?.message);
                    }
                    return sendResponse(statusCode.OK, true, result?.message, result.data);
                } catch (error) {
                    console.error("Error in partnerInfo:", error);
                    return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
                }
            }
            case "settings": {
                try {

                    // Middleware to authenticate user 
                    const isAuthenticated = await authenticateUser(request);
                    console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
                    // Return if request is not authenticated
                    if (!isAuthenticated.status) {
                        return sendResponse(statusCode.BAD_REQUEST, false, isAuthenticated.message);
                    }
                    const partnerId = request.currentPartnerInfo?._id;
                    // Call service to get partner app settings
                    const result = await partnerService.getPartnerAppSettings(partnerId, request.admin);
                    // Handle service response
                    if (!result.status) {
                        return sendResponse(statusCode.BAD_REQUEST, false, result?.message);
                    }
                    return sendResponse(statusCode.CREATED, true, result?.message, result.data);
                } catch (error) {
                    console.error("Error in getPartnerAppSettings:", error);
                    return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
                }
            }
            default:
                return new Response(JSON.stringify({ error: ErrorMessage.INVALID_API_PATH }), {
                    status: statusCode.NOT_FOUND,
                });
        }
    }

    return sendResponse(statusCode.NOT_FOUND, false, ErrorMessage.NOT_FOUND);
};
