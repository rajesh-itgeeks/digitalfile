import { sendResponse } from "../../server/utils/sendResponse";
import { ErrorMessage } from "../../server/constants/messages";
import { authenticateUser } from "../../server/middlewares/auth.middleware.server";
import { statusCode } from "../../server/constants/statusCodes";
import { discountAdd, discountValidate } from "../../server/services/discounts/index.server.js";

export const loader = async ({ request, params }) => {
  // Check if the environment is not development
  // Get path from params object 
  const path = params["*"];
  // Switch cases according to the path
  switch (path) {
    case "check":
      {
        try {
          // console.log("reeeee",request.url.;
          // Middleware to authenticate user 
          const isAuthenticated = await authenticateUser(request);
          // Return if request is not authenticated
          if (!isAuthenticated.status) {
            return sendResponse(statusCode.BAD_REQUEST, false, isAuthenticated.message);
          }
          const admin = request.admin;
          const session = request.session;
          const url = new URL(request.url);
          const orderId = url.searchParams.get("orderId");
          const variantId = url.searchParams.get("variantId");

          console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
          // Call service to get invoice
          const result = await discountAdd(admin, orderId, variantId, session);
          // Handle service response
          return result;
        } catch (error) {
          console.error("Error in invoice details:", error);
          return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
        }
      }

    default:
      return new Response(JSON.stringify({ error: ErrorMessage.INVALID_API_PATH }), {
        status: statusCode.NOT_FOUND,
      });
  }
};

export const action = async ({ request, params }) => {
  const method = request.method;
  // Get path from params object 
  const path = params["*"];

  // Switch cases according to the path
  if (method === "POST") {
    switch (path) {
      case "validate": {
        try {
          console.log(`::--- ${new URL(request.url).pathname}?shop=${new URL(request.url).searchParams.get("shop")} ---::`);
          // Middleware to authenticate user 
          const isAuthenticated = await authenticateUser(request);
          // Return if request is not authenticated
          if (!isAuthenticated.status) {
            return sendResponse(statusCode.BAD_REQUEST, false, isAuthenticated.message);
          }
          const url = new URL(request.url);
          const orderId = url.searchParams.get("orderId");
          // Parse request body
          const details = await request.json();
          details.orderId = orderId;
          const result = await discountValidate(details, request.admin);
          if (!result.status) {
            return sendResponse(statusCode.BAD_REQUEST, false, result?.message);
          }
          // Handle service response
          return sendResponse(statusCode.OK, result.status, result?.message, result.data);
        }
        catch (error) {
          console.error("Error in validate discount:", error?.message);
          return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
        }
      }
    }
  }
};