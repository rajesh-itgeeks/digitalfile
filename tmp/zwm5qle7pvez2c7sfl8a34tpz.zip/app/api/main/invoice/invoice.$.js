import { sendResponse } from "../../server/utils/sendResponse";
import { ErrorMessage } from "../../server/constants/messages";
import { authenticateUser } from "../../server/middlewares/auth.middleware.server";
import { statusCode } from "../../server/constants/statusCodes";
import * as invoiceService from "../../server/services/invoice/index.server.js";
import { unauthenticated } from "../../../shopify.server.js";
import * as invoiceValidation from "../../server/validations/invoice.validation.js";
export const loader = async ({ request, params }) => {
  // Check if the environment is not development

  // Get path from params object 
  const path = params["*"];
  // Switch cases according to the path
  switch (path) {
    case "details":
      {
        try {
          // Middleware to authenticate user 
          const isAuthenticated = await authenticateUser(request);
          // Return if request is not authenticated
          if (!isAuthenticated.status) {
            return sendResponse(statusCode.BAD_REQUEST, false, isAuthenticated.message);
          }
          const admin = request.admin;
          const session = request.session;
          console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
          const partnerId = request.currentPartnerInfo?._id;
          // Call service to get invoice
          const result = await invoiceService.getInvoice(partnerId, admin, session);
          // Handle service response
          return sendResponse(statusCode.OK, result.status, result?.message, result.data);
        } catch (error) {
          console.error("Error in invoice details:", error);
          return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
        }
      }
    case "default-template":
      {
        try {
          // Middleware to authenticate user 
          const isAuthenticated = await authenticateUser(request);
          console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
          // Return if request is not authenticated
          if (!isAuthenticated.status) {
            return sendResponse(statusCode.BAD_REQUEST, false, isAuthenticated.message);
          }
          // Call service to get invoice
          const result = await invoiceService.getDefaultInvoiceDetails();
          // Handle service response
          return sendResponse(statusCode.OK, result.status, result?.message, result.data);
        } catch (error) {
          console.error("Error in invoice details:", error);
          return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
        }
      }
    default:
      return new Response(JSON.stringify({ error: ErrorMessage.INVALID_API_PATH }), {
        status: statusCode.NOT_FOUND,
      });
  }
};

export const action = async ({ request, params }) => {
  const method = request.method;
  // Get path from params object 
  const path = params["*"];

  // Switch cases according to the path
  if (method === "POST") {
    switch (path) {
      case "save": {
        try {

          // Middleware to authenticate user 
          const isAuthenticated = await authenticateUser(request);
          console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
          // Return if request is not authenticated
          if (!isAuthenticated.status) {
            return sendResponse(statusCode.BAD_REQUEST, false, isAuthenticated.message);
          }

          // Parse request body
          const invoiceDetails = await request.json();
          // Validation
          const isValidated = await invoiceValidation.checkInvoiceValidation(invoiceDetails);

          if (!isValidated?.status) {
            return sendResponse(statusCode.BAD_REQUEST, false, isValidated?.message);
          }

          const partnerId = request.currentPartnerInfo?._id;
          invoiceDetails.partnerId = partnerId;
          const admin = request.admin;
          const session = request.session;
          // Call service to get create invoice
          const result = await invoiceService.InvoiceCreate(invoiceDetails, partnerId, admin, session);
          if (!result.status) {
            return sendResponse(statusCode.BAD_REQUEST, false, result?.message);
          }
          // Handle service response
          return sendResponse(statusCode.OK, result.status, result?.message, result.data);
        } catch (error) {
          console.error("Error in template details:", error);
          return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
        }
      }
      case "invoicePreview": {
        try {
          // Middleware to authenticate user 
          const isAuthenticated = await authenticateUser(request);
          console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
          // Return if request is not authenticated
          if (!isAuthenticated.status) {
            return sendResponse(statusCode.BAD_REQUEST, false, isAuthenticated.message);
          }

          // Parse request body
          const invoiceTemplate = await request.json();
          // Validation
          const partnerId = request.currentPartnerInfo?._id;
          const admin = request.admin;
          const session = request.session;
          // Call service to get create invoice
          const result = await invoiceService.InvoicePreview(invoiceTemplate?.invoiceTemplate, admin, session)
          if (!result.status) {
            return sendResponse(statusCode.BAD_REQUEST, false, result?.message);
          }
          // Handle service response
          return sendResponse(statusCode.OK, result.status, result?.message, result.data);
        } catch (error) {
          console.error("Error in template details:", error);
          return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
        }
      }
      case "download-invoice": {
        try {
          console.log(`::--- ${new URL(request.url).pathname}?shop=${new URL(request.url).searchParams.get("shop")} ---::`);
          // Middleware to authenticate user 
          const isAuthenticated = await authenticateUser(request);
          // Return if request is not authenticated
          if (!isAuthenticated.status) {
            return sendResponse(statusCode.BAD_REQUEST, false, isAuthenticated.message);
          }
          const url = new URL(request.url);
          const orderId = url.searchParams.get("orderId");
          const shop = url.searchParams.get("shop");
          if (!orderId || !shop) {
            return sendResponse(statusCode.BAD_REQUEST, false, ErrorMessage.INVALID_REQUEST);
          }
          let session, admin
          // check session in db 

          try {
            ({ session, admin }
              = await unauthenticated.admin(shop))
            console.log(`::--- ${new URL(request.url).pathname}?shop=${session?.shop} ---::`);

          }
          catch (error) {
            return sendResponse(statusCode.BAD_REQUEST, false, ErrorMessage.UNAUTHORIZED);

          }

          if (!session || !admin) {
            return sendResponse(statusCode.BAD_REQUEST, false, ErrorMessage.UNAUTHORIZED);
          }

          const result = await invoiceService.generateInvoicePDF(admin, session, orderId, request.currentPartnerInfo);
          if (!result.status) {
            return sendResponse(statusCode.BAD_REQUEST, false, result?.message);
          }
          // Handle service response
          return sendResponse(statusCode.OK, result.status, result?.message, result.data);
        }
        catch (error) {
          console.error("Error in download invoice:", error?.message);
          return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
        }
      }
    }
  }
};

