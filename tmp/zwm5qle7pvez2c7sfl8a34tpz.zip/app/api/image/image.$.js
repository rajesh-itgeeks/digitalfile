import { uploadImage } from "../server/services/uploadImage/index.server";
import { statusCode } from "../server/constants/statusCodes";
import { sendResponse } from "../server/utils/sendResponse";
import { ErrorMessage } from "../server/constants/messages";

export const action = async ({ request, params }) => {
  const method = request.method;
      // Get path from params object 

  const path = params["*"];
  // Switch cases according to the path
  if (method === "POST") {
    switch (path) {
      case "upload": {
        try {
          console.log(`::--- ${new URL(request.url).pathname}?shop=${new URL(request.url).searchParams.get("shop")} ---::`);
          // parse request body
          const result = await uploadImage(request);
          if (!result.status) {
            return sendResponse(statusCode.BAD_REQUEST, false, result?.message);
          }
          return sendResponse(statusCode.OK, result.status, result?.message, result.data);
        } catch (error) {
          console.error("Error in uploading image:", error);
          return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
        }
      }
    }
  }
};

