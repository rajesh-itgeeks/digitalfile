import { ErrorMessage, SuccessMessage } from "../server/constants/messages";
import { statusCode } from "../server/constants/statusCodes";
import { sendResponse } from "../server/utils/sendResponse";

export const loader = async ({ request }) => {
    try {
        return sendResponse(statusCode.OK, true, SuccessMessage.FETCHED, new Date());
    } catch (error) {
        return sendResponse(statusCode.INVALID_REQUEST, false, ErrorMessage.INVALID_REQUEST);
    }

};


