import { sendResponse } from "../server/utils/sendResponse.js";
import { ErrorMessage, SuccessMessage } from "../server/constants/messages.js";
import { statusCode } from "../server/constants/statusCodes.js";
import { authenticateUser } from "../server/middlewares/auth.middleware.server.js";
import * as dashboardService from "../server/services/dashboards/index.server.js";
// Loader function for GET requests.
export const loader = async (request) => {
    const result = "result"
    return sendResponse(statusCode.OK, true, SuccessMessage.FETCHED, result);
};

// Action function for handling POST , PUT and DELETE requests.
export const action = async ({ request }) => {
    const method = request.method;
    // Handle POST requests
    if (method === "POST") {
        try {
            // Middleware to authenticate user 
            const isAuthenticated = await authenticateUser(request);
            console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
            // Return if request is not authenticated
            if (!isAuthenticated.status) {
                return sendResponse(statusCode.BAD_REQUEST, false, isAuthenticated.message);
            }
            const details = await request.json();
            const partnerId = request.currentPartnerInfo._id;
            // Call service to get and update setup guide
            const result = await dashboardService.setupGuide(partnerId, details);
            // Handle service response
            return sendResponse(statusCode.OK, true, result?.message, result.data);
        } catch (error) {
            console.error("Error in setup-guide:", error);
            return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
        }
    }


    return sendResponse(statusCode.NOT_FOUND, false, ErrorMessage.NOT_FOUND);
};
