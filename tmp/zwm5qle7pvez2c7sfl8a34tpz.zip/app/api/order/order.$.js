import { getOrderCalculateId, orderAdminRevers, orderDetailsById, orderEditCommit , timeExceed } from "../server/services/order/utils.js";
import * as infoUpdateService from "../server/services/order/update-info/index.js"
import * as editService from "../server/services/order/edit/index.js"
import * as cancellationService from "../server/services/order/cancellation/index.js"
import * as upsellService from "../server/services/order/up-sell/index.js"
import * as orderValidation from "../server/validations/order.validation.js"
import * as partnerService from "../server/services/partner/index.server.js";
import * as invoiceService from "../server/services/invoice/index.server.js";
import { sendResponse } from "../server/utils/sendResponse.js";
import { statusCode, } from "../server/constants/statusCodes.js";
import { ErrorMessage, SuccessMessage } from "../server/constants/messages.js";
import { validateOrder } from "../server/middlewares/orderEditing.middleware.js";
import { updatePagePreviewingValidation } from "../server/validations/partner.validation.js";
import { getAllCountryDeliveryProfilesList } from "../server/services/country/index.server.js";
import { setupGuide } from "../server/services/dashboards/index.server.js";
import { upSellDescription } from "../server/services/upsell/index.server.js";
import { support } from "../server/services/support/index.server.js";
import { createSupport } from "../server/validations/support.validation.js";
import { authenticate, unauthenticated } from "../../shopify.server.js";

import * as shippingService from "../server/services/order/shipping/index.js"
import { description } from "../server/validations/upSell.validation.js";
import { languageDetails } from "../server/services/language/index.server.js";

//Loader function for GET requests.
export async function loader({ request, params }) {
  let admin, session, currentPartnerInfo;
  // Check if the environment is not development
  if (process.env.ENV_SERVER !== 'development') {
    let { sessionToken } = await authenticate.public.checkout(request);
    ({ admin, session } = await unauthenticated.admin(sessionToken.dest));
    currentPartnerInfo = await partnerService.getShopInfo(session.shop);
  } else {
    const shop = new URL(request.url).searchParams.get("shop");
    ({ session, admin } = await unauthenticated.admin(shop));
    currentPartnerInfo = await partnerService.getShopInfo(session.shop);
  }
  // Get path from params object 
  const path = params["*"];
  // Switch cases according to the path
  switch (path) {

    case "details":
      {
        console.log(`::--- ${new URL(request.url).pathname}?shop=${session?.shop} ---::`);
        // Extract the orderId from the request URL 
        const orderId = new URL(request.url).searchParams.get("orderId");
        const lang = new URL(request.url).searchParams.get("language")?.split("-")?.[0] || "en";
        const extensionName = new URL(request.url).searchParams.get("extensionName");
        if (!orderId) {
          return sendResponse(statusCode.BAD_REQUEST, false, ErrorMessage.ID_NOT_FOUND);
        }
        // Fetch order details using the orderId  
        const partnerId = currentPartnerInfo?._id;
        const response = await orderDetailsById(orderId, admin, session, partnerId, extensionName, lang);
        if (!response?.status) {
          return sendResponse(statusCode.BAD_REQUEST, false, response?.message);
        }
        if (response?.status) {
          return sendResponse(statusCode.OK, true, SuccessMessage.FETCHED, response?.data);
        }
      }
    case "store-language":
      {
        console.log(`::--- ${new URL(request.url).pathname}?shop=${session?.shop} ---::`);
        // Extract the language from the request URL 
        const lang = new URL(request.url).searchParams.get("language")?.split("-")?.[0] || "en";
        // Fetch language details using language code  
        const partnerId = currentPartnerInfo?._id;
        const response = await languageDetails(partnerId, lang);
        if (!response?.status) {
          return sendResponse(statusCode.BAD_REQUEST, false, response?.message);
        }
        if (response?.status) {
          return sendResponse(statusCode.OK, true, SuccessMessage.FETCHED, response?.data);
        }
      }
    case "time-exceed":
      {
        console.log(`::--- ${new URL(request.url).pathname}?shop=${session?.shop} ---::`);
        // Extract the orderId from the request URL 
        const orderId = new URL(request.url).searchParams.get("orderId");
        if (!orderId) {
          return sendResponse(statusCode.BAD_REQUEST, false, ErrorMessage.ID_NOT_FOUND);
        }

        const partnerId = currentPartnerInfo?._id;
        // Check if order modification is allowed
        const response = await timeExceed(orderId, partnerId, admin, session);
        if (!response.status) {
          return sendResponse(statusCode.BAD_REQUEST, false, response?.message);
        }
        return sendResponse(statusCode.OK, true, response?.message, response?.data);
      }

    default:
      return new Response(JSON.stringify({ error: ErrorMessage.INVALID_API_PATH }), {
        status: statusCode.NOT_FOUND,
      });
  }
}

//Action function for handling POST , PUT and DELETE requests.
export async function action({ request, params }) {
  let admin, session, currentPartnerInfo;
  // Check if the environment is not development
  if (process.env.ENV_SERVER !== 'development') {
    let { sessionToken } = await authenticate.public.checkout(request);
    ({ admin, session } = await unauthenticated.admin(sessionToken.dest));
    currentPartnerInfo = await partnerService.getShopInfo(session.shop);
  } else {
    // Extract shop parameter from the request URL in development mode
    const shop = new URL(request.url).searchParams.get("shop");
    ({ session, admin } = await unauthenticated.admin(shop));
    currentPartnerInfo = await partnerService.getShopInfo(session.shop);
  }
  // Get path from params object 
  const path = params["*"];

  if (request.method === "POST") {
    // Switch cases according to the path
    switch (path) {
      case "add-item":
        {
          console.log(`::--- ${new URL(request.url).pathname}?shop=${session?.shop} ---::`);
          // Extract the orderId from the request URL 
          const orderId = new URL(request.url).searchParams.get("orderId");
          const lang = new URL(request.url).searchParams.get("language")?.split("-")?.[0] || "en";

          if (!orderId) {
            return sendResponse(statusCode.BAD_REQUEST, false, ErrorMessage.ID_NOT_FOUND);
          }
          // Parse request body
          const details = await request.json();

          // Validation
          const isValidated = await orderValidation.addItem(details);
          if (isValidated?.status === false) {
            return sendResponse(statusCode.BAD_REQUEST, false, isValidated?.message);
          }
          details.partnerId = currentPartnerInfo?._id;
          // Check if order modification is allowed
          const timeResult = await timeExceed(orderId, currentPartnerInfo?._id, admin, session);
          if (!timeResult.status) {
            return sendResponse(statusCode.BAD_REQUEST, false, timeResult?.message);
          }
          if (timeResult.data?.customerDisallowEdits || timeResult.data?.disableAddingNewItems) {
            return sendResponse(statusCode.BAD_REQUEST, false, ErrorMessage.ORDER_TIME_FRAME_EXCEEDED);
          }
          // Call service to add order item
          const response = await editService.addOrderItem(details, orderId, admin, false, session, lang);
          if (!response?.status) {
            return sendResponse(statusCode.BAD_REQUEST, false, response?.message);
          }
          return sendResponse(statusCode.OK, true, response?.message, response?.data);
        }
      case "remove-item":
        {
          console.log(`::--- ${new URL(request.url).pathname}?shop=${session?.shop} ---::`);
          // Extract the orderId from the request URL 
          const orderId = new URL(request.url).searchParams.get("orderId");
          const lang = new URL(request.url).searchParams.get("language")?.split("-")?.[0] || "en";
          if (!orderId) {
            return sendResponse(statusCode.BAD_REQUEST, false, ErrorMessage.ID_NOT_FOUND);
          }
          // Parse request body
          const details = await request.json()
          // Validation
          const isValidated = await orderValidation.removeItem(details);
          if (isValidated?.status === false) {
            return sendResponse(statusCode.BAD_REQUEST, false, isValidated?.message);
          }
          details.partnerId = currentPartnerInfo?._id;
          const timeResult = await timeExceed(orderId, currentPartnerInfo?._id, admin, session);
          if (!timeResult.status) {
            return sendResponse(statusCode.BAD_REQUEST, false, timeResult?.message);
          }
          if (timeResult.data?.customerDisallowEdits || timeResult.data?.disableRemovingItems) {
            return sendResponse(statusCode.BAD_REQUEST, false, ErrorMessage.ORDER_TIME_FRAME_EXCEEDED);
          }
          // Call service to remove order item
          const response = await editService.removeOrderItem(details, orderId, admin, false, session, lang);
          return sendResponse(statusCode.OK, true, SuccessMessage.REMOVE, [response]);
        }
      case "edit-item":
        {
          console.log(`::--- ${new URL(request.url).pathname}?shop=${session?.shop} ---::`);
          const details = await request.json()
          const orderId = new URL(request.url).searchParams.get("orderId");
          const isWarning = new URL(request.url).searchParams.get("isWarning");
          const lang = new URL(request.url).searchParams.get("language")?.split("-")?.[0] || "en";

          if (!orderId) {
            return sendResponse(statusCode.BAD_REQUEST, false, ErrorMessage.ID_NOT_FOUND);
          }
          // Check if order modification is allowed
          const timeResult = await timeExceed(orderId, currentPartnerInfo?._id, admin, session);
          if (!timeResult.status) {
            return sendResponse(statusCode.BAD_REQUEST, false, timeResult?.message);
          }
          if (timeResult.data?.customerDisallowEdits || timeResult.data?.disableItemQuantityChanges) {
            return sendResponse(statusCode.BAD_REQUEST, false, ErrorMessage.ORDER_TIME_FRAME_EXCEEDED);
          }
          // VAlidation
          const isValidated = await orderValidation.editItem(details);
          if (isValidated?.status === false) {
            return sendResponse(statusCode.BAD_REQUEST, false, isValidated?.message);
          }

          details.partnerId = currentPartnerInfo?._id;
          details.isWarning = isWarning || 'false';

          // Call service to edit order item
          const response = await editService.editOrderItem(orderId, details, admin, session, lang);
          if (!response?.status) {
            return sendResponse(statusCode.BAD_REQUEST, false, response?.message);
          }
          return sendResponse(statusCode.OK, true, response?.message, response?.data);
        }
      case "swap-item":
        {
          console.log(`::--- ${new URL(request.url).pathname}?shop=${session?.shop} ---::`);
          // Extract the orderId from the request URL 
          const orderId = new URL(request.url).searchParams.get("orderId");
          const lang = new URL(request.url).searchParams.get("language")?.split("-")?.[0] || "en";

          if (!orderId) {
            return sendResponse(statusCode.BAD_REQUEST, false, ErrorMessage.ID_NOT_FOUND);
          }
          // Parse request body
          const details = await request.json()
          // Validation
          const isValidated = await orderValidation.swapItem(details);
          if (isValidated?.status === false) {
            return sendResponse(statusCode.BAD_REQUEST, false, isValidated?.message);
          }
          details.partnerId = currentPartnerInfo?._id;
          // Check if order modification is allowed
          const timeResult = await timeExceed(orderId, currentPartnerInfo?._id, admin, session);
          if (!timeResult.status) {
            return sendResponse(statusCode.BAD_REQUEST, false, timeResult?.message);
          }
          if (timeResult.data?.customerDisallowEdits || timeResult.data?.disableProductSwaps) {
            return sendResponse(statusCode.BAD_REQUEST, false, ErrorMessage.ORDER_TIME_FRAME_EXCEEDED);
          }
          // Call service to swap order item
          const response = await editService.swapOrderItem(details, orderId, admin, session, lang);
          return sendResponse(statusCode.OK, true, SuccessMessage.ADDED, [response]);
        }
      case "add-discount-item":
        {
          console.log(`::--- ${new URL(request.url).pathname}?shop=${session?.shop} ---::`);
          // parse request body
          const details = await request.json()
          // Extract the orderId from the request URL 
          const orderId = new URL(request.url).searchParams.get("orderId");
          const lang = new URL(request.url).searchParams.get("language")?.split("-")?.[0] || "en";

          if (!orderId) {
            return sendResponse(statusCode.BAD_REQUEST, false, ErrorMessage.ID_NOT_FOUND);
          }
          // Validation
          const isValidated = await orderValidation.addDiscountItemValidation(details);
          if (isValidated?.status === false) {
            return sendResponse(statusCode.BAD_REQUEST, false, isValidated?.message);
          }
          details.partnerId = currentPartnerInfo?._id;
          // Check if order modification is allowed
          const timeResult = await timeExceed(orderId, currentPartnerInfo?._id, admin, session);
          if (!timeResult.status) {
            return sendResponse(statusCode.BAD_REQUEST, false, timeResult?.message);
          }
          if (timeResult.data?.customerDisallowEdits || timeResult.data?.disableAddingNewItems) {
            return sendResponse(statusCode.BAD_REQUEST, false, ErrorMessage.ORDER_TIME_FRAME_EXCEEDED);
          }
          // Call service to add discount item
          const response = await upsellService.addDiscountItem(orderId, details, admin, session, lang);
          return sendResponse(statusCode.OK, true, SuccessMessage.FETCHED, [response]);
        }
      case "calculate-id":
        {
          console.log(`::--- ${new URL(request.url).pathname}?shop=${session?.shop} ---::`);
          // Extract the orderId from the request URL
          const orderId = new URL(request.url).searchParams.get("orderId");
          if (!orderId) {
            return sendResponse(statusCode.BAD_REQUEST, false, ErrorMessage.ID_NOT_FOUND);
          }
          // Call service to get calculated order Id
          const response = await getOrderCalculateId(orderId, admin);
          if (!response?.status) {
            return sendResponse(statusCode.BAD_REQUEST, false, response?.message);
          }
          return sendResponse(statusCode.OK, true, response?.message, response?.data);
        }
      case "edit-commit":
        {
          console.log(`::--- ${new URL(request.url).pathname}?shop=${session?.shop} ---::`);
          // Extract the orderId from the request URL
          const orderId = new URL(request.url).searchParams.get("orderId");
          if (!orderId) {
            return sendResponse(statusCode.BAD_REQUEST, false, ErrorMessage.ID_NOT_FOUND);
          }
          const partnerId = currentPartnerInfo?._id;
          // Validation
          const isValidOrder = await validateOrder(orderId, partnerId, admin, session)
          if (!isValidOrder.status) {
            return sendResponse(statusCode.BAD_REQUEST, false, isValidOrder.message);
          }
          // parse request body
          const details = await request.json()
          const isValidated = await orderValidation.editCommit(details);
          if (isValidated?.status === false) {
            return sendResponse(statusCode.BAD_REQUEST, false, isValidated?.message);
          }
          // commit order edit
          const response = await orderEditCommit(details, admin);
          if (!response?.status) {
            return sendResponse(statusCode.BAD_REQUEST, false, response?.message);
          }
          return sendResponse(statusCode.OK, true, response?.message, response?.data);
        }
      case "cancel":
        {
          console.log(`::--- ${new URL(request.url).pathname}?shop=${session?.shop} ---::`);
          // parse request body
          const details = await request.json()
          // Extract the orderId from the request URL 
          const orderId = new URL(request.url).searchParams.get("orderId");
          const lang = new URL(request.url).searchParams.get("language")?.split("-")?.[0] || "en";

          if (!orderId) {
            return sendResponse(statusCode.BAD_REQUEST, false, ErrorMessage.ID_NOT_FOUND);
          }
          const isValidated = await orderValidation.cancelOrder(details);
          if (isValidated?.status === false) {
            return sendResponse(statusCode.BAD_REQUEST, false, isValidated?.message);
          }
          details.partnerId = currentPartnerInfo?._id;
          // Check if order modification is allowed
          const timeResult = await timeExceed(orderId, currentPartnerInfo?._id, admin, session);
          if (!timeResult.status) {
            return sendResponse(statusCode.BAD_REQUEST, false, timeResult?.message);
          }
          if (timeResult.data?.customerDisallowEdits || timeResult.data?.disableOrderCancellations) {
            return sendResponse(statusCode.BAD_REQUEST, false, ErrorMessage.ORDER_TIME_FRAME_EXCEEDED);
          }
          // Call service to cancel order
          const response = await cancellationService.orderCancel(orderId, details, admin, session, lang);
          if (!response?.status) {
            return sendResponse(statusCode.BAD_REQUEST, false, response?.message);
          }
          return sendResponse(statusCode.OK, true, response?.message, response?.data);
        }
      case "shipping-address":
        {
          console.log(`::--- ${new URL(request.url).pathname}?shop=${session?.shop} ---::`);
          // parse request body
          const details = await request.json()
          const orderId = new URL(request.url).searchParams.get("orderId");
          const lang = new URL(request.url).searchParams.get("language")?.split("-")?.[0] || "en";

          if (!orderId) {
            return sendResponse(statusCode.BAD_REQUEST, false, ErrorMessage.ID_NOT_FOUND);
          }
          // Validation
          const isValidated = await orderValidation.shippingAddress(details);
          if (isValidated?.status === false) {
            return sendResponse(statusCode.BAD_REQUEST, false, isValidated?.message);
          }
          details.partnerId = currentPartnerInfo?._id;
          // Check if order modification is allowed
          const timeResult = await timeExceed(orderId, currentPartnerInfo?._id, admin, session);
          if (!timeResult.status) {
            return sendResponse(statusCode.BAD_REQUEST, false, timeResult?.message);
          }
          if (timeResult.data?.customerDisallowEdits || timeResult.data?.disableShippingAddress) {
            return sendResponse(statusCode.BAD_REQUEST, false, ErrorMessage.ORDER_TIME_FRAME_EXCEEDED);
          }
          // Call service to change order shipping address
          const response = await infoUpdateService.changeOrderShippingAddress(orderId, details, admin, session, lang);
          if (!response?.status) {
            return sendResponse(statusCode.BAD_REQUEST, false, response?.message);
          }
          return sendResponse(statusCode.OK, true, response?.message, response?.data);
        }
      case "contact-info":
        {
          console.log(`::--- ${new URL(request.url).pathname}?shop=${session?.shop} ---::`);
          // parse request body
          const details = await request.json()
          const orderId = new URL(request.url).searchParams.get("orderId");
          const lang = new URL(request.url).searchParams.get("language")?.split("-")?.[0] || "en";

          if (!orderId) {
            return sendResponse(statusCode.BAD_REQUEST, false, ErrorMessage.ID_NOT_FOUND);
          }
          // VAlidation
          const isValidated = await orderValidation.contactInfo(details);
          if (isValidated?.status === false) {
            return sendResponse(statusCode.BAD_REQUEST, false, isValidated?.message);
          }
          details.partnerId = currentPartnerInfo?._id;
          // Check if order modification is allowed
          const timeResult = await timeExceed(orderId, currentPartnerInfo?._id, admin, session);
          if (!timeResult.status) {
            return sendResponse(statusCode.BAD_REQUEST, false, timeResult?.message);
          }
          if (timeResult.data?.customerDisallowEdits || timeResult.data?.disableEmailEditing) {
            return sendResponse(statusCode.BAD_REQUEST, false, ErrorMessage.ORDER_TIME_FRAME_EXCEEDED);
          }
          // Call service to update Contact Info
          const response = await infoUpdateService.updateContactInfo(orderId, details, admin, session, lang);
          if (!response?.status) {
            return sendResponse(statusCode.BAD_REQUEST, false, response?.message);
          }
          return sendResponse(statusCode.OK, true, response?.message, response?.data);
        }
      case "page-previewing":
        {
          console.log(`::--- ${new URL(request.url).pathname}?shop=${session?.shop} ---::`);
          const details = await request.json()
          // VAlidation
          const isValidated = await updatePagePreviewingValidation(details);
          if (isValidated?.status === false) {
            return sendResponse(statusCode.BAD_REQUEST, false, isValidated?.message);
          }
          const partnerId = currentPartnerInfo?._id;
          // Call service to update page preview
          const response = await partnerService.updatePagePreviewing(partnerId, details);
          if (!response?.status) {
            return sendResponse(statusCode.BAD_REQUEST, false, response?.message);
          }
          return sendResponse(statusCode.OK, true, response?.message, response?.data);
        }
      case "store-settings":
        {
          console.log(`::--- ${new URL(request.url).pathname}?shop=${session?.shop} ---::`);
          const partnerId = currentPartnerInfo?._id;
          //get partner app settings from db
          const response = await partnerService.getPartnerAppSettings(partnerId, admin);
          if (!response?.status) {
            return sendResponse(statusCode.BAD_REQUEST, false, response?.message);
          }
          return sendResponse(statusCode.OK, true, response?.message, response?.data);
        }
      case "default-country-list":
        {
          console.log(`::--- ${new URL(request.url).pathname}?shop=${session?.shop} ---::`);
          // get all country delivery profiles list
          const response = await getAllCountryDeliveryProfilesList(admin);
          if (!response?.status) {
            return sendResponse(statusCode.BAD_REQUEST, false, response?.message);
          }
          return sendResponse(statusCode.OK, true, response?.message, response?.data);
        }
      case "setup-guide":
        {
          console.log(`::--- ${new URL(request.url).pathname}?shop=${session?.shop} ---::`);
          const details = await request.json();
          const partnerId = currentPartnerInfo?._id;
          // setupguide service call

          const response = await setupGuide(partnerId, details);
          if (!response?.status) {
            return sendResponse(statusCode.BAD_REQUEST, false, response?.message);
          }
          return sendResponse(statusCode.OK, true, response?.message, response?.data);
        }
      case "up-sell-description":
        {
          console.log(`::--- ${new URL(request.url).pathname}?shop=${session?.shop} ---::`);
          const details = await request.json();
          const isValidated = await description(details);
          if (isValidated?.status === false) {
            return sendResponse(statusCode.BAD_REQUEST, false, isValidated?.message);
          }
          const partnerId = currentPartnerInfo?._id;
          // upsell desciption service call
          const response = await upSellDescription(partnerId, details, admin);
          if (!response?.status) {
            return sendResponse(statusCode.BAD_REQUEST, false, response?.message);
          }
          return sendResponse(statusCode.OK, true, response?.message, response?.data);
        }
      case "support":
        {
          console.log(`::--- ${new URL(request.url).pathname}?shop=${session?.shop} ---::`);
          // parse request body
          const details = await request.json();
          // Validation
          const isValidated = await createSupport(details)
          if (!isValidated.status) {
            return sendResponse(statusCode.BAD_REQUEST, false, isValidated?.message);
          }
          // Call service to add get shop info
          const currentPartnerInfo = await partnerService.getShopInfoGraphQl(admin);
          const email = currentPartnerInfo?.data.shop.email;
          const response = await support(details, email);
          if (!response?.status) {
            return sendResponse(statusCode.BAD_REQUEST, false, response?.message);
          }
          return sendResponse(statusCode.OK, true, response?.message, response?.data);
        }
      case "info":
        {
          console.log(`::--- ${new URL(request.url).pathname}?shop=${session?.shop} ---::`);
          if (!currentPartnerInfo) {
            return sendResponse(statusCode.BAD_REQUEST, false, ErrorMessage.NOT_FOUND);
          }
          return sendResponse(statusCode.OK, true, SuccessMessage.FETCHED, currentPartnerInfo);
        }
      case "check-shipping-address":
        {
          console.log(`:::---------------------------------${request.url}---------------------------------:::`);
          const details = await request.json()
          const orderId = new URL(request.url).searchParams.get("orderId");
          const lang = new URL(request.url).searchParams.get("language")?.split("-")?.[0] || "en";
          const extensionName = new URL(request.url).searchParams.get("extensionName");
          if (!orderId) {
            return sendResponse(statusCode.BAD_REQUEST, false, ErrorMessage.ID_NOT_FOUND);
          }
          const isValidated = await orderValidation.shippingAddress(details);
          if (isValidated?.status === false) {
            return sendResponse(statusCode.BAD_REQUEST, false, isValidated?.message);
          }
          details.partnerId = currentPartnerInfo?._id;
          const timeResult = await timeExceed(orderId, currentPartnerInfo?._id, admin, session);

          if (!timeResult.status) {
            return sendResponse(statusCode.BAD_REQUEST, false, timeResult?.message);
          }
          if (timeResult.data?.customerDisallowEdits || timeResult.data?.disableShippingAddress) {
            return sendResponse(statusCode.BAD_REQUEST, false, ErrorMessage.ORDER_TIME_FRAME_EXCEEDED);
          }

          if (details?.selectedMethod !== null && details?.selectedMethod !== undefined) {
            const orderDetails = await orderAdminRevers(orderId, admin);

            const fetchData = await shippingService.fetchShippingAddressOld(orderId, admin,lang);

            const changeResponse = await shippingService.changeOrderShippingAddress(orderId, details, admin, session, extensionName, lang);

            if (!changeResponse?.status) {
              return sendResponse(statusCode.BAD_REQUEST, false, changeResponse?.message);
            }
            const response = await shippingService.updateShippingMethod(orderId, details, admin, session, orderDetails,lang);

            if (!response?.status) {
              if (fetchData?.status) {
                await shippingService.changeOrderShippingAddress(orderId, fetchData.data, admin, session, extensionName, lang);
              }
              return sendResponse(statusCode.BAD_REQUEST, false, response?.message);
            }
            return sendResponse(statusCode.OK, true, changeResponse?.message, changeResponse?.data);
          }
          const response = await shippingService.checkOrderShippingAddress(orderId, details, admin, session, extensionName,lang);
          if (!response?.status) {
            return sendResponse(statusCode.BAD_REQUEST, false, response?.message);
          } else if (response?.address === true) {
            const changeResponse = await shippingService.changeOrderShippingAddress(orderId, details, admin, session, extensionName, lang);

            if (!changeResponse?.status) {
              return sendResponse(statusCode.BAD_REQUEST, false, changeResponse?.message);
            }
            return sendResponse(statusCode.OK, true, changeResponse?.message, changeResponse?.data);
          } else {
            return sendResponse(statusCode.OK, true, response?.message, response?.data);
          }
        }

      case "address-predictions":
        {
          console.log(`::--- ${new URL(request.url).pathname}?shop=${session?.shop} ---::`);
          // parse request body
          const details = await request.json()
          const isValidated = await orderValidation.addressPredictionsValidation(details);
          if (isValidated?.status === false) {
            return sendResponse(statusCode.BAD_REQUEST, false, isValidated?.message);
          }
          const response = await infoUpdateService.addressPredictions(details);
          if (!response?.status) {
            return sendResponse(statusCode.BAD_REQUEST, false, response?.message);
          }
          return sendResponse(statusCode.OK, true, response?.message, response?.data);
        }
      case "address-details":
        {
          console.log(`::--- ${new URL(request.url).pathname}?shop=${session?.shop} ---::`);
          // parse request body
          const details = await request.json()
          const isValidated = await orderValidation.addressDetailsValidation(details);
          if (isValidated?.status === false) {
            return sendResponse(statusCode.BAD_REQUEST, false, isValidated?.message);
          }
          const response = await infoUpdateService.addressDetails(details);
          if (!response?.status) {
            return sendResponse(statusCode.BAD_REQUEST, false, response?.message);
          }
          return sendResponse(statusCode.OK, true, response?.message, response?.data);
        }
      case "update-metafield": {
        try {
          console.log(`::--- ${new URL(request.url).pathname}?shop=${session?.shop} ---::`);

          // Call service to generate pdf
          const result = await infoUpdateService.updateMetaField(session, admin);
          if (!result.status) {
            return sendResponse(statusCode.BAD_REQUEST, false, result?.message);
          }
          // Handle service response
          return sendResponse(statusCode.OK, result.status, result?.message, result.data);
        }
        catch (error) {
          console.error("Error in metafield update:", error);
          return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
        }
      }
      case "download-invoice": {
        try {
          console.log(`::--- ${new URL(request.url).pathname}?shop=${session?.shop} ---::`);
          const url = new URL(request.url);
          const orderId = url.searchParams.get("orderId");
          const partnerId = request.currentPartnerInfo?._id;
          // Call service to generate pdf
          const result = await invoiceService.generateInvoicePDF(admin, session, orderId, partnerId);
          if (!result.status) {
            return sendResponse(statusCode.BAD_REQUEST, false, result?.message);
          }
          // Handle service response
          return sendResponse(statusCode.OK, result.status, result?.message, result.data);
        }
        catch (error) {
          console.error("Error in download invoice:", error);
          return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
        }
      }

      case "validate-address": {
        console.log(`::--- ${new URL(request.url).pathname}?shop=${session?.shop} ---::`);
        // parse request body
        const details = await request.json()
        const orderId = new URL(request.url).searchParams.get("orderId");
        if (!orderId) {
          return sendResponse(statusCode.BAD_REQUEST, false, ErrorMessage.ID_NOT_FOUND);
        }
        // Validation
        // const isValidated = await orderValidation.shippingAddress(details);
        // if (isValidated?.status === false) {
        //   return sendResponse(statusCode.BAD_REQUEST, false, isValidated?.message);
        // }

        const timeResult = await timeExceed(orderId, currentPartnerInfo?._id, admin, session);
        if (!timeResult.status) {
          return sendResponse(statusCode.BAD_REQUEST, false, timeResult?.message);
        }
        if (timeResult.data?.customerDisallowEdits || timeResult.data?.disableShippingAddress) {
          return sendResponse(statusCode.BAD_REQUEST, false, ErrorMessage.ORDER_TIME_FRAME_EXCEEDED);
        }
        // Call service to change order shipping address
        const response = await infoUpdateService.validateAddress(details);
        if (!response?.status) {
          return sendResponse(statusCode.BAD_REQUEST, false, response?.message);
        }
        return sendResponse(statusCode.OK, true, response?.message, response?.data);
      }
      case "cancel-flow": {
        console.log(`::--- ${new URL(request.url).pathname}?shop=${session?.shop} ---::`);
        // parse request body
        const details = await request.json()
        const orderId = new URL(request.url).searchParams.get("orderId");
        const lang = new URL(request.url).searchParams.get("language")?.split("-")?.[0] || "en";

        if (!orderId) {
          return sendResponse(statusCode.BAD_REQUEST, false, ErrorMessage.ID_NOT_FOUND);
        }

        const timeResult = await timeExceed(orderId, currentPartnerInfo?._id, admin, session);
        if (!timeResult.status) {
          return sendResponse(statusCode.BAD_REQUEST, false, timeResult?.message);
        }
        if (timeResult.data?.customerDisallowEdits || timeResult.data?.disableShippingAddress) {
          return sendResponse(statusCode.BAD_REQUEST, false, ErrorMessage.ORDER_TIME_FRAME_EXCEEDED);
        }
        const response = await cancellationService.cancelFlow(details, orderId, admin, currentPartnerInfo?._id, lang);
        if (!response?.status) {
          return sendResponse(statusCode.BAD_REQUEST, false, response?.message);
        }
        return sendResponse(statusCode.OK, true, response?.message, response?.data);
      }

      default:
        return new Response(JSON.stringify({ error: ErrorMessage.INVALID_API_PATH }), {
          status: statusCode.NOT_FOUND,
        });
    }
  }
}
