import { sendResponse } from "../../server/utils/sendResponse";
import mongoose from "mongoose";
import dotenv from "dotenv";
import { ErrorMessage, SuccessMessage } from "../../server/constants/messages";
import { statusCode } from "../../server/constants/statusCodes";
dotenv.config();

export const action = async ({ request }) => {
  const database = mongoose.connection.useDb(process.env.DB_NAME);
  if (request.method === "POST") {
    try {
      console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
      let { page, limit, id, message } = await request.json();
      if (!id && !message) {
        page = parseInt(page) || 1;
        limit = parseInt(limit) || 8;
        const skip = (page - 1) * limit;
        const filter = { contactSupportId: { $exists: false } };
        const totalDocuments = await database
          .collection("customplansupports")
          .countDocuments(filter);
        const paginatedData = await database
          .collection("customplansupports")
          .find(filter)
          .skip(skip)
          .limit(limit)
          .toArray();
        if (totalDocuments === 0) {
          sendResponse(statusCode.NOT_FOUND, false, `Data ${ErrorMessage.NOT_FOUND}`);
        }
        return sendResponse(statusCode.OK, true, SuccessMessage.FETCHED, {data: paginatedData,
          currentPage: page,
          totalPages: Math.ceil(totalDocuments / limit),
          totalItems: totalDocuments,});
      } else {
        const objectId = new mongoose.Types.ObjectId(id);
        const getMessage = await database
          .collection("customplansupports")
          .findOne({ _id: objectId });
        const details = {
          contactSupportId: getMessage._id,
          email: getMessage.email,
          phone: getMessage.phone,
          storeUrl: getMessage.storeUrl,
          lastName: getMessage.lastName,
          firstName: getMessage.firstName,
          message: message,
        };
        const createdMessage = await database
          .collection("customplansupports")
          .insertOne(details);
          return sendResponse(statusCode.OK, true, SuccessMessage.CREATED, createdMessage);
      }
    } catch (error) {
      console.error("Error in getPagePreviewing:", error);
      return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
    }
  } else if (request.method === "DELETE") {
    try {
      console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
      const { id } = await request.json();
      const objectId = new mongoose.Types.ObjectId(id);
      const deletedMessage = await database
        .collection("customplansupports")
        .findOneAndDelete({ _id: objectId });
        return sendResponse(statusCode.OK, true, SuccessMessage.DELETED, deletedMessage);

    } catch (error) {
      console.error("Error in getPagePreviewing:", error);
      return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
    }
  } else {
    return sendResponse(statusCode.INVALID_REQUEST, false, ErrorMessage.INVALID_REQUEST);
  }
};
