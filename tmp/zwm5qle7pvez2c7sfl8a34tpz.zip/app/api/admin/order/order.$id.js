import mongoose from "mongoose";
import { ErrorMessage, SuccessMessage } from "../../server/constants/messages";
import { statusCode } from "../../server/constants/statusCodes";
import { sendResponse } from "../../server/utils/sendResponse";
import dotenv from "dotenv";
dotenv.config();

export const action = async ({ request, params }) => {
  if (request.method === "POST") {
    try {
      console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
      const path = params["*"];
      const id = path;
      const { orderAction, page, limit } = await request.json();
      const partnerId = new mongoose.Types.ObjectId(id);
      const database = mongoose.connection.useDb(process.env.DB_NAME);
      let filter = { partnerId };
      if (orderAction.length > 0) {
        filter.orderAction = { $in: orderAction };
      }
      const totalRecords = await database
        .collection("ordereditinghistories")
        .countDocuments(filter);
        const totalOrder = await database
        .collection("ordereditinghistories").distinct("orderId",{partnerId: filter.partnerId})
      const data = await database
        .collection("ordereditinghistories")
        .find(filter)
        .skip((page - 1) * limit)
        .limit(limit)
        .toArray();

      return sendResponse(statusCode.OK, true, SuccessMessage.FETCHED, {data,totalRecords,totalOrder:totalOrder.length,totalPages: Math.ceil(totalRecords / limit),currentPage: page} );
    } catch (error) {
      console.error("Error in fetching paginated data:", error);
      sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
    }
  }
};
