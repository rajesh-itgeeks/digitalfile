import { json } from '@remix-run/node';
import { authenticate } from "../../../shopify.server";
import { sendResponse } from "../../server/utils/sendResponse";
import dotenv from "dotenv"
import { ErrorMessage, SuccessMessage } from "../../server/constants/messages";
import { statusCode } from "../../server/constants/statusCodes";
dotenv.config();
 

export async function action({ request , params }) {
  console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
  try {
    const { admin } = await authenticate.admin(request);
  const path = params["*"];
  const partnerId = path;
  const body = await request.json();
  let { price, interval ,trialDays, returnUrl} = body;
  price = Number(price);
  trialDays = Number(trialDays);
  const allowedIntervals = ["ANNUAL", "EVERY_30_DAYS"];
  if (isNaN(price) || isNaN(trialDays)) {
    return json({ error: "Price and trialDays must be valid numbers" }, { status: 400 });
  }
  if (!allowedIntervals.includes(interval)) {
    return json({ error: "Interval must be 'ANNUAL' or 'EVERY_30_DAYS'" }, { status: 400 });
  }

  const response = await admin.graphql(
    `#graphql
    mutation AppSubscriptionCreate(
      $name: String!
      $lineItems: [AppSubscriptionLineItemInput!]!
      $returnUrl: URL!
      $trialDays: Int!
    ) {
      appSubscriptionCreate(name: $name, returnUrl: $returnUrl, lineItems: $lineItems, test: true ,trialDays:$trialDays,) {
        userErrors {
          field
          message
        }
        appSubscription {
          id
        }
        confirmationUrl
      }
    }`,
    {
      variables: {
        name: "customize",
        returnUrl: returnUrl,
        trialDays:trialDays,
        lineItems: [
          {
            plan: {
              appRecurringPricingDetails: {
                price: {
                  amount: price,
                  currencyCode: "USD"
                },
                interval: interval,
              }
            }
          }
        ]
      },
    }
  );
  
  const data = await response.json();
  if (data.data.appSubscriptionCreate.userErrors.length > 0) {
    return sendResponse(statusCode.INVALID_REQUEST, false, data.data.appSubscriptionCreate.userErrors);
  }

  return  sendResponse(statusCode.OK, true, SuccessMessage.FETCHED ,data.data.appSubscriptionCreate);
  } catch (error) {
    console.error("Error in getPagePreviewing:", error);
    return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
  }
}


