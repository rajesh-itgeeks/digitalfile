import { sendResponse } from "../../server/utils/sendResponse";
import mongoose from "mongoose";
import { ErrorMessage, SuccessMessage } from "../../server/constants/messages";
import { statusCode } from "../../server/constants/statusCodes";
import dotenv from "dotenv";
dotenv.config();
export const loader = async ({ request, params }) => {
  const path = params["*"];
  switch (path) {
    case "partners": {
      try {
        console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
        const database = mongoose.connection.useDb(process.env.DB_NAME);
        let pipeline = [
          {
            $group: {
              _id: "$planName",
              count: { $sum: 1 },
            },
          },
        ]
        const result = await database
          .collection("partners")
          .aggregate(pipeline)
          .toArray();

        let groupedData = Object.fromEntries(
          result.map(({ _id, count }) => [_id, count]),
        );
        groupedData.total = result.reduce((sum, { count }) => sum + count, 0);

        let activeStores = await database
          .collection("setupguides")
          .find({
            orderEditingFeature: true,
          })
          .toArray();

        const partnerIds = activeStores.map((store) =>
          store.partnerId.toString(),
        );
        let partners = await database
          .collection("partners")
          .find({
            _id: {
              $in: partnerIds.map((id) => new mongoose.Types.ObjectId(id)),
            },
          })
          .toArray();


        activeStores = partners.length;

        if (activeStores) {
          groupedData = { ...groupedData, activeStores: activeStores };
        } else {
          groupedData = { ...groupedData, activeStores: 0 };
        }
        return sendResponse(
          statusCode.OK,
          true,
          SuccessMessage.FETCHED,
          groupedData,
        );
      } catch (error) {
        console.error("Error in getPagePreviewing:", error);
        return sendResponse(
          statusCode.INTERNAL_SERVER_ERROR,
          false,
          ErrorMessage.INTERNAL_SERVER_ERROR,
        );
      }
    }
    default:
      return sendResponse(
        statusCode.INVALID_REQUEST,
        false,
        ErrorMessage.INVALID_REQUEST,
      );
  }
};

export const action = async ({ request, params }) => {
  const method = request.method;
  const path = params["*"];
  switch (path) {
    case "partnerlist": {
      if (method === "POST") {
        try {
          console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
          let { page, limit, type, query, shopType, download } = await request.json();
          download = !!download
          query = query || '';
          let baseFilter = {
            $or: [
              { myshopify_domain: { $regex: query, $options: "i" } },
              { "shopJson.name": { $regex: query, $options: "i" } },
              { "shopJson.domain": { $regex: query, $options: "i" } }
            ]
          };
         
          // ShopType condition tabhi add karo jab shopType mein values hon
          if (shopType.length > 0) {
            baseFilter["shopJson.plan_name"] = { $in: shopType };
          }
          shopType = shopType || []
          page = parseInt(page) || 1;
          limit = parseInt(limit) || 10;
          const skip = download ? 0 : (page - 1) * limit;

          const database = mongoose.connection.useDb(process.env.DB_NAME);
          const sessionData = await database
        .collection("shopify_sessions").find({}).toArray();
          // if (shopType.length == 0) {
          //   shopType = ["shopify", "advanced", "professional", "staff", "plus_sandbox", "trial", "paused", "frozen", "cancelled", "custom", "enterprise", "development", "essential", "partner_test", "staff", "affiliate", "basic", "professional", "npo_lite", "unlimited", "shopify_plus", "starter",];

          // }
          let totalDocuments;
          let partners;
          let activeStores;

          if (type === "all") {
            partners = await database
              .collection("partners")
              .aggregate([
                {
                  $match: baseFilter
                }
              ]).toArray();
            totalDocuments = partners.length;
          } else if (type === "active") {
            activeStores = await database
              .collection("setupguides")
              .find({ orderEditingFeature: true })
              .toArray();

            let partnerIds = [
              ...new Set(
                activeStores.map((store) => store.partnerId).filter((id) => id),
              ),
            ];

            if (partnerIds.length > 0) {
              const partnerData = await database
                .collection("partners")
                .find({ ...baseFilter,
                  _id: {
                    $in: partnerIds.map(
                      (id) => new mongoose.Types.ObjectId(id),
                    ),
                  },
                })
                .toArray();

              const partnerMap = {};
              partnerData.forEach((partner) => {
                partnerMap[partner._id.toString()] = partner;
              });

              let partnerIdss = [
                ...new Set(
                  partnerData.map((store) => store._id).filter((id) => id),
                ),
              ];

              const orderCounts = await database
                .collection("ordereditinghistories")
                .aggregate([
                  { $match: { partnerId: { $in: partnerIdss } } },
                  {
                    $group: {
                      _id: { partnerId: "$partnerId", orderId: "$orderId" },
                    },
                  },
                  { $group: { _id: "$_id.partnerId", count: { $sum: 1 } } },
                ])
                .toArray();

              const orderCountMap = {};
              orderCounts.forEach((order) => {
                orderCountMap[order._id.toString()] = order.count;
              });

              activeStores = activeStores
                .filter((store) => partnerMap[store.partnerId?.toString()])
                .map((store) => ({
                  ...store,
                  partner: partnerMap[store.partnerId.toString()] || null,
                  orderCount: orderCountMap[store.partnerId.toString()] || 0,
                }));
              totalDocuments = partnerIdss.length;
            }
          } else {
            partners = await database
              .collection("partners")
              .find({
                planName: type,
                ...baseFilter,
              })
              .toArray();
            totalDocuments = partners.length;
          }

          if (totalDocuments === 0) {
            return sendResponse(
              statusCode.NOT_FOUND,
              false,
              `Data ${ErrorMessage.NOT_FOUND}`,
            );
          }

          let paginatedData;
          if (partners) {
            const partnerIds = partners.map((partner) => partner._id);
            const orderCounts = await database
              .collection("ordereditinghistories")
              .aggregate([
                { $match: { partnerId: { $in: partnerIds } } },
                {
                  $group: {
                    _id: { partnerId: "$partnerId", orderId: "$orderId" },
                  },
                },
                { $group: { _id: "$_id.partnerId", count: { $sum: 1 } } },
              ])
              .toArray();

            const orderCountMap = {};
            orderCounts.forEach((order) => {
              orderCountMap[order._id.toString()] = order.count;
            });

            partners = partners.map((partner) => ({
              ...partner,
              orderCount: orderCountMap[partner._id.toString()] || 0,
            }));

            partners.sort((a, b) => b.orderCount - a.orderCount);
            paginatedData = download ? partners : partners.slice(skip, skip + limit);
          } else if (activeStores) {
            activeStores.sort((a, b) => b.orderCount - a.orderCount);
            paginatedData = download ? activeStores : activeStores.slice(skip, skip + limit);
          }

          return sendResponse(statusCode.OK, true, SuccessMessage.FETCHED, {
            data: paginatedData || [],
            currentPage: page,
            totalPages: Math.ceil(totalDocuments / limit),
            totalItems: totalDocuments,
          sessionData,

          });
        } catch (error) {
          console.error("Error in getPagePreviewing:", error);
          return sendResponse(
            statusCode.INTERNAL_SERVER_ERROR,
            false,
            ErrorMessage.INTERNAL_SERVER_ERROR,
          );
        }
      } else {
        return sendResponse(
          statusCode.INVALID_REQUEST,
          false,
          ErrorMessage.INVALID_REQUEST,
        );
      }
    }
    case "partners": {
      if (method === "POST") {
        try {
          console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
          const id = await request.json();
          const objectId = new mongoose.Types.ObjectId(id);
          const database = mongoose.connection.useDb(process.env.DB_NAME);
          const data = await database
            .collection("partners")
            .findOne({ _id: objectId });
            // const sessionData = await database
            // .collection("shopify_sessions").find({})
            // console.log("sessionData", sessionData)
          if (!data) {
            return sendResponse(
              statusCode.NOT_FOUND,
              false,
              `Data ${ErrorMessage.NOT_FOUND}`,
            );
          }
          return sendResponse(
            statusCode.OK,
            true,
            SuccessMessage.FETCHED,
            data,
          );
        } catch (error) {
          return sendResponse(
            statusCode.INVALID_REQUEST,
            false,
            ErrorMessage.INVALID_REQUEST,
          );
        }
      }
      if (method === "PUT") {
        try {
          console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
          const { id, hiddenFeatures } = await request.json();
          const objectId = new mongoose.Types.ObjectId(id);
          const database = mongoose.connection.useDb(process.env.DB_NAME);
          const allowedFeatures = [
            "upSell",
            "orderCancellationReason",
            "restocking",
          ];

          if (
            !Array.isArray(hiddenFeatures) ||
            hiddenFeatures.some((feature) => !allowedFeatures.includes(feature))
          ) {
            return sendResponse(
              statusCode.INTERNAL_SERVER_ERROR,
              false,
              ErrorMessage.INTERNAL_SERVER_ERROR,
            );
          }

          let data;
          if (hiddenFeatures.length === 0) {
            data = await database
              .collection("partners")
              .findOne({ _id: objectId });
          } else {
            data = await database
              .collection("partners")
              .findOneAndUpdate(
                { _id: objectId },
                { $set: { hiddenFeatures } },
                { returnDocument: "after" },
              );
          }

          if (!data) {
            sendResponse(
              statusCode.NOT_FOUND,
              false,
              `Data ${ErrorMessage.NOT_FOUND}`,
            );
          }
          return sendResponse(
            statusCode.OK,
            true,
            SuccessMessage.FETCHED,
            data,
          );
        } catch (error) {
          console.error("Error updating Partner", error);
          return sendResponse(
            statusCode.INTERNAL_SERVER_ERROR,
            false,
            ErrorMessage.INTERNAL_SERVER_ERROR,
          );
        }
      } else {
        return sendResponse(
          statusCode.INVALID_REQUEST,
          false,
          ErrorMessage.INVALID_REQUEST,
        );
      }
    }
    default:
      return sendResponse(
        statusCode.INVALID_REQUEST,
        false,
        ErrorMessage.INVALID_REQUEST,
      );
  }
};
