import { json } from "@remix-run/node";
import { ErrorMessage, SuccessMessage } from "../../server/constants/messages";
import { statusCode } from "../../server/constants/statusCodes";
import { sendResponse } from "../../server/utils/sendResponse";
import { Languages } from "../../server/models/languages.model";


export const loader = async ({ request, params }) => {
  const path = params["*"];
  switch (path) {
    case "details": {
      try {
        console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
        const url = new URL(request.url);
        const page = parseInt(url.searchParams.get("page") || "1", 10);
        const limit = parseInt(url.searchParams.get("limit") || "10", 10);

        const skip = (page - 1) * limit;

        const total = await Languages.countDocuments({ isDefault: true });

        const languages = await Languages.find({ isDefault: true })
          .skip(skip)
          .limit(limit)
        return sendResponse(
          statusCode.OK,
          true,
          SuccessMessage.FETCHED,
          { data: languages, page, pages: Math.ceil(total / limit), total }
        );

      } catch (error) {
        console.error("Error fetching language data:", error);
        return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
      }
    }


    case "detailsById": {
      try {
        console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
        const url = new URL(request.url);
        const page = parseInt(url.searchParams.get("page") || "1", 10);
        const limit = parseInt(url.searchParams.get("limit") || "10", 10);
        const skip = (page - 1) * limit;
        const id = url.searchParams.get("id");

        if (!id) {
          return sendResponse(statusCode.BAD_REQUEST, false, "ID is required");
        }

        const languageDocument = await Languages.findById(id);
        if (!languageDocument) {
          return sendResponse(statusCode.NOT_FOUND, false, "Language not found");
        }

        if (!languageDocument.langJson || typeof languageDocument.langJson !== 'object') {
          return sendResponse(statusCode.NOT_FOUND, false, "langJson field is empty or not found");
        }

        const langJsonEntries = Object.entries(languageDocument.langJson);

        const totalCount = langJsonEntries.length;
        const paginatedEntries = langJsonEntries.slice(skip, skip + limit);

        const totalPages = Math.ceil(totalCount / limit);

        return sendResponse(statusCode.OK, true, SuccessMessage.FETCHED, {
          data: paginatedEntries,
          pagination: {
            currentPage: page,
            totalPages,
            totalCount,
          },
        });

      } catch (error) {
        console.error("Error fetching language by ID:", error);
        return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
      }


    }


    default: {
      return sendResponse(statusCode.NOT_FOUND, false, "Invalid route");
    }
  }

};

export const action = async ({ request, params }) => {
  const method = request.method;
  const path = params["*"];
  switch (path) {
    case "addLanguage": {
      if (method === "POST") {
        try {
          console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
          const body = await request.json();
          const { isDefault, lang, langJson } = body;

          const newLanguage = await Languages.create({
            isDefault,
            lang,
            langJson,
          });


          return sendResponse(
            statusCode.CREATED,
            true,
            SuccessMessage.CREATED,
            { data: newLanguage }
          );

        } catch (error) {
          console.error("Error creating new language:", error);
          return sendResponse(
            statusCode.INTERNAL_SERVER_ERROR,
            false,
            ErrorMessage.INTERNAL_SERVER_ERROR
          );
        }
      }
    }
    case "deleteLanguageKeys": {
      if (method === "DELETE") {
        try {
          console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
          const body = await request.json();
          const keysToDelete = Object.keys(body);

          if (!keysToDelete || keysToDelete.length === 0) {
            return sendResponse(statusCode.BAD_REQUEST, false, "Request body must contain keys to delete.");
          }


          const updatePromises = keysToDelete.map(async (key) => {
            await Languages.updateMany(
              { "langJson": { $exists: true } },
              { $unset: { [`langJson.${key}`]: "" } }
            );
          });

          await Promise.all(updatePromises);

          return sendResponse(
            statusCode.OK,
            true,
          );
        } catch (error) {
          console.error("Error deleting keys from langJson:", error);
          return sendResponse(
            statusCode.INTERNAL_SERVER_ERROR,
            false,
            ErrorMessage.INTERNAL_SERVER_ERROR
          );
        }
      }
    }


    default:
      return sendResponse(
        statusCode.INVALID_REQUEST,
        false,
        ErrorMessage.INVALID_REQUEST,
      );
  }
};
