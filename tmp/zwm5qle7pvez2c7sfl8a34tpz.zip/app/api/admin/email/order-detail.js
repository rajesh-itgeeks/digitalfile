import { authenticate } from "../../../shopify.server";
import { sendResponse } from "../../server/utils/sendResponse";
import { ErrorMessage, SuccessMessage } from "../../server/constants/messages";
import { statusCode } from "../../server/constants/statusCodes";
import dotenv from "dotenv";
import { Liquid } from "liquidjs";
dotenv.config();
const engine = new Liquid();

const renderTemplate = async (template, data) => {
  return await engine.parseAndRender(template, data);
};
// Fetch random order ID using GraphQL
const getRandomOrderId = async (admin) => {
  let order = await admin.graphql(`
    query {
      orders(first: 1, reverse: true) {
        edges {
          node {
            id
          }
        }
      }
    }   
  `);
  order = await order.json();
  return order.data.orders.edges[0]?.node?.id;
};

// API Handler
export const action = async ({ request }) => {
  if (request.method == "POST") {
    try {
      console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
      const { template } = await request.json();
      const { admin, session } = await authenticate.admin(request);

      // Get random order ID and fetch order details
      let orderId = await getRandomOrderId(admin);
      if (!orderId) {
        return sendResponse(
          statusCode.NOT_FOUND,
          false,
          ErrorMessage.NOT_FOUND,
        );
      }
      orderId = orderId.split("/").pop();
      const orderDetails = await admin.rest.resources.Order.find({
        session,
        id: orderId,
      });
      const data = { order: orderDetails };
      const html = await renderTemplate(template, data.order);
      return sendResponse(statusCode.OK, true, SuccessMessage.FETCHED, html);
    } catch (error) {
      console.error("Error in GET API:", error);
      return sendResponse(
        statusCode.INTERNAL_SERVER_ERROR,
        false,
        ErrorMessage.INTERNAL_SERVER_ERROR,
      );
    }
  }
};
