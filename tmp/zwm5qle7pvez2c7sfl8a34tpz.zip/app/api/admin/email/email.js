import { sendResponse } from "../../server/utils/sendResponse";
import mongoose from "mongoose";
import { ErrorMessage, SuccessMessage } from "../../server/constants/messages";
import { statusCode } from "../../server/constants/statusCodes";
import dotenv from "dotenv";
dotenv.config();

export const action = async ({ request }) => {
  if (request.method == "POST") {
    try {
      console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
      const { type } = await request.json();
      const database = mongoose.connection.useDb(process.env.DB_NAME);
      const result = await database.collection("defaultnotifications").findOne({ type })
      return sendResponse(statusCode.OK, true, SuccessMessage.FETCHED, result);
    } catch (error) {
      console.error("Error in get emailtemplate:", error);
      return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
    }
  }
  if (request.method == "PUT") {
    try {
      console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
      const { id, subject, emailTemplate } = await request.json();
      const database = mongoose.connection.useDb(process.env.DB_NAME);
      const result = await database.collection("defaultnotifications").findOneAndUpdate({ _id: new mongoose.Types.ObjectId(id) }, { $set: { emailTemplate, subject } }, { returnOriginal: false })
      return sendResponse(statusCode.OK, true, SuccessMessage.FETCHED, result);
    } catch (error) {
      console.error("Error in update emailtemplate:", error);
      return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);
    }
  } else {
    return sendResponse(statusCode.INVALID_REQUEST, false, ErrorMessage.INVALID_REQUEST);
  }

};
