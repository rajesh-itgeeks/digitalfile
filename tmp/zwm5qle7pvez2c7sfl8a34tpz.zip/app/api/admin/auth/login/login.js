import dotenv from "dotenv"
import { ErrorMessage, SuccessMessage } from "../../../server/constants/messages";
import { statusCode } from "../../../server/constants/statusCodes";

import { sendResponse } from "../../../server/utils/sendResponse";
dotenv.config();
export const action = async ({ request }) => {
    if (request.method === 'POST') {
        try{
            console.log(`::--- ${new URL(request.url).pathname}?shop=${request?.session?.shop} ---::`);
            const {email,password} = await request.json();
            if (email == process.env.LOGIN_EMAIL && password == process.env.LOGIN_PASSWORD) {
                return sendResponse(statusCode.OK, true, SuccessMessage.LOGIN);
            } else {
                return sendResponse(statusCode.UNAUTHORIZED, false, ErrorMessage.UNAUTHORIZED);
            }
        } catch (error) {
            return sendResponse(statusCode.INTERNAL_SERVER_ERROR, false, ErrorMessage.INTERNAL_SERVER_ERROR);

        }
    } else {
        return sendResponse(statusCode.INVALID_REQUEST, false, ErrorMessage.INVALID_REQUEST);
    }
}


